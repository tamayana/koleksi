const fs = require('fs');
const packageJson = JSON.parse(fs.readFileSync('./package.json', 'utf8'));

global.owner = ['62895417774124'] // owner number
global.connect = true // Ubah ke false jika ingin mengkoneksikan bot menggunakan QrCode
global.url = "https://t.me/kayyz123"
global.url2 = "https://t.me/kayyz123"
global.packname = "X-hanter Invituz"
global.author = "Kanzyx srq"
global.versi = packageJson.version