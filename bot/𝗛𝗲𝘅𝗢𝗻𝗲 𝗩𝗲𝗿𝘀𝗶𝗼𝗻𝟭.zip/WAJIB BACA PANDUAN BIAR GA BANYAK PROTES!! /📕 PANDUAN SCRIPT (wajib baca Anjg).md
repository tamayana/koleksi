# ⚡ HEXONE
> Script yang dikembangkan oleh **ArgaXwyz/offc** & **LynzOffc**

## 📢 OFFICIAL CHANNEL

**WhatsApp**
- 👤 Arga : https://whatsapp.com/channel/0029Vay4hgh2Jl8J4yIOIA3i
- 👤 Lynz : https://whatsapp.com/channel/0029Vb8bbPaHQbSDS5LK4Q0x

**Telegram**
- 👤 Arga : `t.me/argaxwyz76`
- 👤 Lynz : `t.me/lynzzofficial`

--------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------
# 📖 PANDUAN PENGGUNAAN

## 🔗 01. PAIRING NOMOR

Sebelum menggunakan fitur yang membutuhkan **sender**, nomor yang ingin digunakan harus ditambahkan terlebih dahulu ke sistem pairing.

### 📱 WhatsApp

**.addpair 62xxxxxxxxxx**

#✈️ Telegram
**/addpair 62xxxxxxxxxx**

** 💡 Catatan: Gunakan format nomor internasional. Contoh: 62xxxxxxxxxx**

#📋 02. CEK PAIR LIST

#Setelah melakukan pairing, cek apakah nomor sudah berhasil ditambahkan ke dalam Pair List.

📱 WhatsApp
.pairlist

**✈️ Telegram**
#/pairlist

**Jika nomor sudah muncul di Pair List, berarti nomor tersebut sudah berhasil ditambahkan.**

> ✅ Pastikan nomor yang ingin digunakan memang sudah terdaftar sebelum melanjutkan.

--------------------------------------------------------------------------------------------------------------
##🎯 03. USE PAIR

**Setelah nomor berhasil masuk ke Pair List, nomor tersebut dapat dipilih sebagai sender menggunakan fitur usepair.**

**📱 WhatsApp**

**.usepair** <nomor>
#Contoh:

# .usepair 62xxxxxxxxxx

**✈️ Telegram**

# /usepair <nomor>
# Contoh:

# /usepair 62xxxxxxxxxx

**⚡ Alur **

# .addpair 62xxxxxxxxxx
        ↓
    .pairlist
        ↓
# .usepair 62xxxxxxxxxx

> 💡 Untuk Telegram, gunakan prefix / sesuai command yang tersedia.

--------------------------------------------------------------------------------------------------------------
#⏳ TRIAL / MASA AKTIF

#Hexone memiliki batas pemakaian / masa trial yang telah ditentukan.

>Jika batas pemakaian telah habis, user tidak dapat melanjutkan penggunaan seperti biasa dan perlu menggunakan versi VIP sesuai ketentuan yang berlaku.

**Kalian Bisa Membeli Versi Vip Ke bot Tele dibawah**

**BOT** : t.me/HexOne_Bot

----------------------------------------------------------------------------------------------------------------

##🐞 REPORT & FEEDBACK

**Menemukan bug atau error? Punya kritik, saran, atau request fitur?**

**[Hubungi developer melalui:]** 

**👤 Arga **
t.me/argaxwyz76
**👤 Lynz**
t.me/lynzzofficial

📩 Bisa digunakan untuk:
🐞 Report bug / issue
💡 Kritik & saran
🛠️ Request fitur
❓ Pertanyaan mengenai script


# ⚠️ DISCLAIMER

> Saya berharap seluruh user menggunakan script ini secara tepat dan bertanggung jawab.


# Script ini ditujukan untuk penggunaan terhadap pihak yang memang melakukan pelanggaran atau tindakan yang merugikan, seperti:

>🚫 Cyberbullying
 🚫 Penipuan
 🚫 Tindakan yang merugikan user lain
 🚫 Penyalahgunaan layanan


> ⚠️ Pastikan terlebih dahulu bahwa pihak yang ditindak memang melakukan pelanggaran dan bukan orang yang tidak bersalah.

#Pengembang script tidak bertanggung jawab apabila terjadi kesalahan penggunaan atau terdapat korban yang tidak bersalah. Seluruh konsekuensi dan tanggung jawab atas penggunaan script sepenuhnya ditanggung oleh user.

##📌 QUICK COMMAND

>Fungsi	WhatsApp	Telegram
🔗 Pair nomor	.addpair <nomor>	/addpair <nomor>
📋 Cek pair	.pairlist	/pairlist
🎯 Use pair	.usepair <nomor>	/usepair <nomor>


--------------------------------------------------------------------------------------------------------------


## ❤️ CREDITS

# ⚡ HEXONE

**Collaboration:**  
`HADEXV × SOMEONE`

---

## 👤 DEVELOPER 01

**Name:** Lynzz Official  
**Brand:** SOMEONE  
**Role:** Core Developer & System Architect

### 🎯 Focus
- **Core Architecture**
- **WhatsApp + Telegram Systems**
- **Runtime & Integration**
- **Database Management**
- **Database Troubleshooting**
- **Data Storage & Optimization**

### 📞 Contact Lynzz
**WhatsApp:** `6285707390310`  
**Link:** https://wa.me/6285707390310  
**Telegram:** `t.me/lynzzofficial`

---

## 👤 DEVELOPER 02

**Name:** Arga  
**Brand:** HadeXv  
**Role:** Feature Developer & UI Engineer

### 🎯 Focus
- **Feature Engineering**
- **Menu & UI Experience**
- **Source Protection**
- **Bug Function Development**
- **Testing & Debugging**

### 📞 Contact Arga
**WhatsApp:** `6282337891154`  
**Link:** https://wa.me/6282337891154  
**Telegram:** `t.me/argaxwyz76`

---

> **Thank you for using this script.** ❤️

**⚡ HEXONE — HADEXV × SOMEONE**