/// ─────────── [ 𝖪𝗈𝗇𝖿𝗂𝗀𝗎𝗋𝖺𝗌𝗂 𝖴𝗍𝖺𝗆𝖺 𝖡𝗈𝗍 ] ────────── ///
const config = {
  botName: '𝖸𝗈𝗋𝗎𝗆𝗂𝖬𝖣',
  ownerName: 'FyzzModss',
  creator: ['6281313532320'], // Isi nomor tanpa tanda + dan spasi, contoh: 6281234567890
  prefix: ['.', '#', '!', '/'],

  /// ───────── [ saluran ] ───────── ///
  saluranName: '𝖡𝗈𝗍𝗌 - 𝖨𝗇𝖿𝗈𝗋𝗆𝖺𝗍𝗂𝗈𝗇', 
  saluranId: '120363428260954472@newsletter',
  saluranUrl: 'https://whatsapp.com/channel/0029Vb89lmKI1rcaBBwxOS37', 
  
  /// ───────── [ Link Url ] ───────── ///
  groupUrl: 'https://chat.whatsapp.com/HtjtoqvjAALIQGKMupdN8K', 
  telegramUrl: 'https://t.me/FyzzModss', 
  whatsappUrl: 'https://wa.me/6281313532320',
  
  /// ───────── [ 𝖯𝖺𝗒𝗆𝖾𝗇𝗍 ] ───────── ///
  dana: '085609092154', 
  gopay: 'Tidak Tersedia',
  ovo: 'Tidak Tersedia', 
  
  /// ───────── [ bot Settings ] ───────── ///
  botMode: 'public', // public = semua user bisa pakai, self = hanya owner
  privateOnlyPremium: false, // false = chat pribadi ikut mode bot (public = semua bisa), true = chat pribadi hanya premium/owner
  swgcDelay: 2500, // jeda antar grup saat swgcall (ms)

  /// ───────── [ 𝖯𝗍𝖾𝗋𝗈𝖽𝖺𝖼𝗍𝗒𝗅 ] ───────── ///
  panel: {
    domain: 'https://domain.com', // Domain: https://panel.domainkamu.com
    apikey: 'plta_xxxx', // API Key Application
    capikey: '',
    nestid: '5', // ID Nest
    egg: '15', // ID Egg
    loc: '1', // ID Location
  },

  accessDenied: {
    owner: 'Fitur ini khusus Owner.',
    creator: 'Fitur ini khusus Creator.',
    premium: 'Fitur ini khusus Premium.',
    privatePremium: 'Chat pribadi dengan bot khusus Premium. Silakan pakai bot di grup.',
    group: 'Fitur ini hanya bisa dipakai di dalam Grup.',
    admin: 'Fitur ini khusus Admin Grup.',
    botAdmin: 'Jadikan bot sebagai Admin Grup dulu.',
  },
};

export default config;
