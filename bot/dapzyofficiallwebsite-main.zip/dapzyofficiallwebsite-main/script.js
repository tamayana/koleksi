/*
 * DAPZY OFFICIAL — konfigurasi mudah.
 * WA_ADMIN wajib diganti dengan nomor WhatsApp admin format internasional:
 * contoh Indonesia: 6281234567890 (tanpa tanda +, spasi, atau angka 0 di depan).
 * Website statis ini memakai konfirmasi pesanan manual; belum memverifikasi pembayaran otomatis.
 */
const CONFIG = {
  WA_ADMIN: "62881038298178",
  TELEGRAM_URL: "https://t.me/Dapzygens",
  DANA_NAME: "An daffa",
  DANA_NUMBER: "0881037758526",
  CHANNEL_URL: "https://whatsapp.com/channel/0029VbC326uGU3BCA5oFjt0J"
};

const toast = document.getElementById("toast");
let toastTimer;
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}
function normalizedWhatsApp() {
  return String(CONFIG.WA_ADMIN || "").replace(/\D/g, "");
}
function openWhatsApp(message) {
  const number = normalizedWhatsApp();
  if (!number || number.includes("GANTI") || number.length < 10) {
    showToast("Admin WhatsApp belum diatur. Buka script.js dan isi WA_ADMIN.");
    return;
  }
  const url = "https://wa.me/" + number + "?text=" + encodeURIComponent(message);
  window.open(url, "_blank", "noopener,noreferrer");
}
function rupiah(value) {
  return new Intl.NumberFormat("id-ID", {style:"currency",currency:"IDR",maximumFractionDigits:0}).format(Number(value));
}
document.querySelectorAll("[data-buy]").forEach(button => {
  button.addEventListener("click", () => {
    const card = button.closest("[data-product]");
    if (!card) return;
    const product = card.dataset.product;
    const price = Number(card.dataset.price);
    const message = [
      "Halo Admin DAPZY OFFICIAL 👋",
      "",
      "Saya ingin memesan produk:",
      "📦 Produk: " + product,
      "💰 Harga tertera: " + rupiah(price),
      "",
      "Mohon konfirmasi ketersediaan, total pembayaran, dan instruksi pembayaran QRIS/DANA.",
      "Saya memahami pesanan dan pembayaran dikonfirmasi manual oleh admin."
    ].join("\n");
    openWhatsApp(message);
  });
});
document.querySelectorAll("[data-contact]").forEach(button => {
  button.addEventListener("click", () => openWhatsApp("Halo Admin DAPZY OFFICIAL 👋\nSaya ingin bertanya tentang produk dan layanan."));
});
document.querySelectorAll("[data-copy]").forEach(button => {
  button.addEventListener("click", async () => {
    const target = document.getElementById(button.dataset.copy);
    const value = target ? target.textContent.trim() : "";
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(value);
      } else {
        const area = document.createElement("textarea");
        area.value = value; area.style.position = "fixed"; area.style.opacity = "0";
        document.body.appendChild(area); area.select();
        const ok = document.execCommand("copy"); area.remove();
        if (!ok) throw new Error("copy failed");
      }
      showToast("Berhasil disalin: " + value);
    } catch (error) {
      showToast("Salin manual: " + value);
    }
  });
});
const modal = document.getElementById("qrisModal");
document.getElementById("viewQris").addEventListener("click", () => {
  modal.classList.add("open"); modal.setAttribute("aria-hidden", "false");
});
document.querySelectorAll("[data-close-modal]").forEach(el => el.addEventListener("click", () => {
  modal.classList.remove("open"); modal.setAttribute("aria-hidden", "true");
}));
document.addEventListener("keydown", event => {
  if (event.key === "Escape") { modal.classList.remove("open"); modal.setAttribute("aria-hidden", "true"); }
});
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
menuToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
});
navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open"); menuToggle.setAttribute("aria-expanded", "false");
}));
document.getElementById("year").textContent = new Date().getFullYear();

// Drag/touch rotation for the 3D photo cube.
(() => {
  const scene = document.getElementById('cubeScene');
  const cube = scene && scene.querySelector('.cube');
  if (!scene || !cube) return;
  let rx = -24, ry = 35, dragging = false, lastX = 0, lastY = 0;
  const paint = () => { cube.style.transform = `rotateX(${rx}deg) rotateY(${ry}deg)`; };
  scene.addEventListener('pointerdown', e => { dragging = true; lastX = e.clientX; lastY = e.clientY; scene.setPointerCapture(e.pointerId); });
  scene.addEventListener('pointermove', e => { if (!dragging) return; ry += (e.clientX-lastX)*.7; rx -= (e.clientY-lastY)*.55; rx = Math.max(-75, Math.min(75, rx)); lastX=e.clientX; lastY=e.clientY; paint(); });
  const stop = () => { dragging = false; };
  scene.addEventListener('pointerup', stop); scene.addEventListener('pointercancel', stop); paint();
})();

// FUN ZONE: klaim hanya dibuka setelah jawaban benar untuk soal aktif.
(() => {
  const questions = [
    {q:'Bahasa pemrograman yang sering digunakan untuk membuat interaksi website adalah?', a:['javascript','js']},
    {q:'Apa nama tempat untuk menyimpan dan mengelola kode proyek secara online yang digunakan Dapzy?', a:['github','git hub']},
    {q:'Berapa hasil dari 7 × 8?', a:['56']},
    {q:'Apa kepanjangan dari HTML?', a:['hypertext markup language']},
    {q:'Planet apa yang dikenal sebagai Planet Merah?', a:['mars']}
  ];
  const question=document.getElementById('gameQuestion'), answer=document.getElementById('gameAnswer'), check=document.getElementById('checkAnswer'), next=document.getElementById('nextQuestion'), feedback=document.getElementById('gameFeedback'), scoreEl=document.getElementById('gameScore'), claim=document.getElementById('claimPrize');
  if(!question || !answer || !check || !next || !feedback || !claim) return;
  let current=-1, score=0, solved=false;
  const lockClaim=()=>{ claim.hidden=true; claim.removeAttribute('href'); claim.setAttribute('aria-disabled','true'); };
  function newQuestion(){
    let n; do{n=Math.floor(Math.random()*questions.length)}while(n===current && questions.length>1);
    current=n; solved=false; question.textContent=questions[n].q; answer.value=''; answer.disabled=false; check.disabled=false;
    feedback.textContent='Jawab dengan tepat untuk membuka tombol klaim hadiah.'; feedback.className='game-feedback'; lockClaim();
  }
  check.addEventListener('click',()=>{
    if(solved) return;
    const value=answer.value.trim().toLocaleLowerCase('id-ID').replace(/[.!?]/g,'').replace(/\\s+/g,' ');
    if(!value){feedback.textContent='Isi jawaban terlebih dahulu.';feedback.className='game-feedback error';lockClaim();return;}
    if(questions[current].a.includes(value)){
      solved=true;score++;scoreEl.textContent='Skor: '+score;
      feedback.textContent='Benar! Tombol klaim hadiah sudah terbuka. Hubungi owner untuk konfirmasi.';feedback.className='game-feedback success';
      answer.disabled=true;check.disabled=true;
      const msg='Halo Owner DAPZY OFFICIAL! Saya berhasil menjawab soal FUN ZONE dengan benar dan ingin mengklaim hadiah. Skor saya: '+score+'.';
      claim.href='https://wa.me/'+normalizedWhatsApp()+'?text='+encodeURIComponent(msg);
      claim.hidden=false;claim.removeAttribute('aria-disabled');
    } else {
      feedback.textContent='Jawaban belum tepat. Tombol klaim tetap terkunci.';feedback.className='game-feedback error';lockClaim();
    }
  });
  answer.addEventListener('input',()=>{if(!solved) lockClaim();});
  answer.addEventListener('keydown',e=>{if(e.key==='Enter')check.click();});
  next.addEventListener('click',newQuestion);
  claim.addEventListener('click',e=>{if(!solved || claim.hidden || !claim.href || claim.href==='#'){e.preventDefault();lockClaim();}});
  newQuestion();
})();

// Download each sticker as a standalone SVG file.
document.querySelectorAll('[data-download-sticker]').forEach(button=>{
  button.addEventListener('click',()=>{
    const art=document.getElementById(button.dataset.downloadSticker);
    const svg=art && art.querySelector('svg');
    if(!svg) return;
    const copy=svg.cloneNode(true);
    copy.setAttribute('xmlns','http://www.w3.org/2000/svg');
    const blob=new Blob([new XMLSerializer().serializeToString(copy)],{type:'image/svg+xml;charset=utf-8'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=button.dataset.downloadSticker+'.svg';
    document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
    showToast('Stiker berhasil diunduh.');
  });
});
