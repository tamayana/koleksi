/*

  !- Credits By RYZZISHERE
  https://wa.me/6281322299494
  
*/

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

//~~~~~~~~~~~ Settings Bot ~~~~~~~~~~~//
global.owner = '6281322299494'
global.versi = '1.0'
global.namaOwner = '⏤͟͟͞͞𝗥𝘆𝘇𝘇𝗜𝘀𝗛𝗲𝗿𝗲'
global.packname = '⏤͟͟͞͞𝗥𝘆𝘇𝘇𝗜𝘀𝗛𝗲𝗿𝗲'
global.botname = '⏤͟͟͞͞𝗘𝘃𝗼𝘂𝗿𝘁𝗵 𝗖𝗽𝗮𝗻𝗲𝗹'
global.botname2 = '⏤͟͟͞͞𝗘𝘃𝗼𝘂𝗿𝘁𝗵 𝗖𝗽𝗮𝗻𝗲𝗹'

//~~~~~~~~~~~ Settings Link ~~~~~~~~~~//
global.linkOwner = "https://wa.me/6281322299494"
global.linkGrup = "https://whatsapp.com/channel/0029VavzrXEGZNCljESQln2f"

//~~~~~~~~~~~ Settings Jeda ~~~~~~~~~~//
global.delayJpm = 3500
global.delayPushkontak = 6000

//~~~~~~~~~~ Settings Saluran ~~~~~~~~~//
global.linkSaluran = "https://whatsapp.com/channel/0029VavzrXEGZNCljESQln2f"
global.idSaluran = "120363364576983263@newsletter"
global.namaSaluran = "</> 𝗥𝘆𝘇𝘇𝗜𝘀𝗛𝗲𝗿𝗲"

//~~~~~~~~~ Settings Orderkuota ~~~~~~~~//
global.merchantIdOrderKuota = ""
global.apiOrderKuota = ""
global.qrisOrderKuota = ""

//~~~~~~~~~~ Settings Apikey ~~~~~~~~~~//
global.apiDigitalOcean = "-"
global.apiSimpleBot = "simplebotz85"

//~~~~~~~~~ Settings Payment ~~~~~~~~~//
global.dana = "089671524705"
global.ovo = "089671524705"
global.gopay = "085721177299"

//~~~~~~~~~~ Settings Image ~~~~~~~~~~//
global.image = {
menu: "https://files.catbox.moe/hh7u2m.jpg", 
reply: "https://files.catbox.moe/hh7u2m.jpg", 
logo: "https://files.catbox.moe/hh7u2m.jpg",
qris: "https://files.catbox.moe/hh7u2m.jpg"
}

//~~~~~~~~~ Settings Api Panel ~~~~~~~~//
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://zyroohostnorusuh.ikyyservetbotwa.biz.id"
global.apikey = "ptla_qi6yjz39GmFcZZfcCNa6sKp62BvdfOgDvdHhcIrQjhK" //ptla
global.capikey = "ptlc_62HfJcAJizq6OPvbkQGjwghvtIflBLXYlBdY3lGr1dh" //ptlc

//~~~~~~~~ Settings Api Panel 2 ~~~~~~~~//
global.eggV2 = "15" // Egg ID
global.nestidV2 = "5" // nest ID
global.locV2 = "1" // Location ID
global.domainV2 = "https://zyroohostnorusuh.ikyyservetbotwa.biz.id"
global.apikeyV2 = "ptla_qi6yjz39GmFcZZfcCNa6sKp62BvdfOgDvdHhcIrQjhK" //ptla
global.capikeyV2 = "ptlc_62HfJcAJizq6OPvbkQGjwghvtIflBLXYlBdY3lGr1dh" //ptlc

//~~~~~~~ Settings Api Subdomain ~~~~~~~//
global.subdomain = {
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "oof_QRNdUC4aMQ3xIB8dmkGaZu7rk2J-0P_tN55l"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "CrQMyDn2fhchlGne2ogAw7PvJLsg4x8vasBv__6D"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "cj17Lzg9otqwkYIVzgL0pcVA4GfcXqePHAOhCqa_"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "N_VhWv2ZK6UJxLdCnxMfZx9PtzAdmPGM3HmOjZR4"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "qRxwgS3Kl_ziCXti2p4BHbWTvGUYzAuYmVM28ZEp"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "sH60tbg10UH8gpNrlYpf3UMse1CNJ01EKJ69YVqb"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "GRe4rg-vhb4c8iSjKCALHJC0LaxkzNPgmmgcDGpm"
}
}

//~~~~~~~~~~ Settings Message ~~~~~~~~//
global.mess = {
	owner: "*[ 𝐀𝐊𝐄𝐒 𝐆𝐀𝐆𝐀𝐋❗]*\nғɪᴛᴜʀ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪ ɢᴜɴᴀᴋᴀɴ ᴏʟᴇʜ ʙᴀɴɢ ᴀʟ! ",
	admin: "*[ 𝐀𝐊𝐒𝐄𝐒 𝐆𝐀𝐆𝐀𝐋 ❗ ]*\nғɪᴛᴜʀ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪ ɢᴜɴᴀᴋᴀɴ ᴀᴅᴍɪɴ ɢʙ",
	botAdmin: "*[ 𝐀𝐊𝐒𝐄𝐒 𝐆𝐀𝐆𝐀𝐋 ❗ ]*\nғɪᴛᴜʀ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪ ɢᴜɴᴀᴋᴀɴ ᴋᴇᴛɪᴋᴀ ʙᴏᴛ ᴊᴀᴅɪ ᴀᴅᴍɪɴ ʏᴀ ʟᴇ",
	group: "*[ 𝐀𝐊𝐒𝐄𝐒 𝐆𝐀𝐆𝐀𝐋 ❗ ]*\nғɪᴛᴜʀ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɴɢᴜɴᴀᴋᴀɴ ᴅɪᴅᴀʟᴀᴍ ɢʀᴜʙ ʙʀᴏ ᴋᴜ!!",
	private: "*[ 𝐀𝐊𝐒𝐄𝐒 𝐆𝐀𝐆𝐀𝐋 ❗ ]*\nғɪᴛᴜʀ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪɢᴜɴᴀᴋᴀɴ ᴅɪ ᴘʀɪᴠᴀᴛᴇ ᴄʜᴀᴛ ʙʀᴏ ᴋᴜ! ",
	prem: "*[ 𝐀𝐊𝐒𝐄𝐒 𝐆𝐀𝐆𝐀𝐋 ❗ ]*\nғɪᴛᴜʀ ɪɴɪ ʜᴀɴʏᴀ ʙɪsᴀ ᴅɪ ɢᴜɴᴀᴋᴀɴ ᴏʟᴇʜ ᴘʀᴇᴍɪᴜᴍ!",
	wait: '𝙒𝙀𝙏 𝘼𝘽𝘼𝙉𝙂𝙆𝙐𝙃',
	error: '𝙂𝘼𝙂𝘼𝙇 ❗',
	done: '𝘿𝙊𝙉𝙀 𝘽𝘼𝙉𝙂 ✅'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})